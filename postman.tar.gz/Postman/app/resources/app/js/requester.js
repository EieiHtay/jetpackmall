/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		0: 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// script path function
/******/ 	function jsonpScriptSrc(chunkId) {
/******/ 		return __webpack_require__.p + "" + ({"9":"CommonLazyChunk","10":"RequesterInit","11":"postman-converters","12":"monaco-editor","13":"postman-runtime","14":"RequesterModalContainer","15":"RequesterBuilderContainer","16":"WorkspaceBrowser","17":"CollectionBrowserContainer","18":"StatusBarContainer","19":"jsonMode","20":"html","21":"htmlMode","22":"xml","23":"javascript","24":"tsMode","25":"markdown","26":"yaml","27":"graphql","28":"csharp","29":"cpp","30":"fsharp","31":"powershell","32":"go","33":"java","34":"objective-c","35":"php","36":"python","37":"ruby","38":"swift","39":"postman-code-generators"}[chunkId]||chunkId) + ".js"
/******/ 	}
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// JSONP chunk loading for javascript
/******/
/******/ 		var installedChunkData = installedChunks[chunkId];
/******/ 		if(installedChunkData !== 0) { // 0 means "already installed".
/******/
/******/ 			// a Promise means "currently loading".
/******/ 			if(installedChunkData) {
/******/ 				promises.push(installedChunkData[2]);
/******/ 			} else {
/******/ 				// setup Promise in chunk cache
/******/ 				var promise = new Promise(function(resolve, reject) {
/******/ 					installedChunkData = installedChunks[chunkId] = [resolve, reject];
/******/ 				});
/******/ 				promises.push(installedChunkData[2] = promise);
/******/
/******/ 				// start chunk loading
/******/ 				var script = document.createElement('script');
/******/ 				var onScriptComplete;
/******/
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.src = jsonpScriptSrc(chunkId);
/******/
/******/ 				// create error before stack unwound to get useful stacktrace later
/******/ 				var error = new Error();
/******/ 				onScriptComplete = function (event) {
/******/ 					// avoid mem leaks in IE.
/******/ 					script.onerror = script.onload = null;
/******/ 					clearTimeout(timeout);
/******/ 					var chunk = installedChunks[chunkId];
/******/ 					if(chunk !== 0) {
/******/ 						if(chunk) {
/******/ 							var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 							var realSrc = event && event.target && event.target.src;
/******/ 							error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 							error.name = 'ChunkLoadError';
/******/ 							error.type = errorType;
/******/ 							error.request = realSrc;
/******/ 							chunk[1](error);
/******/ 						}
/******/ 						installedChunks[chunkId] = undefined;
/******/ 					}
/******/ 				};
/******/ 				var timeout = setTimeout(function(){
/******/ 					onScriptComplete({ type: 'timeout', target: script });
/******/ 				}, 120000);
/******/ 				script.onerror = script.onload = onScriptComplete;
/******/ 				document.head.appendChild(script);
/******/ 			}
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "../js/";
/******/
/******/ 	// on error function for async loading
/******/ 	__webpack_require__.oe = function(err) { console.error(err); throw err; };
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push([0,5,8]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(1);


/***/ }),

/***/ 1:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _styles_requester_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4415);
/* harmony import */ var _styles_requester_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_requester_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4416);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_TelemetryHelpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4417);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2083);
/* harmony import */ var _shared_ThemeContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4418);










const Requester = react_loadable__WEBPACK_IMPORTED_MODULE_4___default()({
  loader: () => Promise.all(/* import() | RequesterInit */[__webpack_require__.e(9), __webpack_require__.e(10)]).then(__webpack_require__.bind(null, 4796)),
  loading: () => react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null) });


if (false) {} else {
  window.onbeforeunload = () => {
    return false;
  };
}

const rootEl = document.getElementsByClassName('app-root')[0];

_init__WEBPACK_IMPORTED_MODULE_2__["default"].init(err => {
  if (err) {
    Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["render"])(react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_7__["default"], { showError: true }), rootEl);
    return;
  }
  Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["render"])(
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_7__["default"], null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_shared_ThemeContext__WEBPACK_IMPORTED_MODULE_8__["Theme"], null,
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Requester, null))),


  rootEl,
  () => {
    let loadTime = Object(_utils_TelemetryHelpers__WEBPACK_IMPORTED_MODULE_5__["getWindowLoadTime"])();
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app_performance_metric', 'requester_window_loaded', null, null, { load_time: loadTime });
  });

});

/***/ }),

/***/ 144:
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),

/***/ 145:
/***/ (function(module, exports) {

module.exports = require("zlib");

/***/ }),

/***/ 2975:
/***/ (function(module, exports) {

module.exports = require("child_process");

/***/ }),

/***/ 4283:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async_series__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _controllers_Shortcuts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4284);
/* harmony import */ var _models_ToastManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4287);
/* harmony import */ var _controllers_ElectronContextMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4288);
/* harmony import */ var _models_collections_CollectionClipboard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4290);
/* harmony import */ var _models_Toasts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4291);







/**
                                                *
                                                * @param {*} cb
                                                */
function bootIndependentServices(cb) {
  _.assign(window.pm, {
    toasts: _models_Toasts__WEBPACK_IMPORTED_MODULE_5__,
    toastManager: new _models_ToastManager__WEBPACK_IMPORTED_MODULE_2__["default"](),
    contextMenuManager: new _controllers_ElectronContextMenu__WEBPACK_IMPORTED_MODULE_3__["default"](),
    clipboard: new _models_collections_CollectionClipboard__WEBPACK_IMPORTED_MODULE_4__["default"]() });

  pm.logger.info('IndependentServices~boot - Success');
  cb && cb(null);
}

/* harmony default export */ __webpack_exports__["default"] = (bootIndependentServices);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4288:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ElectronContextMenu; });
/* harmony import */ var _utils_DraftJsHelper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4289);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1269);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1714);
/* harmony import */ var _utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(764);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(742);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1545);
/* harmony import */ var _electron_ElectronService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1223);










/**
                                                                 * Handles context menu creation for Electron
                                                                 * Currently, the context menu supports:
                                                                 * 1. Encode/Decode URI Component for selected text
                                                                 * 2. Set as env var
                                                                 * 3. Set as global var
                                                                 * @private
                                                                 */let
ElectronContextMenu = class ElectronContextMenu {
  constructor() {
    this.Remote = __webpack_require__(62).remote;
    this.Menu = this.Remote.Menu;
    this.MenuItem = this.Remote.MenuItem;

    this.currentSelection = '';
    this.currentAceSelection = '';
    this.activeComponent = null;
    this.attachEventListeners();

    /**
                                  * On right click in any input field, text gets automatically selected even if there was no explicit selection made before.
                                  * The text which gets automatically selected on right click, depends on the cursor position.
                                  */
    window.addEventListener('contextmenu', e => {
      e.preventDefault();
      this.currentSelection = window.getSelection().toString();
      let menu = this.buildMenu(e);

      // Empty menu fix for windows native app
      if (menu && _.size(menu.items)) {
        menu.popup(Object(_electron_ElectronService__WEBPACK_IMPORTED_MODULE_8__["getCurrentWindow"])());
      }
    }, false);
  }

  attachEventListeners() {
    pm.mediator.on('textEditor:selectionChange', this.handleSelectionChange, this);
    pm.mediator.on('contextMenu:inputActivated', this.handleActiveInputChange, this);
  }

  handleSelectionChange(value) {
    this.currentAceSelection = value;
  }

  handleActiveInputChange(component) {
    this.currentSelection = window.getSelection().toString();
    this.activeComponent = component;
  }

  buildMenu(e) {
    let menu = new this.Menu(),
    isInput = _.get(e, 'target.nodeName') === 'INPUT' || _.get(e, 'target.nodeName') === 'TEXTAREA',
    hasAutoSuggest = _.get(this.activeComponent, 'refs.autoSuggest') ? true : false,
    isAceEditor = _.get(e, 'target.className') === 'ace_text-input',
    isMonacoEditor = e.target.closest('.monaco-editor'),
    requesterTab,
    selectedText = this.currentAceSelection || this.currentSelection; // Fetching the non empty string

    // Resetting values so that context menu is not triggered on right clicking anywhere on the screen
    this.currentSelection = '';
    this.currentAceSelection = '';

    if (_.get(e, 'target.closest') && (requesterTab = e.target.closest('.requester-tab'))) {

      this.buildTabMenu(menu, _.get(requesterTab, 'dataset.tabId'));
    } else
    if (!isInput && _.get(e, 'target.closest') && (e.target.closest('.collection-sidebar-list-item') ||
    e.target.closest('.collection-browser-list-item__folder') ||
    e.target.closest('.collection-browser-list-item__request'))) {
      return null;
    } else
    if (_.get(e, 'target.classList')) {
      if (e.target.classList.contains('requester-tab')) {
        this.buildTabMenu(menu, _.get(e.target, 'dataset.tabId'));
      } else
      if (e.target.classList.contains('requester-tab__name')) {
        this.buildTabMenu(menu, _.get(e.target, 'dataset.tabId'));
      }
    }

    if (!_.isEmpty(selectedText)) {
      this.buildEnvironmentMenu(menu, selectedText);
      this.buildGlobalMenu(menu, selectedText);
      this.buildGenericMenu(menu);
      _.trim(selectedText) && this.buildFindMenu(menu, selectedText);
      this.buildEncodeDecodeMenu(menu);
    }

    // Display generic input menu for input
    else if (isInput) {
        this.buildGenericMenu(menu);
      } else

      if (hasAutoSuggest || isAceEditor) {
        this.buildGenericMenu(menu);
        this.buildEncodeDecodeMenu(menu);
        this.activeComponent = null;
      } else
      if (isMonacoEditor) {
        this.buildTextEditorMenu(menu, e);
        this.activeComponent = null;
      }

    return menu;
  }

  buildTabMenu(menu, id) {

    // dont need isPreview, duplicate can be done for all cases
    menu.append(new this.MenuItem({
      label: 'Duplicate Tab',
      click: () => {
        _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].duplicate({ id: id });
      } }));

    menu.append(new this.MenuItem({ type: 'separator' }));

    menu.append(new this.MenuItem({
      label: 'Close',
      accelerator: 'CommandOrControl+W',
      click: () => {
        _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].close({ id: id });
      } }));

    menu.append(new this.MenuItem({
      label: 'Force Close',
      accelerator: 'CommandOrControl+Alt+W',
      click: () => {
        _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].close({ id: id }, { force: true });
      } }));

    menu.append(new this.MenuItem({
      label: 'Close Other Tabs',
      click: () => {
        _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].closeAllButCurrent();
      } }));

    menu.append(new this.MenuItem({
      label: 'Close All Tabs',
      click: () => {
        _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].closeAll();
      } }));

    menu.append(new this.MenuItem({
      label: 'Force Close All Tabs',
      click: () => {
        _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].requestForceCloseAll();
      } }));

  }

  buildFindMenu(menu, selectedText) {
    menu.append(new this.MenuItem({
      label: `Find: ${selectedText}`,
      click: () => pm.mediator.trigger('findSelectedText', selectedText) }));

  }

  buildGenericMenu(menu) {

    menu.append(new this.MenuItem({
      label: 'Undo',
      role: 'undo' }));

    menu.append(new this.MenuItem({
      label: 'Redo',
      role: 'redo' }));

    menu.append(new this.MenuItem({ type: 'separator' }));
    menu.append(new this.MenuItem({
      label: 'Cut',
      role: 'cut' }));

    menu.append(new this.MenuItem({
      label: 'Copy',
      role: 'copy' }));

    menu.append(new this.MenuItem({
      label: 'Paste',
      role: 'paste' }));

    menu.append(new this.MenuItem({
      label: 'Select All',
      role: 'selectall' }));

    menu.append(new this.MenuItem({ type: 'separator' }));
  }

  buildTextEditorMenu(menu, event) {

    menu.append(new this.MenuItem({
      label: 'Undo',
      click: () => {pm.mediator.trigger('textEditor:undo', event.target);} }));

    menu.append(new this.MenuItem({
      label: 'Redo',
      click: () => {pm.mediator.trigger('textEditor:redo', event.target);} }));

    menu.append(new this.MenuItem({ type: 'separator' }));
    menu.append(new this.MenuItem({
      label: 'Cut',
      role: 'cut' }));

    menu.append(new this.MenuItem({
      label: 'Copy',
      role: 'copy' }));

    menu.append(new this.MenuItem({
      label: 'Paste',
      role: 'paste' }));

    menu.append(new this.MenuItem({
      label: 'Select All',
      click: () => {pm.mediator.trigger('textEditor:selectAll', event.target);} }));

  }

  buildEncodeDecodeMenu(menu) {
    menu.append(new this.MenuItem({
      label: 'EncodeURIComponent',
      click: () => {this.encodeURI();} }));

    menu.append(new this.MenuItem({
      label: 'DecodeURIComponent',
      click: () => {this.decodeURI();} }));

  }

  buildEnvironmentMenu(menu, selectionText) {
    let environment = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveEnvironmentStore');
    if (!environment || _.isEmpty(environment.values)) {
      return;
    }
    let environmentName = environment.name;
    let submenu = new this.Menu();

    let environmentVars = _.reject(environment.values, { enabled: false }),
    environmentKeys = _.map(environmentVars, 'key');

    _.forEach(environmentKeys, (key, index) => {
      submenu.append(new this.MenuItem({
        label: key,
        click: () => {this.updateEnvironmentVariableFromContextMenu(index, selectionText);} }));

    });

    menu.append(new this.MenuItem({
      label: 'Set: ' + environmentName,
      type: 'submenu',
      submenu: submenu }));

  }

  buildGlobalMenu(menu, selectionText) {
    let globals = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveGlobalsStore');
    if (!globals || _.isEmpty(globals.values)) {
      return;
    }
    let submenu = new this.Menu();

    let globalVars = _.reject(globals.values, { enabled: false });
    let globalKeys = _.map(globalVars, 'key');

    _.forEach(globalKeys, (key, index) => {
      submenu.append(new this.MenuItem({
        label: key,
        click: () => {this.updateGlobalVariableFromContextMenu(index, selectionText);} }));

    });

    // Show Set:Globals only if globals are present
    if (_.size(globalKeys)) {
      menu.append(new this.MenuItem({
        label: 'Set: Globals',
        type: 'submenu',
        submenu: submenu }));

    }
  }

  encodeURI() {
    var selectionStart, selectionEnd, oldValue, newValue, args;
    if (_.get(this.activeComponent, 'refs.autoSuggest')) {
      var editorState = this.activeComponent.state.editorState,
      selectionObj = _utils_DraftJsHelper__WEBPACK_IMPORTED_MODULE_0__["default"].getAutoSuggestSelectionRange(editorState);
      oldValue = selectionObj.oldValue;
      selectionStart = selectionObj.selectionStart;
      selectionEnd = selectionObj.selectionEnd;
      args = [];
    } else
    {
      var inputBox = document.activeElement;
      selectionStart = inputBox.selectionStart;
      selectionEnd = inputBox.selectionEnd;
      if (!inputBox || !inputBox.value) {
        return;
      }
      oldValue = inputBox.value;
      args = [null];
    }
    try {
      newValue = oldValue.substring(0, selectionStart) +
      encodeURIComponent(oldValue.substring(selectionStart, selectionEnd)) +
      oldValue.substring(selectionEnd, oldValue.length);
    }
    catch (e) {
      return;
    }
    args.push(newValue);
    if (this.activeComponent && this.activeComponent.handleChange) {
      this.activeComponent.handleChange.apply(this.activeComponent, args);
    }
  }

  decodeURI() {
    var selectionStart, selectionEnd, oldValue, newValue, args;
    if (_.get(this.activeComponent, 'refs.autoSuggest')) {
      var editorState = this.activeComponent.state.editorState,
      selectionObj = _utils_DraftJsHelper__WEBPACK_IMPORTED_MODULE_0__["default"].getAutoSuggestSelectionRange(editorState);
      oldValue = selectionObj.oldValue;
      selectionStart = selectionObj.selectionStart;
      selectionEnd = selectionObj.selectionEnd;
      args = [];
    } else
    {
      var inputBox = document.activeElement;
      selectionStart = inputBox.selectionStart;
      selectionEnd = inputBox.selectionEnd;
      if (!inputBox || !inputBox.value) {
        return;
      }
      oldValue = inputBox.value;
      args = [null];
    }

    try {
      var newValue = oldValue.substring(0, selectionStart) +
      decodeURIComponent(oldValue.substring(selectionStart, selectionEnd)) +
      oldValue.substring(selectionEnd, oldValue.length);
    }
    catch (e) {
      return;
    }
    args.push(newValue);
    if (this.activeComponent && this.activeComponent.handleChange) {
      this.activeComponent.handleChange.apply(this.activeComponent, args);
    }
  }

  updateGlobalVariableFromContextMenu(index, selectionText) {
    let model = 'globals',
    modelId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveGlobalsStore').id,
    activeWorkspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').id,
    sessionId = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_4__["getSessionId"])(model, modelId, activeWorkspaceId);

    Object(_modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_3__["getSessionFor"])(sessionId).
    then(session => {
      if (!session) {
        return;
      }

      let values = _.clone(session.values),
      enabledVariables = _.reject(values, { enabled: false });

      enabledVariables[index].value = selectionText;

      let data = {
        id: sessionId,
        model: model,
        modelId: modelId,
        workspace: activeWorkspaceId,
        values: values };


      let updateSessionEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_5__["createEvent"])('update', 'variablesession', data);
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('session', 'user_edit', model);
      return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(updateSessionEvent);
    }).
    catch(err => {
      pm.logger.warn('Failed to update global value through context menu', err);
      pm.toasts.error('Something went wrong. Please check DevTools.');
    });
  }

  updateEnvironmentVariableFromContextMenu(index, selectionText) {
    let model = 'environment',
    modelId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveEnvironmentStore').id,
    activeWorkspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').id,
    sessionId = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_4__["getSessionId"])(model, modelId, activeWorkspaceId);

    Object(_modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_3__["getSessionFor"])(sessionId).
    then(session => {
      if (!session) {
        return;
      }

      let values = _.clone(session.values),
      enabledVariables = _.reject(values, { enabled: false });

      enabledVariables[index].value = selectionText;

      let data = {
        id: sessionId,
        model: model,
        modelId: modelId,
        workspace: activeWorkspaceId,
        values: values };


      let updateSessionEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_5__["createEvent"])('update', 'variablesession', data);
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('session', 'user_edit', model);
      return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(updateSessionEvent);
    }).
    catch(err => {
      pm.logger.warn('Failed to update session through context menu', err);
      pm.toasts.error('Something went wrong. Please check DevTools.');
    });
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4289:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var draft_js_lib_getContentStateFragment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2290);
/* harmony import */ var draft_js_lib_getContentStateFragment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(draft_js_lib_getContentStateFragment__WEBPACK_IMPORTED_MODULE_0__);
let

DraftJsHelper = class DraftJsHelper {
  getAutoSuggestSelectionRange(editorState) {
    var fragment = draft_js_lib_getContentStateFragment__WEBPACK_IMPORTED_MODULE_0___default()(editorState.getCurrentContent(), editorState.getSelection()),
    oldValue = editorState.getCurrentContent().getPlainText(),
    selectedValue = fragment // eslint-disable-line lodash/prefer-lodash-method
    .map(block => {
      return block.getText();
    }).join('\n'),
    selectionStart = oldValue.indexOf(selectedValue),
    selectionEnd = selectionStart + selectedValue.length;
    return {
      oldValue,
      selectionStart,
      selectionEnd };

  }};


/* harmony default export */ __webpack_exports__["default"] = (new DraftJsHelper());

/***/ }),

/***/ 4290:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionClipboard; });
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1269);
/* harmony import */ var _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(781);

let

CollectionClipboard = class CollectionClipboard {
  cutItem(item, collectionId) {
    if (_.isEmpty(item)) {
      return;
    }
    this.clipboard = {
      id: item.id,
      type: item.type,
      collectionId: collectionId,
      action: 'cut' };

  }

  copyItem(item, collectionId) {
    if (_.isEmpty(item)) {
      return;
    }
    this.clipboard = {
      id: item.id,
      type: item.type,
      collectionId: collectionId,
      action: 'copy' };

  }

  async pasteItem(destination) {
    let source = this.getClipboard();

    if (_.isEmpty(source)) {
      return;
    }

    if (source.action === 'cut') {
      this.clearClipboard();
      let moveEvent = {};

      if (destination.type === 'request' && source.type === 'request') {
        moveEvent = {
          name: 'move',
          namespace: 'request',
          data: {
            model: 'request',
            request: { id: source.id },
            after: {
              model: destination.type,
              modelId: destination.id } } };



      } else

      if (_.includes(['collection', 'folder'], destination.type) && _.includes(['request', 'folder'], source.type)) {
        moveEvent = {
          name: 'move',
          namespace: source.type,
          data: {
            model: source.type,
            [source.type]: { id: source.id },
            target: {
              model: destination.type,
              modelId: destination.id } } };



      } else
      if (destination.type === 'request' && source.type === 'folder') {
        let destinationRequest = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getRequest({ id: destination.id });

        moveEvent = {
          name: 'move',
          namespace: source.type,
          data: {
            model: source.type,
            [source.type]: { id: source.id },
            target: {
              model: destinationRequest.folder ? 'folder' : 'collection',
              modelId: destinationRequest.folder ? destinationRequest.folder : destinationRequest.collection } } };



      }
      if (!_.isEmpty(moveEvent)) {
        Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(moveEvent).
        then(response => {
          if (!_.isEmpty(_.get(response, 'error'))) {
            pm.logger.error(`Error while moving ${source.type} ${destination.type}`, response.error);
            return;
          }
        }).
        catch(err => {
          pm.logger.error(`Error in pipeline while moving ${source.type} ${destination.type}`, err);
        });
      }
    } else
    if (source.action === 'copy') {
      this.clearClipboard();
      let duplicateEvent = {};

      if (destination.type === 'request' && _.includes(['request', 'folder'], source.type)) {
        let destinationRequest = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getRequest({ id: destination.id });
        duplicateEvent = {
          name: 'duplicate',
          namespace: source.type,
          data: {
            model: source.type,
            [source.type]: { id: source.id },
            target: {
              model: destinationRequest.folder ? 'folder' : 'collection',
              modelId: destinationRequest.folder ? destinationRequest.folder : destinationRequest.collection } } };



      } else

      if (_.includes(['folder', 'collection'], destination.type) && _.includes(['folder', 'request'], source.type)) {
        duplicateEvent = {
          name: 'duplicate',
          namespace: source.type,
          data: {
            model: source.type,
            [source.type]: { id: source.id },
            target: {
              model: destination.type,
              modelId: destination.id } } };



      }

      if (!_.isEmpty(duplicateEvent)) {
        Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(duplicateEvent).
        then(response => {
          if (!_.isEmpty(_.get(response, 'error'))) {
            pm.logger.error(`Error while duplicating ${source.type} on ${destination.type}`, response.error);
            return;
          }
        }).
        catch(err => {
          pm.logger.error(`Error in pipeline while duplicating ${source.type} on ${destination.type}`, err);
        });
      }
    }
  }

  getClipboard() {
    return this.clipboard;
  }

  clearClipboard() {
    this.clipboard = null;
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4294:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async_series__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _bootStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4295);
/* harmony import */ var _bootShortcuts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4297);
/* harmony import */ var _bootSyncProxy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4298);
/* harmony import */ var _bootConsoleInterface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4300);
/* harmony import */ var _controllers_UIZoom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4302);
/* harmony import */ var _controllers_ProxyListManager__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4303);
/* harmony import */ var _models_AppUpdateNotifier__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4304);
/* harmony import */ var _models_tcp_ElectronTCPReader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4306);
/* harmony import */ var _models_requests_CertificateManager__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4307);
/* harmony import */ var _models_ProtocolHandler__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4308);
/* harmony import */ var _components_base_XPaths_XPathManager__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1754);
/* harmony import */ var _services_ModelEventToUIEventService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4309);
/* harmony import */ var _models_InterceptorManager__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4310);
/* harmony import */ var _models_InterceptorInstaller__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4312);
/* harmony import */ var _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4087);
/* harmony import */ var _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _services_UIEventServiceHandler__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4313);
/* harmony import */ var _services_AccessControl_DbRollbackService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4314);
/* harmony import */ var _bootAPIDevInterface__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4315);
/* harmony import */ var _services_CloudProxyHandler__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4320);
/* harmony import */ var _runtime_services_RequestExecutionService__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1708);
/* harmony import */ var _runtime_models_OAuth2Tokens__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4323);
/* harmony import */ var _runtime_models_OAuth2Manager__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4324);
/* harmony import */ var _models_cookies_CookieManager__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4328);

























/**
                                                                 *
                                                                 * @param {*} cb
                                                                 */
function bootRequester(cb) {
  async_series__WEBPACK_IMPORTED_MODULE_0___default()([
  _bootStore__WEBPACK_IMPORTED_MODULE_1__["default"],
  _bootShortcuts__WEBPACK_IMPORTED_MODULE_2__["default"],
  _bootSyncProxy__WEBPACK_IMPORTED_MODULE_3__["default"],
  _bootConsoleInterface__WEBPACK_IMPORTED_MODULE_4__["default"],
  _bootAPIDevInterface__WEBPACK_IMPORTED_MODULE_18__["default"],
  _models_ProtocolHandler__WEBPACK_IMPORTED_MODULE_10__["default"].initialize,
  next => {
    Object(_services_AccessControl_DbRollbackService__WEBPACK_IMPORTED_MODULE_17__["initializeRollbackNotifications"])();
    next();
  }],
  err => {
    _.assign(window.pm, {
      proxyListManager: new _controllers_ProxyListManager__WEBPACK_IMPORTED_MODULE_6__["default"](), // [settings]
      certificateManager: new _models_requests_CertificateManager__WEBPACK_IMPORTED_MODULE_9__["default"](), // [settings]
      uiZoom: new _controllers_UIZoom__WEBPACK_IMPORTED_MODULE_5__["default"](), // [settings]
      updateNotifier: new _models_AppUpdateNotifier__WEBPACK_IMPORTED_MODULE_7__["default"](), // [appwindow, settings, app]
      tcpReader: new _models_tcp_ElectronTCPReader__WEBPACK_IMPORTED_MODULE_8__["default"](), // [settings, appwindow]
      interceptorManager: new _models_InterceptorManager__WEBPACK_IMPORTED_MODULE_13__["default"](),
      interceptorBridge: _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_15___default.a,
      interceptorInstaller: new _models_InterceptorInstaller__WEBPACK_IMPORTED_MODULE_14__["default"](),
      xPathManager: _components_base_XPaths_XPathManager__WEBPACK_IMPORTED_MODULE_11__["default"],
      cloudProxyHandler: new _services_CloudProxyHandler__WEBPACK_IMPORTED_MODULE_19__["default"](),
      cookieManager: new _models_cookies_CookieManager__WEBPACK_IMPORTED_MODULE_23__["default"](),
      oAuth2Tokens: new _runtime_models_OAuth2Tokens__WEBPACK_IMPORTED_MODULE_21__["default"](),
      oAuth2Manager: new _runtime_models_OAuth2Manager__WEBPACK_IMPORTED_MODULE_22__["default"]() });


    _services_ModelEventToUIEventService__WEBPACK_IMPORTED_MODULE_12__["default"].initialize();
    _services_UIEventServiceHandler__WEBPACK_IMPORTED_MODULE_16__["default"].init();
    _runtime_services_RequestExecutionService__WEBPACK_IMPORTED_MODULE_20__["default"].initialize();

    pm.appWindow.sendToElectron({ event: 'postmanInitialized' }); // Initialize protocol handline need revisit

    err ? pm.logger.error('Requester~boot - Failed', err) : pm.logger.info('Requester~boot - Success');
    return cb && cb(err);
  });
}

/* harmony default export */ __webpack_exports__["default"] = (bootRequester);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4298:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _models_sync_SyncManagerProxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4299);


/**
                                                                    *
                                                                    */
function bootSyncProxy(cb) {
  _.assign(window.pm, { syncManager: new _models_sync_SyncManagerProxy__WEBPACK_IMPORTED_MODULE_0__["default"]() });
  pm.logger.info('SyncProxy~boot - Success');
  cb && cb(null);
}

/* harmony default export */ __webpack_exports__["default"] = (bootSyncProxy);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4299:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(742);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);




/**
                                                    * Handles the socket, and is the interface for sending and receiving changesets
                                                    *
                                                    * @class SyncManager
                                                    */
var SyncManagerProxy = backbone__WEBPACK_IMPORTED_MODULE_0___default.a.Model.extend({
  defaults: function () {
    return {
      loggedIn: false,
      nextReconnectTime: null,
      timeTillReconnect: null };

  },

  sendEventToSyncShared: function (event) {
    this.syncInternalChannel.publish(event);
  },

  attachInternalChannelSubscription: function () {
    this.syncManagerInternalDispose = this.syncInternalChannel.subscribe(event => {
      let eventNamespace = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventNamespace"])(event),
      eventName = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventName"])(event),
      eventData = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventData"])(event);

      if (eventNamespace === 'timeTillReconnect' && eventName === 'updated') {
        this.set('timeTillReconnect', eventData.timeTillReconnect);
        return;
      }

      if (eventNamespace === 'loggedIn' && eventName === 'updated') {
        this.set('loggedIn', eventData.loggedIn);
        return;
      }

      if (eventNamespace === 'conflicts' && eventName === 'show') {
        this.showConflicts(eventData.conflicts);
        return;
      }

      if (eventNamespace === 'issue' && eventName === 'show') {
        this.showSyncIssue(eventData.issue);
        return;
      }
    });
  },

  initialize: function () {
    this.syncInternalChannel = pm.eventBus.channel('sync-manager-internal');
    this.attachInternalChannelSubscription();
  },

  showConflicts: function (conflicts) {
    this.trigger('showConflicts', conflicts);
  },

  showSyncIssue: function (issue) {
    pm.mediator.trigger('showSyncIssue', issue);
  },

  syncIconClick: function () {
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('syncIconClicked', 'command'));
  },

  restoreCollection: function (restoreTarget, cb) {
    let isSocketConnected = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('SyncStatusStore').isSocketConnected;
    if (!isSocketConnected) {
      pm.toasts.error('You need to be connected to Postman Sync to restore a collection.');
      _.isFunction(cb) && cb(new Error('No sync connection to restore collection'));
      return;
    }
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('restoreCollection', 'command', { restoreTarget: restoreTarget }));
    cb();
  },

  conflictsResolved: function (resolution) {
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('conflictsResolved', 'command', { resolution: resolution }));
  },

  forceSync: function () {
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('forceSync', 'command'));
  },

  forceSyncCollectionAndContinue: function (id) {
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('forceSyncCollectionAndContinue', 'command', { collection: id }));
  },

  forceConnect: function () {
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('forceConnect', 'command'));
  },

  fetchPendingConflicts: function () {
    this.sendEventToSyncShared(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('fetchPendingConflicts', 'command'));
  } });


/* harmony default export */ __webpack_exports__["default"] = (SyncManagerProxy);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4300:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _runtime_api_ConsoleInterface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4301);


/**
                                                                       * Boots up the console interface
                                                                       * @param {Function} cb - The callback with error
                                                                       */
function bootConsoleInterface(cb) {
  _.assign(window.pm, {
    console: new _runtime_api_ConsoleInterface__WEBPACK_IMPORTED_MODULE_0__["default"]() // @todo: Change to pm.console when we replace the current console
  });

  // Initialize the new console interface with current window information
  window.pm.console.initialize(pm && pm.window && pm.window.id).
  then(() => {
    pm.logger.info('NewConsole~boot - Success');

    // using `setTimeout` here to ensure that we take the errors in `cb` out
    // of the stack trace and do not call the `catch` block (which calls the
    // `cb` again!)
    return cb && setTimeout(cb, 0);
  }).
  catch(err => {
    pm.logger.error('NewConsole~boot - Failed');
    return cb && cb(err);
  });
}

/* harmony default export */ __webpack_exports__["default"] = (bootConsoleInterface);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4301:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ConsoleInterface; });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(650);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(uuid__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(742);
/* harmony import */ var _js_modules_pipelines_app_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1240);
/* harmony import */ var _constants_ConsoleEventSeverity__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(731);
/* harmony import */ var _constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1495);


// @note: remove the below imports when removing the `clear` method. The console
// service should be responsible for interacting with the pipeline.
// see the comment for `clear` method for details





let

ConsoleInterface = class ConsoleInterface {




































  /**
                                            * Constructor
                                            */ /**
                                                * The ID of the window that is associated for an instance
                                                * @type {String}
                                                * @private
                                                */ /**
                                                    * The types of events that we're handling.
                                                    * @default
                                                    * @type {Set<String>}
                                                    * @private
                                                    */constructor() {this.initialized = false;this._eventTypes = new Set([_constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_4__["CONSOLE_EVENT_LOG"], _constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_4__["CONSOLE_EVENT_NETWORK"], _constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_4__["CONSOLE_EVENT_EXCEPTION"]]);this._timelineId = null;this._windowId = null;this._sequence = 0; // Initialize the sugar helper methods over write
    this.log = this.write.bind(this, _constants_ConsoleEventSeverity__WEBPACK_IMPORTED_MODULE_3__["CONSOLE_LEVEL_LOG"]);this.info = this.write.bind(this, _constants_ConsoleEventSeverity__WEBPACK_IMPORTED_MODULE_3__["CONSOLE_LEVEL_INFO"]);this.warn = this.write.bind(this, _constants_ConsoleEventSeverity__WEBPACK_IMPORTED_MODULE_3__["CONSOLE_LEVEL_WARN"]);this.error = this.write.bind(this, _constants_ConsoleEventSeverity__WEBPACK_IMPORTED_MODULE_3__["CONSOLE_LEVEL_ERROR"]);} /**
                                                                                                                                                                                                                               * Connect to the timeline and register event types
                                                                                                                                                                                                                               *
                                                                                                                                                                                                                               * @param {String} windowId - The window id for attaching to the console stream
                                                                                                                                                                                                                               * @return {Promise} - A promise that resolves if connected to a timeline successfully
                                                                                                                                                                                                                               */ /**
                                                                                                                                                                                                                                   * A counter maintained to establish strict order of logs
                                                                                                                                                                                                                                   * @type {number}
                                                                                                                                                                                                                                   * @private
                                                                                                                                                                                                                                   */ /**
                                                                                                                                                                                                                                       * The ID of the console stream (timeline) that we're connected to.
                                                                                                                                                                                                                                       * @type {String}
                                                                                                                                                                                                                                       */ /**
                                                                                                                                                                                                                                           * The state of the console interface. It is true if the console is attached to a timeline.
                                                                                                                                                                                                                                           * @default
                                                                                                                                                                                                                                           * @type {Boolean}
                                                                                                                                                                                                                                           */initialize(windowId) {if (this.initialized) {return Promise.reject(new Error('Console has already been initialized'));}if (!windowId || typeof windowId !== 'string') {return Promise.reject(new TypeError('Invalid value for argument `windowId`'));}this._windowId = windowId;this._timelineId = uuid__WEBPACK_IMPORTED_MODULE_0___default.a.v4();this._sequence = 0;

    return Object(_js_modules_pipelines_app_action__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('createTimeline', 'console', {
      id: this._timelineId,
      window: this._windowId })).

    then(result => {
      if (!result || result.status !== 'OK') {
        return Promise.reject(new Error('Could not create a timeline for the window'));
      }

      this.initialized = true;

      return Promise.resolve();
    });
  }

  /**
     * Check if we're handling the event that was sent
     *
     * @param {String} eventType - the event type to check
     * @return {Boolean} - true if we're handling the event type
     */
  canHandleEvent(eventType) {
    if (typeof eventType !== 'string') {
      return false;
    }

    return this._eventTypes.has(eventType);
  }

  getTimelineId() {
    return this._timelineId;
  }

  /**
     * Writes a log to console
     *
     * @param {String} severity - One of several severity levels for the console message
     *  (defined in constants/ConsoleEventSeverity.js)
     * @param {String} eventType - One of the several available types for a console message.
     *  This must be one which was sent while instantiating the console
     * @param {Object} source - TBD
     * @param {Object} log - A detailed description for this log
     * @param {Number} [timestamp] - A timestamp to be used when logging this value
     */
  write(severity, eventType, source, log, timestamp = Date.now()) {
    if (!this.canHandleEvent(eventType)) {
      throw new Error(`ConsoleInterface~write: Could not handle event type: ${eventType}`);
    }

    if (!severity || typeof severity !== 'string') {
      return new Error('Invalid value for argument `severity`');
    }

    if (!source || typeof source !== 'object') {
      return new Error('Invalid value for argument `source`');
    }

    if (!log) {
      return new Error('Invalid value for argument `log`');
    }

    if (timestamp && (typeof timestamp !== 'number' || timestamp < 0)) {
      return new Error('Invalid value for argument `timestamp`');
    }

    if (!this.initialized) {
      pm.logger.warn('ConsoleInterface~write: Cannot write as interface has not been initialized');

      return;
    }

    return Object(_js_modules_pipelines_app_action__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('createEvent', 'console', {
      id: uuid__WEBPACK_IMPORTED_MODULE_0___default.a.v4(),
      timeline: this._timelineId,
      sequence: this._sequence++,
      timestamp,
      type: eventType,
      severity,
      source,
      details: log }));

  }

  /**
     * Clears console events from the persistence storage for all timelines.
     */
  clear() {
    if (!this.initialized) {
      pm.logger.warn('ConsoleInterface~clear: Cannot clear as interface has not been initialized');

      return;
    }

    // We're calling the dispatchAppAction directly to clear all console events
    // because:
    //   the clear event is supposed to be just like another event in a timeline
    //   to allow exporting timelines with info before the clear event was
    //   fired. Until the export capabilities are not added to the console, it's
    //   useless to keep the events in the storage which impacts performance.
    return Object(_js_modules_pipelines_app_action__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('deleteEvents', 'console', { timeline: this._timelineId }));
  }

  /**
     * Disconnect from the console stream. Once this method is called, the window
     * will not be able to send any logs to this stream.
     */
  destroy() {
    if (!this.initialized) {
      pm.logger.warn('ConsoleInterface~destroy: Cannot destroy as interface has not been initialized');

      return;
    }

    this.initialized = false;

    return Object(_js_modules_pipelines_app_action__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["createEvent"])('deleteTimeline', 'console', { id: this._timelineId }));
  }};

/***/ }),

/***/ 4303:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxyListManager; });
const WHITELISTED_PROPS = ['disabled', 'httpProxy', 'httpsProxy', 'host', 'port',
'authenticate', 'username', 'password', 'bypass'];

/**
                                                    * Transform older proxy settings to newer version (globalProxies -> globalProxy).
                                                    *
                                                    * @param {Object[]} config
                                                    * @returns {Object}
                                                    */
function transformOlderSettings(config) {
  const defaultConfig = {
    disabled: true,
    httpProxy: true,
    httpsProxy: true,
    port: 8080 };


  if (!(Array.isArray(config) && config.length > 0)) {
    return defaultConfig;
  }

  config = config[0];

  if (!(config && config.host)) {
    return defaultConfig;
  }

  let pattern = String(_.get(config, 'match.pattern', '')),
  httpProxy = pattern.includes('http:') || pattern.includes('http+'),
  httpsProxy = pattern.includes('https');

  return {
    httpProxy: !httpProxy && !httpsProxy ? true : httpProxy, // unlikely but, set at-least HTTP proxy
    httpsProxy: httpsProxy,
    host: config.host,
    port: config.port,
    authenticate: config.authenticate,
    username: config.username,
    password: config.password,
    disabled: config.disabled };

}

/**
   * SDK compatible url mach for which the proxy has been associated with.
   *
   * @param {Boolean} httpProxy
   * @param {Boolean} httpsProxy
   * @returns {String}
   */
function getMatchPattern(httpProxy, httpsProxy) {
  const suffix = '://*:*/*';

  if (httpsProxy) {
    if (httpProxy) {
      return 'http+https' + suffix;
    }

    return 'https' + suffix;
  }

  return 'http' + suffix;
}

/**
   * Get bypass list for the proxy setting.
   *
   * @param {String} bypass
   * @returns {String[]}
   */
function getBypassList(bypass) {
  if (!(bypass && typeof bypass === 'string')) {return;}

  // split by ',' and '\n' and filter empty strings
  bypass = bypass.split(/,|\n/g).map(h => h.trim()).filter(Boolean);

  let host,
  i,
  ii = bypass.length,
  bypassList = new Array(ii);

  for (i = 0; i < ii; i++) {
    host = bypass[i];

    if (host.includes('://')) {// protocol is specified
      host = host.endsWith('/') ?
      host : // already a complete URL
      host + ':*/*'; // match all ports and paths
    } else
    {// just hostname
      host = `http+https://${host}:*/*`;
    }

    bypassList[i] = host;
  }

  return bypassList;
}let

ProxyListManager = class ProxyListManager {
  constructor() {
    this.globalProxy = this.getFromDB();
  }

  getFromDB() {
    let config = pm.settings.getSetting('ProxyListManager');

    !_.isObject(config) && (config = {});

    // migrate to newer global proxy configuration (< v7.9.0)
    // @note this migrate as well as set default config for newer versions
    if (!config.globalProxy) {
      config.globalProxy = transformOlderSettings(config.globalProxies);

      // update local storage to avoid this migration on every load
      this.saveToDB({ globalProxy: config.globalProxy });
    }

    return config.globalProxy;
  }

  saveToDB(config) {
    // bail out if not a valid config object (if present)
    if (config && !config.globalProxy) {
      return;
    }

    pm.settings.setSetting('ProxyListManager', config || { globalProxy: this.globalProxy });
  }

  update(config) {
    // bail out if not a valid config object
    if (!(config && config.globalProxy)) {
      return;
    }

    this.globalProxy = Object.assign(this.globalProxy, _.pick(config.globalProxy, WHITELISTED_PROPS));
  }

  /**
     * @returns {Object[]} - SDK compatible ProxyConfigList object
     */
  getGlobalProxyConfigList() {
    let globalProxy = this.globalProxy;

    return [{
      match: getMatchPattern(globalProxy.httpProxy, globalProxy.httpsProxy),
      host: globalProxy.host,
      port: globalProxy.port,
      authenticate: globalProxy.authenticate,
      username: globalProxy.username,
      password: globalProxy.password,
      disabled: globalProxy.disabled,
      bypass: getBypassList(globalProxy.bypass) }];

  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4304:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _modules_services_APIService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1220);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(784);
/* harmony import */ var _utils_HttpService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1221);
/* harmony import */ var _services_AppReleaseService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1635);
/* harmony import */ var _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(769);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _utils_ShellHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(746);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(742);
/* harmony import */ var domain__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4305);
/* harmony import */ var domain__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(domain__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _constants_InfobarConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1258);
/* harmony import */ var _controllers_Infobar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1259);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_12__);














const APP_UPDATE = 'appUpdate',
APP_UPDATE_EVENTS = 'app-update-events',
CHECK_FOR_ELECTRON_VERSION_UPDATED = 'checkForElectronVersionUpdated',
UPDATE_ELECTRON = 'updateElectron',
APPLY_ELECTRON_UPDATE = 'applyElectronUpdate',

ELECTRON_UPDATE_ERROR = 'electronAppUpdateError',
ELECTRON_UPDATE_NOT_AVAILABLE = 'electronAppUpdateNotAvailable',
ELECTRON_UPDATE_DOWNLOADED = 'electronAppUpdateDownloaded',
CHECK_FOR_ELECTRON_VERSION_UPDATE = 'checkForElectronVersionUpdate',
CHECK_FOR_ELECTRON_UPDATE = 'checkForElectronUpdate',
ELECTRON_VERSION_UPDATED = 'electronVersionUpdated';


const AUTO_UPDATE_TIMER = 24 * 3600 * 1000, // 24 hours
NO_UPDATE_BANNER_TIMEOUT = 7 * 24 * 3600 * 1000, // A week
NOT_UPDATED_BANNER_ID = 'not-updated-banner',
NOT_UPDATED_MESG = {
  _id: NOT_UPDATED_BANNER_ID, // not using id since that will be overridden
  message: 'An update has been downloaded for Postman. Restart now to install the update.',
  priority: 80,
  type: _constants_InfobarConstants__WEBPACK_IMPORTED_MODULE_10__["SUCCESS"],
  isDismissable: true,
  primaryAction: {
    label: 'Restart',
    onClick: () => {
      pm.updateNotifier.applyUpdate();
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'app_restart', 'restart_banner');
    } },

  onDismiss: function (params) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'dismiss_update_restart_banner');
  } },

PUBLIC_CHANNELS = ['prod', 'canary'];

var semver = __webpack_require__(1634),
AppUpdateNotifier = backbone__WEBPACK_IMPORTED_MODULE_12___default.a.Model.extend({
  defaults: function () {
    return {
      status: 'idle',
      initialized: false,
      data: null,
      releaseNotes: null,
      isAutoDownloaded: false,
      isUpdateEnabled: true };

  },
  initialize: function () {
    this.set('isUpdateEnabled', pm.app.get('isUpdateEnabled'));

    // Disable if the flag is set but only if it is not a public facing channel
    // Used while running integration tests
    if (pm.env.DISABLE_UPDATES && !_.includes(PUBLIC_CHANNELS, window.RELEASE_CHANNEL)) {
      return;
    }

    if (!this.get('isUpdateEnabled')) {
      pm.logger.info('Updater bailed! Running on Snap!');
      return;
    }

    // initialization should be idempotent
    if (this.get('initialized')) {
      return;
    }
    this.set('initialized', true);

    // migrate existing data
    if (pm.settings.getSetting('autoDownloadUpdateStatus') === 0) {
      pm.settings.setSetting('autoDownloadUpdateStatus', _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_0__["default"].autoDownload.MINOR);
    }
    this.updaterEventBus = pm.eventBus.channel(APP_UPDATE_EVENTS);
    this.attachUpdaterEventsListeners();

    this.checkForVersionUpdate();

    this.version = pm.app.get('version');
    this.appId = pm.app.get('installationId');
    this.userAgent = navigator.userAgent;
    this.platform = this.getPlatform();
    this.arch = this.getArch();
    this.updateServerDomain = postman_update_server_url;

    setTimeout(() => {
      navigator.onLine && this.updateHandler();
    }, 10000); // After 10 sec

    setInterval(() => {
      // If an update is already downloaded don't check for new updates
      if (this.get('status') === 'downloaded') {
        // Show the banner if user has not restarted app for a week
        const hasCrossedNoUpdateTimeout = Date.now() - this.get('downloadedTimestamp') > NO_UPDATE_BANNER_TIMEOUT,
        isBannerAlreadyOpen = _.find(_controllers_Infobar__WEBPACK_IMPORTED_MODULE_11__["default"].infoList, { _id: NOT_UPDATED_BANNER_ID }); // same banner is already shown, don't show another

        if (hasCrossedNoUpdateTimeout && !isBannerAlreadyOpen) {
          _controllers_Infobar__WEBPACK_IMPORTED_MODULE_11__["default"].add(NOT_UPDATED_MESG);
          _controllers_Infobar__WEBPACK_IMPORTED_MODULE_11__["default"].show();
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'show_update_restart_banner');
        }

        return;
      }

      navigator.onLine && this.updateHandler();
    }, AUTO_UPDATE_TIMER);
  },

  checkForVersionUpdate() {
    this.updaterEventBus.publish(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])(CHECK_FOR_ELECTRON_VERSION_UPDATED, APP_UPDATE));
  },

  attachUpdaterEventsListeners() {
    this.updaterEventBus.subscribe((event = {}) => {
      console.log('App updater event', event); // Logging intentionally

      let eventName = event.name;
      if (eventName === ELECTRON_UPDATE_NOT_AVAILABLE) {
        this.noUpdateFound();
        return;
      }
      if (eventName === ELECTRON_UPDATE_ERROR) {
        this.onUpdateError(event.data);
        return;
      }
      if (eventName === ELECTRON_UPDATE_DOWNLOADED) {
        this.onUpdateDownloaded();
        return;
      }

      if (eventName === ELECTRON_VERSION_UPDATED) {
        this.notifyVersionUpdate(event.data);
        return;
      }

      if (eventName === CHECK_FOR_ELECTRON_UPDATE) {
        this.checkForUpdates(true);
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'check_update', 'menu');
        return;
      }
    });
  },

  updateHandler() {
    // populate release notes for current version
    this.fetchReleaseNotes();
    this.checkForUpdates();
  },

  getArch: function () {
    let platform = navigator.platform;

    if (platform === 'Win32' || platform === 'Win64') {
      let userAgent = navigator.userAgent;

      if (_.includes(userAgent, 'WOW64') || _.includes(userAgent, 'Win64')) {
        return '64';
      }

      return '32';
    }

    if (_.includes(platform, 'Linux')) {
      if (_.includes(platform, '64')) {
        return '64';
      }

      return '32';
    }

    return '64';
  },

  getPlatform: function () {
    let platform = navigator.platform;

    if (platform === 'Win32' || platform === 'Win64') {
      let userAgent = navigator.userAgent;

      if (_.includes(userAgent, 'WOW64') || _.includes(userAgent, 'Win64')) {
        return 'WIN64';
      }

      return 'WIN32';
    }

    if (_.includes(platform, 'Linux')) {
      return 'LINUX';
    }

    return 'OSX';
  },

  onUpdateError: function (eventData = {}) {
    let error = eventData.error,
    label = this.get('isAutoDownloaded') ? 'auto_update' : 'manual_update';

    this.set({
      status: 'error',
      data: null,
      releaseNotes: null });

    pm.logger.error('Error in update flow: ' + JSON.stringify(error));
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'error', label);
  },

  applyUpdate: function () {
    this.set({ status: 'applying' });

    // Sending through bus is not recommended here
    // As, the app quits in this case which triggers a crash at times
    _utils_ShellHelper__WEBPACK_IMPORTED_MODULE_7__["default"].sendToMain(APPLY_ELECTRON_UPDATE);
  },

  onUpdateDownloaded: function () {
    this.set({
      status: 'downloaded',
      downloadedTimestamp: Date.now() });

    pm.mediator.trigger('closeSettingsModal');
    !this.get('isAutoDownloaded') && pm.mediator.trigger('showUpdateModal');
  },

  notifyVersionUpdate: function (data = {}) {
    setTimeout(() => {
      let currentVersion = data.currentVersion,
      currentPlatform = window.process.platform + '-' + window.process.arch;

      // Show alert message
      pm.toasts.success('Successfully updated to version ' + currentVersion);

      // Send analytics event
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'updated', null, null, null, { noActiveWorkspace: true });

      // Notify update information to the server.
      _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__["default"].
      get().
      then((user = {}) => {
        Object(_modules_services_APIService__WEBPACK_IMPORTED_MODULE_1__["NotifyServerOfVersionChange"])(user, currentVersion + '-' + currentPlatform);
      });
    }, 5000);
  },

  downloadUpdate: function (isSilent = false, options = {}) {

    this.set({
      status: 'downloading',
      isAutoDownloaded: _.isBoolean(isSilent) ? isSilent : false });

    this.getAdditionalParams(params => {
      let data = this.get('data'),
      eventPayload = {
        channel: _services_AppReleaseService__WEBPACK_IMPORTED_MODULE_4__["default"].getReleaseChannel(),
        version: this.version,
        downloadVersion: this.downloadVersion,
        appId: this.appId,
        userAgent: this.userAgent,
        platform: this.platform,
        arch: this.arch,
        downloadURL: options.downloadURL || data && data.url,
        updateServerDomain: this.updateServerDomain,
        additionalParamsString: params };

      _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__["default"].
      get().
      then((user = {}) => {
        _.assign(eventPayload, { userId: user.id });
        this.updaterEventBus.publish(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])(UPDATE_ELECTRON, APP_UPDATE, eventPayload));
      }).
      catch(e => {
        this.updaterEventBus.publish(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])(UPDATE_ELECTRON, APP_UPDATE, eventPayload));
      });
    });
  },

  noUpdateFound: function () {
    this.set({
      status: 'updateNotAvailable',
      data: null });

  },

  updateFoundWithVersion: function (data) {
    this.set({
      status: 'updateAvailable',
      data: data,
      releaseNotes: null });

    this.fetchReleaseNotes();
  },

  shouldAutoDownload: function (version) {
    let versionDiff = 'major', // Also the reason for keeping the fail proof, hence defaults to major
    autoDownloadUpdateStatus = pm.settings.getSetting('autoDownloadUpdateStatus') || _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_0__["default"].autoDownload.MINOR;

    try {
      versionDiff = semver.diff(pm.app.get('version'), version);
    }

    // throws exception in case of wrong version from ARS. should not be the case as ARS also uses semver,
    // happens only if the data.version node is not available.
    catch (e) {
      console.log(e);
    } finally
    {
      if (autoDownloadUpdateStatus === _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_0__["default"].autoDownload.MINOR) {
        return ['minor', 'preminor', 'patch', 'prepatch', 'prerelease'].includes(versionDiff);
      }
      return autoDownloadUpdateStatus === _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_0__["default"].autoDownload.ALL;
    }
  },

  getAdditionalParams: function (cb) {
    _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__["default"].
    get().
    then((user = {}) => {
      let deviceInfo = pm.app && pm.app.getDeviceInfo(),
      userId = _.toString(user.id) || '0',

      // @todo: until ars starts reading syncEnabled info from service send this flag
      // this flag may or may not be accurate
      syncEnabled = user.syncEnabled || false,
      teamPlan = _.get(user, 'organizations.0.plan', '');

      cb && cb([
      `installationId=${_.get(deviceInfo, 'id')}`,
      `userId=${userId}`,
      `syncEnabled=${syncEnabled}`,
      `teamPlan=${teamPlan}`].
      join('&'));
    }).
    catch(e => {

      // Don't block if anything fails.
      return '';
    });
  },

  getUpdateStatusURL: function (cb) {
    this.getAdditionalParams(params => {
      let updateChannel = _services_AppReleaseService__WEBPACK_IMPORTED_MODULE_4__["default"].getReleaseChannel(),
      appReleaseServerEndpoint = postman_update_server_url + 'update/status?' + [
      `channel=${updateChannel}`,
      `currentVersion=${this.version}`,
      `arch=${this.arch}`,
      `platform=${this.platform.toLowerCase()}`,
      params].
      join('&');

      cb && cb(appReleaseServerEndpoint);
    });
  },

  releaseNotesEndpoint: function (cb) {
    this.getAdditionalParams(params => {
      let updateChannel = _services_AppReleaseService__WEBPACK_IMPORTED_MODULE_4__["default"].getReleaseChannel();
      cb && cb(postman_update_server_url + 'api/version/notes?' + [
      `from=${this.version}`,
      `channel=${updateChannel}`,
      `platform=${this.platform.toLowerCase()}`,
      params].
      join('&'));
    });
  },

  fetchReleaseNotes: function () {
    this.releaseNotesEndpoint(url => {
      _utils_HttpService__WEBPACK_IMPORTED_MODULE_3__["default"].request(url).then(({ body, status }) => {
        if (status === 200) {
          this.set({ releaseNotes: _utils_util__WEBPACK_IMPORTED_MODULE_2__["default"].constructReleaseNotes(body.notes) });
        }
      }).catch(error => {
        console.warn('Error while fetching releaseNotes', error);
      });
    });
  },

  checkForUpdates: function (isManual) {
    let currentStatus = this.get('status');

    if (currentStatus == 'downloading' || currentStatus == 'downloaded') {
      if (isManual) {
        pm.mediator.trigger('closeSettingsModal');
        pm.mediator.trigger('showUpdateModal', { origin: 'manual' });
      }

      return;
    }

    this.set({
      status: 'checking',
      data: null,
      releaseNotes: null });


    if (isManual) {
      pm.mediator.trigger('closeSettingsModal');
      pm.mediator.trigger('showUpdateModal', { origin: 'manual' });
    }

    this.getUpdateStatusURL(url => {
      _utils_HttpService__WEBPACK_IMPORTED_MODULE_3__["default"].request(url).then(({ body, status }) => {
        // setting the downloaded version
        this.downloadVersion = body.version;

        if (status === 200) {
          if (!isManual && this.shouldAutoDownload(body.version)) {
            // silently download the update
            this.downloadUpdate(true, { downloadURL: body.url });
          } else {
            // either it is manual update or it is auto-update but version is major and settings is set to minor

            // show the modal for update and also show the badge over settings icon
            this.updateFoundWithVersion(body);

            // do not show this modal if the user has dismissed it already once
            if (this.get('updateModalDismissed')) {
              return;
            }

            !isManual && pm.mediator.trigger('showUpdateModal', { origin: 'auto' });
            _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('app', 'view_update_available_modal', isManual ? 'manual' : 'auto');
          }
        } else
        if (status === 204) {
          this.noUpdateFound();
        }
      }).catch(err => {
        console.warn('Error while checking for update', err);
        this.set({
          status: 'error',
          data: null,
          releaseNotes: null });

      });
    });
  } });


/* harmony default export */ __webpack_exports__["default"] = (AppUpdateNotifier);

/**
                                   * @typedef {Object} AppUpdateNotifier~releaseNotes
                                   *
                                   * @property {String} name Version name
                                   * @property {Object} notes Release notes
                                   * @property {String[]} notes.Bugfixes bugfixes in the release
                                   * @property {String[]} notes.Improvements improvements in the release
                                   * @property {String[]} notes.Features new features in the release
                                   */
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4305:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// This file should be ES5 compatible
/* eslint prefer-spread:0, no-var:0, prefer-reflect:0, no-magic-numbers:0 */


module.exports = function () {
	// Import Events
	var events = __webpack_require__(131);

	// Export Domain
	var domain = {};
	domain.createDomain = domain.create = function () {
		var d = new events.EventEmitter();

		function emitError(e) {
			d.emit('error', e);
		}

		d.add = function (emitter) {
			emitter.on('error', emitError);
		};
		d.remove = function (emitter) {
			emitter.removeListener('error', emitError);
		};
		d.bind = function (fn) {
			return function () {
				var args = Array.prototype.slice.call(arguments);
				try {
					fn.apply(null, args);
				}
				catch (err) {
					emitError(err);
				}
			};
		};
		d.intercept = function (fn) {
			return function (err) {
				if (err) {
					emitError(err);
				} else
				{
					var args = Array.prototype.slice.call(arguments, 1);
					try {
						fn.apply(null, args);
					}
					catch (err) {
						emitError(err);
					}
				}
			};
		};
		d.run = function (fn) {
			try {
				fn();
			}
			catch (err) {
				emitError(err);
			}
			return this;
		};
		d.dispose = function () {
			this.removeAllListeners();
			return this;
		};
		d.enter = d.exit = function () {
			return this;
		};
		return d;
	};
	return domain;
}.call(this);

/***/ }),

/***/ 4306:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(784);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1269);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(742);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(769);




let

ElectronTCPReader = class ElectronTCPReader {

  constructor() {

    _.assign(this, {
      socketId: null,
      socketInfo: null,
      port: '5005',
      target_type: 'history',
      target_id: '',
      status: 'disconnected',
      filters: {
        url: '',
        url_disabled: '',
        methods: '',
        status_codes: '',
        content_type: '' } });



    let readerSettings = localStorage.getItem('readerSettings'),
    readerSettingsJSON = null;
    try {
      if (!_.isEmpty(readerSettings)) {
        readerSettingsJSON = JSON.parse(readerSettings);
      }
    }

    catch (e) {
      pm.logger.error('Error in parsing proxy settings');
    } finally
    {
      if (!_.isEmpty(readerSettingsJSON)) {
        _.assign(this, _.pick(readerSettingsJSON, ['port', 'target_type', 'target_id', 'filters']));
      }
    }

    pm.appWindow.trigger('registerInternalEvent', 'proxyRequestCaptured', this.onProxyRequestCaptured, this);
    pm.appWindow.trigger('registerInternalEvent', 'proxyClosed', this.onProxyClosed, this);

    pm.appWindow.trigger('registerInternalEvent', 'proxyNotif', this.onProxyNotif, this);
  }

  save() {
    localStorage.setItem('readerSettings', JSON.stringify(_.pick(this, ['port', 'target_type', 'target_id', 'filters'])));
  }

  onProxyClosed() {
    this.stopListening();
    this.status = 'disconnected';
    pm.trigger('proxyStatusChanged', this.status);
  }

  onProxyNotif(action, result) {
    if (action == 'start') {
      pm.mediator.trigger(
      result == 'success' ? 'proxyStartSuccess' : 'proxyStartFailure');

    } else
    if (action == 'stop') {
      pm.mediator.trigger(
      result == 'success' ? 'proxyStopSuccess' : 'proxyStopFailure');

    }
  }

  onProxyRequestCaptured(requestObject) {
    var url = requestObject.url,
    method = requestObject.method,
    headers = requestObject.headers,
    data = requestObject.data;

    requestObject = {
      url: url,
      method: method,
      headers: headers,
      data: data,
      name: url };


    console.log('Recd request from proxy: ' + url + ', ' + method);
    this.addRequestObject(requestObject);
  }

  isAllowed(request, filters) {

    var methods;

    // Captured request URL should contain the URL in the proxy 'URL Contains' filter
    if (filters.url && filters.url.trim() && request.url.search(filters.url.trim()) < 0) {
      return false;
    }

    // Captured request URL should not contain the URL in the 'URL Does not Contain' filter
    if (filters.url_disabled && filters.url_disabled.trim() && request.url.search(filters.url_disabled.trim()) >= 0) {
      return false;
    }

    methods = filters.methods ? filters.methods.split(',') : [];

    methods = methods.map(method => {
      return method.trim().toUpperCase();
    }).filter(method => {
      return method.length > 0;
    });

    methods = _.uniq(methods);

    // Captured request method should belong to proxy 'Methods' filters (if any)
    if (methods.length > 0 && !methods.includes(request.method.toUpperCase())) {
      return false;
    }

    return true;
  }

  checkTarget(id) {
    var collections = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').collections,
    collection = _.find(collections, item => {return item.id === id;}),
    editPermission = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('PermissionStore').can('edit', 'collection', id);

    return collection && editPermission;
  }

  addRequestObject(request) {
    var target_type = this.target_type,
    collection,
    target_id,
    filters = this.filters;

    // console.log("Settings are", this.toJSON());
    if (this.isAllowed(request, filters)) {
      // modify request for sync
      let headerData = [];
      request.headerData = _.map(_.keys(request.headers), key => {
        return {
          key,
          value: request.headers[key] };

      });

      if (request.data) {
        request.dataMode = 'raw';
      }

      if (_.find(headerData, { value: 'application/x-www-form-urlencoded' })) {
        request.dataMode = 'urlencoded';
        request.data = _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].unpackUrlEncodedData(request.data);
      }

      if (this.checkTarget(this.target_id)) {
        _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_4__["default"].
        get().
        then(user => {
          target_id = this.target_id;

          _.assign(request, {
            id: _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].guid(),
            collection: target_id,
            owner: user.id });


          let requestCreateEvent = {
            name: 'create_deep',
            namespace: 'request',
            data: { request },
            target: {
              model: 'collection',
              modelId: target_id } };


          Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(requestCreateEvent).
          then(response => {
            if (!_.isEmpty(_.get(response, 'error'))) {
              pm.logger.error('Error in creating collection from tcp', response.error);
              return;
            }
          });
        }).
        catch(err => {
          pm.logger.error('Error while creating collection from tcp', err);
        });
      } else
      {
        _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_4__["default"].
        get().
        then(user => {
          if (!user) {
            pm.logger.error(new Error('ElectronTCPReader: Could not create history. Current user is missing.'));
            return;
          }

          let currentDate = new Date(),
          workspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').workspace,
          historyCreateEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["createEvent"])(
          'create',
          'history',
          _.assign({}, request, { id: _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].guid(), createdAt: currentDate.toISOString(), workspace, owner: user.id, lastUpdatedBy: user.id }));


          return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(historyCreateEvent).
          catch(e => {console.log('Error in creating history through proxy', e);});
        });
      }
    }
  }

  startListening() {
    var model = this;

    var portToUse = this.port;

    pm.appWindow.sendToElectron({
      event: 'startProxy',
      data: { port: portToUse } });


    this.status = 'connected';
    pm.mediator.trigger('proxyStatusChanged', this.status);

  }

  stopListening() {
    pm.appWindow.sendToElectron({
      event: 'stopProxy',
      data: {} });

    this.status = 'disconnected';
    pm.mediator.trigger('proxyStatusChanged', this.status);
  }

  connect() {
    this.startListening();
    this.status = 'connected';
    pm.mediator.trigger('proxyStatusChanged', this.status);
  }

  disconnect() {
    this.stopListening();
    this.status = 'disconnected';
    pm.mediator.trigger('proxyStatusChanged', this.status);
    let interceptor = document.getElementsByClassName('icon-navbar-interceptor')[0];
    !_.isEmpty(interceptor) && interceptor.classList.remove('active');
  }};


/* harmony default export */ __webpack_exports__["default"] = (ElectronTCPReader);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4307:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_0__);

const Certificate = backbone__WEBPACK_IMPORTED_MODULE_0___default.a.Model.extend({
  defaults: function () {
    return {
      host: '',
      pemPath: '',
      keyPath: '',
      pfxPath: '',
      passphrase: null };

  },

  toJSON: function () {
    return {
      host: this.get('host'),
      pemPath: this.get('pemPath'),
      keyPath: this.get('keyPath'),
      pfxPath: this.get('pfxPath'),
      passphrase: this.get('passphrase') };

  } });



const CertificateManager = backbone__WEBPACK_IMPORTED_MODULE_0___default.a.Collection.extend({
  model: Certificate,

  initialize: function () {
    this.loadCertificates();
    pm.settings.on('setSetting:clientCertificates', this.loadCertificates, this);
  },

  loadCertificates: function () {
    let serialisedStore = pm.settings.getSetting('clientCertificates'),
    certificateStore = {};

    try {
      certificateStore = JSON.parse(serialisedStore);
      let certificates = _.get(certificateStore, 'certificates', []);
      let sanitizedCertificates = _.map(certificates, certificate => {
        let sanitizedHost = certificate.host.
        replace(/.*?:\/\//g, '') // strip protocol
        .replace(/\?.*/, '') // strip query
        .replace(/\/.*/, '') // strip path
        .replace(/^\./, ''); // strip leading period

        return _.assign({}, certificate, { host: sanitizedHost });
      });
      this.reset(sanitizedCertificates);
    }
    catch (e) {
      pm.logger.error('Error loading certificates', e);
    }
  },

  saveCertificates: function () {
    let certificateStore = { certificates: this.toJSON() };

    try {
      let serialisedStore = JSON.stringify(certificateStore);
      pm.settings.setSetting('clientCertificates', serialisedStore);
    }
    catch (e) {
      pm.logger.error('Error saving certificates', e);
    }
  },

  findCertificateByDomain: function (host) {
    return _.find(this.models, certificateModel => {
      return host === certificateModel.get('host');
    });
  },

  addCertificate(host, pemPath, keyPath, pfxPath, passphrase) {
    if (!host) {
      pm.logger.error('Error adding certificate', arguments);
      return;
    }

    let certificate = this.findCertificateByDomain(host);

    if (certificate) {
      this.updateCertificate(host, pemPath, keyPath, pfxPath, passphrase);
    } else
    {
      this.add({
        host: host,
        pemPath: pemPath,
        keyPath: keyPath,
        pfxPath: pfxPath,
        passphrase: passphrase });

    }

    this.saveCertificates();
    return true;
  },

  updateCertificate(host, pemPath, keyPath, pfxPath, passphrase) {
    let certificate = this.findCertificateByDomain(host);

    if (!certificate) {
      return false;
    }

    certificate.set({
      pemPath: pemPath,
      keyPath: keyPath,
      pfxPath: pfxPath,
      passphrase: passphrase });


    this.saveCertificates();

    return true;
  },

  removeCertificate(host) {
    let certificate = this.findCertificateByDomain(host);

    if (!certificate) {
      return false;
    }

    this.remove(certificate);

    this.saveCertificates();

    return true;
  } });


/* harmony default export */ __webpack_exports__["default"] = (CertificateManager);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4308:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var electron__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(62);
/* harmony import */ var electron__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(electron__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apinetwork_controllers_APINetworkImporter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1663);
/* harmony import */ var _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(765);
/* harmony import */ var _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(748);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};




const POSTMAN_PROTOCOL = 'postman:',

/**
                                      * Map for model and action in postman URL to its handler function.
                                      * New handleres can be registered here.
                                      */
ACTION_HANDLER_MAP = {
  'collections': {
    'import': function () {
      return _apinetwork_controllers_APINetworkImporter__WEBPACK_IMPORTED_MODULE_1__["default"];
    } },

  'oauth2': {
    'callback': function () {
      return urlData => {
        pm.mediator.trigger('oauth2Callback', urlData);
      };
    } } };



const ProtocolHandler = {
  initialize: function (cb) {
    let channel = pm.eventBus.channel('protocol-handler');
    channel.subscribe(ProtocolHandler.onProtocolEvent);

    cb && cb(null);
  },

  onProtocolEvent: function (params) {
    _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_2___default.a.getCurrentWindow().
    then(window => {
      let currentWindowId = window.id;

      if (currentWindowId !== params.windowId) return;

      ProtocolHandler.handleProtocolUrl(params.url);
    });
  },

  /**
      * Creates url object for given url
      *
      * @param {string} url returns the string
      */
  getURLObject: function (url) {
    return new URL(url);
  },

  /**
      * Validates the postman URL structure and routing to specific handler function based on
      * action in URL. The format of URL should be in
      *
      * postman://app/<model>/<action>/<entityId>?<query_params>#URL_hash
      *
      * @param {string} url Custom protocol URL
      */
  handleProtocolUrl: async function (url) {
    let urlObject,
    urlParts,
    urlData,
    traceId,
    protocolHandler;

    try {
      urlObject = ProtocolHandler.getURLObject(url),
      traceId = urlObject.searchParams.get('traceId');

      if (_.get(urlObject, 'protocol') !== POSTMAN_PROTOCOL) {
        throw new Error('ProtocolHandler~handleProtocolUrl: Incorrect Protocol, url: ' + url);
      }

      urlParts = urlObject.pathname.slice(2).split('/');

      if (_.get(urlParts, '[0]') !== 'app') {
        throw new Error('ProtocolHandler~handleProtocolUrl: Incorrect URL format, url: ' + url);
      }

      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2(_extends({
        category: 'postman_protocol',
        action: 'parse_url',
        label: 'success',
        entityType: 'model' },
      traceId && { traceId }));

    } catch (e) {
      pm.logger.error(e);

      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2(_extends({
        category: 'postman_protocol',
        action: 'parse_url',
        label: 'failure',
        entityType: 'model' },
      traceId && { traceId }));


      return Promise.reject(e);
    }

    try {
      urlData = {
        model: urlParts[1],
        action: urlParts[2],
        entityId: urlParts[3],
        queryString: urlObject.search,
        hash: urlObject.hash,
        urlObject };


      protocolHandler = _.get(ACTION_HANDLER_MAP, [urlData.model, urlData.action]);

      if (!_.isFunction(protocolHandler)) {
        throw new Error('ProtocolHandler~handleProtocolUrl: Incorrect Action, url: ' + url);
      }

      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2(_extends({
        category: 'postman_protocol',
        action: 'find_handler',
        label: 'success',
        entityType: 'model' },
      traceId && { traceId }));


      await protocolHandler()(urlData);
    } catch (e) {
      pm.logger.error(e);

      if (_.isString(e.message) && e.message.includes('ProtocolHandler~handleProtocolUrl: Incorrect Action')) {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2(_extends({
          category: 'postman_protocol',
          action: 'find_handler',
          label: 'failure',
          entityType: 'model' },
        traceId && { traceId }));

      }

      return Promise.reject(e);
    }
  } };


/* harmony default export */ __webpack_exports__["default"] = (ProtocolHandler);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4309:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(742);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(664);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(async__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _UIEventService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1755);





let allowedEvents = [
'created', 'updated', 'deleted', 'duplicated', 'shared', 'favorited', 'unfavorited',
'joined', 'left', 'added_dependencies', 'removed_dependencies', 'response',
'authenticated', 'skip', 'createdOnSync'],

modelEventHandlers = {
  forkedcollection: function (eventProps) {
    switch (eventProps.name) {
      case 'createdOnSync':
        return createPayload('forkCreated', eventProps.data);}

  },

  collection: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('collectionCreated', eventProps.data);
      case 'duplicated':
        return createPayload('collectionDuplicated', eventProps.data);
      case 'shared':
        return createPayload('collectionShared', eventProps.data);
      case 'favorited':
        return createPayload('collectionFavorited', eventProps.data);
      case 'unfavorited':
        return createPayload('collectionUnfavorited', eventProps.data);
      case 'deleted_deep':
        return createPayload('collectionDeleted', eventProps.data);}

  },

  environment: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('environmentCreated', eventProps.data);
      case 'duplicated':
        return createPayload('environmentDuplicated', eventProps.data);
      case 'deleted':
        return createPayload('environmentDeleted', eventProps.data);}

  },

  folder: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('folderCreated', eventProps.data);
      case 'duplicated':
        return createPayload('folderDuplicated', eventProps.data);
      case 'deleted_deep':
        return createPayload('folderDeleted', eventProps.data);}

  },

  headerpreset: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('headerpresetCreated', eventProps.data);
      case 'deleted':
        return createPayload('headerpresetDeleted', eventProps.data);}

  },

  history: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('historyCreated', eventProps.data);
      case 'deleted':
        return createPayload('historyDeleted', eventProps.data);}

  },

  response: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('exampleCreated', eventProps.data);
      case 'deleted':
        return createPayload('exampleDeleted', eventProps.data);}

  },

  request: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('requestCreated', eventProps.data);
      case 'duplicated':
        return createPayload('requestDuplicated', eventProps.data);
      case 'deleted':
        return createPayload('requestDeleted', eventProps.data);}

  },

  workspace: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('workspaceCreated', eventProps.data);
      case 'deleted':
        return createPayload('workspaceDeleted', eventProps.data);
      case 'added_dependencies':
        return createPayload('workspaceDependenciesAdded', eventProps.data);
      case 'removed_dependencies':
        return createPayload('workspaceDependenciesRemoved', eventProps.data);
      case 'joined':
        return createPayload('workspaceJoined', eventProps.data);
      case 'left':
        return createPayload('workspaceLeft', eventProps.data);}

  },

  monitor: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('monitorCreated', eventProps.data);
      case 'deleted':
        return createPayload('monitorDeleted', eventProps.data);}

  },

  mock: function (eventProps) {
    switch (eventProps.name) {
      case 'created':
        return createPayload('mockCreated', eventProps.data);
      case 'deleted':
        return createPayload('mockDeleted', eventProps.data);}

  },

  requestexecution: function (eventProps) {
    switch (eventProps.name) {
      case 'response':
        return createPayload('responseMetaReceived', eventProps.data);}

  },

  authentication: function (eventProps) {
    switch (eventProps.name) {
      case 'authenticated':
        return createPayload('userSignedIn', eventProps.data);
      case 'skip':
        return createPayload('userSkippedSignIn', eventProps.data);}

  } };




const ERROR_UNSUPPORTED_ACTOR = 'UNSUPPORTED_ACTOR';

/**
                                                      * @param name {String} - Name of the event
                                                      * @param data {any} - Data associated with the event
                                                      * @param meta {object} - Any meta information associated with the event
                                                      */
function createPayload(name, data, meta) {
  return {
    name,
    data,
    meta };

}

/**
   * filter non user events
   *
   * @param {any} event
   * @param {any} callback
   */
function filterUnsupportedEvents(event, callback) {
  let actor = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_0__["getActor"])(event),
  actorType = actor && actor.type;

  // whitelist only USER actions
  if (!_.includes(['USER'], actorType)) {
    callback(new Error(ERROR_UNSUPPORTED_ACTOR));
    return;
  }

  callback(null, event);
}

/**
   * build analytics payloads from event
   *
   * @param {any} event
   * @param {any} callback
   */
function buildUIEventFromModelEvent(event, callback) {
  eventTransformer(event, (err, payloads) => {
    if (err) {
      callback(err);
      return;
    }

    callback(null, payloads);
  });
}

/**
   * queue analytic events
   *
   * @param {any} payloads
   * @param {any} callback
   */
function emitUIEvent(events, callback) {
  // bail if no payload to queue
  if (_.isEmpty(events)) {
    return callback(null);
  }

  _.each(events, event => {
    _UIEventService__WEBPACK_IMPORTED_MODULE_2__["default"].publish(event.name, event.data, event.meta);
  });
  callback(null);
}

/**
   * Job of this function is to transform events from different event buses to UIEvents
   * e.g model-event, postman-runtime.
   *
   *
   * @param event {Object} - model event
   * @param callback {function}
   */
function eventTransformer(event, callback) {
  if (!event) {
    return callback();
  }

  let payloads = [];

  Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_0__["processEvent"])(event, allowedEvents, function (event, cb) {
    let namespace = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_0__["getEventNamespace"])(event),
    name = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_0__["getEventName"])(event),
    data = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_0__["getEventData"])(event),
    meta = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_0__["getEventMeta"])(event),
    handler = modelEventHandlers[namespace],
    eventProps = {
      data: data,
      name: name,
      meta: meta || {} },

    eventPayload;

    // this should never happen
    if (!handler) {
      return cb();
    }

    // convert events to payloads and accumulate
    eventPayload = handler(eventProps);
    if (!_.isEmpty(eventPayload)) {
      payloads.push(eventPayload);
    }

    return cb();
  }, function () {
    callback && callback(null, payloads);
  });
}

/**
   * handle broadcast bus event
   *
   * @param {any} event
   */
function handleBusEvent(event) {
  async__WEBPACK_IMPORTED_MODULE_1___default.a.waterfall([
  function (callback) {
    callback(null, event);
  },

  filterUnsupportedEvents,
  buildUIEventFromModelEvent,
  emitUIEvent],
  function (err) {
    err &&
    !_.includes([ERROR_UNSUPPORTED_ACTOR], err && err.message) &&
    pm.logger.error(err);
  });
}

/**
   * @param {any} event
   */
function handleRuntimeBusEvent({ id, event }) {
  async__WEBPACK_IMPORTED_MODULE_1___default.a.waterfall([
  function (callback) {
    callback(null, {
      namespace: 'requestexecution',
      name: event,
      data: { id } });

  },
  buildUIEventFromModelEvent,
  emitUIEvent],
  function (err) {
    err &&
    !_.includes([ERROR_UNSUPPORTED_ACTOR], err && err.message) &&
    pm.logger.error(err);
  });
}

/**
   * @param {any} event
   */
function handleAuthHandlerEvents(event) {
  async__WEBPACK_IMPORTED_MODULE_1___default.a.waterfall([
  function (callback) {
    callback(null, event);
  },
  buildUIEventFromModelEvent,
  emitUIEvent],
  function (err) {
    err &&
    !_.includes([ERROR_UNSUPPORTED_ACTOR], err && err.message) &&
    pm.logger.error(err);
  });
}


/**
   *
   */
/* harmony default export */ __webpack_exports__["default"] = ({
  initialize() {
    let modelEventChannel = pm.eventBus.channel('model-events'),
    authHandlerEventChannel = pm.eventBus.channel('auth-handler-events');

    modelEventChannel.subscribe(handleBusEvent);
    authHandlerEventChannel.subscribe(handleAuthHandlerEvents);

    // Runtime does not publish to the event bus, he handing the events through agents
    pm.runtime.agent.on('events', handleRuntimeBusEvent);
  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4310:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(749);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(784);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1269);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(742);
/* harmony import */ var base64_arraybuffer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4311);
/* harmony import */ var base64_arraybuffer__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(base64_arraybuffer__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(769);
/* harmony import */ var _utils_InterceptorUtil__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4088);
/* harmony import */ var _utils_InterceptorUtil__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_utils_InterceptorUtil__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4087);
/* harmony import */ var _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_InterceptorBridge__WEBPACK_IMPORTED_MODULE_7__);









const semver = __webpack_require__(1634);let

InterceptorManager = class InterceptorManager {
  constructor() {

    // [INTERCEPT-15] maintaining a boolean variable to avoid multiple 'Disconnected from Interceptor' logs
    var isDisconnectedFromInterceptorBridge = false,
    isInterceptorBridgeInstalled = false,
    installationStatus = 'BRIDGE_NOT_YET_INSTALLED',
    connectionStatus,

    channel = pm.eventBus.channel('interceptor-store'),

    // store for interceptor settings
    interceptorSettingsStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorSettingsStore'),

    // store for installation of interceptor installation states
    interceptorInstallationUIStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorInstallationUIStore'),

    // fetching domain list in sync with Interceptor from store
    syncDomainList = interceptorSettingsStore.getSyncDomainList();

    // the ipcClient will be connected to the interceptorBridge
    // as soon as the main process of app loads
    pm.appWindow.sendToElectron({
      event: 'initializeInterceptorBridge' });


    // sending cookie sync options (domain list, enabled) to Interceptor as soon as App is connected to Interceptor
    this.enableCookieSyncFromInterceptor();

    // sending request capture options to Interceptor as soon as App is connected to Interceptor
    this.configureRequestCaptureFromInterceptor();

    // preserving state to avoid the multiple logs of KEY_MISMATCH errors
    // false once app loads, true after first KEY_MISMATCH error occurs
    interceptorSettingsStore.updateKeyMismatchSettings(false);

    // asking main to send the custom encryption key if it's set
    if (interceptorSettingsStore.customKeyInitialized) {
      pm.appWindow.sendToElectron({
        event: 'fetchCustomEncryptionKey' });

    }

    // handling events to update the interceptor store
    // to maintain the consistency across the multiple open renderer windows
    channel.subscribe(this.UIEventHandler);

    // handles the interceptor response based on their types
    pm.appWindow.trigger('registerInternalEvent', 'interceptorResponse', function (data) {
      pm.mediator.trigger('onMessageExternal', data);

      // if payload received from interceptor contains extension info,
      // we check for min version required
      // interceptor gets disconnected if min version criteria is not satisfied
      if (data.extensionInfo && data.extensionInfo.version) {
        if (semver.compare(data.extensionInfo.version, interceptorSettingsStore.minExtensionVersion) == -1) {
          console.log('Current extension is', data.extensionInfo.version, '. Min extension version required is ', interceptorSettingsStore.minExtensionVersion);

          // making interceptor disconnected if minVersion criteria is not satisfied
          interceptorSettingsStore.updateInterceptorBridgeConnectionStatus(false);

          // notifying interceptor that min version criteria is not satisfied
          pm.appWindow.sendToElectron({
            event: 'forwardInterceptorRequest',
            message: {
              type: 'REQUIRE_VERSION_UPDATE',
              postmanMessage: {
                satisfied: false,
                minExtensionVersion: interceptorSettingsStore.minExtensionVersion } } });



          interceptorSettingsStore.updateMinExtensionVersionSatisfiedFlag(false);
          interceptorSettingsStore.updateMinVersionSatisfied(false);

        } else
        {
          this.handleInterceptorResponse(data);
        }

        // the encryption UI will be shown only if version criteria satisfies
        if (semver.compare(data.extensionInfo.version, interceptorSettingsStore.minExtensionVersionForCustomEncryption) == -1) {
          interceptorSettingsStore.updateMinExtensionVersionForCustomEncryptionSatisfiedFlag(false);
        }
      } else
      {
        this.handleInterceptorResponse(data);
      }
    }, this);

    // logs the encryption key being used for App ~ Interceptor communication
    pm.appWindow.trigger('registerInternalEvent', 'fetchEncryptionKey', function (data) {
      console.log('InterceptorBridge Encryption Key : ', data.key);
    }, this);

    pm.appWindow.trigger('registerInternalEvent', 'fetchCustomEncryptionKey', function (data) {
      interceptorSettingsStore.updateCustomEncryptionKey(data.key);
    }, this);

    // logs the list of domains in sync
    pm.appWindow.trigger('registerInternalEvent', 'getSyncDomainListForInterceptor', function () {
      if (!syncDomainList) {
        console.log('InterceptorBridge : No domains found');
      } else
      {
        console.log('InterceptorBridge : Domain List ', syncDomainList);
      }
    }, this);

    // confirms interceptor bridge is connected
    pm.appWindow.trigger('registerInternalEvent', 'updateInterceptorBridgeConnectionStatus', function (msg) {
      connectionStatus = msg.data.connectedToPostman;

      // here, interceptor bridge is connected with postman app
      if (connectionStatus) {
        console.log('Connected to Interceptor');
        isDisconnectedFromInterceptorBridge = false;
        isInterceptorBridgeInstalled = true;

        // updates the connection status and installed status
        interceptorSettingsStore.updateInterceptorBridgeConnectionStatus(connectionStatus);
        interceptorSettingsStore.updateInterceptorBridgeInstallationStatus(isInterceptorBridgeInstalled);
      } else
      {
        if (!isDisconnectedFromInterceptorBridge) {
          console.log('Disconnected from Interceptor');
          isDisconnectedFromInterceptorBridge = true;
          pm.interceptorInstaller.checkInstallationStatus();
        }
      }

      // re-send cookie sync options to interceptor
      this.enableCookieSyncFromInterceptor();

      // re-send request capture options to interceptor
      this.configureRequestCaptureFromInterceptor();


    }, this);

    pm.appWindow.trigger('registerInternalEvent', 'interceptorBridgeInstallationStatusResponse', function (data) {
      if (isDisconnectedFromInterceptorBridge) {
        if (data.status.platformSpecific.os === 'MACOS') {
          if (!data.status.platformSpecific.nodeInstalled) {
            installationStatus = 'MACOS_NODE_NOT_YET_INSTALLED';
            isInterceptorBridgeInstalled = false;
          } else
          {
            if (data.status.manifestAdded && data.status.interceptorBridgeInstalled) {
              isInterceptorBridgeInstalled = true;
            } else
            {
              isInterceptorBridgeInstalled = false;
              installationStatus = 'BRIDGE_NOT_YET_INSTALLED';
            }
          }
        } else
        if (data.status.platformSpecific.os === 'WINDOWS') {
          if (data.status.manifestAdded && data.status.interceptorBridgeInstalled && data.status.platformSpecific.registryKeyAdded) {
            isInterceptorBridgeInstalled = true;
          } else
          {
            isInterceptorBridgeInstalled = false;
            installationStatus = 'BRIDGE_NOT_YET_INSTALLED';
          }
        } else
        if (data.status.platformSpecific.os === 'LINUX') {
          if (data.status.manifestAdded && data.status.interceptorBridgeInstalled) {
            isInterceptorBridgeInstalled = true;
          } else
          {
            isInterceptorBridgeInstalled = false;
            installationStatus = 'BRIDGE_NOT_YET_INSTALLED';
          }
        }
        interceptorSettingsStore.updateInterceptorBridgeInstallationStatus(isInterceptorBridgeInstalled);
        interceptorInstallationUIStore.updateInitialInstallationStatus(installationStatus);
        interceptorSettingsStore.updateInterceptorBridgeConnectionStatus(connectionStatus);
      }
    }, this);

    pm.appWindow.trigger('registerInternalEvent', 'refreshInterceptorBridgeConnectionStatus', function (msg) {
      if (msg.connectedToInterceptorBridge) {
        console.log('Connected to Interceptor');
        interceptorSettingsStore.updateInterceptorBridgeConnectionStatus(msg.connectedToInterceptorBridge);
      }
    }, this);

  }

  /**
     *
     * Updates `InterceptorSettingStore` according to the event.name.
     * The current renderer window publishes events for other open renderer windows
     * to update the store and hence UI.
     *
     * @param {Object} event contains namespace, name, data
     * Note: For interceptor settings store related events, event.namespace will always be `update-interceptor-store`
     */
  UIEventHandler(event) {
    var interceptorSettingsStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorSettingsStore');
    if (event.namespace === 'update-interceptor-store') {
      if (event.name === 'enableCookieSync') {
        interceptorSettingsStore.updateCookieSyncEnabledSettings(true);
      } else
      if (event.name === 'disableCookieSync') {
        interceptorSettingsStore.updateCookieSyncEnabledSettings(false);
      } else
      if (event.name === 'updateDomainList') {
        interceptorSettingsStore.updateSyncDomainList(event.data);
      } else
      if (event.name === 'enableRequestCapture') {
        interceptorSettingsStore.updateCaptureRequestEnabledSettings(true);
      } else
      if (event.name === 'disableRequestCapture') {
        interceptorSettingsStore.updateCaptureRequestEnabledSettings(false);
      } else
      if (event.name === 'updateRequestFilters') {
        interceptorSettingsStore.updateRequestCaptureFilters(event.data);
      } else
      {
        console.log('Received unknown event', event);
      }
    }
  }

  handleInterceptorResponse(data) {
    var interceptorSettingsStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorSettingsStore');
    if (data.type === 'COOKIE_DUMP') {
      if (interceptorSettingsStore.isCookieSyncEnabled()) {
        interceptorSettingsStore.updateKeyMismatchSettings(false);
        this.addCookiesToApp(data.message);
      }
    } else
    if (data.type === 'REQUIRE_VERSION_UPDATE') {
      console.log(`Min Postman App version required is ${data.postmanMessage.minAppVersion}, please upgrade Postman App`);

      // lower version of App is present, need an update
      interceptorSettingsStore.updateMinAppVersion(data.postmanMessage.minAppVersion);
      interceptorSettingsStore.updateMinExtensionVersionSatisfiedFlag(true);
      interceptorSettingsStore.updateMinVersionSatisfied(false);

      // changing the Interceptor connected status to false
      interceptorSettingsStore.updateInterceptorBridgeConnectionStatus(false);

    } else
    if (data.type === 'COOKIE_REMOVED') {
      if (interceptorSettingsStore.isCookieSyncEnabled()) {
        interceptorSettingsStore.updateKeyMismatchSettings(false);
        this.deleteCookiesFromApp(data.message);
      }
    } else
    if (data.type === 'COOKIE_UPDATED') {
      if (interceptorSettingsStore.isCookieSyncEnabled()) {
        interceptorSettingsStore.updateKeyMismatchSettings(false);
        this.addCookiesToApp(data.message);
      }
    } else
    if (data.type === 'UPDATED_DOMAIN_LIST') {
      if (interceptorSettingsStore.isCookieSyncEnabled()) {
        interceptorSettingsStore.updateKeyMismatchSettings(false);

        // updating local sync domain list
        this.syncDomainList = data.postmanMessage.syncDomainList;

        // updating store
        interceptorSettingsStore.updateAcknowledgedDomainList(data.postmanMessage.syncDomainList);

        console.log('INTERCEPTOR CONNECTIVITY: Updated domain list : ', this.syncDomainList);
      }
    } else
    if (data.type === 'ADD_DOMAIN_ACK') {
      if (interceptorSettingsStore.isCookieSyncEnabled()) {
        interceptorSettingsStore.updateKeyMismatchSettings(false);
        interceptorSettingsStore.addNewAcknowledgedDomain(data.postmanMessage.domain);
      }
    } else
    if (data.type === 'REMOVE_DOMAIN_ACK') {
      if (interceptorSettingsStore.isCookieSyncEnabled()) {
        interceptorSettingsStore.updateKeyMismatchSettings(false);
        interceptorSettingsStore.removeAcknowledgedDomain(data.postmanMessage.domain);
      }
    } else
    if (data.type === 'KEY_MISMATCH') {
      if (!interceptorSettingsStore.isKeymismatch()) {
        console.log('INTERCEPTOR CONNECTIVITY: Key mismatched between Interceptor and Postman App');
        interceptorSettingsStore.updateKeyMismatchSettings(true);
      }
    } else
    if (data.type === 'KEY_VALIDATION_RESULT') {
      var validationResults = data;

      // validation is true only if the keys are same at app and interceptor
      if (validationResults.data.validation) {
        console.log('INTERCEPTOR CONNECTIVITY: App / Interceptor encryption keys match');
        interceptorSettingsStore.updateKeyMismatchSettings(false);
      } else
      {
        console.log('INTERCEPTOR CONNECTIVITY: App / Interceptor encryption keys mismatch');
        interceptorSettingsStore.updateKeyMismatchSettings(true);
      }
    } else
    if (data.type === 'CONFIGURE_COOKIE_SYNC_ACK') {
      if (data.postmanMessage.enabled) {
        console.log('INTERCEPTOR CONNECTIVITY: Configure cookie sync acknowledged');
      } else
      {
        console.log('INTERCEPTOR CONNECTIVITY: Configure cookie sync stopped');
      }
      interceptorSettingsStore.updateKeyMismatchSettings(false);
    } else
    if (data.type === 'ENABLE_COOKIE_SYNC_ACK') {
      if (data.postmanMessage.enabled) {
        console.log('INTERCEPTOR CONNECTIVITY: Cookie Sync enabled for the domains - ', data.postmanMessage.syncDomainList);
      } else
      {
        console.log('INTERCEPTOR CONNECTIVITY: cookie sync disabled');
      }
      interceptorSettingsStore.updateKeyMismatchSettings(false);
      interceptorSettingsStore.updateAcknowledgedDomainList(data.postmanMessage.syncDomainList);

    } else
    if (data.type === 'CONFIGURE_REQUEST_CAPTURE_ACK') {
      if (data.postmanMessage.enabled) {
        console.log('INTERCEPTOR CONNECTIVITY: Capture requests enabled');
      } else
      {
        console.log('INTERCEPTOR CONNECTIVITY: Capture requests disabled');
      }
      interceptorSettingsStore.updateKeyMismatchSettings(false);
    } else
    if (data.type === 'CAPTURED_REQUEST') {
      interceptorSettingsStore.updateKeyMismatchSettings(false);
      if (interceptorSettingsStore.isRequestCaptureEnabled()) {
        this.addRequestObject(data.message.postmanMessage.request);
      }
    } else
    if (data.type === 'REQUEST_ENABLE_COOKIE_SYNC') {
      if (data.postmanMessage.enabled) {
        // Interceptor requesting to enable cookie sync
        _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default.a.cookieSync.enable();
      } else
      {
        // Interceptor requesting to disable cookie sync
        _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default.a.cookieSync.disable();
      }
    } else
    if (data.type === 'REQUEST_ADD_DOMAIN') {
      // Interceptor requesting to add a domain
      _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default.a.cookieSync.addDomain(data.postmanMessage.value);
    } else
    if (data.type === 'REQUEST_REMOVE_DOMAIN') {
      // Interceptor requesting to remove a domain
      _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default.a.cookieSync.removeDomain(data.postmanMessage.value);
    } else
    if (data.type === 'REQUEST_CONFIGURE_REQUEST_CAPTURE') {

      // updating filters if any
      if (data.postmanMessage.filters) {
        interceptorSettingsStore.updateRequestCaptureFilters({
          url: data.postmanMessage.filters.url,
          methods: data.postmanMessage.filters.method });

      }

      if (data.postmanMessage.enabled) {
        // Interceptor requesting to enable request capture
        _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default.a.requestCapture.enable();
      } else
      {
        // Interceptor requesting to disable request capture
        _InterceptorBridge__WEBPACK_IMPORTED_MODULE_7___default.a.requestCapture.disable();
      }
    } else
    {
      console.log(data);
    }
  }

  enableCookieSyncFromInterceptor() {

    var interceptorSettingsStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorSettingsStore');

    // fetching domain list in sync with Interceptor from store
    var syncDomainList = interceptorSettingsStore.getSyncDomainList(),
    enabled = interceptorSettingsStore.isCookieSyncEnabled();

    // syncing back all cookies after App establishes connection with Interceptor bridge
    pm.appWindow.sendToElectron({
      event: 'forwardInterceptorRequest',
      message: {
        type: 'ENABLE_COOKIE_SYNC',
        postmanMessage: {
          enabled,
          syncDomainList } } });



  }

  configureRequestCaptureFromInterceptor() {
    var interceptorSettingsStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorSettingsStore'),
    enabled = interceptorSettingsStore.isRequestCaptureEnabled(), // can be True or False
    filters = interceptorSettingsStore.getRequestCaptureFilters(), // fetching filters from store
    url = filters.url,
    methodArray = Object(_utils_InterceptorUtil__WEBPACK_IMPORTED_MODULE_6__["sanitize"])(filters.methods),
    captureResponse = false;

    pm.appWindow.sendToElectron({
      event: 'forwardInterceptorRequest',
      message: {
        type: 'CONFIGURE_REQUEST_CAPTURE',
        postmanMessage: {
          filters: {
            url,
            method: methodArray },

          captureResponse,
          enabled } } });




  }


  addCookiesToApp(cookies) {
    var newCookies = this.addUrlPropsToCookies(cookies),
    bulkCookies = _.map(newCookies, cookieItem => {
      return {
        url: cookieItem.url,
        host: cookieItem.domain,
        cookie: cookieItem };

    });

    // addBulkCookies also has a second parameter `callback` if required
    pm.cookieManager.addBulkCookies(bulkCookies);
  }

  addUrlPropsToCookies(cookies) {
    var url;
    for (var i = 0; i < cookies.length; i++) {
      url = '';
      if (cookies[i].secure) {
        url += 'https://';
      } else
      {
        url += 'http://';
      }
      if (cookies[i].domain.indexOf('.') === 0) {
        url += cookies[i].domain.substring(1);
      } else
      {
        url += cookies[i].domain;
      }
      url += cookies[i].path;
      cookies[i].url = url;
    }
    return cookies;
  }

  deleteCookiesFromApp(cookies) {
    var newCookies = this.addUrlPropsToCookies(cookies);
    for (var i = 0; i < newCookies.length; i++) {
      pm.cookieManager.deleteCookie(newCookies[i].domain, newCookies[i].name, newCookies[i].path, function () {
        // cookie is removed
      });
    }
  }

  checkTarget(id) {
    var collections = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('ActiveWorkspaceStore').collections,
    collection = _.find(collections, item => {return item.id === id;}),
    editPermission = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('PermissionStore').can('edit', 'collection', id);

    return collection && editPermission;
  }

  // Used to check if the content-type
  // in the captured request is urlencoded
  // The body needs to be split differently if this is the case
  isUrlEncodedHeaderPresent(headers) {
    for (var i = 0; i < headers.length; i++) {
      if (headers[i].name.toLowerCase() === 'content-type') {
        if (headers[i].value.search('urlencoded') >= 0) {
          return true;
        }
      }
    }

    return false;
  }

  // Used to extract form data key-value
  // pairs from the captured request
  getFormData(data) {
    var formData = [],
    i;

    if (!data) {
      return formData;
    }

    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        var itemLength = data[key].length;
        for (i = 0; i < itemLength; i++) {
          formData.push({
            'key': key,
            'value': data[key][i] });

        }
      }
    }

    return formData;
  }

  getRawData(data) {
    if (!data) {
      return '';
    }

    return _utils_util__WEBPACK_IMPORTED_MODULE_1__["default"].arrayBufferToString(base64_arraybuffer__WEBPACK_IMPORTED_MODULE_4___default.a.decode(data));
  }

  addRequestObject(requestObj) {
    var interceptorSettingsStore = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('InterceptorSettingsStore'),
    target_id = interceptorSettingsStore.requestCaptureTarget(),
    request;

    request = {
      name: requestObj.url,
      url: requestObj.url,
      method: requestObj.method,
      headers: {},
      headerData: [],
      data: '' };


    // modify request for sync
    requestObj.requestHeaders.forEach(data => {
      var headers = Object.values(data);
      request.headers[data.name] = data.value;
      request.headerData.push({
        key: data.name,
        value: data.value });

    });

    // different types of body are encoded differently at the interceptor's end
    if (requestObj.requestBody) {
      if (requestObj.requestBodyType === 'formData') {
        if (this.isUrlEncodedHeaderPresent(requestObj.requestHeaders)) {
          request.dataMode = 'urlencoded';
        } else
        {
          request.dataMode = 'params';
        }

        // TODO: Think about removing Content-Type header
        request.data = this.getFormData(_.get(requestObj, 'requestBody.formData'));
      } else
      {
        request.dataMode = 'raw';
        request.data = this.getRawData(_.get(requestObj, 'requestBody.rawData'));
      }
    }

    if (this.checkTarget(target_id)) {
      _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__["default"].
      get().
      then(user => {
        _.assign(request, {
          id: _utils_util__WEBPACK_IMPORTED_MODULE_1__["default"].guid(),
          collection: target_id,
          owner: user.id });


        let requestCreateEvent = {
          name: 'create_deep',
          namespace: 'request',
          data: { request },
          target: {
            model: 'collection',
            modelId: target_id } };


        Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_2__["default"])(requestCreateEvent).
        then(response => {
          if (!_.isEmpty(_.get(response, 'error'))) {
            pm.logger.error('Error in creating collection from InterceptorManager', response.error);
            return;
          }
        });
      }).
      catch(err => {
        pm.logger.error('Error while creating collection from InterceptorManager', err);
      });
    }

    // else create history
    else {
        _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_5__["default"].
        get().
        then(user => {
          if (!user) {
            pm.logger.error(new Error('InterceptorManager: Could not create history. Current user is missing.'));
            return;
          }

          let currentDate = new Date(),
          workspace = _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"]('ActiveWorkspaceSessionStore').workspace,
          historyCreateEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_3__["createEvent"])(
          'create',
          'history',
          _.assign({}, request, { id: _utils_util__WEBPACK_IMPORTED_MODULE_1__["default"].guid(), createdAt: currentDate.toISOString(), workspace, owner: user.id, lastUpdatedBy: user.id }));


          return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_2__["default"])(historyCreateEvent).
          catch(e => {console.log('Error in creating history through proxy', e);});
        });
      }
  }};



/* harmony default export */ __webpack_exports__["default"] = (InterceptorManager);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4311:
/***/ (function(module, exports) {

/*
 * base64-arraybuffer
 * https://github.com/niklasvh/base64-arraybuffer
 *
 * Copyright (c) 2012 Niklas von Hertzen
 * Licensed under the MIT license.
 */
(function(){
  "use strict";

  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

  // Use a lookup table to find the index.
  var lookup = new Uint8Array(256);
  for (var i = 0; i < chars.length; i++) {
    lookup[chars.charCodeAt(i)] = i;
  }

  exports.encode = function(arraybuffer) {
    var bytes = new Uint8Array(arraybuffer),
    i, len = bytes.length, base64 = "";

    for (i = 0; i < len; i+=3) {
      base64 += chars[bytes[i] >> 2];
      base64 += chars[((bytes[i] & 3) << 4) | (bytes[i + 1] >> 4)];
      base64 += chars[((bytes[i + 1] & 15) << 2) | (bytes[i + 2] >> 6)];
      base64 += chars[bytes[i + 2] & 63];
    }

    if ((len % 3) === 2) {
      base64 = base64.substring(0, base64.length - 1) + "=";
    } else if (len % 3 === 1) {
      base64 = base64.substring(0, base64.length - 2) + "==";
    }

    return base64;
  };

  exports.decode =  function(base64) {
    var bufferLength = base64.length * 0.75,
    len = base64.length, i, p = 0,
    encoded1, encoded2, encoded3, encoded4;

    if (base64[base64.length - 1] === "=") {
      bufferLength--;
      if (base64[base64.length - 2] === "=") {
        bufferLength--;
      }
    }

    var arraybuffer = new ArrayBuffer(bufferLength),
    bytes = new Uint8Array(arraybuffer);

    for (i = 0; i < len; i+=4) {
      encoded1 = lookup[base64.charCodeAt(i)];
      encoded2 = lookup[base64.charCodeAt(i+1)];
      encoded3 = lookup[base64.charCodeAt(i+2)];
      encoded4 = lookup[base64.charCodeAt(i+3)];

      bytes[p++] = (encoded1 << 2) | (encoded2 >> 4);
      bytes[p++] = ((encoded2 & 15) << 4) | (encoded3 >> 2);
      bytes[p++] = ((encoded3 & 3) << 6) | (encoded4 & 63);
    }

    return arraybuffer;
  };
})();


/***/ }),

/***/ 4312:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
let InterceptorInstaller = class InterceptorInstaller {

  constructor() {

    // checking intermediate states for interceptor bridge installation
    pm.appWindow.trigger('registerInternalEvent', 'interceptorBridgeInstallationStatusUpdate', function (data) {
      pm.mediator.trigger('onMessageExternal', data);
      if (data.status === 'downloadStarted') {
        console.log('Downloading Interceptor Bridge...');
      } else
      if (data.status === 'downloadFinished') {
        console.log('Downloaded Interceptor Bridge');
      } else
      if (data.status === 'installationStarted') {
        console.log('Installing Interceptor Bridge');
      } else
      if (data.status === 'manifestAdded') {
        console.log('Added manifest');
      } else
      if (data.status === 'registryKeyAdded') {
        console.log('Added registry key');
      } else
      if (data.status === 'installationFinished') {
        pm.settings.setSetting('interceptor.interceptorBridgeInstalled', true);
        console.log('InterceptorBridge is installed successfully');
      } else
      if (data.status === 'error') {
        pm.settings.setSetting('interceptor.interceptorBridgeInstalled', false);
        console.log('Error occured while installing Interceptor Bridge: ', data.errorMessage);
      }
    }, this);

    // checking intermediate states for node installation
    pm.appWindow.trigger('registerInternalEvent', 'nodeInstallationStatusUpdate', function (data) {
      if (data.status === 'downloadStarted') {
        console.log('Downloading Node...');
      } else
      if (data.status === 'downloadFinished') {
        console.log('Node is downloaded successfully');
      } else
      if (data.status === 'installationFinished') {
        console.log('Node is installed successfully');
      } else
      if (data.status === 'installationNotFinished') {
        console.log('Node installation is not finished');
      } else
      if (data.status === 'error') {
        console.log(data.errorMessage);
      }
    }, this);

    pm.appWindow.trigger('registerInternalEvent', 'interceptorBridgeResetStatusUpdate', function (data) {
      if (data.status === 'success') {
        console.log('Interceptor Bridge installation is reset successfully');
      } else
      if (data.status === 'error') {
        console.log(data.errorMessage);
      }
    }, this);

  }

  /**
     * sets up the Native App ~ Interceptor integration
     * i.e. puts the native server in Applications/ folder
     * puts the manifest at chrome-specific location
     *
     */
  installInterceptorBridge() {
    pm.appWindow.sendToElectron({
      event: 'installInterceptorBridge' });

    return 'InterceptorBridge installation initiated';
  }

  /**
     * checks for the presence of manifest and Interceptor Bridge executable
     * checks for the presence of registry key in case of windows
     * checks for the presence of node in case of macOS
     */
  checkInstallationStatus() {
    pm.appWindow.sendToElectron({
      event: 'checkInstallationStatus' });

    return 'Check Installation initiated';
  }

  /**
     * it downloads node installer in case of macOS if it doesn't exist
     */
  installNode() {
    pm.appWindow.sendToElectron({
      event: 'installNode' });

    return 'Node installation initiated';
  }

  /**
     *
     * resets interceptor bridge installation by initiating
     *
     * 1. removal of `InterceptorBridge` directory
     * 2. removal of manifest present at os-specific location
     * 3. removal of registry key (only in case of windows)
     *
     */
  reset() {
    pm.appWindow.sendToElectron({
      event: 'resetInterceptorBridgeInstallation' });

    return 'Resetting Interceptor Bridge installation';
  }};



/* harmony default export */ __webpack_exports__["default"] = (InterceptorInstaller);

/***/ }),

/***/ 4313:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UIEventService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1755);
/* harmony import */ var _constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1756);



/**
                                                               * Initializer
                                                               * It subscribes to the UIEventService and attaches the handlers for it
                                                               */
function init() {
  _UIEventService__WEBPACK_IMPORTED_MODULE_0__["default"].subscribe(_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_1__["LOGOUT_EVENT"], _handleLogout);
}

/**
   * @private
   * @description It triggers the logout for the app.
   */
function _handleLogout() {
  pm.mediator.trigger('showUserSignoutModal');
}

/* harmony default export */ __webpack_exports__["default"] = ({ init });

/***/ }),

/***/ 4314:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeRollbackNotifications", function() { return initializeRollbackNotifications; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rollbackQueue", function() { return rollbackQueue; });
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(664);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(781);
/* harmony import */ var _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1244);
/* harmony import */ var _modules_controllers_HeaderPresetController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1245);
/* harmony import */ var _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(756);
/* harmony import */ var _runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1246);
/* harmony import */ var _modules_controllers_HistoryController__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1247);
/* harmony import */ var _modules_controllers_HistoryResponseController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1248);
/* harmony import */ var _modules_controllers_CollectionRunController__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1237);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(748);
/* harmony import */ var _modules_sync_helpers_sync_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1560);
/* harmony import */ var _models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1558);













let pendingNotifyChanges = [];

const controllerMap = {
  workspace: _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_4__["default"].get.bind(_modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_4__["default"]),
  globals: _runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_5__["default"].get.bind(_runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_5__["default"]),
  environment: _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_2__["default"].get.bind(_runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_2__["default"]),
  headerpreset: _modules_controllers_HeaderPresetController__WEBPACK_IMPORTED_MODULE_3__["default"].get.bind(_modules_controllers_HeaderPresetController__WEBPACK_IMPORTED_MODULE_3__["default"]),
  collection: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getCollection.bind(_modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"]),
  folder: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getFolder.bind(_modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"]),
  request: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getRequest.bind(_modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"]),
  response: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getResponse.bind(_modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"]),
  history: _modules_controllers_HistoryController__WEBPACK_IMPORTED_MODULE_6__["default"].get.bind(_modules_controllers_HistoryController__WEBPACK_IMPORTED_MODULE_6__["default"]),
  historyresponse: _modules_controllers_HistoryResponseController__WEBPACK_IMPORTED_MODULE_7__["default"].get.bind(_modules_controllers_HistoryResponseController__WEBPACK_IMPORTED_MODULE_7__["default"]),
  collectionrun: _modules_controllers_CollectionRunController__WEBPACK_IMPORTED_MODULE_8__["default"].get.bind(_modules_controllers_CollectionRunController__WEBPACK_IMPORTED_MODULE_8__["default"]) },

SUPPORTED_MODELS = _.keys(controllerMap),
SUPPORTED_ACTIONS = ['create', 'import', 'update', 'transfer', 'destroy'],
COLLECTION_CHILDREN_MODELS = ['folder', 'request', 'response'],
WS_DEPS_MODELS = new Set(['collection', 'environment', 'headerpreset']),
COLLECTION_OR_ENVIRONMENT = new Set(['collection', 'environment']),

TOAST_DEBOUNCE_TIME = 1000, // 1 sec
TOAST_MAX_DEBOUNCE = 60 * 1000, // 1 min
debouncedShowNotification = _.debounce(_showNotification, TOAST_DEBOUNCE_TIME, { 'maxWait': TOAST_MAX_DEBOUNCE }),
TOAST_TITLE_SUFFIX = 'changes could not be saved',
TOAST_MESSAGE = 'You don\'t seem to have the required permissions to perform these actions';

/**
                                                                                              * Rolls back the action performed by the changeset
                                                                                              * @param {Object} changeset
                                                                                              * @param {Function} callback
                                                                                              */
function rollbackWorker(changeset, callback = _.noop) {
  pm.logger.info(`DbRollbackService~rollbackWorker: rollingback ${changeset.model}:${changeset.action}`);

  let { model, action } = changeset;

  if (!_.includes(SUPPORTED_MODELS, model) || !_.includes(SUPPORTED_ACTIONS, action)) {
    pm.logger.warn('DbRollbackService~rollbackWorker: entity model/action not supported', { model, action });
    return callback();
  }

  _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEvent(model, 'rollback', action);

  Promise.resolve()

  // get the remote entity
  .then(() => {
    // For the actions where an entity was created, it won't exist on remote
    if (!_.includes(['import', 'create'], action)) {
      return _getEntityFromRemote(changeset);
    }
  })

  // perform the rollback
  .then(remoteEntitySyncMessage => {
    return _rollback(changeset, remoteEntitySyncMessage);
  })

  // log and call the callback
  .then(() => {
    pm.logger.info(`DbRollbackService~rollbackWorker: completed rollback for ${changeset.model}:${changeset.action}`);
    callback();
  })

  // on errors just log it and call the callback without error
  .catch(err => {
    pm.logger.error('DbRollbackService~rollbackWorker: error while processsing rollback', err);

    // Do not bubble the error up
    callback();
  });
}

/**
   * For a given changeset, returns the remote entity
   * For update/destroy operations: remote entity will be the same
   *     transfer operations: remote entity will be a common ancestor of the source and destination
   *     create operations: should not be called since it will not exist on remote (if called anyway, will return undefined)
   * @param {Object} changeset
   * @returns {Promise<Object>} Resolved value is the remote entity
   */
async function _getEntityFromRemote(changeset) {
  let { action } = changeset,
  data = changeset.data || {},
  entityModel,

  // Get the populated entity for actions: destroy and transfer
  populate = _.includes(['destroy', 'transfer'], action),
  query = {}, // will be using to pass `populate` & `owner` query params
  criteria = {};

  // For create operation, there cannot be an entity on remote
  if (action === 'create') {
    return;
  }

  populate && (query.populate = true);

  if (action === 'transfer') {
    let parent = await _getCommonAncestor(data.from, data.to);

    if (!parent) {
      return;
    }

    // for transfer changeset, the entity to fetch is the parent entity
    entityModel = parent.type;

    if (entityModel === 'collection') {
      let collection = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getCollection({ id: parent.id });

      if (!collection) {
        return;
      }

      criteria.id = _getEntityUid(collection);
    } else

    if (entityModel === 'folder') {
      let folder = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getFolder({ id: parent.id }),
      collection = folder && (await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getCollection({ id: folder.collection }));

      if (!collection) {
        return;
      }

      criteria.id = parent.id;
      query.owner = collection.owner;
    }
  } else

  {
    entityModel = changeset.model;
    criteria = _getCriteriaFromChangeset(changeset);

    if (!criteria) {
      return;
    }

    // for collection and environment, the id should be uid
    if (entityModel === 'environment' || entityModel === 'collection') {
      let entityUid = data.owner && data.modelId && _getEntityUid(data);

      if (!entityUid) {
        let entity = await controllerMap[entityModel]({ id: criteria.id });
        entityUid = entity && _getEntityUid(entity);
      }

      if (!entityUid) {
        return;
      }

      criteria.id = entityUid;
    }

    // for request/folder/response either id should be UID or query should have owner as the parent collection ID
    // we are going with "adding the owner in query" approach
    else if (_.includes(COLLECTION_CHILDREN_MODELS, entityModel)) {
        let collectionId,
        collection;

        // when entity is deleted, first get the parent (can be request, folder or collection)
        if (action === 'destroy') {
          let parent = data.parent || {};

          if (parent.model === 'collection') {
            collectionId = parent.modelId;
          } else {// folder or request
            let requestOrFolder = await controllerMap[parent.model]({ id: parent.modelId });
            collectionId = requestOrFolder && requestOrFolder.collection;
          }
        }

        // otherwise get the entity first (request, response or folder) and get the collectionId from it
        else {
            let entity = await controllerMap[entityModel]({ id: criteria.id });
            collectionId = entity && entity.collection;
          }

        if (!collectionId) {
          return;
        }

        collection = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getCollection({ id: collectionId });

        if (!collection) {
          return;
        }

        query.owner = collection.owner;
      }
  }

  return new Promise(resolve => {
    _modules_sync_helpers_sync_api__WEBPACK_IMPORTED_MODULE_10__["findOne"](entityModel, criteria, query, (err, entitySyncMessageData, entitySyncMessage) => {
      err ? resolve() : resolve(entitySyncMessage);
    });
  });
}

/**
   * Returns the common ancestor for given two entities
   * @param {Object} entity1 has model and modelId
   * @param {Object} entity2 has model and modelId
   * @returns {Promise<Object>} resolved value has type and id
   */
async function _getCommonAncestor(entity1, entity2) {
  // if one of the two entities is collection, then that is the common ancestor
  if (entity1.model === 'collection') {
    return {
      type: 'collection',
      id: entity1.modelId };

  }

  if (entity2.model === 'collection') {
    return {
      type: 'collection',
      id: entity2.modelId };

  }

  // Both the entities are folder: a request/folder was moved from a folder to another folder
  // @TODO-rbac: for now we return the parent collection, but can be optimized to return the least common ancestor
  let folder = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getFolder({ id: entity1.modelId });

  return folder && {
    type: 'collection',
    id: folder.collection };

}

/**
   * Returns the criteria with which an entity can be queried from remote server (sync)
   * @param {Object} changeset
   * @returns {Object} criteria
   */
function _getCriteriaFromChangeset(changeset) {
  switch (changeset.action) {
    case 'import':
    case 'create':
      return; // for these actions no entity exists on remote

    case 'destroy':
      return {
        id: _.get(changeset, 'data.modelId') // @TODO-rbac fix this for history destroy where there are multiple items
      };

    case 'update':{
        // globals are fetched using the workspaceId
        if (changeset.model === 'globals') {
          return {
            workspace: _.get(changeset, 'data.instance.workspace') };

        }

        return {
          id: _.get(changeset, 'data.modelId') };

      }}


  pm.logger.warn('action not supported for getting entity id from changeset', changeset.action);
}

/**
   * Returns the UID for an environment or a collection
   * @param {Object} entity
   */
function _getEntityUid(entity = {}) {
  return `${entity.owner}-${entity.id || entity.modelId}`;
}

/**
   * Rollback the action performed by the changeset using the remote entity
   * @param {Object} changeset
   * @param {Object} remoteEntitySyncMessage
   */
async function _rollback(changeset, remoteEntitySyncMessage) {
  let { model, action } = changeset,
  data = changeset.data || {};

  // If the entity does not exist on remote for the actions that needs it for reverting, bail out
  // All actions expect where an entity was created needs the remote entity to revert
  if (!_.includes(['create', 'import'], action) && !remoteEntitySyncMessage) {
    pm.logger.warn(`DbRollbackService~_rollback: could not rollback ${model}:${action} since entity does not exist on remote`);
    return;
  }

  switch (action) {

    // if creating an entity failed, just delete it locally
    case 'create':
    case 'import':{
        let entityDestroyChangeset = Object.assign({}, changeset, { action: _getActionForDestroy(model) });

        pm.logger.info('DbRollbackService~_rollback: rolling back an import by deleting the entity');

        await Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["processIncomingChangeset"])(entityDestroyChangeset);
        _queueNotification(model, data.instance, action);
        break;
      }

    // if updating an entity failed, update the skeleton locally
    case 'update':{
        _.set(remoteEntitySyncMessage, ['meta', 'action'], 'update');
        let remoteEntityChangeset = Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["buildChangesetFromMessage"])(remoteEntitySyncMessage);

        pm.logger.info('DbRollbackService~_rollback: rolling back an update by updating the entity');

        await Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["processIncomingChangeset"])(remoteEntityChangeset);
        _queueNotification(model, _.assign({ id: data.modelId }, data.instance), action);
        break;
      }

    // if deleting an entity failed, import it back
    case 'destroy':
    case 'delete':{
        let metaAction = _getActionForImport(model),
        remoteEntityChangeset;

        _.set(remoteEntitySyncMessage, ['meta', 'action'], metaAction);
        remoteEntityChangeset = Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["buildChangesetFromMessage"])(remoteEntitySyncMessage);

        pm.logger.info('DbRollbackService~_rollback: rolling back an destroy by #1 importing the entity');

        // import the entity
        await Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["processIncomingChangeset"])(remoteEntityChangeset);

        // update the workspace dependencies: it was removed from all workspaces during the action we are rolling back
        if (WS_DEPS_MODELS.has(remoteEntitySyncMessage.meta.model)) {
          let uId = _getEntityUid(remoteEntitySyncMessage.data),
          model = _.get(remoteEntitySyncMessage, 'meta.model');

          pm.logger.info('DbRollbackService~_rollback: rolling back an destroy by #2 updating the ws dependencies', model, uId);
          await _rollbackWorkspaceDependency(model, uId);
        }

        _queueNotification(model, { id: data.modelId }, action);
        break;
      }

    // for transfer changeset, we need to drop and import the common ancestor
    case 'transfer':{
        let entityDestroySyncMessage = {
          model: remoteEntitySyncMessage.meta.model,
          model_id: remoteEntitySyncMessage.model_id,
          action: _getActionForDestroy(model) },

        entityDestroyChangeset = Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["buildChangesetFromMessage"])(entityDestroySyncMessage),
        entityImportChangeset;


        // delete the common ancestor
        pm.logger.info('DbRollbackService~_rollback: rolling back a transfer by #1 deleting the common ancestor', entityDestroySyncMessage);
        await Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["processIncomingChangeset"])(entityDestroyChangeset);

        // import the common ancestor back
        pm.logger.info('DbRollbackService~_rollback: rolling back a transfer by #2 importing the common ancestor');
        _.set(remoteEntitySyncMessage, ['meta', 'action'], _getActionForImport(model));
        entityImportChangeset = Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["buildChangesetFromMessage"])(remoteEntitySyncMessage);
        await Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["processIncomingChangeset"])(entityImportChangeset);

        // update the workspace dependencies: during the delete operation as part of rollback, this was removed from all workspaces
        if (WS_DEPS_MODELS.has(remoteEntitySyncMessage.meta.model)) {
          let uId = _getEntityUid(remoteEntitySyncMessage.data),
          model = _.get(remoteEntitySyncMessage, 'meta.model');

          pm.logger.info('DbRollbackService~_rollback: rolling back a transfer by #3 updating the ws dependencies', model, uId);

          await _rollbackWorkspaceDependency(model, uId);
        }

        _queueNotification(model, { id: data.modelId }, action);
        break;
      }}

}

/**
   * Returns the action to be used to create sync changeset for deleting an entity
   * @param {String} model
   */
function _getActionForDestroy(model) {
  return COLLECTION_OR_ENVIRONMENT.has(model) ? 'unsubscribe' : 'destroy';
}

/**
   * Returns the action to be used to create sync changeset for importing an entity
   * @param {String} model
   */
function _getActionForImport(model) {
  return COLLECTION_OR_ENVIRONMENT.has(model) ? 'subscribe' : 'import';
}

/**
   * Will update all the workspaces' dependencies for a given collection/environment
   * @param {String} type collection or environment
   * @param {String} uId
   */
async function _rollbackWorkspaceDependency(type, uId) {
  let remoteWorkspaceMessages = await new Promise(resolve => {
    _modules_sync_helpers_sync_api__WEBPACK_IMPORTED_MODULE_10__["find"]('workspace', { dependencies: true }, (err, data) => {
      err ? resolve([]) : resolve(data);
    });
  }),
  localWorkspacesById = _.keyBy((await _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_4__["default"].getAll()), 'id'),
  wsUpdateChangesets = [];

  // Generate the sync messages
  _.each(remoteWorkspaceMessages, remoteWorkspaceMessage => {
    let wsId = remoteWorkspaceMessage.data.id,
    localWorkspace = localWorkspacesById[wsId],
    remoteWsDeps = _.get(remoteWorkspaceMessage, ['data', 'dependencies', type + 's']),
    localWsDeps = _.get(localWorkspace, ['dependencies', type + 's']),
    wsUpdateChangeset;

    // if the dependency exists on remote but not on local, update the workspace
    if (_.includes(remoteWsDeps, uId) && !_.includes(localWsDeps, uId)) {
      _.set(remoteWorkspaceMessage, ['meta', 'action'], 'update');
      wsUpdateChangeset = Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["buildChangesetFromMessage"])(remoteWorkspaceMessage);
      wsUpdateChangesets.push(wsUpdateChangeset);
    }
  });

  console.log('DbRollbackService~_rollbackWorkspaceDependency: ws dependencies update changesets', wsUpdateChangesets);

  // Apply the sync messages in parallel
  return Promise.all(_.map(wsUpdateChangesets, wsUpdateChangeset => {
    return Object(_models_sync_services_SyncIncomingHandler__WEBPACK_IMPORTED_MODULE_11__["processIncomingChangeset"])(wsUpdateChangeset);
  })).
  catch(err => {
    pm.logger.error('DbRollbackService~_rollbackWorkspaceDependency: error while updating workspace dependencies during rollback', err);
  });
}

function _getRollbackNotificationChannel() {
  return pm.eventBus.channel('rollback-notifications');
}

/**
   * Queues a rollback notification
   * Notifications are collated together based on time and then flushed
   * @param {String} model
   * @param {Object} entity
   * @param {String} action
   */
function _queueNotification(model, entity, action) {
  let rollbackChannel = _getRollbackNotificationChannel();

  rollbackChannel.publish({ model, entity, action });
}

/**
   * Subscribes to a channel to get the rollback notifications
   * It will collate then collate those notifications and flush them later
   */
function initializeRollbackNotifications() {
  let rollbackChannel = _getRollbackNotificationChannel();

  rollbackChannel.subscribe((message = {}) => {
    let { model, entity, action } = message;

    if (!model || !action) {
      return;
    }

    pendingNotifyChanges.push({ model, entity, action });
    debouncedShowNotification();
  });
}

/**
   * Shows the notification for all the collated actions
   */
function _showNotification() {
  if (_.isEmpty(pendingNotifyChanges)) {
    return;
  }

  pm.toasts.error(TOAST_MESSAGE, {
    persist: false,
    title: `${pendingNotifyChanges.length} ${TOAST_TITLE_SUFFIX}`

    // @TODO-rbac: Implement this
    // primaryAction: {
    //  label: 'See details',
    //  onClick: _handleNotificationClickDetails.bind(null, pendingNotifyChanges)
    // }
  });

  _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEvent('rollback', 'view_toast', _.toString(_.size(pendingNotifyChanges)));

  pendingNotifyChanges = [];
}

const rollbackQueue = async__WEBPACK_IMPORTED_MODULE_0___default.a.queue(rollbackWorker, 1);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4315:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _api_dev_public_APIDevInterface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4316);


/**
                                                                        *
                                                                        * @param {Callback} cb
                                                                        */
function bootAPIDevInterface(cb) {
  _.assign(window.pm, { apiDev: new _api_dev_public_APIDevInterface__WEBPACK_IMPORTED_MODULE_0__["default"]() });
  pm.logger.info('APIDevInterface~boot - Success');
  return cb && cb(null);
}

/* harmony default export */ __webpack_exports__["default"] = (bootAPIDevInterface);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4316:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APIDevInterface; });
/* harmony import */ var _services_APIDevInterfaceService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4317);
let

APIDevInterface = class APIDevInterface {

  constructor() {
    this.constants = {
      schemaType: {
        OPENAPI3: 'openapi3',
        OPENAPI2: 'openapi2',
        OPENAPI1: 'openapi1',
        RAML1: 'raml',
        RAML: 'raml0.8',
        GRAPHQL: 'graphql' },

      model: {
        COLLECTION: 'collection' } };


  }

  /**
     *
     * @param {String} model
     * @param {String} modelId
     * @param {callback} cb
     */
  getAPIForModel(model, modelId, cb) {
    if (!model) {
      return cb({
        status: 'ERR_MISSING_MODEL',
        message: 'model is a mandatory parameter' });

    }

    if (model !== 'collection') {
      return cb({
        status: 'ERR_UNSUPPORTED_MODEL',
        message: 'Specified model is not supported' });

    }

    if (!modelId) {
      return cb({
        status: 'ERR_MISSING_MODELID',
        message: 'modelId is a mandatory parameter' });

    }

    if (typeof modelId != 'string') {
      return cb({
        status: 'ERR_INVALID_MODELID',
        message: 'modelId should be string' });

    }

    Object(_services_APIDevInterfaceService__WEBPACK_IMPORTED_MODULE_0__["getRelationForModel"])(modelId, (error, res) => {
      if (error) {
        pm.logger.warn('APIDevInterface~getAPIForModel', error);
        return cb(null);
      }

      if (!_.get(res, 'apiId')) {
        pm.logger.warn('APIDevInterface~getAPIForModel: There is no API linked to the model');
        return cb(null);
      }

      let apiModel = new API(model, modelId, res);

      cb(null, apiModel);
    });
  }};let


API = class API {





  constructor(model, modelId, apiLinkedToCollection) {this.id = null;this.name = null;this.version = null;
    this.model = model;
    this.modelId = modelId;
    this.initialize(apiLinkedToCollection);
  }

  initialize(definition) {
    this.id = definition.apiId;
    this.name = definition.apiName;
    this.version = { id: definition.apiVersionId, name: definition.apiVersionName };
  }

  /**
     *
     * @param {Object} options : Additional parameters
     * @param {callback} cb: Callback that handles the response
     */
  getSchema(options, cb) {
    if (this.model === 'collection') {
      if (!options ||
      typeof _.get(options, 'schemaTypes') !== 'object') {
        return cb({
          status: 'ERR_INVALID_SCHEMA_TYPES',
          message: 'Invalid supported schema types' });

      }

      let definition = {
        apiId: this.id,
        apiVersionId: this.version.id,
        modelId: this.modelId,
        types: _.get(options, 'schemaTypes').toString() };


      Object(_services_APIDevInterfaceService__WEBPACK_IMPORTED_MODULE_0__["getSchemaForModel"])(definition, (error, res) => {
        if (!error) {
          return cb(null, res);
        }
        if (error.status === 401) {
          return cb({
            status: 'ERR_UNAUTHENTICATED_USER',
            message: _.get(error, 'error.message') });

        }
        if (error.status === 500) {
          return cb({
            status: 'SERVER_ERROR',
            message: _.get(error, 'error.message') });

        }
        if (error.status === 403) {
          return cb({
            status: 'ERR_FORBIDDEN',
            message: _.get(error, 'error.message') });

        }
        if (error.status === 404 || error.status === 400) {
          return cb(null);
        }
        cb(null);
      });
    }
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4317:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRelationForModel", function() { return getRelationForModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSchemaForModel", function() { return getSchemaForModel; });
/* harmony import */ var _controllers_APIRelationController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4318);
/* harmony import */ var _APIDevService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1551);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(742);
/* harmony import */ var _controllers_APISchemaController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4319);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(650);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(uuid__WEBPACK_IMPORTED_MODULE_4__);






const TYPE_CREATE = 'create';

/**
                               *
                               * @param {String} modelId
                               * @param {Callback} cb
                               */
function getRelationForModel(modelId, cb) {
  cb = _.once(cb);
  _controllers_APIRelationController__WEBPACK_IMPORTED_MODULE_0__["default"].get({
    id: modelId }).
  then(relation => {

    /**
                     * if relation exists in DB,
                     * call the callback with the data
                     * and return
                     */
    if (relation) {

      // if the relation does not exist on the
      // latest version of the API, then apiVersionId
      // will be undefined
      //
      // We are providing the information only if the model
      // is linked to the latest API version
      if (relation.apiId && relation.apiVersionId) {
        return cb(null, relation);
      } else {

        // return null when the relation
        // does not exist on the latest version
        return cb(null);
      }
    }

    /**
       * if relation does not exist in DB
       * ,i.e, data not found in DB,
       * then fetch the relation from server
       * call callback with the fetched data
       * and create entry in the api_relations
       */else
      {
        fetchRelationForModelFromServer(modelId).then(relationToCreate => {
          cb(null, relationToCreate);
          createAndSubscribeForRelation(modelId, relationToCreate);
        }).
        catch(error => {
          pm.logger.error('Failed to get relation for the model', error);
          cb(error);
        });
      }
  });
}

/**
   * Publish an event to the shared process
   * via realtime-db-update channel to create
   * the entry in the api_relations table
   * and subscribe for the modelId
   * @param {String} modelId
   * @param {Object} relationToCreate
   */
function createAndSubscribeForRelation(modelId, relationToCreate) {
  pm.eventBus.channel('realtime-db-update').publish(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["createEvent"])(TYPE_CREATE, 'updateDB', {
    id: modelId,
    response: relationToCreate,
    table: 'api_relations' }));

}

/**
   * get data for the API linked
   * to the collection if the collectionId
   * is not available in DB cache
   */
function fetchRelationForModelFromServer(modelId) {
  return _APIDevService__WEBPACK_IMPORTED_MODULE_1__["default"].getAPILinkedToCollection(modelId).then(response => {
    let relationToUpdate = {
      id: modelId,
      apiId: _.get(response, 'api.id'),
      apiName: _.get(response, 'api.name'),
      apiVersionId: _.get(response, 'api.versions[0].id'),
      apiCreatedAt: _.get(response, 'api.createdAt'),
      apiUpdatedAt: _.get(response, 'api.updatedAt'),
      apiVersionName: _.get(response, 'api.versions[0].name'),
      apiVersionCreatedAt: _.get(response, 'api.versions[0].createdAt'),
      apiVersionUpdatedAt: _.get(response, 'api.versions[0].updatedAt') };

    return Promise.resolve(relationToUpdate);
  }).
  catch(error => {
    return Promise.reject(error);
  });
}

/**
   *
   * @param {Object} definition
   * @param {Callback} cb
   */
function getSchemaForModel(definition, cb) {
  cb = _.once(cb);
  _controllers_APISchemaController__WEBPACK_IMPORTED_MODULE_3__["default"].get({
    apiVersionId: definition.apiVersionId }).
  then(schema => {

    /**
                   * if schema exists in DB,
                   * call the callback with the data
                   * and return
                   */
    if (schema) {

      /**
                  * Bail out if the requested schema type
                  * does not match the schema type in DB cache
                  */
      if (!_.includes(definition.types, schema.type)) {
        return cb(null);
      }
      let schemaToBeReturned = {
        id: schema.schemaId,
        schema: schema.schema,
        type: schema.type,
        language: schema.language };


      return cb(null, schemaToBeReturned);
    }

    /**
       * if schema does not exist in DB
       * ,i.e, data not found in DB,
       * the fetch the schema from server
       * call callback with the fetched data
       * and create entry in the api_schemas
       */else
      {
        fetchSchemaForModelFromServer(definition).then(schemaToCreate => {
          let schemaToBeReturned = {
            id: schemaToCreate.schemaId,
            schema: schemaToCreate.schema,
            type: schemaToCreate.type,
            language: schemaToCreate.language };


          cb(null, schemaToBeReturned);
          createAndSubscribeForSchema(definition, schemaToCreate);
        }).
        catch(error => {
          pm.logger.error('Failed to get schema for the model', error);
          cb(error);
        });
      }
  });
}

/**
   *
   * @param {Object} definition
   */
function fetchSchemaForModelFromServer(definition) {
  return _APIDevService__WEBPACK_IMPORTED_MODULE_1__["default"].fetchSchemaForCollection(definition.modelId, definition.types).
  then(response => {
    let schemaFromResponse = _.get(response, 'body.data.schema'),
    schemaToCreate = {
      id: uuid__WEBPACK_IMPORTED_MODULE_4___default.a.v4(),
      schemaId: schemaFromResponse.id,
      apiId: definition.apiId,
      apiVersionId: definition.apiVersionId,
      schema: schemaFromResponse.schema,
      type: schemaFromResponse.type,
      language: schemaFromResponse.language,
      updatedAt: schemaFromResponse.updatedAt };

    return Promise.resolve(schemaToCreate);
  }).
  catch(error => {
    return Promise.reject(error);
  });
}

/**
   *
   * @param {String} modelId
   * @param {Object} schemaToCreate
   */
function createAndSubscribeForSchema(definition, schemaToCreate) {
  pm.eventBus.channel('realtime-db-update').publish(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["createEvent"])(TYPE_CREATE, 'updateDB', {
    id: definition.modelId,
    response: schemaToCreate,
    table: 'api_schemas' }));

}


/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4318:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _js_modules_controllers_ListController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(757);


/* harmony default export */ __webpack_exports__["default"] = (_.defaults({
  type: 'apirelation' },
_js_modules_controllers_ListController__WEBPACK_IMPORTED_MODULE_0__["default"]));
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4319:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _js_modules_controllers_ListController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(757);



/* harmony default export */ __webpack_exports__["default"] = (_.defaults({
  type: 'apischema' },
_js_modules_controllers_ListController__WEBPACK_IMPORTED_MODULE_0__["default"]));
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4320:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CloudProxyHandler; });
let electron = __webpack_require__(62),
app = electron.remote.app,
ipcRenderer = electron.ipcRenderer,
path = __webpack_require__(64),
FileService = __webpack_require__(1228),
{ decodeBase122 } = __webpack_require__(4321),
CONFIG_FILE_PATH = path.resolve(app.getPath('userData'), 'Postman_Config', 'proxy'),
DEFAULT_PROXY_CONFIG = null;

/**
                              * This acts as the point of communication for proxy settings in the renderer
                              */let
CloudProxyHandler = class CloudProxyHandler {
  constructor() {
    FileService.read(CONFIG_FILE_PATH).
    then(configData => {
      let parsedConfig = JSON.parse(decodeBase122(configData));

      this.proxyConfig = this.sanitizeConfig(parsedConfig);
    }).
    catch(e => {
      pm.logger.warn('CloudProxyHandler: Error while reading proxy configuration from user data - ', e);

      this.proxyConfig = DEFAULT_PROXY_CONFIG;
    });
  }

  /**
     * Dispatches an event to the main process when the user submits their proxy credentials
     *
     * @param {Object} credentials
     */
  handleProxyAuthSubmit(credentials) {
    ipcRenderer.send('handleProxyAuthSubmit', credentials);
  }

  /**
     * Checks if the proxy config schema is valid or not. If it is not, returns the DEFAULT_PROXY_CONFIG.
     *
     * @param {Object} proxyConfig
     *
     * @returns {Object}
     */
  sanitizeConfig(proxyConfig) {
    let isConfigValid = true;

    if (!proxyConfig || !proxyConfig.auth) {
      isConfigValid = false;
    }

    return isConfigValid ? proxyConfig : DEFAULT_PROXY_CONFIG;
  }};

/***/ }),

/***/ 4321:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Buffer) {let base122 = __webpack_require__(4322);

module.exports = {
  encodeBase122: function (data) {
    let stringifiedData = JSON.stringify(data),
    base122Encoded = base122.encode(Buffer.from(stringifiedData)),
    encodedData = Buffer.from(base122Encoded).toString();

    return encodedData;
  },

  decodeBase122: function (data) {
    let base122Decoded = base122.decode(Buffer.from(data)),
    decodedData = Buffer.from(base122Decoded).toString();

    return decodedData;
  } };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4322:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Buffer) {/* eslint-disable */

/**
                      * Github repo - https://github.com/kevinAlbs/Base122
                      *
                      * MIT License
                      * Copyright (c) 2016 Kevin Albertson
                      *
                      * Permission is hereby granted, free of charge, to any person obtaining a copy
                      * of this software and associated documentation files (the "Software"), to deal
                      * in the Software without restriction, including without limitation the rights
                      * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
                      * copies of the Software, and to permit persons to whom the Software is
                      * furnished to do so, subject to the following conditions:
                      *
                      * The above copyright notice and this permission notice shall be included in all
                      * copies or substantial portions of the Software.
                      *
                      * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
                      * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
                      * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
                      * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
                      * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
                      * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
                      * SOFTWARE.
                      */

// Provides functions for encoding/decoding data to and from base-122.

let fs = __webpack_require__(144);

const kString = 0,
kUint8Array = 1,
kDefaultMimeType = 'image/jpeg',
kDebug = false,
kIllegals = [
0, // null
10, // newline
13, // carriage return
34, // double quote
38, // ampersand
92 // backslash
],
kShortened = 0b111 // Uses the illegal index to signify the last two-byte char encodes <= 7 bits.
;

/**
   * Encodes raw data into base-122.
   * @param {Uint8Array|Buffer|Array|String} rawData - The data to be encoded. This can be an array
   * or Buffer with raw data bytes or a string of bytes (i.e. the type of argument to btoa())
   * @returns {Array} The base-122 encoded data as a regular array of UTF-8 character byte values.
   */
function encode(rawData) {
    let dataType = typeof rawData == 'string' ? kString : kUint8Array,
    curIndex = 0,
    curBit = 0, // Points to current bit needed
    curMask = 0b10000000,
    outData = [],
    getByte = dataType == kString ? i => rawData.codePointAt(i) : i => rawData[i];


    /**
                                                                                    * Get seven bits of input data. Returns false if there is no input left.
                                                                                    */
    function get7() {
        if (curIndex >= rawData.length) return false;

        // Shift, mask, unshift to get first part.
        let firstByte = getByte(curIndex);
        let firstPart = (0b11111110 >>> curBit & firstByte) << curBit;

        // Align it to a seven bit chunk.
        firstPart >>= 1;

        // Check if we need to go to the next byte for more bits.
        curBit += 7;
        if (curBit < 8) return firstPart; // Do not need next byte.
        curBit -= 8;
        curIndex++;

        // Now we want bits [0..curBit] of the next byte if it exists.
        if (curIndex >= rawData.length) return firstPart;
        let secondByte = getByte(curIndex);
        let secondPart = 0xFF00 >>> curBit & secondByte & 0xFF;

        // Align it.
        secondPart >>= 8 - curBit;
        return firstPart | secondPart;
    }

    while (true) {
        // Grab 7 bits.
        let bits = get7();
        if (bits === false) break;
        debugLog('Seven input bits', print7Bits(bits), bits);

        let illegalIndex = kIllegals.indexOf(bits);
        if (illegalIndex != -1) {
            // Since this will be a two-byte character, get the next chunk of seven bits.
            let nextBits = get7();
            debugLog('Handle illegal sequence', print7Bits(bits), print7Bits(nextBits));

            let b1 = 0b11000010,
            b2 = 0b10000000;
            if (nextBits === false) {
                debugLog('Last seven bits are an illegal sequence.');
                b1 |= (0b111 & kShortened) << 2;
                nextBits = bits; // Encode these bits after the shortened signifier.
            } else {
                b1 |= (0b111 & illegalIndex) << 2;
            }

            // Push first bit onto first byte, remaining 6 onto second.
            let firstBit = (nextBits & 0b01000000) > 0 ? 1 : 0;
            b1 |= firstBit;
            b2 |= nextBits & 0b00111111;
            outData.push(b1);
            outData.push(b2);
        } else {
            outData.push(bits);
        }
    }
    return outData;
}


/**
   * Decodes base-122 encoded data back to the original data.
   * @param {Uint8Array|Buffer|String} rawData - The data to be decoded. This can be a Uint8Array
   * or Buffer with raw data bytes or a string of bytes (i.e. the type of argument to btoa())
   * @returns {Array} The data in a regular array representing byte values.
   */
function decode(base122Data) {
    let strData = typeof base122Data == 'string' ? base122Data : utf8DataToString(base122Data),
    decoded = [],
    decodedIndex = 0,
    curByte = 0,
    bitOfByte = 0;


    function push7(byte) {
        byte <<= 1;

        // Align this byte to offset for current byte.
        curByte |= byte >>> bitOfByte;
        bitOfByte += 7;
        if (bitOfByte >= 8) {
            decoded.push(curByte);
            bitOfByte -= 8;

            // Now, take the remainder, left shift by what has been taken.
            curByte = byte << 7 - bitOfByte & 255;
        }
    }

    for (let i = 0; i < strData.length; i++) {
        let c = strData.charCodeAt(i);

        // Check if this is a two-byte character.
        if (c > 127) {
            // Note, the charCodeAt will give the codePoint, thus
            // 0b110xxxxx 0b10yyyyyy will give => xxxxxyyyyyy
            let illegalIndex = c >>> 8 & 7; // 7 = 0b111.
            // We have to first check if this is a shortened two-byte character, i.e. if it only
            // encodes <= 7 bits.
            if (illegalIndex != kShortened) push7(kIllegals[illegalIndex]);

            // Always push the rest.
            push7(c & 127);
        } else {
            // One byte characters can be pushed directly.
            push7(c);
        }
    }
    return decoded;
}


/**
   * Converts a sequence of UTF-8 bytes to a string.
   * @param {Uint8Array|Buffer} data - The UTF-8 data.
   * @returns {String} A string with each character representing a code point.
   */
function utf8DataToString(data) {
    return Buffer.from(data).toString('utf-8');
}

// For debugging.
function debugLog() {
    if (kDebug) console.log(...arguments);
}

// For debugging.
function print7Bits(num) {
    return '0000000'.substring(num.toString(2).length) + num.toString(2);
}

// For debugging.
function print8Bits(num) {
    return '00000000'.substring(num.toString(2).length) + num.toString(2);
}

module.exports = {
    encode: encode,
    decode: decode };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4323:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(784);
/* harmony import */ var _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(758);




const OAuth2Token = backbone__WEBPACK_IMPORTED_MODULE_0___default.a.Model.extend({
  defaults() {
    return {
      id: '',
      name: 'OAuth2 Token',
      expires_in: null,
      timestamp: null,
      data: [] };

  },

  /**
     * Checks whether the token is expired or not.
     *
     * @returns {Boolean} whether the token is expired or not
     */
  isExpired() {
    // Check in `data` array for `expires_in` field as well because previously generated
    // tokens don't have `expires_in` set directly in model
    const expiresIn = this.get('expires_in') || _.get(
    _.find(this.get('data'), ['key', 'expires_in']),
    'value');


    // Here timestamp is in milliseconds and expiresIn is in seconds
    return Number(this.get('timestamp')) + Number(expiresIn) * 1000 < Date.now();
  } }),


OAuth2Tokens = backbone__WEBPACK_IMPORTED_MODULE_0___default.a.Collection.extend({
  model: OAuth2Token,

  comparator(a, b) {
    const at = a.get('timestamp'),
    bt = b.get('timestamp');

    return at > bt;
  },

  initialize() {
    pm.mediator.on('addOAuth2Token', this.addAccessToken, this);
    pm.mediator.on('updateOAuth2Token', this.updateAccessToken, this);
    pm.mediator.on('deleteOAuth2Token', this.deleteAccessToken, this);
    this.loadAllAccessTokens();
  },

  loadAllAccessTokens() {
    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    find('oauth2accesstoken', {}).
    then(accessTokens => {
      accessTokens.forEach(token => {
        this.add(token, { merge: true });
      });
      pm.mediator.trigger('loadedAllStoredOAuth2Tokens');
    }).
    catch(e => {
      pm.logger.error('Error in fetching oauth2 access tokens', e);
    });
  },

  /**
     * @param {Object} tokenData - object having access_token and other optional attributes like scope, token_type, etc
     */
  addAccessToken(tokenData) {
    const accessToken = {
      id: _js_utils_util__WEBPACK_IMPORTED_MODULE_1__["default"].guid(),
      timestamp: Date.now(),
      expires_in: tokenData.expires_in,
      data: [],
      name: tokenData.name };


    // Make sure data is added to token response for any response
    // openID and other implementations may have different keys for access token
    // this allows users to manually copy the key from the response
    _.forOwn(tokenData, (value, key) => {
      if (key !== 'result') {
        accessToken.data.push({
          key,
          value });

      }
    });

    tokenData.access_token && (accessToken.access_token = tokenData.access_token);

    // @todo: the result is not being used anywhere, confirm with kane before removing
    // eslint-disable-next-line no-prototype-builtins
    if (tokenData.hasOwnProperty('access_token')) {
      accessToken.data.push({
        key: 'result',
        value: 'success' });

    }

    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    create('oauth2accesstoken', accessToken).
    then(() => {
      const at = new OAuth2Token(accessToken);

      this.add(at, { merge: true });
      pm.mediator.trigger('addedOAuth2Token', accessToken);
    }).
    catch(e => {
      pm.logger.error('Error in adding access token', e);
    });
  },

  updateAccessToken(params) {
    const token = this.get(params.id);

    token.set('name', params.name);
    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    findOne('oauth2accesstoken', { id: params.id }).
    then(tokenFromDb => {
      if (tokenFromDb) {
        return _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
        update('oauth2accesstoken', token.toJSON());
      }

      // @todo Will this ever be called? This flow is only used to update the
      // name of an already saved accessToken @samvel
      return _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
      create('oauth2accesstoken', token);
    }).
    then(() => {
      pm.mediator.trigger('updatedOAuth2Token', token.id);
    }).
    catch(e => {
      pm.logger.error('Error in updating access token', e);
    });
  },

  deleteAccessToken(id) {
    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    delete('oauth2accesstoken', { id }).
    then(() => {
      this.remove(id);
    }).
    catch(e => {
      pm.logger.error('OAuth2Tokens~deleteAccessToken: Error in deleting access token', e);
    });
  },

  deleteAllAccessTokens(callback) {
    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    delete('oauth2accesstoken', { id: _.map(this.models, 'id') }).
    then(() => {
      this.reset();
      _.isFunction(callback) && callback();
    }).
    catch(e => {
      pm.logger.error('OAuth2Tokens~deleteAllAccessToken: Error in deleting access token', e);
      this.reset();
      _.isFunction(callback) && callback(e);
    });
  },

  deleteExpiredTokens(callback) {
    const ids = _.transform(this.models, (acc, m) => {
      if (m.isExpired()) {
        acc.push(m.id);
      }
    }, []);

    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    delete('oauth2accesstoken', { id: ids }).
    then(() => {
      this.remove(ids);
      _.isFunction(callback) && callback();
    }).
    catch(e => {
      pm.logger.error('OAuth2Tokens~deleteExpiredToken: Error in deleting access token', e);
      this.remove(ids);
      _.isFunction(callback) && callback(e);
    });
  } });


/* harmony default export */ __webpack_exports__["default"] = (OAuth2Tokens);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4324:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers_OAuth2TokenFetcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4325);
/* harmony import */ var _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(758);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const DEFAULT_TOKEN_NAME = 'OAuth2 Token',
OAuth2Manager = backbone__WEBPACK_IMPORTED_MODULE_0___default.a.Model.extend({
  defaults() {
    return {
      oAuth2: {
        accessTokenUrl: '',
        addTokenTo: 'url',
        client_authentication: 'header',
        authUrl: '',
        clientId: '',
        clientSecret: '',
        grant_type: 'authorization_code',
        name: 'Token Name',
        password: '',
        redirect_uri: '',
        scope: '',
        state: '',
        useBrowser: false,
        username: '',
        algorithm: 'S256',
        code_verifier: '' },

      savedOAuth2Tokens: [] };

  },

  initialize() {
    pm.mediator.on('addedOAuth2Token', this.addOAuth2Token, this);
    pm.mediator.on('loadedAllStoredOAuth2Tokens', this.loadCurrentTokens, this);
    this.oAuth2TokenFetcher = new _helpers_OAuth2TokenFetcher__WEBPACK_IMPORTED_MODULE_1__["default"]();
    this.loadCurrentTokens();
    this.on('change:oAuth2', this.updateDB);
    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    findOne('authhelperstate', { id: 'oAuth2-meta' }).
    then(helper => {
      if (helper) {
        this.set('oAuth2', this.translateFromLegacy.oAuth2(helper.auth));
      }
    }).
    catch(e => {
      pm.logger.error('OAuth2Manager~initialize: Error in fetching oauth2-meta', e);
    });
  },

  updateDB() {
    const helper = { id: 'oAuth2-meta' };

    helper.auth = this.translateIntoLegacy.oAuth2(this.toJSON().oAuth2);
    _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
    findOne('authhelperstate', { id: 'oAuth2-meta' }).
    then(helperFromDb => {
      if (helperFromDb) {
        return _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
        update('authhelperstate', helper);
      }

      return _js_modules_services_ModelService__WEBPACK_IMPORTED_MODULE_2__["default"].
      create('authhelperstate', helper);
    }).
    catch(e => {
      pm.logger.error('OAuth2Manager~updateDB: Error in updating oauth2-meta', e);
    });
  },

  setToDefault() {
    this.set(this.defaults());
  },

  processOAuth2RequestToken(collectionId) {
    const params = this.get('oAuth2'); // Currently entered parameters on the UI

    this.oAuth2TokenFetcher.startAuthorization(this.translateIntoLegacy.oAuth2(params), collectionId);
  },

  cancelOAuth2RequestToken() {
    this.oAuth2TokenFetcher.finishAuthorizationFlow();
  },

  processOAuth2DeleteToken(token) {
    let currentTokens = _.clone(this.get('savedOAuth2Tokens'));

    pm.mediator.trigger('deleteOAuth2Token', token.id);

    currentTokens = currentTokens.filter(tk => tk.id !== token.id);
    this.set('savedOAuth2Tokens', currentTokens);
  },

  loadOAuth2Token(rawToken) {
    const currentTokens = _.clone(this.get('savedOAuth2Tokens')),

    newTokenData = _.zipObject(_.map(rawToken.data, 'key'), _.map(rawToken.data, 'value'));

    newTokenData.id = rawToken.id;
    newTokenData.name = rawToken.name;
    currentTokens.push(newTokenData);
    this.set('savedOAuth2Tokens', currentTokens);
  },

  addOAuth2Token(newToken) {
    const currentTokens = _.clone(this.get('savedOAuth2Tokens')),
    currentTokenDataInForm = this.get('oAuth2');

    let newTokenData;

    if (!_.isEmpty(currentTokenDataInForm.name) && _.isEmpty(newToken.name)) {
      const params = {
        id: newToken.id,
        name: currentTokenDataInForm.name };


      pm.mediator.trigger('updateOAuth2Token', params);
      newTokenData = _.zipObject(_.map(newToken.data, 'key'), _.map(newToken.data, 'value'));
      newTokenData.id = newToken.id;
      newTokenData.name = currentTokenDataInForm.name || DEFAULT_TOKEN_NAME;
      currentTokens.push(newTokenData);
      pm.mediator.trigger('newOAuth2Token', newTokenData);
      this.set('savedOAuth2Tokens', currentTokens);
    } else {
      newTokenData = _.zipObject(_.map(newToken.data, 'key'), _.map(newToken.data, 'value'));
      newTokenData.id = newToken.id;
      newTokenData.name = newToken.name || DEFAULT_TOKEN_NAME;
      currentTokens.push(newTokenData);
      pm.mediator.trigger('newOAuth2Token', newTokenData);
      this.set('savedOAuth2Tokens', currentTokens);
    }
  },

  updateOAauth2Token(updatedToken) {
    let currentTokens = this.get('savedOAuth2Tokens');

    pm.mediator.trigger('updateOAuth2Token', updatedToken);

    currentTokens = currentTokens.map(tk => {
      if (tk.id === updatedToken.id) {
        const token = _extends({},
        tk, {
          name: updatedToken.name });


        return token;
      }

      return tk;
    });

    this.set('savedOAuth2Tokens', currentTokens);
  },

  loadCurrentTokens() {
    if (typeof pm.oAuth2Tokens !== 'undefined') {
      const currentTokens = pm.oAuth2Tokens.models || [];

      currentTokens.forEach(token => {
        const rawToken = token.toJSON();

        this.loadOAuth2Token(rawToken);
      });
    }
  },

  deleteAllTokens(callback) {
    pm.oAuth2Tokens && pm.oAuth2Tokens.
    deleteAllAccessTokens(() => {
      this.set('savedOAuth2Tokens', []);
      _.isFunction(callback) && callback();
    });
  },

  deleteExpiredTokens(callback) {
    pm.oAuth2Tokens && pm.oAuth2Tokens.
    deleteExpiredTokens(() => {
      this.set('savedOAuth2Tokens', []);
      this.loadCurrentTokens();
      _.isFunction(callback) && callback();
    });
  },

  translateIntoLegacy: {
    oAuth2(newParams) {
      return {
        access_token_url: newParams.accessTokenUrl,
        add_token_to: newParams.addTokenTo || 'url',
        authorization_url: newParams.authUrl,
        client_authentication: newParams.client_authentication,
        client_id: newParams.clientId,
        client_secret: newParams.clientSecret,
        grant_type: newParams.grant_type,
        name: newParams.name,
        password: newParams.password,
        redirect_uri: newParams.redirect_uri,
        scope: newParams.scope,
        state: newParams.state,
        useBrowser: newParams.useBrowser,
        username: newParams.username,
        algorithm: newParams.algorithm,
        code_verifier: newParams.code_verifier };

    } },


  translateFromLegacy: {
    oAuth2(newParams) {
      return {
        accessTokenUrl: newParams.access_token_url,
        addTokenTo: newParams.add_token_to || 'url',
        authUrl: newParams.authorization_url,
        client_authentication: newParams.client_authentication,
        clientId: newParams.client_id,
        clientSecret: newParams.client_secret,
        grant_type: newParams.grant_type,
        name: newParams.name,
        password: newParams.password,
        redirect_uri: newParams.redirect_uri,
        scope: newParams.scope,
        state: newParams.state,
        useBrowser: newParams.useBrowser,
        username: newParams.username,
        algorithm: newParams.algorithm || 'S256',
        code_verifier: newParams.code_verifier || '' };

    } } });



/* harmony default export */ __webpack_exports__["default"] = (OAuth2Manager);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4325:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return OAuth2TokenFetcher; });
/* harmony import */ var postman_collection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(790);
/* harmony import */ var postman_collection__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(postman_collection__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(612);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(178);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(querystring__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_utils_ModelToSdkTransformer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1710);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1222);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(784);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4326);
/* harmony import */ var _js_modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1714);
/* harmony import */ var _OAuth2Utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4327);
/* harmony import */ var _OAuth2Utils__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_OAuth2Utils__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1711);
/* harmony import */ var _constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1495);
/* harmony import */ var _api_ExecutionManager__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1716);
/* harmony import */ var _constants_RuntimeEventsConstants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1717);
/* harmony import */ var _constants_RuntimeEventsConstants__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_constants_RuntimeEventsConstants__WEBPACK_IMPORTED_MODULE_13__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};














const isBrowser = window.SDK_PLATFORM === 'browser',
WEB_CALLBACK_URL = 'https://oauth.pstmn.io/v1/browser-callback',
NATIVE_CALLBACK_URL = 'https://oauth.pstmn.io/v1/callback',
BROWSER_CALLBACK_URL = isBrowser ? WEB_CALLBACK_URL : NATIVE_CALLBACK_URL,
CALLBACK_TIMEOUT = 120000,
POPUP_WIDTH = 600,
POPUP_HEIGHT = 600,
OAUTH2_GRANT_TYPE = {
  AUTHORIZATION_CODE: 'authorization_code',
  AUTHORIZATION_CODE_WITH_PKCE: 'authorization_code_with_pkce',
  IMPLICIT: 'implicit',
  PASSWORD_CREDENTIALS: 'password_credentials',
  CLIENT_CREDENTIALS: 'client_credentials' },


EVENT_SCHEMA = _extends({
  response: {
    to: 'object',
    select: {
      0: { key: 'error' },
      2: {
        key: 'response',
        select: {
          code: true,
          stream: true,
          contentInfo: {
            replace: { call: true } } } } } } },





_.pick(_constants_RuntimeEventsConstants__WEBPACK_IMPORTED_MODULE_13___default.a, ['start', 'exception', 'request', 'abort', 'done']));let


OAuth2TokenFetcher = class OAuth2TokenFetcher {
  constructor() {
    // Id of the auth flow that is currently running
    this.id = null;

    // Params for currently running auth flow
    this.params = null;

    // Response code for token request
    this.tokenResponseCode = null;

    // Wait timer for auth request response from external browser
    this.pendingBrowserAuthTimeout = null;

    // Reference to popup window opened in web app
    this.popupWindow = null;

    this.attachListeners();

    this.exectionManager = new _api_ExecutionManager__WEBPACK_IMPORTED_MODULE_12__["default"](Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('OAuth2TokenRequestStore'));
  }

  attachListeners() {
    // Handle events form OAuth2WindowManager
    pm.eventBus.channel('oauth2-login').subscribe(({ name, namespace, data }) => {
      // Ignore events that are not emitted for current runId
      if (!(this.id && _.get(data, 'id') === this.id)) {
        return;
      }

      // Handle auth callback from BrowserWindow
      if (namespace === 'oauth2BrowserLogin' && name === 'loginCallback') {
        return this.handleAuthCallback(data.error, data.result);
      }

      // Log requests from BrowserWindow in console
      if (namespace === 'oauth2BrowserLogin' && name === 'log') {
        const consolePayload = _extends({},
        data.payload, {
          indirect: 'auth',
          browserRequest: true });


        return pm.console.log(_constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_11__["CONSOLE_EVENT_NETWORK"], {}, consolePayload);
      }
    });

    // Handle auth callback from external browser via postman:// protocol
    if (!isBrowser) {
      pm.mediator.on('oauth2Callback', data => {
        // Bail out if there is no ongoing authentication
        if (!this.id) {return;}

        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2___default.a.parse(data.queryString.slice(1)),

        // Extract params from hash for implicit grant type
        hashParams = querystring__WEBPACK_IMPORTED_MODULE_2___default.a.parse(data.hash.slice(1)),

        // Combine queryParams and hashParams
        params = _.merge({}, queryParams, hashParams);

        // Find error from params to bubble it up
        let error = _.find(params, (value, key) => _.toLower(key) === 'error');

        clearTimeout(this.pendingBrowserAuthTimeout);

        error = error && new Error(error);

        return this.handleAuthCallback(error, params);
      });
    }

    // Handle events form oauth URL opened in another tab for web app
    if (isBrowser) {
      window.addEventListener('message', event => {
        // Bail out if there is no ongoing authentication
        if (!this.id) {
          return;
        }

        const data = _.get(event, 'data');

        // Bail out if the message is not sent from auth callback
        if (!(data && data.isAuthCallback)) {
          return;
        }

        data.queryString = data.queryString || '';
        data.hash = data.hash || '';

        const queryParams = querystring__WEBPACK_IMPORTED_MODULE_2___default.a.parse(data.queryString.slice(1)),

        // Extract params from hash for implicit grant type
        hashParams = querystring__WEBPACK_IMPORTED_MODULE_2___default.a.parse(data.hash.slice(1)),

        // Combine queryParams and hashParams
        params = _.merge({}, queryParams, hashParams);

        // Find error from params to bubble it up
        let error = _.find(params, (value, key) => _.toLower(key) === 'error');

        clearTimeout(this.pendingBrowserAuthTimeout);

        this.closePopupWindow();

        error = error && new Error(error);

        return this.handleAuthCallback(error, params);
      });
    }
  }

  /**
     * Starts OAuth 2.0 authorization flow. This may or may not involve opening the
     * external browser or OAuth2WindowManager with the given url.
     *
     * @param {Object} params OAuth 2 definition
     * @param {Object} [collectionId] Collection ID of the request from which the flow is started
     */
  startAuthorization(params, collectionId) {
    // Bailout if the id is not null. This should never happen. Because it means that one
    // authorization flow is currently in progress and only one flow can run at a time.
    if (this.id) {
      return Promise.reject(new Error('Could not start OAuth2 authentication process, please complete the ongoing authentication first.'));
    }

    // Set the id for new auth flow
    this.id = uuid_v4__WEBPACK_IMPORTED_MODULE_1___default()();

    // Inform the UI that auth flow is started
    pm.mediator.trigger('oauth2Start');

    const environmentId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveEnvironmentStore').id,
    globalsId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveGlobalsStore').id,
    workspaceId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id;

    return Object(_js_modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_8__["getVariableSessionMap"])({
      environmentId, globalsId, workspaceId, collectionId }).

    then(variablesMap => ({
      grant_type: params.grant_type,
      useBrowser: params.useBrowser || isBrowser, // Always use browser for web app
      algorithm: params.algorithm,
      access_token_url: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.access_token_url), variablesMap),
      authorization_url: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.authorization_url), variablesMap),
      client_authentication: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.client_authentication), variablesMap),
      client_id: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.client_id), variablesMap),
      client_secret: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.client_secret), variablesMap),
      password: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.password), variablesMap),
      redirect_uri: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.redirect_uri), variablesMap) || '/',
      scope: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.scope), variablesMap),
      state: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.state), variablesMap),
      username: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.username), variablesMap),
      name: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.name), variablesMap),
      code_verifier: _js_utils_ResolveVariableHelper__WEBPACK_IMPORTED_MODULE_7__["default"].resolve(_.clone(params.code_verifier), variablesMap) })).

    then(params => {
      // Cache params for current auth flow
      this.params = params;

      switch (params.grant_type) {
        case OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE:

        case OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE_WITH_PKCE:
          return this.handleAuthorizationCodeType();

        case OAUTH2_GRANT_TYPE.IMPLICIT:
          return this.handleImplicitType();

        case OAUTH2_GRANT_TYPE.PASSWORD_CREDENTIALS:
          return this.handlePasswordCredentialsType();

        case OAUTH2_GRANT_TYPE.CLIENT_CREDENTIALS:
          return this.handleClientCredentialsType();

        default:
          return Promise.reject(new Error('Could not complete OAuth 2.0 authorization, grant type is invalid'));}

    });
  }

  /**
     * Complete the ongoing authorization code flow.
     *
     * @param {Object} err error during the auth flow
     * @param {Object} result generated token data
     */
  finishAuthorizationFlow(err, result) {
    // Bail out if there is no ongoing auth flow
    if (!this.id) {
      return;
    }

    clearTimeout(this.pendingBrowserAuthTimeout);

    this.closePopupWindow();

    pm.runtime.terminateExecution({ id: this.id });

    Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('OAuth2TokenRequestStore').remove(this.id);

    this.id = null;

    if (err) {
      pm.mediator.trigger('oauth2Error', err.message || String(err));
      pm.toasts.error('Could not complete OAuth 2.0 login. Check Postman Console for more details.');
      pm.console.error(_constants_ConsoleEventTypes__WEBPACK_IMPORTED_MODULE_11__["CONSOLE_EVENT_EXCEPTION"], {}, {
        name: err && err.name,
        message: err.message || String(err) });


      return;
    }

    if (!result) {
      return;
    }

    // Add resolved token name in token
    result.name = this.params.name;

    // Inform the UI about newly generated token
    pm.mediator.trigger('addOAuth2Token', result);
  }

  /**
     * Starts authentication through external browser and returns the result in callback
     *
     * @param {SDKUrl} authUrl auth URL to open in browser
     */
  handleAuthFromBrowser(authUrl) {
    // Bail out if authUrl does not have host. It won't open in browser.
    if (!authUrl.getHost()) {
      return this.finishAuthorizationFlow(new Error('Invalid host for auth URL.'));
    }

    // Do not allow opening any protocol that is not http or https
    // this prevents security vulnerabilities, do not remove this ever, ever
    if (!(authUrl.protocol === 'https' || authUrl.protocol === 'http')) {
      return this.finishAuthorizationFlow(new Error('Invalid protocol for auth URL. Only HTTP and HTTPS protocol are allowed.'));
    }

    // Clear the pending auth after timeout and return error in callback
    this.pendingBrowserAuthTimeout = setTimeout(() => {
      this.finishAuthorizationFlow(new Error('OAuth 2.0 request timed out. Please try again.'));
    }, CALLBACK_TIMEOUT);

    if (isBrowser) {
      // Open auth URL in popup window
      this.openPopupWindow(authUrl.toString(true), POPUP_WIDTH, POPUP_HEIGHT);
    } else {
      // Open auth URL in external browser
      Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__["openExternalLink"])(authUrl.toString(true));
    }
  }

  /**
     * Opens the given URL in new popup window.
     *
     * @param {String} url url to open in new window
     * @param {Number} w width of the window
     * @param {Number} h height of the window
     */
  openPopupWindow(url, w, h) {
    // Calculations for dual-screen position
    // Obtain width and height in a way that works in all browsers.
    const dualScreenLeft = window.screenLeft || window.screenX,
    dualScreenTop = window.screenTop || window.screenY,
    width = window.innerWidth || document.documentElement.clientWidth || screen.width,
    height = window.innerHeight || document.documentElement.clientHeight || screen.height,
    systemZoom = width / window.screen.availWidth,
    left = (width - w) / 2 / systemZoom + dualScreenLeft,
    top = (height - h) / 2 / systemZoom + dualScreenTop;

    // Open popup window in center of the screen
    this.popupWindow = window.open(url, '', `scrollbars=yes,width=${w / systemZoom}, height=${h / systemZoom}, top=${top}, left=${left}`);
    this.popupWindow.focus();
  }

  /**
     * Closes the open popup window if there is any.
     */
  closePopupWindow() {
    if (!this.popupWindow) {
      return;
    }

    this.popupWindow.close();
    this.popupWindow = null;
  }

  /**
     * Handles OAuth flow for authorization_code/authorization_code_with_pkce grant type.
     * Involves opening auth url in a window/external browser.
     *
     * @see https://tools.ietf.org/html/rfc6749#section-4.1
     * @see https://tools.ietf.org/html/rfc7636 for PKCE Extension
     */
  handleAuthorizationCodeType() {
    const { params } = this,
    authUrl = new postman_collection__WEBPACK_IMPORTED_MODULE_0___default.a.Url(params.authorization_url);

    // Always use browser callback URL while authenticating through browser
    if (params.useBrowser) {
      params.redirect_uri = BROWSER_CALLBACK_URL;
    }

    // Add auth params for login window
    authUrl.addQueryParams([
    {
      key: 'response_type',
      value: 'code' },

    {
      key: 'state',
      value: encodeURIComponent(params.state) },

    {
      key: 'client_id',
      value: encodeURIComponent(params.client_id) },

    {
      key: 'scope',
      value: encodeURIComponent(params.scope) },

    {
      key: 'redirect_uri',
      value: encodeURIComponent(params.redirect_uri) }]);



    if (params.grant_type === OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE_WITH_PKCE) {
      params.code_verifier = params.code_verifier || Object(_OAuth2Utils__WEBPACK_IMPORTED_MODULE_9__["generateCodeVerifier"])();

      authUrl.addQueryParams([
      {
        key: 'code_challenge',
        value: encodeURIComponent(Object(_OAuth2Utils__WEBPACK_IMPORTED_MODULE_9__["getCodeChallenge"])(params.code_verifier, params.algorithm)) },

      {
        key: 'code_challenge_method',
        value: encodeURIComponent(params.algorithm) }]);


    }

    if (params.useBrowser) {
      // Login via browser
      this.handleAuthFromBrowser(authUrl);
    } else {
      // Request window manager for login
      pm.eventBus.channel('oauth2-login').publish({
        name: 'startLogin',
        namespace: 'oauth2BrowserLogin',
        data: {
          id: this.id,
          url: authUrl.toString(),
          cookiePartitionId: _js_utils_util__WEBPACK_IMPORTED_MODULE_5__["default"].getCookiePartition(),
          strictSSL: pm.settings.getSetting('SSLCertVerify'),
          matchOptions: {
            params: ['code'],
            uri: params.redirect_uri } } });



    }
  }

  /**
     * Handles OAuth 2.0 flow for implicit grant type. Involves user login on a window.
     *
     * @see https://tools.ietf.org/html/rfc6749#section-4.2
     */
  handleImplicitType() {
    const { params } = this,
    authUrl = new postman_collection__WEBPACK_IMPORTED_MODULE_0___default.a.Url(params.authorization_url);

    // Always use browser callback URL while authenticating through browser
    if (params.useBrowser) {
      params.redirect_uri = BROWSER_CALLBACK_URL;
    }

    authUrl.addQueryParams([
    {
      key: 'response_type',
      value: 'token' },

    {
      key: 'state',
      value: encodeURIComponent(params.state) },

    {
      key: 'client_id',
      value: encodeURIComponent(params.client_id) },

    {
      key: 'scope',
      value: encodeURIComponent(params.scope) },

    {
      key: 'redirect_uri',
      value: encodeURIComponent(params.redirect_uri) }]);



    if (params.useBrowser) {
      // Login via browser
      this.handleAuthFromBrowser(authUrl);
    } else {
      // Request window manager for login
      pm.eventBus.channel('oauth2-login').publish({
        name: 'startLogin',
        namespace: 'oauth2BrowserLogin',
        data: {
          id: this.id,
          url: authUrl.toString(),
          cookiePartitionId: _js_utils_util__WEBPACK_IMPORTED_MODULE_5__["default"].getCookiePartition(),
          strictSSL: pm.settings.getSetting('SSLCertVerify'),
          matchOptions: {
            params: ['access_token'],
            uri: params.redirect_uri } } });



    }
  }

  /**
     * Handles auth request result from redirect URL.
     *
     * @see https://tools.ietf.org/html/rfc6749#section-4.1.2
     *
     * @param {Object} err error during authorization request
     * @param {Object} response parsed result from redirect URL params/hash
     */
  handleAuthCallback(err, response) {
    if (err) {
      return this.finishAuthorizationFlow(err);
    }

    if (this.params.grant_type === OAUTH2_GRANT_TYPE.IMPLICIT) {
      // Access_token is in the hash, no further request needed
      return this.finishAuthorizationFlow(null, response);
    }

    const { params } = this,
    request = this.getOAuth2TokenRequest(params.access_token_url, OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE);

    // Add authorization code flow specific params
    request.body.urlencoded.populate([
    {
      key: 'code',
      value: response.code },

    {
      key: 'redirect_uri',
      value: params.redirect_uri }]);



    if (params.grant_type === OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE_WITH_PKCE) {
      request.body.urlencoded.append({
        key: 'code_verifier',
        value: params.code_verifier });

    }

    // Authenticate token request
    this.addClientAuthentication(request, params);

    // Exchange authorization code for access token
    this.requestAccessToken({ request: request.toJSON() });
  }

  /**
     * Handles OAuth 2.0 flow for password grant type. Does not involve user login flow.
     * @see https://tools.ietf.org/html/rfc6749#section-4.3
     */
  handlePasswordCredentialsType() {
    const { params } = this,
    request = this.getOAuth2TokenRequest(params.access_token_url, 'password');

    request.body.urlencoded.populate([
    {
      key: 'username',
      value: params.username },

    {
      key: 'password',
      value: params.password },

    {
      key: 'scope',
      value: params.scope }]);



    // Authenticate token request
    this.addClientAuthentication(request, params);

    // Request token
    this.requestAccessToken({ request: request.toJSON() });
  }

  /**
     * Handles OAuth 2.0 flow for client credentials grant type. Does not involve user login flow.
     *
     * @see https://tools.ietf.org/html/rfc6749#section-4.4
     */
  handleClientCredentialsType() {
    const { params } = this,
    request = this.getOAuth2TokenRequest(params.access_token_url, OAUTH2_GRANT_TYPE.CLIENT_CREDENTIALS);

    request.body.urlencoded.add({
      key: 'scope',
      value: params.scope });


    // Authenticate token request
    this.addClientAuthentication(request, params);

    // Request token
    this.requestAccessToken({ request: request.toJSON() });
  }

  /**
     * Returns a bootstrapped token request for OAuth 2.0. Has grant type added to body.
     *
     * @param {SDKUrl} url url for token request
     * @param {String} grantType grant type to be sent in payload
     *
     * @returns {SDKRequest} an sdk Request Object
     */
  getOAuth2TokenRequest(url, grantType) {
    return new postman_collection__WEBPACK_IMPORTED_MODULE_0___default.a.Request({
      method: 'POST',
      url,
      header: [{
        key: 'Content-Type',
        value: 'application/x-www-form-urlencoded' }],

      body: {
        mode: 'urlencoded',
        urlencoded: [{
          key: 'grant_type',
          value: grantType }] } });



  }

  /**
     * Adds client authentication to request.
     * If `client_authentication` is set to body, it is added to body, or as basic auth header if set to `header`.
     *
     * @param {SDKRequest} request request to authenticate
     * @param {Object} options has `client_authentication`, client_id` and `client_secret`
     */
  addClientAuthentication(request, options) {
    if (options.client_authentication === 'body') {
      request.body.urlencoded.populate([
      {
        key: 'client_id',
        value: options.client_id },

      {
        key: 'client_secret',
        value: options.client_secret }]);


    } else {
      (options.grant_type === OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE ||
      options.grant_type === OAUTH2_GRANT_TYPE.AUTHORIZATION_CODE_WITH_PKCE) &&
      request.body.urlencoded.add({
        key: 'client_id',
        value: options.client_id });


      request.auth = new postman_collection__WEBPACK_IMPORTED_MODULE_0___default.a.RequestAuth({
        type: 'basic',
        basic: [
        {
          key: 'username',
          value: options.client_id },

        {
          key: 'password',
          value: options.client_secret }] });



    }
  }

  /**
     * Handles the request for a token using the token url. This is passed to `postman-runtime` so that user cookies
     * are not added to this request and client certificates can be attached.
     *
     * @param {SDKItem~definition} item item for token request
     */
  requestAccessToken(item) {
    const collection = { item },
    variables = {},
    runOptions = {
      useSystemProxy: pm.settings.getSetting('useSystemProxy'),
      proxies: pm.proxyListManager.getGlobalProxyConfigList(),
      ignoreProxyEnvironmentVariables: !_js_utils_util__WEBPACK_IMPORTED_MODULE_5__["default"].useProxyEnvironmentVariables(),
      certificates: _js_utils_ModelToSdkTransformer__WEBPACK_IMPORTED_MODULE_3__["default"].getClientSslCerts(pm.certificateManager),
      fileResolver: {
        workingDir: Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_10__["getWorkingDir"])(),
        insecureFileRead: Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_10__["insecureFileRead"])(),
        fileWhitelist: [] },

      requester: {
        useWhatWGUrlParser: pm.settings.getSetting('useWhatWGUrlParser'),
        strictSSL: pm.settings.getSetting('SSLCertVerify'),
        extendedRootCA: pm.settings.getSetting('isCACertEnabled') ? pm.settings.getSetting('CACertPath') : undefined,
        verbose: true },

      script: {
        serializeLogs: true } },


    execution = this.exectionManager.create(EVENT_SCHEMA);

    Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('OAuth2TokenRequestStore').add({
      id: execution.id,
      tokenFetcher: this });


    execution.start(collection, variables, runOptions);
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4326:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var postman_collection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(790);
/* harmony import */ var postman_collection__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(postman_collection__WEBPACK_IMPORTED_MODULE_0__);


// Add Unit tests
let ResolveVariableHelper = class ResolveVariableHelper {
  constructor() {
  }

  resolve(string, variables = {}) {
    if (typeof string === 'number') {
      return string;
    }

    if (string == null) {
      return '';
    }

    return postman_collection__WEBPACK_IMPORTED_MODULE_0__["Property"].replaceSubstitutions(string, variables);
  }};


/* harmony default export */ __webpack_exports__["default"] = (new ResolveVariableHelper());

/***/ }),

/***/ 4327:
/***/ (function(module, exports, __webpack_require__) {

const crypto = __webpack_require__(376);

/**
                                   * Base64url Encoding without Padding
                                   *
                                   * @see https://tools.ietf.org/html/rfc7636#page-17
                                   *
                                   * @param {Buffer} buffer
                                   */
const base64urlencode = buffer => {
  let encodedString = buffer.toString('base64');

  // eslint-disable-next-line prefer-destructuring
  encodedString = encodedString.split('=')[0];
  encodedString = encodedString.replace(/\+/g, '-');
  encodedString = encodedString.replace(/\//g, '_');

  return encodedString;
},

/**
   * Generate Code Verifier for OAuth2.0 Proof Key for Code Exchange flow.
   * 32-octet sequence generates code verifier having length of 43.
   *
   * @see https://tools.ietf.org/html/rfc7636#page-8
   *
   * @param {Number} [length=32]  It is the length of octets from which code verifier will be generated
   */
generateCodeVerifier = (length = 32) => {
  const buffer = crypto.randomBytes(length);

  return base64urlencode(buffer);
},

/**
   * Generate code challenge from code verifier.
   *
   * @param {String} codeVerifier
   * @param {String} codeChallengeMethod
   */
getCodeChallenge = (codeVerifier, codeChallengeMethod) => {
  if (!codeVerifier || codeChallengeMethod === 'plain') {
    return codeVerifier || '';
  }

  const hash = crypto.createHash('sha256').update(codeVerifier).digest();

  return base64urlencode(hash);
};

module.exports = {
  generateCodeVerifier,
  getCodeChallenge };

/***/ }),

/***/ 4328:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(784);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(664);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(async__WEBPACK_IMPORTED_MODULE_1__);



/**
                            * @typedef {Object} Cookie
                            */

/**
                                * Handles the 'Manage Cookies' modal in electron
                                *
                                * @class CookieManager
                                *
                                * @todo Incomplete
                                */let
CookieManager = class CookieManager {

  constructor() {
    this.cookies = {};
    this.callbackAccumulator = [];

    this.loadCookiesDebounced = _.debounce(this.loadCookies, 300);
  }

  _cookieStore(method, options, callback) {
    pm.runtime.cookieHandler(method, _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].getCookiePartition(), options, callback);
  }

  /**
     * @private
     *
     * @param {string} url - URL of the cookie
     * @param {string} host - Host (domain) name of the cookie
     * @param {Object} cookie - Cookie object
     * @param {Function} [callback] - Callback function to be triggered
     */
  _writeToCookieStore(url, host, cookie, callback) {
    if (!host) {return;}

    var urlKey = host;
    urlKey[0] == '.' && (urlKey = urlKey.substring(1));
    if (!this.cookies.hasOwnProperty(urlKey)) {
      this.cookies[urlKey] = {};
    }

    // cookie will be loaded once the callback is successful
    if (cookie.url.indexOf('http://') !== 0 && cookie.url.indexOf('https://') !== 0) {
      cookie.url = 'http://' + cookie.url;
    }

    if (!cookie.domain) {
      cookie.domain = host;
    }
    if (!cookie.Path) {
      cookie.Path = '/';
    }

    if (host[0] == '.') {
      host = host.substring(1);
    }
    var cookieToSet = {
      url: cookie.url,
      name: cookie.name,
      value: cookie.value,
      domain: host,
      path: cookie.path,
      secure: cookie.secure,
      expirationDate: cookie.expires,
      httpOnly: cookie.httpOnly };


    this._cookieStore('set', cookieToSet, err => {
      _.isFunction(callback) && callback(err);
    });
  }

  /**
     * `loadCookiesBulk` accumulates all the callbacks and uses debounced `loadCookies`.
     * Once `loadCookies` is triggered, all the callbacks are called and the accumulator is cleared.
     *
     * @param {Function} callback - Callback function to be triggered
     */
  loadCookiesBulk(callback) {
    this.callbackAccumulator.push(callback);

    this.loadCookiesDebounced(() => {
      const callbacks = this.callbackAccumulator;

      // Empty the callback accumulator so that we do not miss any callback during flushing of
      // other callbacks
      this.callbackAccumulator = [];

      _.forEach(callbacks, callback => {
        _.isFunction(callback) && callback();
      });
    });
  }

  // when the app loads
  // load all session cookies into this.cookies

  // when a request is being sent
  // if the cookies header is present > (call webContent.cookies.set)
  // and add to this.cookies

  // when a response is received
  // for each set cookie header, parse the Set-Cookie header and add it to .set and the store > NOTE- this might never be called
  // also get the cookies for the request's domain, and re-add to this.cookies (if electron parses response headers on it's own)

  loadCookies(callback) {
    // This makes sure we clear all the cookies in each domain, but retain the domain
    // We ignore the cache because, now the main process can delete cookies
    // and we have no means to update out cache.
    _.forEach(_.keys(this.cookies), domain => {
      this.cookies[domain] = {};
    });

    this._cookieStore('get', {}, (err, cookies) => {
      if (err) {
        pm.logger.error(err);
        return _.isFunction(callback) && callback();
      }

      try {
        _.each(cookies, cookie => {
          var domain = cookie.domain;
          if (domain[0] == '.') {
            domain = domain.substring(1);
          }
          if (!this.cookies.hasOwnProperty(domain)) {
            this.cookies[domain] = {};
          }
          !this.cookies[domain][cookie.name] && (this.cookies[domain][cookie.name] = []);
          this.cookies[domain][cookie.name].push(cookie);
        });
        pm.mediator.trigger('loadedCookies', this.getDomainList());
      }
      catch (e) {
        pm.logger.error(e);
      } finally
      {
        return _.isFunction(callback) && callback();
      }
    });
  }

  getAllCookies() {
    return _.cloneDeep(this.cookies);
  }

  getAllCookiesAsync(cb) {
    this._cookieStore('get', {}, (err, cookies) => {
      if (err) {return cb(err);}

      _.each(cookies, cookie => {
        var domain = cookie.domain;
        if (domain[0] == '.') {
          domain = domain.substring(1);
        }
        if (!this.cookies.hasOwnProperty(domain)) {
          this.cookies[domain] = {};
        }
        this.cookies[domain][cookie.name] = cookie;
      });

      cb(null, this.cookies);
    });
  }

  getCookiesForDomain(domain) {
    if (domain[0] === '.') {
      domain = domain.slice(1);
    }
    return this.cookies[domain];
  }

  getDomainList() {
    var retVal = [];
    for (var domain in this.cookies) {
      if (this.cookies.hasOwnProperty(domain)) {
        retVal.push(domain);
      }
    }
    return retVal;
  }

  // Acc. to the spec at https://tools.ietf.org/html/rfc6265#section-5.1.4
  getCookiesForUrl(url) {
    if (!url) {return [];}
    url = _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].ensureProperUrl(url);
    try {
      var urlObject = _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].getURLProps(url),
      hostname = urlObject.hostname,
      domainCookies = _.values(this.getCookiesForDomain(hostname));
      return _.filter(domainCookies, function (domainCookie) {
        return (
          !urlObject.pathname ||
          urlObject.pathname == domainCookie.path ||
          urlObject.pathname.indexOf(domainCookie.path) == 0 && (
          urlObject.pathname[domainCookie.path.length] == '/' ||
          _.last(domainCookie.path) == '/'));


      });
    }
    catch (e) {
      // invalid URL
      return [];
    }
  }

  /*
    * cookie string is the value of the Cookies header
    * add these cookies to URL
    */
  addCookies(url, cookieString) {
    try {
      var urlObject = _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"].getURLProps(url);
      var host = urlObject.host;
      var cookies = _utils_util__WEBPACK_IMPORTED_MODULE_0__["default"]._parseCookieHeader(host, cookieString);
      _.each(cookies, cookie => {
        this.addSingleCookie(url, host, cookie);
      });
    }
    catch (e) {
      pm.logger.error('Could not add cookies for invalid URL');
      pm.logger.error(e);
    }
  }

  /**
     * `cookies` param has a similar structure to `addSingleCookie` method's params
     *
     * @param {Object[]} cookies - Array of Objects containing cookies
     * @param {string} cookies[].url - URL of the cookie
     * @param {string} cookies[].host - Host (domain) name of the cookie
     * @param {Object} cookies[].cookie - Cookie object
     * @param {Function} [callback] - Callback function to be triggered
     */
  addBulkCookies(cookies, callback) {
    async__WEBPACK_IMPORTED_MODULE_1___default.a.each(cookies, (cookieItem, next) => {
      this._writeToCookieStore(cookieItem.url, cookieItem.host, cookieItem.cookie, next);
    }, err => {
      if (err) {
        return _.isFunction(callback) && callback(err);
      }

      this.loadCookiesBulk(() => {
        _.isFunction(callback) && callback();
      });
    });
  }

  /**
     *
     * @param {string} url - URL of the cookie
     * @param {string} host - Host (domain) name of the cookie
     * @param {Object} cookie - Cookie object
     * @param {Function} [callback] - Callback function to be triggered
     */
  addSingleCookie(url, host, cookie, callback) {
    this._writeToCookieStore(url, host, cookie, err => {
      if (err) {
        return _.isFunction(callback) && callback(err);
      }

      this.loadCookies(() => {
        _.isFunction(callback) && callback();
      });
    });
  }

  /**
    * Called when a New domain is added from the Cookie Modal
    * @private
    */
  addNewDomain(domainName) {
    if (!domainName || domainName == '') {
      return;
    }
    domainName = domainName.toLowerCase();
    if (!this.cookies.hasOwnProperty(domainName)) {
      this.cookies[domainName] = {};
    }
  }

  editCookie(domain, oldCookie, newCookie, callback) {
    let cookieName = oldCookie.name,
    cookiePath = oldCookie.path;

    this._cookieStore('get', {}, (err, cookies) => {
      if (err) {_.isFunction(callback) && callback(err);}

      _.each(cookies, cookie => {
        if (!cookie) {
          return;
        }

        cookie.domain = cookie.domain[0] === '.' ? cookie.domain.slice(1) : cookie.domain;

        _.isEqual(cookie.domain, domain) && _.isEqual(cookie.path, cookiePath) && _.isEqual(cookie.name, cookieName) && this.deleteCookie(domain, cookieName, cookie.path, error => {
          error && _.isFunction(callback) && callback(error);

          this.addSingleCookie(newCookie.url, newCookie.domain, newCookie, error => {
            _.isFunction(callback) && callback(error);
          });
        });
      });
    });
  }

  deleteDomain(domain, callback) {
    let cookiesForDomain = this.cookies[domain],
    cookiesToDelete = _.flatMap(cookiesForDomain); // take the values and flatten them

    // The delete single cookie logic deletes multiple cookies with same name
    // and then adds back the ones which shouldn't have been deleted. So we should do this
    // in series, otherwise because of concurrency we will end up with some cookies non-deleted
    async__WEBPACK_IMPORTED_MODULE_1___default.a.eachSeries(cookiesToDelete, (cookie, next) => {
      this.deleteCookie(domain, cookie.name, cookie.path, next);
    }, res => {
      // wait for all cookies to be deleted, then delete the domain too from UI
      if (res && res.type === 'RemoveCookieError') {
        res['domain'] = domain;
        _.isFunction(callback) && callback(res);

        return;
      }

      delete this.cookies[domain];

      this.loadCookies(() => {
        let res = {
          type: 'Success',
          domain: domain };


        _.isFunction(callback) && callback(res);
      });
    });
  }

  deleteCookie(domain, cookieName, path, callback) {
    let url = domain + path,
    matchingCookies = _.get(this.cookies, [domain[0] === '.' ? domain.slice(1) : domain, cookieName]);

    if (!matchingCookies) {
      return;
    }

    if (url[0] === '.') {
      url = 'www' + url;
    }

    var httpUrl = url,
    httpsUrl = url,
    index = _.findIndex(matchingCookies, { path });

    if (index === -1) {
      _.isFunction(callback) && callback();
      return;
    }

    if (url.indexOf('http://') !== 0 && url.indexOf('https://') !== 0) {
      httpUrl = 'http://' + url;
      httpsUrl = 'https://' + url;
    }

    this._cookieStore('remove', { url: httpUrl, name: cookieName }, err => {
      if (err) {
        err['type'] = 'removeCookieError';
        _.isFunction(callback) && callback(err);
      }

      this._cookieStore('remove', { url: httpsUrl, name: cookieName }, err => {
        if (err) {
          err['type'] = 'removeCookieError';
          _.isFunction(callback) && callback(err);
        }

        if (_.size(matchingCookies) <= 1) {
          this.loadCookies(() => {
            _.isFunction(callback) && callback();
          });
          return;
        }

        // If there were multiple cookies with same name & different paths,
        // this would have deleted all those cookies, adding them back
        matchingCookies.splice(index, 1); // remove the one which was intended to be deleted

        let bulkCookies = _.map(matchingCookies, cookie => {
          cookie.url = cookie.domain + cookie.path;
          cookie.secure ? cookie.url = 'https://' + cookie.url : cookie.url = 'http://' + cookie.url;

          return {
            url: cookie.url,
            host: cookie.domain,
            cookie };

        });

        this.addBulkCookies(bulkCookies, () => {
          _.isFunction(callback) && callback();
        });
      });
    });
  }};


/* harmony default export */ __webpack_exports__["default"] = (CookieManager);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4337:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeConfigurations", function() { return initializeConfigurations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeServices", function() { return initializeServices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "subscribeToModelEvents", function() { return subscribeToModelEvents; });
/* harmony import */ var _services_Configuration__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4338);
/* harmony import */ var _services_FeatureFlags__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4342);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(742);





let servicesMap = [
_services_Configuration__WEBPACK_IMPORTED_MODULE_0__["default"],
_services_FeatureFlags__WEBPACK_IMPORTED_MODULE_1__["default"]];


/**
                * Initializes the configuration service
                *
                * @param {Function} cb
                */
function initializeConfigurations(cb) {
  initializeServices().
  then(({ configService, featureFlagService }) => {
    pm.configs = configService;
    pm.features = featureFlagService;
    pm.logger.info('bootConfigurations~initialize - Success');
    cb && cb(null);
  }).
  catch(e => {
    pm.logger.error('bootConfigurations~initialize - Failed', e);
    cb & cb(e);
  });
}

/**
   * Initializes the configuration caches
   */
function initializeServices() {
  return Promise.all(_.map(servicesMap, s => {
    let service = new s();
    subscribeToModelEvents(service, service._getLayerNamespaces());
    return Promise.resolve(service);
  })).
  then(values => {
    return {
      configService: values[0],
      featureFlagService: values[1] };

  });
}

/**
   * Subscribes the caches to the model-events on the event bus
   *
   * @param {*} cache
   * @param {*} namespaces
   */
function subscribeToModelEvents(service, namespaces) {
  pm.eventBus.channel('model-events').subscribe(function (event) {
    Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["processEvent"])(event, ['updated'], function (event, cb) {
      let eventNamespace = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["getEventNamespace"])(event),
      eventName = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["getEventName"])(event);

      if (!_.includes(namespaces, eventNamespace)) {
        return cb && cb();
      }

      // Bail out if any other action except updated
      if (eventName !== 'updated') {
        return cb && cb();
      }

      // Invalidate the cache if changes are made
      service.invalidateCache();
      cb && cb();
    });
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4338:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BaseConfigurationService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);
/* harmony import */ var _modules_controllers_UserConfigurationController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1232);
/* harmony import */ var _modules_controllers_DefaultConfigurationController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4340);


let

Configuration = class Configuration extends _BaseConfigurationService__WEBPACK_IMPORTED_MODULE_0__["default"] {constructor(...args) {var _temp;return _temp = super(...args), this.
    layers = {
      user: {
        controller: _modules_controllers_UserConfigurationController__WEBPACK_IMPORTED_MODULE_1__["default"],
        namespace: 'userconfigs' },

      app: {
        controller: _modules_controllers_DefaultConfigurationController__WEBPACK_IMPORTED_MODULE_2__["default"],
        namespace: 'defaultconfigs' } }, this.




    resolutionOrder = ['app', 'user'], _temp;} // The order in which the layers will be resolved
};

/* harmony default export */ __webpack_exports__["default"] = (Configuration);

/***/ }),

/***/ 4339:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return BaseConfigurationService; });
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(131);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_0__);
let

BaseConfigurationService = class BaseConfigurationService extends events__WEBPACK_IMPORTED_MODULE_0___default.a {
  _getLayerNamespaces() {
    return _.map(this.layers, layer => layer.namespace);
  }

  _getResolved(key) {
    if (this.resolvedConfiguration[key] === undefined) {
      return Promise.reject(new Error('ConfigurationService: Could not get config. Key does not exist'));
    }
    return Promise.resolve(this.resolvedConfiguration[key]);
  }

  // Single level access support
  get(key) {
    // cache hit
    if (this.resolvedConfiguration) {
      return this._getResolved(key);
    }

    // cache miss
    return this.
    resolveConfigurationLayers().
    then(resolvedConfiguration => {
      this.resolvedConfiguration = resolvedConfiguration;
      return this._getResolved(key);
    });
  }

  // @todo Lazy loading implementation
  //
  // NOTE: PREVENT MISUSE OF THIS METHOD.
  // USE THE GET METHOD TO GET SPECIFIED KEYS.
  _getAll() {
    // cache hit
    if (this.resolvedConfiguration) {
      return Promise.resolve(this.resolvedConfiguration);
    }

    // cache miss
    return this.
    resolveConfigurationLayers().
    then(resolvedConfiguration => {
      this.resolvedConfiguration = resolvedConfiguration;
      return this.resolvedConfiguration;
    });
  }

  /**
     * Resolves single level JSON
     */
  resolveConfigurationLayers() {
    return Promise.all(_.map(this.resolutionOrder, i => this.layers[i].controller.getAll())).
    then(configurations => {
      let resolvedConfiguration = {};
      _.forEach(configurations, configuration => {
        Object.assign(resolvedConfiguration, configuration);
      });
      return resolvedConfiguration;
    });
  }

  invalidateCache() {
    this.resolvedConfiguration = null;
    this.emit('changed');
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4340:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
let defaultConfiguration = __webpack_require__(4341);

/* harmony default export */ __webpack_exports__["default"] = ({
  getAll: function () {
    return Promise.resolve(defaultConfiguration);
  } });

/***/ }),

/***/ 4341:
/***/ (function(module) {

module.exports = JSON.parse("{\"editor.requestEditorLayoutName\":\"layout-1-column\",\"request.autoPersistVariables\":true,\"user.plansToAllowUpgrade\":[],\"workspace.visibilityAvailablePlans\":[],\"editor.openInNew\":false,\"editor.skipConfirmationBeforeClose\":false,\"editor.showIcons\":true}");

/***/ }),

/***/ 4342:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BaseConfigurationService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4339);
/* harmony import */ var _modules_controllers_UserFeatureFlagController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1225);
/* harmony import */ var _modules_controllers_DefaultFeatureFlagController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4343);


let

FeatureFlags = class FeatureFlags extends _BaseConfigurationService__WEBPACK_IMPORTED_MODULE_0__["default"] {constructor(...args) {var _temp;return _temp = super(...args), this.
    layers = {
      user: {
        controller: _modules_controllers_UserFeatureFlagController__WEBPACK_IMPORTED_MODULE_1__["default"],
        namespace: 'userfeatureflags' },

      app: {
        controller: _modules_controllers_DefaultFeatureFlagController__WEBPACK_IMPORTED_MODULE_2__["default"],
        namespace: 'defaultfeatureflags' } }, this.




    resolutionOrder = ['app', 'user'], _temp;} // The order in which the layers will be resolved.

  isEnabled(key) {
    return super.get(key);
  }

  get() {
    return new Error('Feature Flags: Use the isEnabled API to get a flag');
  }};


/* harmony default export */ __webpack_exports__["default"] = (FeatureFlags);

/***/ }),

/***/ 4343:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
let defaultFeatureFlags = __webpack_require__(4344);

/* harmony default export */ __webpack_exports__["default"] = ({
  getAll: function () {
    return Promise.resolve(defaultFeatureFlags);
  } });

/***/ }),

/***/ 4344:
/***/ (function(module) {

module.exports = JSON.parse("{\"inviteByNonAdmin\":false,\"collectionAndFolderConfigurations\":false,\"schemaChangelog\":true,\"requestValidation\":true,\"schemaSyncing\":false,\"schemaValidation\":true}");

/***/ }),

/***/ 4345:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_, global) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgentInterface", function() { return AgentInterface; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IPCAgent", function() { return IPCAgent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebsocketAgent", function() { return WebsocketAgent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XHRAgent", function() { return XHRAgent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgentManager", function() { return AgentManager; });
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4346);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(664);
/* harmony import */ var async__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(async__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4356);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(751);
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4400);
/* harmony import */ var eventemitter3__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(eventemitter3__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1711);
/* harmony import */ var _js_common_utils_pathIsInside__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4401);
/* harmony import */ var _js_common_utils_pathIsInside__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_js_common_utils_pathIsInside__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(742);
/* harmony import */ var _js_common_services_RuntimeExecutionService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4402);
/* harmony import */ var _js_common_services_RuntimeExecutionService__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_js_common_services_RuntimeExecutionService__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2104);
/* harmony import */ var _constants_VisualizerConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1740);
/* harmony import */ var _js_common_utils_postmanFs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4413);
/* harmony import */ var _js_common_utils_postmanFs__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_js_common_utils_postmanFs__WEBPACK_IMPORTED_MODULE_12__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _desc, _value, _class, _descriptor, _descriptor2, _desc2, _value2, _class7, _descriptor3;function _initDefineProp(target, property, descriptor, context) {if (!descriptor) return;Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 });}function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {var desc = {};Object['ke' + 'ys'](descriptor).forEach(function (key) {desc[key] = descriptor[key];});desc.enumerable = !!desc.enumerable;desc.configurable = !!desc.configurable;if ('value' in desc || desc.initializer) {desc.writable = true;}desc = decorators.slice().reverse().reduce(function (desc, decorator) {return decorator(target, property, desc) || desc;}, desc);if (context && desc.initializer !== void 0) {desc.value = desc.initializer ? desc.initializer.call(context) : void 0;desc.initializer = undefined;}if (desc.initializer === void 0) {Object['define' + 'Property'](target, property, desc);desc = null;}return desc;}function _initializerWarningHelper(descriptor, context) {throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');} /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           * @file The agent manager forms a singleton to control which runtime agent
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           *       interface is used on which platform
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           */




// { REMOVE By shifting path related activity to the agent


// REMOVE }



// { REMOVE By shifting path related activity to the agent



// REMOVE }








// { REMOVE By shifting path related activity to the agent
const processFiles = files => _.map(files, file => {
  // If the file in not an instance of File then it already has been
  // processes, there is not much to do here (We should not hit this flow ideally)
  if (!(file instanceof File)) {
    return file;
  }

  const workingDir = Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__["getWorkingDir"])();

  // Note: IPC Agent cannot be used in web hence we do not are much about
  // unavailability of file.path
  let filePath = file.path;

  if (_js_common_utils_pathIsInside__WEBPACK_IMPORTED_MODULE_7___default()(filePath, workingDir)) {
    // Set the relative path of the file from the workingDir as the selected file path
    filePath = path__WEBPACK_IMPORTED_MODULE_3___default.a.relative(workingDir, filePath);
  }

  // At this point we know that the file is an instance of file, i.e it has been newly added,
  // we transform the File object to a standard object that rest of the application will understand
  return {
    // The name of the file without the path
    name: file.name,

    // The mediatype of the file
    type: file.type,

    // The actual path will be used for white listing, null value will not add to whitelist
    // Note: actual path is always a absolute path
    actual: file.path,

    // Whatever the file path is sanitize it to posix (This has to be done right before saving)
    path: Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__["sanitizePath"])(filePath) };

});

/**
     * Converts binary responseStream to base64 encoded string
     *
     * @param {Buffer|Uint8Array|ArrayBuffer|String} data
     */
function base64Encode(responseStream) {
  if (responseStream instanceof ArrayBuffer) {
    // ResponseStream will be ArrayBuffer in browser with Websocket agent. convert it to Uint8Array
    responseStream = new Uint8Array(responseStream);
  }

  if (responseStream instanceof Uint8Array) {
    // ResponseStream will be Uint8Array in browser. convert it to binary string
    const binstr = Array.prototype.map.call(responseStream, ch => String.fromCharCode(ch)).join('');

    return btoa(binstr);
  }

  // Checking if Buffer exist and responseStream is an instance of Buffer
  if (global.Buffer && responseStream instanceof global.Buffer) {
    // ResponseStream will be Buffer in electron app.
    return responseStream.toString('base64');
  }

  if (typeof responseStream === 'string') {
    return btoa(responseStream);
  }

  return null;
}

// REMOVE }

/**
 * Class to handle lifecycle of an agent
 */let
Lifecycle = (_class = class Lifecycle {constructor() {_initDefineProp(this, 'state', _descriptor, this);_initDefineProp(this, 'health', _descriptor2, this);this.


    selected = false;}


  setConnectionState(state) {
    this.state = state;
  }


  setHealth(health) {
    this.health = health;
  }

  /**
     * Interface to check health of the system
     */
  checkHealth() {}

  /**
                    * Hook triggered when agent gets selected
                    */
  select() {this.selected = true;}

  /**
                                    * Hook triggered when the agents gets deselected
                                    */
  deselect() {this.selected = false;}}, (_descriptor = _applyDecoratedDescriptor(_class.prototype, 'state', [mobx__WEBPACK_IMPORTED_MODULE_4__["observable"]], { enumerable: true, initializer: function () {return _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].DISCONNECTED;} }), _descriptor2 = _applyDecoratedDescriptor(_class.prototype, 'health', [mobx__WEBPACK_IMPORTED_MODULE_4__["observable"]], { enumerable: true, initializer: function () {return false;} }), _applyDecoratedDescriptor(_class.prototype, 'setConnectionState', [mobx__WEBPACK_IMPORTED_MODULE_4__["action"]], Object.getOwnPropertyDescriptor(_class.prototype, 'setConnectionState'), _class.prototype), _applyDecoratedDescriptor(_class.prototype, 'setHealth', [mobx__WEBPACK_IMPORTED_MODULE_4__["action"]], Object.getOwnPropertyDescriptor(_class.prototype, 'setHealth'), _class.prototype)), _class);


/**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * A interface class implementing generic agent interfaces
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      *
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * @interface
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */
let AgentInterface = class AgentInterface extends Lifecycle {constructor(...args) {var _temp;return _temp = super(...args), this.
    type = 'default', _temp;}

  /**
                               * Interface to trigger run a full collection
                               *
                               * @param {Object} info
                               * @param {String} info.id
                               * @param {Object} collection A collection in v2 postman collection schema
                               * @param {Object} options
                               *
                               */
  executeCollection() {}

  /**
                          * Terminates an ongoing execution
                          *
                          * @param {Object} criteria
                          * @param {String} criteria.id
                          *
                          */
  terminateExecution() {}

  /**
                           * Pauses an ongoing execution
                           *
                           * @param {Object} criteria
                           * @param {String} criteria.id
                           */
  pauseExecution() {}

  /**
                       * Resumes a paused ongoing execution
                       *
                       * @param {Object} criteria
                       * @param {String} criteria.id
                       */
  resumeExecution() {}

  /**
                        * @LivePreview: Used to preview request (headers, body/query params)
                        *
                        * @param {Object} request
                        * @param {Object} options
                        *  cookiePartitionId,
                        *  implicitCacheControl,
                        *  implicitTraceHeader,
                        *  protocolProfileBehavior
                        */
  previewRequest() {}

  /**
                       * Check if the given path is within the working directory
                       * @param {String} path
                       * @returns {Boolean}
                       */
  isInWorkingDir() {return false;}


  /**
                                    * Post process file selection for platform and agent compatibility
                                    *
                                    * @param {FileList} files A list of files returned from file selection
                                    * @param {processFileCallback} cb
                                    *
                                    * @callback processFileCallback Callback for
                                    * @param {Error} err
                                    * @param {Array} processedFiles
                                    */
  processFiles(_, cb) {return cb(null, _);}

  /**
                                             * Read contents of a file
                                             * @param {String|File} path
                                             * @param {readFileCallback} cb
                                             *
                                             * @callback readFileCallback Callback for
                                             * @param {Error} err
                                             * @param {String} content The content of the file after decoding as string
                                             */
  readFile(_, cb) {return cb(null, '');}

  /**
                                          * Check if the given file path is accessible
                                          * @param {String} path - Path to a directory or file (absolute or relative to working directory)
                                          * @param {Boolean} writeable - Should the access be writable
                                          * @param {pathAccessibleCallback} cb
                                          *
                                          * @callback pathAccessibleCallback
                                          * @param {Error} err - Error if file is not accessible
                                          */
  pathAccessible(_, __, cb) {return cb();}

  /**
                                            * Get the visualizer style content
                                            *
                                            * @param {getVisualizerStyleCallback} cb
                                            *
                                            * @callback getVisualizerStyleCallback
                                            * @param {Error} err
                                            * @param {String} content
                                            */
  getVisualizerStyle(cb) {return cb(null, '');}

  /**
                                                 * Get the preview source for visualizer/response preview
                                                 *
                                                 * @param {String} template
                                                 * @param {Object} options
                                                 * @param {String} options.fileExtension
                                                 * @param {String} options.mediaType
                                                 * @param {getPreviewFileCallback} cb
                                                 *
                                                 * @callback getPreviewFileCallback
                                                 * @param {Error} err
                                                 * @param {Object} template
                                                 * @param {('src'|'srcDoc')} template.type
                                                 * @param {String} template.value
                                                 */
  getPreviewFile(_, __, cb) {return cb(null, { type: 'src', value: '' });}

  /**
                                                                            * Used to query cookie manager
                                                                            *
                                                                            * @param {String} method - CookieManager method name
                                                                            * @param {String} partitionId - Electron session's partition id
                                                                            * @param {Object} options - Arguments
                                                                            * @param {Function} cb
                                                                            */
  cookieHandler(_, __, ___, cb) {return cb();}

  /**
                                                * Used to Save Response Buffer to a File
                                                *
                                                * @param {Object} contentInfo
                                                * @param {Buffer} stream
                                                * @param {Function} cb
                                                */
  saveResponseToFile(_, __, cb) {return cb();}};


/**
                                                  * Class representing Runtime behind IPC transport
                                                  * @class
                                                  * @implements {AgentInterface}
                                                  */
let IPCAgent = class IPCAgent extends AgentInterface {


  constructor(publish) {
    super();this.type = _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].IPC;

    this.ipc = __webpack_require__(62).ipcRenderer; // eslint-disable-line import/no-unresolved, global-require

    // Attach the general respond back channel
    this.ipc.on('runtime-ipc-event', (ev, message) => {publish(message);});

    Object(mobx__WEBPACK_IMPORTED_MODULE_4__["transaction"])(() => {
      this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTED);
      this.setHealth(true);
    });
  }

  $emit(event) {
    this.ipc.send('runtime-ipc-command', event);
  }

  $fn(event, fn, args, cb) {
    this.ipc.invoke('runtime-ipc-cb', event, fn, args).
    then(result => cb(...result)).
    catch(err => cb(err));
  }

  /**
     * @override
     */
  executeCollection(info, collection, variables, options) {
    this.$emit(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('execute', 'collection', {
      info,
      collection,
      variables,
      options }));

  }

  /**
     * @override
     */
  terminateExecution(criteria) {
    this.$emit(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('terminate', 'execution', {
      execution: criteria.id }));

  }

  /**
     * @override
     */
  pauseExecution(criteria) {
    this.$emit(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('pause', 'execution', {
      execution: criteria.id }));

  }

  /**
     * @override
     */
  resumeExecution(criteria) {
    this.$emit(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('resume', 'execution', {
      execution: criteria.id }));

  }

  /**
     * @override
     */
  previewRequest(request, options, cb) {
    this.$fn('runtime', 'previewRequest', [request, options], cb);
  }

  /**
     * @override
     */
  isInWorkingDir(path) {
    return this.ipc.sendSync(
    'postman-runtime-ipc-sync',
    'isInWorkingDir',
    [Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__["getWorkingDir"])(), path]);

  }

  /**
     * @override
     */
  processFiles(files, cb = _.noop) {
    if (!files || _.isEmpty(files)) {
      return cb(null, files);
    }

    return cb(null, processFiles(files));
  }

  /**
     * @private
     *
     * Create a temporary file in the filesystem
     *
     * @param {String} name - Name of the file to be generated
     * @param {String} content - Content of the file
     * @param {createTemporaryFileCallback} cb - Callback function to be called on temp file creation
     *
     * @callback createTemporaryFileCallback Callback for
     * @param {Error} err
     * @param {String} tempFilepath - Path of the temporary file
     */
  $createTemporaryFile(name, content, cb) {
    this.$fn('files', 'create-temp', [name, content], cb);
  }

  /**
     * @override
     */
  readFile(path, cb) {
    // If path is an instance of file then extract the path from it
    if (path instanceof File) {
      path = path.path; // eslint-disable-line no-param-reassign
    }

    const postmanFs = new _js_common_utils_postmanFs__WEBPACK_IMPORTED_MODULE_12___default.a(Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__["getWorkingDir"])()),

    // Convert relative path to absolute if required
    absolutePath = postmanFs._resolve(path, true);

    this.$fn('files', 'read', [absolutePath], cb);
  }

  /**
     * @override
     */
  pathAccessible(filePath, writeable, cb) {
    // If no path is given then there is nothing to check
    if (!filePath) {
      return cb();
    }

    const postmanFs = new _js_common_utils_postmanFs__WEBPACK_IMPORTED_MODULE_12___default.a(Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__["getWorkingDir"])()),

    // Convert relative path to absolute
    absolutePath = postmanFs._resolve(filePath, true);

    this.$fn('files', 'access', [absolutePath, writeable], cb);
  }

  /**
     * @override
     */
  getVisualizerStyle(cb) {
    const stylesPath = path__WEBPACK_IMPORTED_MODULE_3___default.a.join(pm.app.get('visualizerLibrariesPath'), 'vendor.min.css');

    this.readFile(stylesPath, (err, result) => {
      const style = result && `<style type="text/css">${result}</style>`;

      cb(err, style);
    });
  }

  /**
     * @override
     */
  getPreviewFile(template, options = {}, cb) {
    const ext = options.fileExtension || 'html';

    this.$createTemporaryFile(`${shortid__WEBPACK_IMPORTED_MODULE_0___default.a.generate()}.${ext}`, template, (err, result) => {
      cb(err, result && {
        type: 'src',
        value: `file://${result}` });

    });
  }

  /**
     * @override
     */
  cookieHandler(method, partitionId, options, cb) {
    this.$fn('cookie', method, [partitionId, options], cb);
  }

  /**
     * @override
     */
  saveResponseToFile(contentInfo, stream, cb) {
    this.$fn('files', 'saveResponse', [contentInfo, stream], cb);
  }};


/**
       * Class representing Runtime behind Websocket transport
       * @class
       * @implements {AgentInterface}
       * @implements {Connection}
       */
let WebsocketAgent = class WebsocketAgent extends AgentInterface {


  constructor(publish) {
    super();

    // Note: extraEncryption will have no effect if remoteVerification is false
    this.type = _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS;this.opts = {
      handshakePath: `${window.postman_runtime_agent_service_url}/handshake/create`,
      remoteVerification: true,
      extraEncryption: false,
      port: window.postman_runtime_agent_port,
      autoConnect: true,
      healthCheckTimeout: 1000 };


    this.ioOptions = {
      reconnectionAttempts: 5,
      reconnectionDelayMax: 5000, // 10s
      timeout: 10000, // 10s
      transports: ['websocket'] };


    this.publish = publish;
    this.isWeb = window.SDK_PLATFORM === 'browser';

    this.socket = null;
    this.isReconnecting = false;
  }

  /**
     * Method of perform a health check to check of availability of the agent
     */
  async checkHealth() {
    // If the state is already connected then no need for a health check we can mark isHealthy to true
    if (this.state === _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTED) {
      // If health is not already set to true then set it to true
      !this.health && this.setHealth(true);

      return;
    }

    const aborter = new AbortController(),
    timeout = setTimeout(() => {aborter.abort();}, this.opts.healthCheckTimeout);

    return fetch(`http://localhost:${this.opts.port}/knockknock`, { signal: aborter.signal }).
    then(() => {
      clearTimeout(timeout);

      // If auto-connect is set to true and this agent is the selected one then fire connect
      // to automatically connect the agent
      if (this.health === false && this.selected && this.opts.autoConnect) {
        this.connect();
      }

      this.setHealth(true);
    }).
    catch(() => {
      clearTimeout(timeout);

      this.setHealth(false);
    });
  }

  /**
     * Connect to the websocket agent
     */
  connect() {
    // If the state is already in a connecting state then don't go forward
    if (this.state === _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTING) {
      return;
    }

    // If the socket is present and it is connected or isReconnecting then just bail out as-well
    if (this.socket && (this.socket.connected || this.isReconnecting)) {
      return;
    }

    // We are now attempting to connect/reconnect to the server
    this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTING);

    async__WEBPACK_IMPORTED_MODULE_1___default.a.waterfall([
    // Initiate remote verification if configured
    next => {
      if (!this.opts.remoteVerification) {
        return next(null, null);
      }

      // Remote Verification is turned-on hence we go the full way
      fetch(this.opts.handshakePath, { credentials: 'include' }).
      then(response => {
        if (response.status !== 200) {
          return Promise.reject(new Error(`Runtime agent verification failed to initiate. Got status code ${response.status}`));
        }

        return response.json();
      }).
      then(data => {
        this.encryption = {/* TODO: Set encryption key here */};

        return fetch(`http://localhost:${this.opts.port}/handshake`, {
          headers: {
            'x-access-token': data.token } });


      }).
      then(response => {
        if (response.status !== 200) {
          return Promise.reject(new Error(`Runtime agent verification failed to complete. Got status code ${response.status}`));
        }

        return response.json();
      }).
      then(({ id }) => {next(null, id);}).
      catch(err => {
        this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].DISCONNECTED);

        pm.logger.error('AgentManager~connect: Agent handshake failed', err);

        return next(err);
      });
    },

    // Establish the websocket connection
    (id, next) => {
      this.socket = socket_io_client__WEBPACK_IMPORTED_MODULE_2___default()(`http://localhost:${this.opts.port}`, _extends({},
      this.ioOptions, {
        path: '/agent',
        query: {
          token: id } }));



      this.socket.on('runtime', this.publish || _.noop);

      this.socket.on('connect', () => {
        this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTED);
        this.isReconnecting = false; // It connected, reset the reconnecting state

        pm.logger.info('AgentManager~connect : Connected to websocket agent');
      });

      // Sad cases handling here
      this.socket.on('disconnect', reason => {
        pm.logger.warn('AgentManager~connect: Disconnected from websocket agent. reason=', reason);

        // There are primarily 3 reasons why disconnect happens
        // 1. transport close - the server crashed
        // 2. io server disconnect - the server explicitly closed the connection
        // 3. io client disconnect - the client explicitly closed the connection
        // The client will only attempt to reconnect in the case of transport close and no other case
        this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].DISCONNECTED);

        // This.isReconnecting = false;
      });

      // Fired upon a connection error
      this.socket.on('connect_error', err => {
        // There can be a connection error if the server is not reachable or the handshake failed
        // We will try not to continue to attempt reconnection if its not network problem
        // FIXME: This flow might be hit in reconnection flow as well hence auto reconnection using
        // socket.io is not going to work more than 1 attempt for this case
        if (_.get(err, 'description.error.code') !== 'ECONNREFUSED') {
          this.socket.disconnect();
          this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].DISCONNECTED);
          this.isReconnecting = false;
        }
      });

      // Fired upon an attempt to reconnect.
      this.socket.on('reconnecting', attempt => {
        this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTING);
        this.isReconnecting = true;
        pm.logger.info('AgentManager~connect: Reconnecting to websocket agent. attempt=', attempt);
      });

      // Fired when couldn’t reconnect within reconnectionAttempts.
      this.socket.on('reconnect_failed', () => {
        this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].DISCONNECTED);
        this.isReconnecting = false;

        pm.logger.warn('AgentManager~connect: Reconnection failed from websocket agent. reason=', reason);
      });

      return next();
    }]);

  }

  /**
     * @override
     */
  select() {
    super.select();

    // Trigger a connect in case connection has not been established
    this.connect();
  }

  /**
     * @private
     *
     * Send an event to runtime over the network transport
     *
     * @param {String} event
     * @param {Object} message
     */
  $emit(event, message) {
    if (!this.socket || !this.socket.connected) {
      return false;
    }

    this.socket.emit(event, message);

    return true;
  }

  /**
     * @private
     *
     * Call an Remote function over the network
     *
     * @param {String} event - The channel of fn
     * @param {String} fn - Name of the remote function to call
     * @param {Array} args - Array of arguments for the remote function
     * @param {*} cb - The callback function to bind to the remote function
     */
  $fn(event, fn, args, cb) {
    if (!this.socket || !this.socket.connected) {
      // @todo: Handle what happens when connection is no available
      return cb(new Error('Connection Error'));
    }

    this.socket.emit(event, fn, args, cb);
  }

  /**
     * @private
     *
     * Upload contents of a file to the working directory
     *
     * @param {String} path - The path the file to upload in working directory
     * @param {File} data - The reference to the file object or content to write
     * @param {Function} cb - The callback to be called when done
     */
  $upload(path, data, cb) {
    if (!this.socket || !this.socket.connected) {
      // @todo: Handle what happens when connection is no available
      return cb(new Error('Connection Error'));
    }

    this.socket.binary(true).emit('uploads', Object(_js_utils_FsHelper__WEBPACK_IMPORTED_MODULE_6__["getWorkingDir"])(), path, data, cb);
  }

  /**
     * @override
     *
     * @note Executing a collection over the ws socket agent introduces a new state
     * where the connection is not yet established or disconnected, in such a condition
     * we are emitting a fake terminated event so that UI can respond accordingly and not
     * get stuck waiting for a finish. It also by-passes history creation
     */
  executeCollection(info, collection, variables, options) {
    this.$emit('runtime', Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('execute', 'collection', {
      info,
      collection,
      variables,
      options }));

  }

  /**
     * @override
     */
  terminateExecution(criteria) {
    this.$emit('runtime', Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('terminate', 'execution', {
      execution: criteria.id }));

  }

  /**
     * @override
     */
  pauseExecution(criteria) {
    this.$emit('runtime', Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('pause', 'execution', {
      execution: criteria.id }));

  }

  /**
     * @override
     */
  resumeExecution(criteria) {
    this.$emit('runtime', Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('resume', 'execution', {
      execution: criteria.id }));

  }

  /**
     * @override
     */
  previewRequest(request, options, cb) {
    this.$fn('runtime-fn', 'previewRequest', [request, options], cb);
  }

  /**
     * @override
     * @note IMPORTANT: Checking if the given path is in the working directory cannot be
     * done with the websocket agent at the moment because of the synchronous API.
     * Hence we always return true for any kind of path.
     * TODO: Convert working directory checks to be asynchronous with bulk API checks
     */
  isInWorkingDir() {
    return true;
  }

  /**
     * @override
     * Process or Upload file to working directory
     *
     * @param {Array} files
     * @param {Function} cb
     *
     * @note For running on web-platform we upload the contents of the file to the
     * working directory
     */
  processFiles(files, cb = _.noop) {
    if (!files || _.isEmpty(files)) {
      return cb(null, files);
    }

    // If its not the web platform them process files the traditional way
    if (!this.isWeb) {
      return cb(null, processFiles(files));
    }

    const iden = shortid__WEBPACK_IMPORTED_MODULE_0___default.a.generate();

    async__WEBPACK_IMPORTED_MODULE_1___default.a.map(files, (file, done) => {
      // If the file in not an instance of File then it already has been
      // processes, there is not much to do here
      if (!(file instanceof File)) {
        return done(null, file);
      }

      const path = [iden, file.name].join('/');

      // Upload the file to the working directory, we will not have an actual path here ever
      this.$upload(path, file, err => {
        if (err) {return done(err, {});}

        return done(null, {
          name: file.name,
          type: file.type,
          actual: null,
          path });

      });
    }, cb);
  }

  /**
     * @override
     */
  readFile(path, cb) {
    // If the path is not an instance of File then read through agent
    if (!(path instanceof File)) {
      return this.$fn('files', 'read', [path], cb);
    }

    const reader = new FileReader();

    reader.onload = () => {
      cb(null, reader.result);
    };

    reader.onerror = () => {
      cb(reader.error);
    };

    return reader.readAsText(path);
  }

  /**
     * @override
     */
  pathAccessible(path, writeable, cb) {
    // If no path is given then there is nothing to check
    if (!path) {
      return cb();
    }

    this.$fn('files', 'access', [path, writeable], cb);
  }

  /**
     * @override
     */
  getVisualizerStyle(cb) {
    // Here again we are bi-roads.
    // If app, fetch from file system
    if (!this.isWeb) {
      const stylesPath = path__WEBPACK_IMPORTED_MODULE_3___default.a.join(pm.app.get('visualizerLibrariesPath'), 'vendor.min.css');

      return this.readFile(stylesPath, (err, result) => {
        const style = result && `<style type="text/css">${result}</style>`;

        cb(err, style);
      });
    }

    // If web, fetch from CDN
    return cb(null, `<link rel="stylesheet" href="${_constants_VisualizerConstants__WEBPACK_IMPORTED_MODULE_11__["SKELETON_CSS_URL"]}"></link>`);
  }

  /**
     * @override
     */
  getPreviewFile(template, options = {}, cb) {
    const mediaType = options.mediaType || 'text/html';

    // Use data URI for media preview
    if (mediaType !== 'text/html') {
      const encodedTemplate = `data:${mediaType};base64,${base64Encode(template)}`;

      return cb(null, {
        type: 'src',
        value: encodedTemplate });

    }

    // Just return the preview as srcDoc
    cb(null, {
      type: 'srcDoc',
      value: template });

  }

  /**
     * @override
     */
  cookieHandler(method, partitionId, options, cb) {
    this.$fn('cookie', method, [partitionId, options], cb);
  }

  /**
     * @override
     */
  saveResponseToFile(contentInfo, stream, cb) {
    this.$fn('files', 'saveResponse', [contentInfo, stream], cb);
  }};


/**
       * Class representing Runtime with XHR
       * @class
       * @implements {AgentInterface}
       */
let XHRAgent = class XHRAgent extends AgentInterface {











  constructor(publish) {
    super();this.type = _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].XHR;this.initialized = false;this._fileReferences = new Map();

    this.$emit = publish;

    this.setHealth(true);
  }

  /**
     * @override
     * @returns {Promise}
     */ /**
         * Map to locally store path to File reference.
         *
         * @private
         */async select() {super.select();if (this.initialized) {return;}

    // Set the agent to have been initialized so as not to re-initialize on subsequent selects
    this.initialized = true;

    // Create the instance of runtime the very first time XHR agent is selected
    this.runtime = await Object(_js_common_services_RuntimeExecutionService__WEBPACK_IMPORTED_MODULE_9__["Browser"])();

    // Set the connection to connected. At this point we are ready for sending request
    this.setConnectionState(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTED);
  }

  /**
     * @override
     */
  executeCollection(info, collection, variables, options) {
    options.fileResolver = this.$fileResolver(); // Attach file resolver
    this.runtime.startRun(info, collection, variables, options, this.$emit);
  }

  /**
     * @override
     */
  terminateExecution(criteria) {
    this.runtime.stopRun(criteria.id, this.$emit);
  }

  /**
     * @override
     */
  pauseExecution(criteria) {
    this.runtime.pauseRun(criteria.id, this.$emit);
  }

  /**
     * @override
     */
  resumeExecution(criteria) {
    this.runtime.resumeRun(criteria.id, this.$emit);
  }

  /**
     * @override
     */
  previewRequest(request, _, cb) {
    this.runtime.previewRequest(request, {}, cb);
  }

  isInWorkingDir(path) {
    return this._fileReferences.has(path);
  }

  /**
     * @override
     */
  processFiles(files, cb) {
    if (!files || _.isEmpty(files)) {
      return cb(null, files);
    }

    const iden = shortid__WEBPACK_IMPORTED_MODULE_0___default.a.generate();

    async__WEBPACK_IMPORTED_MODULE_1___default.a.map(files, (file, done) => {
      // If the file in not an instance of File then it already has been
      // processes, there is not much to do here
      if (!(file instanceof File)) {
        return done(null, file);
      }

      const path = [iden, file.name].join('/');

      this._fileReferences.set(path, file);

      done(null, {
        name: file.name,
        type: file.type,
        actual: null,
        path });

    }, cb);
  }

  /**
     * @override
     */
  readFile(path, cb) {
    if (!(path instanceof File)) {
      // Check if we have the fileReference in the localmap
      if (!this._fileReferences.has(path)) {
        return cb();
      }

      // Replace the path with the fileReference
      path = this._fileReferences.get(path);
    }

    const reader = new FileReader();

    reader.onload = () => {
      cb(null, reader.result);
    };

    reader.onerror = () => {
      cb(reader.error);
    };

    return reader.readAsText(path);
  }

  /**
     * @override
     */
  pathAccessible(path, writeable, cb) {
    // TODO: Cannot check this we will assume that it is accessible by default or not
    cb(null);
  }

  /**
     * @override
     */
  getVisualizerStyle(cb) {
    // Fetch from CDN
    return cb(null, `<link rel="stylesheet" href="${_constants_VisualizerConstants__WEBPACK_IMPORTED_MODULE_11__["SKELETON_CSS_URL"]}"></link>`);
  }

  /**
     * @override
     */
  getPreviewFile(template, options = {}, cb) {
    const mediaType = options.mediaType || 'text/html';

    // Use data URI for media preview
    if (mediaType !== 'text/html') {
      const encodedTemplate = `data:${mediaType};base64,${base64Encode(template)}`;

      return cb(null, {
        type: 'src',
        value: encodedTemplate });

    }

    // Just return the preview as srcDoc
    cb(null, {
      type: 'srcDoc',
      value: template });

  }

  /**
     * `fs` like file resolver for XHR agent.
     *
     * @private
     */
  $fileResolver() {
    const fileReferences = this._fileReferences;

    return {
      stat(path, cb) {
        if (!fileReferences.has(path)) {
          const error = new Error(`ENOENT: no such file or directory, stat '${path}'`);

          error.code = 'ENOENT';
          error.path = path;

          return cb(error);
        }

        cb(null, {
          mode: 33060 // 444
        });
      },
      createReadStream(path) {
        return fileReferences.get(path);
      } };

  }

  /**
     * @override
     */
  saveResponseToFile(contentInfo, stream, cb) {
    R.saveStreamToFile(contentInfo, stream, cb);
  }};


// Create a name to constructor map
const AGENTS = new Map([
[_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].IPC, IPCAgent],
[_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS, WebsocketAgent],
[_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].XHR, XHRAgent]]);


let AgentManager = (_class7 = class AgentManager extends eventemitter3__WEBPACK_IMPORTED_MODULE_5___default.a {



  constructor() {
    super();

    // Create a storage for storing all initialized agents
    _initDefineProp(this, 'agent', _descriptor3, this);this._agents = new Map([]);
    this._healthCheck = {
      shortInterval: 5000, // 5 seconds
      longInterval: 30000 // 30 seconds
    };

    // If this is not the browser platform then we only use the IPC agent
    if (window.SDK_PLATFORM !== 'browser') {
      return this.switchAgent(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].IPC);
    }

    // Construct the xhr and websocket agents as the available agents
    this._agents.set(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].XHR, new (AGENTS.get(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].XHR))(this.publish.bind(this)));
    this._agents.set(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS, new (AGENTS.get(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS))(this.publish.bind(this)));

    // Otherwise the game beings, depending on the settings
    const type = _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["SETTING_TO_TYPE_MAP"][pm.settings.getSetting(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["SETTING_KEY"])];

    // Switch to the agent depending on the setting immediately
    this.switchAgent(type);

    // Finally we will listen to the setting changing
    pm.settings.on(`setSetting:${_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["SETTING_KEY"]}`, key => {
      this.switchAgent(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["SETTING_TO_TYPE_MAP"][key]);
    });

    // Start the websocket health checks
    this._checkWSHealth();
  }

  async _checkWSHealth() {
    // If agent does not have a ws agent then bail out
    if (!this._agents.has(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS)) {return;}

    // Perform health check on the websocket agent
    await this._agents.get(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS).checkHealth();

    setTimeout(
    () => {this._checkWSHealth();},

    // If the current agent type is WS and agent is not healthy then use a shorter interval
    this.agent.type === _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].WS && !this.agent.health ?
    this._healthCheck.shortInterval :
    this._healthCheck.longInterval);

  }


  switchAgent(type) {
    // If the agent friendly type does not include this type error out
    if (!AGENTS.has(type)) {
      pm.logger.error(`AgentManager~switchAgent - Cannot switch to unknown agent ${type}`);

      return;
    }

    if (window.SDK_PLATFORM === 'browser' && type === _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["TYPES"].IPC) {
      pm.logger.error(`AgentManager~switchAgent - Cannot switch to ${type} agent on browser platform`);

      return;
    }

    // Trigger the deselect hook on the existing agent
    this.agent.deselect();

    // Change or Create the next agent
    if (this._agents.has(type)) {
      // If the agent map already has the agent initialized then use that
      this.agent = this._agents.get(type);
    } else {
      // If we do not have the agent initialized yet, we initialize it
      this.agent = new (AGENTS.get(type))(this.publish.bind(this));

      // And the agent to list of initialized agents
      this._agents.set(type, this.agent);
    }

    // Trigger the agent select hook
    this.agent.select();

    this.emit('change', this.agent);
  }

  /**
     * Subscribe to events emitted by runtime agent
     * @param {Function} fn Listeners function for events emitted by the runtime agents
     */
  publish(message) {
    // We are going to emit this as standard event as well
    this.emit('events', message);

    // Note: This should be the only place in the entire app where messages
    // are published to `postman-runtime` channel.
    // Currently the `RuntimeVariableUpdatesListener` and `ModelEventToUIEventService`
    // are using this in the share process to update session variables and for lessons respectively
    // TODO: Remove these usages by establish a contract with lessons
    // pm.eventBus.channel('postman-runtime').publish(message);
  }


  get type() {
    return this.agent.type;
  }


  get isAvailable() {
    return this.agent.health;
  }


  get stat() {
    return {
      state: this.agent.state,
      type: this.agent.type,
      health: this.agent.health };

  }


  get isReady() {
    // The agent is ready when its healthy and state is connected
    return this.agent.health && this.agent.state === _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_10__["STATES"].CONNECTED;
  }}, (_descriptor3 = _applyDecoratedDescriptor(_class7.prototype, 'agent', [mobx__WEBPACK_IMPORTED_MODULE_4__["observable"]], { enumerable: true, initializer: function () {return new AgentInterface();} }), _applyDecoratedDescriptor(_class7.prototype, 'switchAgent', [mobx__WEBPACK_IMPORTED_MODULE_4__["action"]], Object.getOwnPropertyDescriptor(_class7.prototype, 'switchAgent'), _class7.prototype), _applyDecoratedDescriptor(_class7.prototype, 'type', [mobx__WEBPACK_IMPORTED_MODULE_4__["computed"]], Object.getOwnPropertyDescriptor(_class7.prototype, 'type'), _class7.prototype), _applyDecoratedDescriptor(_class7.prototype, 'isAvailable', [mobx__WEBPACK_IMPORTED_MODULE_4__["computed"]], Object.getOwnPropertyDescriptor(_class7.prototype, 'isAvailable'), _class7.prototype), _applyDecoratedDescriptor(_class7.prototype, 'stat', [mobx__WEBPACK_IMPORTED_MODULE_4__["computed"]], Object.getOwnPropertyDescriptor(_class7.prototype, 'stat'), _class7.prototype), _applyDecoratedDescriptor(_class7.prototype, 'isReady', [mobx__WEBPACK_IMPORTED_MODULE_4__["computed"]], Object.getOwnPropertyDescriptor(_class7.prototype, 'isReady'), _class7.prototype)), _class7);


/**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           * A booting interface for the Agent manager
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           * @param {Function} done
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           */
/* harmony default export */ __webpack_exports__["default"] = (function (done) {
  // Create a new manager and keep it within this scope
  const manager = new AgentManager();

  // Setup the pm.runtime with an agent property which is both
  // observable and event-emitter
  pm.runtime = new Proxy({}, {
    get(target, prop) {
      if (prop === 'agent') {
        return manager;
      }

      return manager.agent[prop];
    } });


  return done && done();
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61), __webpack_require__(19)))

/***/ }),

/***/ 4346:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = __webpack_require__(4347);


/***/ }),

/***/ 4347:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var alphabet = __webpack_require__(4348);
var build = __webpack_require__(4350);
var isValid = __webpack_require__(4354);

// if you are using cluster or multiple servers use this to make each instance
// has a unique value for worker
// Note: I don't know if this is automatically set when using third
// party cluster solutions such as pm2.
var clusterWorkerId = __webpack_require__(4355) || 0;

/**
 * Set the seed.
 * Highly recommended if you don't want people to try to figure out your id schema.
 * exposed as shortid.seed(int)
 * @param seed Integer value to seed the random alphabet.  ALWAYS USE THE SAME SEED or you might get overlaps.
 */
function seed(seedValue) {
    alphabet.seed(seedValue);
    return module.exports;
}

/**
 * Set the cluster worker or machine id
 * exposed as shortid.worker(int)
 * @param workerId worker must be positive integer.  Number less than 16 is recommended.
 * returns shortid module so it can be chained.
 */
function worker(workerId) {
    clusterWorkerId = workerId;
    return module.exports;
}

/**
 *
 * sets new characters to use in the alphabet
 * returns the shuffled alphabet
 */
function characters(newCharacters) {
    if (newCharacters !== undefined) {
        alphabet.characters(newCharacters);
    }

    return alphabet.shuffled();
}

/**
 * Generate unique id
 * Returns string id
 */
function generate() {
  return build(clusterWorkerId);
}

// Export all other functions as properties of the generate function
module.exports = generate;
module.exports.generate = generate;
module.exports.seed = seed;
module.exports.worker = worker;
module.exports.characters = characters;
module.exports.isValid = isValid;


/***/ }),

/***/ 4348:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var randomFromSeed = __webpack_require__(4349);

var ORIGINAL = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-';
var alphabet;
var previousSeed;

var shuffled;

function reset() {
    shuffled = false;
}

function setCharacters(_alphabet_) {
    if (!_alphabet_) {
        if (alphabet !== ORIGINAL) {
            alphabet = ORIGINAL;
            reset();
        }
        return;
    }

    if (_alphabet_ === alphabet) {
        return;
    }

    if (_alphabet_.length !== ORIGINAL.length) {
        throw new Error('Custom alphabet for shortid must be ' + ORIGINAL.length + ' unique characters. You submitted ' + _alphabet_.length + ' characters: ' + _alphabet_);
    }

    var unique = _alphabet_.split('').filter(function(item, ind, arr){
       return ind !== arr.lastIndexOf(item);
    });

    if (unique.length) {
        throw new Error('Custom alphabet for shortid must be ' + ORIGINAL.length + ' unique characters. These characters were not unique: ' + unique.join(', '));
    }

    alphabet = _alphabet_;
    reset();
}

function characters(_alphabet_) {
    setCharacters(_alphabet_);
    return alphabet;
}

function setSeed(seed) {
    randomFromSeed.seed(seed);
    if (previousSeed !== seed) {
        reset();
        previousSeed = seed;
    }
}

function shuffle() {
    if (!alphabet) {
        setCharacters(ORIGINAL);
    }

    var sourceArray = alphabet.split('');
    var targetArray = [];
    var r = randomFromSeed.nextValue();
    var characterIndex;

    while (sourceArray.length > 0) {
        r = randomFromSeed.nextValue();
        characterIndex = Math.floor(r * sourceArray.length);
        targetArray.push(sourceArray.splice(characterIndex, 1)[0]);
    }
    return targetArray.join('');
}

function getShuffled() {
    if (shuffled) {
        return shuffled;
    }
    shuffled = shuffle();
    return shuffled;
}

/**
 * lookup shuffled letter
 * @param index
 * @returns {string}
 */
function lookup(index) {
    var alphabetShuffled = getShuffled();
    return alphabetShuffled[index];
}

function get () {
  return alphabet || ORIGINAL;
}

module.exports = {
    get: get,
    characters: characters,
    seed: setSeed,
    lookup: lookup,
    shuffled: getShuffled
};


/***/ }),

/***/ 4349:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// Found this seed-based random generator somewhere
// Based on The Central Randomizer 1.3 (C) 1997 by Paul Houle (houle@msc.cornell.edu)

var seed = 1;

/**
 * return a random number based on a seed
 * @param seed
 * @returns {number}
 */
function getNextValue() {
    seed = (seed * 9301 + 49297) % 233280;
    return seed/(233280.0);
}

function setSeed(_seed_) {
    seed = _seed_;
}

module.exports = {
    nextValue: getNextValue,
    seed: setSeed
};


/***/ }),

/***/ 4350:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var generate = __webpack_require__(4351);
var alphabet = __webpack_require__(4348);

// Ignore all milliseconds before a certain time to reduce the size of the date entropy without sacrificing uniqueness.
// This number should be updated every year or so to keep the generated id short.
// To regenerate `new Date() - 0` and bump the version. Always bump the version!
var REDUCE_TIME = 1567752802062;

// don't change unless we change the algos or REDUCE_TIME
// must be an integer and less than 16
var version = 7;

// Counter is used when shortid is called multiple times in one second.
var counter;

// Remember the last time shortid was called in case counter is needed.
var previousSeconds;

/**
 * Generate unique id
 * Returns string id
 */
function build(clusterWorkerId) {
    var str = '';

    var seconds = Math.floor((Date.now() - REDUCE_TIME) * 0.001);

    if (seconds === previousSeconds) {
        counter++;
    } else {
        counter = 0;
        previousSeconds = seconds;
    }

    str = str + generate(version);
    str = str + generate(clusterWorkerId);
    if (counter > 0) {
        str = str + generate(counter);
    }
    str = str + generate(seconds);
    return str;
}

module.exports = build;


/***/ }),

/***/ 4351:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var alphabet = __webpack_require__(4348);
var random = __webpack_require__(4352);
var format = __webpack_require__(4353);

function generate(number) {
    var loopCounter = 0;
    var done;

    var str = '';

    while (!done) {
        str = str + format(random, alphabet.get(), 1);
        done = number < (Math.pow(16, loopCounter + 1 ) );
        loopCounter++;
    }
    return str;
}

module.exports = generate;


/***/ }),

/***/ 4352:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var crypto = typeof window === 'object' && (window.crypto || window.msCrypto); // IE 11 uses window.msCrypto

var randomByte;

if (!crypto || !crypto.getRandomValues) {
    randomByte = function(size) {
        var bytes = [];
        for (var i = 0; i < size; i++) {
            bytes.push(Math.floor(Math.random() * 256));
        }
        return bytes;
    };
} else {
    randomByte = function(size) {
        return crypto.getRandomValues(new Uint8Array(size));
    };
}

module.exports = randomByte;


/***/ }),

/***/ 4353:
/***/ (function(module, exports) {

// This file replaces `format.js` in bundlers like webpack or Rollup,
// according to `browser` config in `package.json`.

module.exports = function (random, alphabet, size) {
  // We can’t use bytes bigger than the alphabet. To make bytes values closer
  // to the alphabet, we apply bitmask on them. We look for the closest
  // `2 ** x - 1` number, which will be bigger than alphabet size. If we have
  // 30 symbols in the alphabet, we will take 31 (00011111).
  // We do not use faster Math.clz32, because it is not available in browsers.
  var mask = (2 << Math.log(alphabet.length - 1) / Math.LN2) - 1
  // Bitmask is not a perfect solution (in our example it will pass 31 bytes,
  // which is bigger than the alphabet). As a result, we will need more bytes,
  // than ID size, because we will refuse bytes bigger than the alphabet.

  // Every hardware random generator call is costly,
  // because we need to wait for entropy collection. This is why often it will
  // be faster to ask for few extra bytes in advance, to avoid additional calls.

  // Here we calculate how many random bytes should we call in advance.
  // It depends on ID length, mask / alphabet size and magic number 1.6
  // (which was selected according benchmarks).

  // -~f => Math.ceil(f) if n is float number
  // -~i => i + 1 if n is integer number
  var step = -~(1.6 * mask * size / alphabet.length)
  var id = ''

  while (true) {
    var bytes = random(step)
    // Compact alternative for `for (var i = 0; i < step; i++)`
    var i = step
    while (i--) {
      // If random byte is bigger than alphabet even after bitmask,
      // we refuse it by `|| ''`.
      id += alphabet[bytes[i] & mask] || ''
      // More compact than `id.length + 1 === size`
      if (id.length === +size) return id
    }
  }
}


/***/ }),

/***/ 4354:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var alphabet = __webpack_require__(4348);

function isShortId(id) {
    if (!id || typeof id !== 'string' || id.length < 6 ) {
        return false;
    }

    var nonAlphabetic = new RegExp('[^' +
      alphabet.get().replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&') +
    ']');
    return !nonAlphabetic.test(id);
}

module.exports = isShortId;


/***/ }),

/***/ 4355:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = 0;


/***/ }),

/***/ 4356:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Module dependencies.
 */

var url = __webpack_require__(4357);
var parser = __webpack_require__(4361);
var Manager = __webpack_require__(4369);
var debug = __webpack_require__(4359)('socket.io-client');

/**
 * Module exports.
 */

module.exports = exports = lookup;

/**
 * Managers cache.
 */

var cache = exports.managers = {};

/**
 * Looks up an existing `Manager` for multiplexing.
 * If the user summons:
 *
 *   `io('http://localhost/a');`
 *   `io('http://localhost/b');`
 *
 * We reuse the existing instance based on same scheme/port/host,
 * and we initialize sockets for each namespace.
 *
 * @api public
 */

function lookup (uri, opts) {
  if (typeof uri === 'object') {
    opts = uri;
    uri = undefined;
  }

  opts = opts || {};

  var parsed = url(uri);
  var source = parsed.source;
  var id = parsed.id;
  var path = parsed.path;
  var sameNamespace = cache[id] && path in cache[id].nsps;
  var newConnection = opts.forceNew || opts['force new connection'] ||
                      false === opts.multiplex || sameNamespace;

  var io;

  if (newConnection) {
    debug('ignoring socket cache for %s', source);
    io = Manager(source, opts);
  } else {
    if (!cache[id]) {
      debug('new io instance for %s', source);
      cache[id] = Manager(source, opts);
    }
    io = cache[id];
  }
  if (parsed.query && !opts.query) {
    opts.query = parsed.query;
  }
  return io.socket(parsed.path, opts);
}

/**
 * Protocol version.
 *
 * @api public
 */

exports.protocol = parser.protocol;

/**
 * `connect`.
 *
 * @param {String} uri
 * @api public
 */

exports.connect = lookup;

/**
 * Expose constructors for standalone build.
 *
 * @api public
 */

exports.Manager = __webpack_require__(4369);
exports.Socket = __webpack_require__(4395);


/***/ }),

/***/ 4357:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Module dependencies.
 */

var parseuri = __webpack_require__(4358);
var debug = __webpack_require__(4359)('socket.io-client:url');

/**
 * Module exports.
 */

module.exports = url;

/**
 * URL parser.
 *
 * @param {String} url
 * @param {Object} An object meant to mimic window.location.
 *                 Defaults to window.location.
 * @api public
 */

function url (uri, loc) {
  var obj = uri;

  // default to window.location
  loc = loc || (typeof location !== 'undefined' && location);
  if (null == uri) uri = loc.protocol + '//' + loc.host;

  // relative path support
  if ('string' === typeof uri) {
    if ('/' === uri.charAt(0)) {
      if ('/' === uri.charAt(1)) {
        uri = loc.protocol + uri;
      } else {
        uri = loc.host + uri;
      }
    }

    if (!/^(https?|wss?):\/\//.test(uri)) {
      debug('protocol-less url %s', uri);
      if ('undefined' !== typeof loc) {
        uri = loc.protocol + '//' + uri;
      } else {
        uri = 'https://' + uri;
      }
    }

    // parse
    debug('parse %s', uri);
    obj = parseuri(uri);
  }

  // make sure we treat `localhost:80` and `localhost` equally
  if (!obj.port) {
    if (/^(http|ws)$/.test(obj.protocol)) {
      obj.port = '80';
    } else if (/^(http|ws)s$/.test(obj.protocol)) {
      obj.port = '443';
    }
  }

  obj.path = obj.path || '/';

  var ipv6 = obj.host.indexOf(':') !== -1;
  var host = ipv6 ? '[' + obj.host + ']' : obj.host;

  // define unique id
  obj.id = obj.protocol + '://' + host + ':' + obj.port;
  // define href
  obj.href = obj.protocol + '://' + host + (loc && loc.port === obj.port ? '' : (':' + obj.port));

  return obj;
}


/***/ }),

/***/ 4358:
/***/ (function(module, exports) {

/**
 * Parses an URI
 *
 * @author Steven Levithan <stevenlevithan.com> (MIT license)
 * @api private
 */

var re = /^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;

var parts = [
    'source', 'protocol', 'authority', 'userInfo', 'user', 'password', 'host', 'port', 'relative', 'path', 'directory', 'file', 'query', 'anchor'
];

module.exports = function parseuri(str) {
    var src = str,
        b = str.indexOf('['),
        e = str.indexOf(']');

    if (b != -1 && e != -1) {
        str = str.substring(0, b) + str.substring(b, e).replace(/:/g, ';') + str.substring(e, str.length);
    }

    var m = re.exec(str || ''),
        uri = {},
        i = 14;

    while (i--) {
        uri[parts[i]] = m[i] || '';
    }

    if (b != -1 && e != -1) {
        uri.source = src;
        uri.host = uri.host.substring(1, uri.host.length - 1).replace(/;/g, ':');
        uri.authority = uri.authority.replace('[', '').replace(']', '').replace(/;/g, ':');
        uri.ipv6uri = true;
    }

    return uri;
};


/***/ }),

/***/ 4359:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(process) {/* eslint-env browser */

/**
 * This is the web browser implementation of `debug()`.
 */

exports.log = log;
exports.formatArgs = formatArgs;
exports.save = save;
exports.load = load;
exports.useColors = useColors;
exports.storage = localstorage();

/**
 * Colors.
 */

exports.colors = [
	'#0000CC',
	'#0000FF',
	'#0033CC',
	'#0033FF',
	'#0066CC',
	'#0066FF',
	'#0099CC',
	'#0099FF',
	'#00CC00',
	'#00CC33',
	'#00CC66',
	'#00CC99',
	'#00CCCC',
	'#00CCFF',
	'#3300CC',
	'#3300FF',
	'#3333CC',
	'#3333FF',
	'#3366CC',
	'#3366FF',
	'#3399CC',
	'#3399FF',
	'#33CC00',
	'#33CC33',
	'#33CC66',
	'#33CC99',
	'#33CCCC',
	'#33CCFF',
	'#6600CC',
	'#6600FF',
	'#6633CC',
	'#6633FF',
	'#66CC00',
	'#66CC33',
	'#9900CC',
	'#9900FF',
	'#9933CC',
	'#9933FF',
	'#99CC00',
	'#99CC33',
	'#CC0000',
	'#CC0033',
	'#CC0066',
	'#CC0099',
	'#CC00CC',
	'#CC00FF',
	'#CC3300',
	'#CC3333',
	'#CC3366',
	'#CC3399',
	'#CC33CC',
	'#CC33FF',
	'#CC6600',
	'#CC6633',
	'#CC9900',
	'#CC9933',
	'#CCCC00',
	'#CCCC33',
	'#FF0000',
	'#FF0033',
	'#FF0066',
	'#FF0099',
	'#FF00CC',
	'#FF00FF',
	'#FF3300',
	'#FF3333',
	'#FF3366',
	'#FF3399',
	'#FF33CC',
	'#FF33FF',
	'#FF6600',
	'#FF6633',
	'#FF9900',
	'#FF9933',
	'#FFCC00',
	'#FFCC33'
];

/**
 * Currently only WebKit-based Web Inspectors, Firefox >= v31,
 * and the Firebug extension (any Firefox version) are known
 * to support "%c" CSS customizations.
 *
 * TODO: add a `localStorage` variable to explicitly enable/disable colors
 */

// eslint-disable-next-line complexity
function useColors() {
	// NB: In an Electron preload script, document will be defined but not fully
	// initialized. Since we know we're in Chrome, we'll just detect this case
	// explicitly
	if (typeof window !== 'undefined' && window.process && (window.process.type === 'renderer' || window.process.__nwjs)) {
		return true;
	}

	// Internet Explorer and Edge do not support colors.
	if (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
		return false;
	}

	// Is webkit? http://stackoverflow.com/a/16459606/376773
	// document is undefined in react-native: https://github.com/facebook/react-native/pull/1632
	return (typeof document !== 'undefined' && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance) ||
		// Is firebug? http://stackoverflow.com/a/398120/376773
		(typeof window !== 'undefined' && window.console && (window.console.firebug || (window.console.exception && window.console.table))) ||
		// Is firefox >= v31?
		// https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
		(typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31) ||
		// Double check webkit in userAgent just in case we are in a worker
		(typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
}

/**
 * Colorize log arguments if enabled.
 *
 * @api public
 */

function formatArgs(args) {
	args[0] = (this.useColors ? '%c' : '') +
		this.namespace +
		(this.useColors ? ' %c' : ' ') +
		args[0] +
		(this.useColors ? '%c ' : ' ') +
		'+' + module.exports.humanize(this.diff);

	if (!this.useColors) {
		return;
	}

	const c = 'color: ' + this.color;
	args.splice(1, 0, c, 'color: inherit');

	// The final "%c" is somewhat tricky, because there could be other
	// arguments passed either before or after the %c, so we need to
	// figure out the correct index to insert the CSS into
	let index = 0;
	let lastC = 0;
	args[0].replace(/%[a-zA-Z%]/g, match => {
		if (match === '%%') {
			return;
		}
		index++;
		if (match === '%c') {
			// We only are interested in the *last* %c
			// (the user may have provided their own)
			lastC = index;
		}
	});

	args.splice(lastC, 0, c);
}

/**
 * Invokes `console.log()` when available.
 * No-op when `console.log` is not a "function".
 *
 * @api public
 */
function log(...args) {
	// This hackery is required for IE8/9, where
	// the `console.log` function doesn't have 'apply'
	return typeof console === 'object' &&
		console.log &&
		console.log(...args);
}

/**
 * Save `namespaces`.
 *
 * @param {String} namespaces
 * @api private
 */
function save(namespaces) {
	try {
		if (namespaces) {
			exports.storage.setItem('debug', namespaces);
		} else {
			exports.storage.removeItem('debug');
		}
	} catch (error) {
		// Swallow
		// XXX (@Qix-) should we be logging these?
	}
}

/**
 * Load `namespaces`.
 *
 * @return {String} returns the previously persisted debug modes
 * @api private
 */
function load() {
	let r;
	try {
		r = exports.storage.getItem('debug');
	} catch (error) {
		// Swallow
		// XXX (@Qix-) should we be logging these?
	}

	// If debug isn't set in LS, and we're in Electron, try to load $DEBUG
	if (!r && typeof process !== 'undefined' && 'env' in process) {
		r = process.env.DEBUG;
	}

	return r;
}

/**
 * Localstorage attempts to return the localstorage.
 *
 * This is necessary because safari throws
 * when a user disables cookies/localstorage
 * and you attempt to access it.
 *
 * @return {LocalStorage}
 * @api private
 */

function localstorage() {
	try {
		// TVMLKit (Apple TV JS Runtime) does not have a window object, just localStorage in the global context
		// The Browser also has localStorage in the global context.
		return localStorage;
	} catch (error) {
		// Swallow
		// XXX (@Qix-) should we be logging these?
	}
}

module.exports = __webpack_require__(4360)(exports);

const {formatters} = module.exports;

/**
 * Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
 */

formatters.j = function (v) {
	try {
		return JSON.stringify(v);
	} catch (error) {
		return '[UnexpectedJSONParseError]: ' + error.message;
	}
};

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(31)))

/***/ }),

/***/ 4360:
/***/ (function(module, exports, __webpack_require__) {


/**
 * This is the common logic for both the Node.js and web browser
 * implementations of `debug()`.
 */

function setup(env) {
	createDebug.debug = createDebug;
	createDebug.default = createDebug;
	createDebug.coerce = coerce;
	createDebug.disable = disable;
	createDebug.enable = enable;
	createDebug.enabled = enabled;
	createDebug.humanize = __webpack_require__(2578);

	Object.keys(env).forEach(key => {
		createDebug[key] = env[key];
	});

	/**
	* Active `debug` instances.
	*/
	createDebug.instances = [];

	/**
	* The currently active debug mode names, and names to skip.
	*/

	createDebug.names = [];
	createDebug.skips = [];

	/**
	* Map of special "%n" handling functions, for the debug "format" argument.
	*
	* Valid key names are a single, lower or upper-case letter, i.e. "n" and "N".
	*/
	createDebug.formatters = {};

	/**
	* Selects a color for a debug namespace
	* @param {String} namespace The namespace string for the for the debug instance to be colored
	* @return {Number|String} An ANSI color code for the given namespace
	* @api private
	*/
	function selectColor(namespace) {
		let hash = 0;

		for (let i = 0; i < namespace.length; i++) {
			hash = ((hash << 5) - hash) + namespace.charCodeAt(i);
			hash |= 0; // Convert to 32bit integer
		}

		return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
	}
	createDebug.selectColor = selectColor;

	/**
	* Create a debugger with the given `namespace`.
	*
	* @param {String} namespace
	* @return {Function}
	* @api public
	*/
	function createDebug(namespace) {
		let prevTime;

		function debug(...args) {
			// Disabled?
			if (!debug.enabled) {
				return;
			}

			const self = debug;

			// Set `diff` timestamp
			const curr = Number(new Date());
			const ms = curr - (prevTime || curr);
			self.diff = ms;
			self.prev = prevTime;
			self.curr = curr;
			prevTime = curr;

			args[0] = createDebug.coerce(args[0]);

			if (typeof args[0] !== 'string') {
				// Anything else let's inspect with %O
				args.unshift('%O');
			}

			// Apply any `formatters` transformations
			let index = 0;
			args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
				// If we encounter an escaped % then don't increase the array index
				if (match === '%%') {
					return match;
				}
				index++;
				const formatter = createDebug.formatters[format];
				if (typeof formatter === 'function') {
					const val = args[index];
					match = formatter.call(self, val);

					// Now we need to remove `args[index]` since it's inlined in the `format`
					args.splice(index, 1);
					index--;
				}
				return match;
			});

			// Apply env-specific formatting (colors, etc.)
			createDebug.formatArgs.call(self, args);

			const logFn = self.log || createDebug.log;
			logFn.apply(self, args);
		}

		debug.namespace = namespace;
		debug.enabled = createDebug.enabled(namespace);
		debug.useColors = createDebug.useColors();
		debug.color = selectColor(namespace);
		debug.destroy = destroy;
		debug.extend = extend;
		// Debug.formatArgs = formatArgs;
		// debug.rawLog = rawLog;

		// env-specific initialization logic for debug instances
		if (typeof createDebug.init === 'function') {
			createDebug.init(debug);
		}

		createDebug.instances.push(debug);

		return debug;
	}

	function destroy() {
		const index = createDebug.instances.indexOf(this);
		if (index !== -1) {
			createDebug.instances.splice(index, 1);
			return true;
		}
		return false;
	}

	function extend(namespace, delimiter) {
		const newDebug = createDebug(this.namespace + (typeof delimiter === 'undefined' ? ':' : delimiter) + namespace);
		newDebug.log = this.log;
		return newDebug;
	}

	/**
	* Enables a debug mode by namespaces. This can include modes
	* separated by a colon and wildcards.
	*
	* @param {String} namespaces
	* @api public
	*/
	function enable(namespaces) {
		createDebug.save(namespaces);

		createDebug.names = [];
		createDebug.skips = [];

		let i;
		const split = (typeof namespaces === 'string' ? namespaces : '').split(/[\s,]+/);
		const len = split.length;

		for (i = 0; i < len; i++) {
			if (!split[i]) {
				// ignore empty strings
				continue;
			}

			namespaces = split[i].replace(/\*/g, '.*?');

			if (namespaces[0] === '-') {
				createDebug.skips.push(new RegExp('^' + namespaces.substr(1) + '$'));
			} else {
				createDebug.names.push(new RegExp('^' + namespaces + '$'));
			}
		}

		for (i = 0; i < createDebug.instances.length; i++) {
			const instance = createDebug.instances[i];
			instance.enabled = createDebug.enabled(instance.namespace);
		}
	}

	/**
	* Disable debug output.
	*
	* @return {String} namespaces
	* @api public
	*/
	function disable() {
		const namespaces = [
			...createDebug.names.map(toNamespace),
			...createDebug.skips.map(toNamespace).map(namespace => '-' + namespace)
		].join(',');
		createDebug.enable('');
		return namespaces;
	}

	/**
	* Returns true if the given mode name is enabled, false otherwise.
	*
	* @param {String} name
	* @return {Boolean}
	* @api public
	*/
	function enabled(name) {
		if (name[name.length - 1] === '*') {
			return true;
		}

		let i;
		let len;

		for (i = 0, len = createDebug.skips.length; i < len; i++) {
			if (createDebug.skips[i].test(name)) {
				return false;
			}
		}

		for (i = 0, len = createDebug.names.length; i < len; i++) {
			if (createDebug.names[i].test(name)) {
				return true;
			}
		}

		return false;
	}

	/**
	* Convert regexp to namespace
	*
	* @param {RegExp} regxep
	* @return {String} namespace
	* @api private
	*/
	function toNamespace(regexp) {
		return regexp.toString()
			.substring(2, regexp.toString().length - 2)
			.replace(/\.\*\?$/, '*');
	}

	/**
	* Coerce `val`.
	*
	* @param {Mixed} val
	* @return {Mixed}
	* @api private
	*/
	function coerce(val) {
		if (val instanceof Error) {
			return val.stack || val.message;
		}
		return val;
	}

	createDebug.enable(createDebug.load());

	return createDebug;
}

module.exports = setup;


/***/ }),

/***/ 4361:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Module dependencies.
 */

var debug = __webpack_require__(4362)('socket.io-parser');
var Emitter = __webpack_require__(4365);
var binary = __webpack_require__(4366);
var isArray = __webpack_require__(4367);
var isBuf = __webpack_require__(4368);

/**
 * Protocol version.
 *
 * @api public
 */

exports.protocol = 4;

/**
 * Packet types.
 *
 * @api public
 */

exports.types = [
  'CONNECT',
  'DISCONNECT',
  'EVENT',
  'ACK',
  'ERROR',
  'BINARY_EVENT',
  'BINARY_ACK'
];

/**
 * Packet type `connect`.
 *
 * @api public
 */

exports.CONNECT = 0;

/**
 * Packet type `disconnect`.
 *
 * @api public
 */

exports.DISCONNECT = 1;

/**
 * Packet type `event`.
 *
 * @api public
 */

exports.EVENT = 2;

/**
 * Packet type `ack`.
 *
 * @api public
 */

exports.ACK = 3;

/**
 * Packet type `error`.
 *
 * @api public
 */

exports.ERROR = 4;

/**
 * Packet type 'binary event'
 *
 * @api public
 */

exports.BINARY_EVENT = 5;

/**
 * Packet type `binary ack`. For acks with binary arguments.
 *
 * @api public
 */

exports.BINARY_ACK = 6;

/**
 * Encoder constructor.
 *
 * @api public
 */

exports.Encoder = Encoder;

/**
 * Decoder constructor.
 *
 * @api public
 */

exports.Decoder = Decoder;

/**
 * A socket.io Encoder instance
 *
 * @api public
 */

function Encoder() {}

var ERROR_PACKET = exports.ERROR + '"encode error"';

/**
 * Encode a packet as a single string if non-binary, or as a
 * buffer sequence, depending on packet type.
 *
 * @param {Object} obj - packet object
 * @param {Function} callback - function to handle encodings (likely engine.write)
 * @return Calls callback with Array of encodings
 * @api public
 */

Encoder.prototype.encode = function(obj, callback){
  debug('encoding packet %j', obj);

  if (exports.BINARY_EVENT === obj.type || exports.BINARY_ACK === obj.type) {
    encodeAsBinary(obj, callback);
  } else {
    var encoding = encodeAsString(obj);
    callback([encoding]);
  }
};

/**
 * Encode packet as string.
 *
 * @param {Object} packet
 * @return {String} encoded
 * @api private
 */

function encodeAsString(obj) {

  // first is type
  var str = '' + obj.type;

  // attachments if we have them
  if (exports.BINARY_EVENT === obj.type || exports.BINARY_ACK === obj.type) {
    str += obj.attachments + '-';
  }

  // if we have a namespace other than `/`
  // we append it followed by a comma `,`
  if (obj.nsp && '/' !== obj.nsp) {
    str += obj.nsp + ',';
  }

  // immediately followed by the id
  if (null != obj.id) {
    str += obj.id;
  }

  // json data
  if (null != obj.data) {
    var payload = tryStringify(obj.data);
    if (payload !== false) {
      str += payload;
    } else {
      return ERROR_PACKET;
    }
  }

  debug('encoded %j as %s', obj, str);
  return str;
}

function tryStringify(str) {
  try {
    return JSON.stringify(str);
  } catch(e){
    return false;
  }
}

/**
 * Encode packet as 'buffer sequence' by removing blobs, and
 * deconstructing packet into object with placeholders and
 * a list of buffers.
 *
 * @param {Object} packet
 * @return {Buffer} encoded
 * @api private
 */

function encodeAsBinary(obj, callback) {

  function writeEncoding(bloblessData) {
    var deconstruction = binary.deconstructPacket(bloblessData);
    var pack = encodeAsString(deconstruction.packet);
    var buffers = deconstruction.buffers;

    buffers.unshift(pack); // add packet info to beginning of data list
    callback(buffers); // write all the buffers
  }

  binary.removeBlobs(obj, writeEncoding);
}

/**
 * A socket.io Decoder instance
 *
 * @return {Object} decoder
 * @api public
 */

function Decoder() {
  this.reconstructor = null;
}

/**
 * Mix in `Emitter` with Decoder.
 */

Emitter(Decoder.prototype);

/**
 * Decodes an encoded packet string into packet JSON.
 *
 * @param {String} obj - encoded packet
 * @return {Object} packet
 * @api public
 */

Decoder.prototype.add = function(obj) {
  var packet;
  if (typeof obj === 'string') {
    packet = decodeString(obj);
    if (exports.BINARY_EVENT === packet.type || exports.BINARY_ACK === packet.type) { // binary packet's json
      this.reconstructor = new BinaryReconstructor(packet);

      // no attachments, labeled binary but no binary data to follow
      if (this.reconstructor.reconPack.attachments === 0) {
        this.emit('decoded', packet);
      }
    } else { // non-binary full packet
      this.emit('decoded', packet);
    }
  } else if (isBuf(obj) || obj.base64) { // raw binary data
    if (!this.reconstructor) {
      throw new Error('got binary data when not reconstructing a packet');
    } else {
      packet = this.reconstructor.takeBinaryData(obj);
      if (packet) { // received final buffer
        this.reconstructor = null;
        this.emit('decoded', packet);
      }
    }
  } else {
    throw new Error('Unknown type: ' + obj);
  }
};

/**
 * Decode a packet String (JSON data)
 *
 * @param {String} str
 * @return {Object} packet
 * @api private
 */

function decodeString(str) {
  var i = 0;
  // look up type
  var p = {
    type: Number(str.charAt(0))
  };

  if (null == exports.types[p.type]) {
    return error('unknown packet type ' + p.type);
  }

  // look up attachments if type binary
  if (exports.BINARY_EVENT === p.type || exports.BINARY_ACK === p.type) {
    var buf = '';
    while (str.charAt(++i) !== '-') {
      buf += str.charAt(i);
      if (i == str.length) break;
    }
    if (buf != Number(buf) || str.charAt(i) !== '-') {
      throw new Error('Illegal attachments');
    }
    p.attachments = Number(buf);
  }

  // look up namespace (if any)
  if ('/' === str.charAt(i + 1)) {
    p.nsp = '';
    while (++i) {
      var c = str.charAt(i);
      if (',' === c) break;
      p.nsp += c;
      if (i === str.length) break;
    }
  } else {
    p.nsp = '/';
  }

  // look up id
  var next = str.charAt(i + 1);
  if ('' !== next && Number(next) == next) {
    p.id = '';
    while (++i) {
      var c = str.charAt(i);
      if (null == c || Number(c) != c) {
        --i;
        break;
      }
      p.id += str.charAt(i);
      if (i === str.length) break;
    }
    p.id = Number(p.id);
  }

  // look up json data
  if (str.charAt(++i)) {
    var payload = tryParse(str.substr(i));
    var isPayloadValid = payload !== false && (p.type === exports.ERROR || isArray(payload));
    if (isPayloadValid) {
      p.data = payload;
    } else {
      return error('invalid payload');
    }
  }

  debug('decoded %s as %j', str, p);
  return p;
}

function tryParse(str) {
  try {
    return JSON.parse(str);
  } catch(e){
    return false;
  }
}

/**
 * Deallocates a parser's resources
 *
 * @api public
 */

Decoder.prototype.destroy = function() {
  if (this.reconstructor) {
    this.reconstructor.finishedReconstruction();
  }
};

/**
 * A manager of a binary event's 'buffer sequence'. Should
 * be constructed whenever a packet of type BINARY_EVENT is
 * decoded.
 *
 * @param {Object} packet
 * @return {BinaryReconstructor} initialized reconstructor
 * @api private
 */

function BinaryReconstructor(packet) {
  this.reconPack = packet;
  this.buffers = [];
}

/**
 * Method to be called when binary data received from connection
 * after a BINARY_EVENT packet.
 *
 * @param {Buffer | ArrayBuffer} binData - the raw binary data received
 * @return {null | Object} returns null if more binary data is expected or
 *   a reconstructed packet object if all buffers have been received.
 * @api private
 */

BinaryReconstructor.prototype.takeBinaryData = function(binData) {
  this.buffers.push(binData);
  if (this.buffers.length === this.reconPack.attachments) { // done with buffer list
    var packet = binary.reconstructPacket(this.reconPack, this.buffers);
    this.finishedReconstruction();
    return packet;
  }
  return null;
};

/**
 * Cleans up binary packet reconstruction variables.
 *
 * @api private
 */

BinaryReconstructor.prototype.finishedReconstruction = function() {
  this.reconPack = null;
  this.buffers = [];
};

function error(msg) {
  return {
    type: exports.ERROR,
    data: 'parser error: ' + msg
  };
}


/***/ }),

/***/ 4362:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(process) {/**
 * This is the web browser implementation of `debug()`.
 *
 * Expose `debug()` as the module.
 */

exports = module.exports = __webpack_require__(4363);
exports.log = log;
exports.formatArgs = formatArgs;
exports.save = save;
exports.load = load;
exports.useColors = useColors;
exports.storage = 'undefined' != typeof chrome
               && 'undefined' != typeof chrome.storage
                  ? chrome.storage.local
                  : localstorage();

/**
 * Colors.
 */

exports.colors = [
  '#0000CC', '#0000FF', '#0033CC', '#0033FF', '#0066CC', '#0066FF', '#0099CC',
  '#0099FF', '#00CC00', '#00CC33', '#00CC66', '#00CC99', '#00CCCC', '#00CCFF',
  '#3300CC', '#3300FF', '#3333CC', '#3333FF', '#3366CC', '#3366FF', '#3399CC',
  '#3399FF', '#33CC00', '#33CC33', '#33CC66', '#33CC99', '#33CCCC', '#33CCFF',
  '#6600CC', '#6600FF', '#6633CC', '#6633FF', '#66CC00', '#66CC33', '#9900CC',
  '#9900FF', '#9933CC', '#9933FF', '#99CC00', '#99CC33', '#CC0000', '#CC0033',
  '#CC0066', '#CC0099', '#CC00CC', '#CC00FF', '#CC3300', '#CC3333', '#CC3366',
  '#CC3399', '#CC33CC', '#CC33FF', '#CC6600', '#CC6633', '#CC9900', '#CC9933',
  '#CCCC00', '#CCCC33', '#FF0000', '#FF0033', '#FF0066', '#FF0099', '#FF00CC',
  '#FF00FF', '#FF3300', '#FF3333', '#FF3366', '#FF3399', '#FF33CC', '#FF33FF',
  '#FF6600', '#FF6633', '#FF9900', '#FF9933', '#FFCC00', '#FFCC33'
];

/**
 * Currently only WebKit-based Web Inspectors, Firefox >= v31,
 * and the Firebug extension (any Firefox version) are known
 * to support "%c" CSS customizations.
 *
 * TODO: add a `localStorage` variable to explicitly enable/disable colors
 */

function useColors() {
  // NB: In an Electron preload script, document will be defined but not fully
  // initialized. Since we know we're in Chrome, we'll just detect this case
  // explicitly
  if (typeof window !== 'undefined' && window.process && window.process.type === 'renderer') {
    return true;
  }

  // Internet Explorer and Edge do not support colors.
  if (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
    return false;
  }

  // is webkit? http://stackoverflow.com/a/16459606/376773
  // document is undefined in react-native: https://github.com/facebook/react-native/pull/1632
  return (typeof document !== 'undefined' && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance) ||
    // is firebug? http://stackoverflow.com/a/398120/376773
    (typeof window !== 'undefined' && window.console && (window.console.firebug || (window.console.exception && window.console.table))) ||
    // is firefox >= v31?
    // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
    (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31) ||
    // double check webkit in userAgent just in case we are in a worker
    (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
}

/**
 * Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
 */

exports.formatters.j = function(v) {
  try {
    return JSON.stringify(v);
  } catch (err) {
    return '[UnexpectedJSONParseError]: ' + err.message;
  }
};


/**
 * Colorize log arguments if enabled.
 *
 * @api public
 */

function formatArgs(args) {
  var useColors = this.useColors;

  args[0] = (useColors ? '%c' : '')
    + this.namespace
    + (useColors ? ' %c' : ' ')
    + args[0]
    + (useColors ? '%c ' : ' ')
    + '+' + exports.humanize(this.diff);

  if (!useColors) return;

  var c = 'color: ' + this.color;
  args.splice(1, 0, c, 'color: inherit')

  // the final "%c" is somewhat tricky, because there could be other
  // arguments passed either before or after the %c, so we need to
  // figure out the correct index to insert the CSS into
  var index = 0;
  var lastC = 0;
  args[0].replace(/%[a-zA-Z%]/g, function(match) {
    if ('%%' === match) return;
    index++;
    if ('%c' === match) {
      // we only are interested in the *last* %c
      // (the user may have provided their own)
      lastC = index;
    }
  });

  args.splice(lastC, 0, c);
}

/**
 * Invokes `console.log()` when available.
 * No-op when `console.log` is not a "function".
 *
 * @api public
 */

function log() {
  // this hackery is required for IE8/9, where
  // the `console.log` function doesn't have 'apply'
  return 'object' === typeof console
    && console.log
    && Function.prototype.apply.call(console.log, console, arguments);
}

/**
 * Save `namespaces`.
 *
 * @param {String} namespaces
 * @api private
 */

function save(namespaces) {
  try {
    if (null == namespaces) {
      exports.storage.removeItem('debug');
    } else {
      exports.storage.debug = namespaces;
    }
  } catch(e) {}
}

/**
 * Load `namespaces`.
 *
 * @return {String} returns the previously persisted debug modes
 * @api private
 */

function load() {
  var r;
  try {
    r = exports.storage.debug;
  } catch(e) {}

  // If debug isn't set in LS, and we're in Electron, try to load $DEBUG
  if (!r && typeof process !== 'undefined' && 'env' in process) {
    r = process.env.DEBUG;
  }

  return r;
}

/**
 * Enable namespaces listed in `localStorage.debug` initially.
 */

exports.enable(load());

/**
 * Localstorage attempts to return the localstorage.
 *
 * This is necessary because safari throws
 * when a user disables cookies/localstorage
 * and you attempt to access it.
 *
 * @return {LocalStorage}
 * @api private
 */

function localstorage() {
  try {
    return window.localStorage;
  } catch (e) {}
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(31)))

/***/ }),

/***/ 4363:
/***/ (function(module, exports, __webpack_require__) {


/**
 * This is the common logic for both the Node.js and web browser
 * implementations of `debug()`.
 *
 * Expose `debug()` as the module.
 */

exports = module.exports = createDebug.debug = createDebug['default'] = createDebug;
exports.coerce = coerce;
exports.disable = disable;
exports.enable = enable;
exports.enabled = enabled;
exports.humanize = __webpack_require__(4364);

/**
 * Active `debug` instances.
 */
exports.instances = [];

/**
 * The currently active debug mode names, and names to skip.
 */

exports.names = [];
exports.skips = [];

/**
 * Map of special "%n" handling functions, for the debug "format" argument.
 *
 * Valid key names are a single, lower or upper-case letter, i.e. "n" and "N".
 */

exports.formatters = {};

/**
 * Select a color.
 * @param {String} namespace
 * @return {Number}
 * @api private
 */

function selectColor(namespace) {
  var hash = 0, i;

  for (i in namespace) {
    hash  = ((hash << 5) - hash) + namespace.charCodeAt(i);
    hash |= 0; // Convert to 32bit integer
  }

  return exports.colors[Math.abs(hash) % exports.colors.length];
}

/**
 * Create a debugger with the given `namespace`.
 *
 * @param {String} namespace
 * @return {Function}
 * @api public
 */

function createDebug(namespace) {

  var prevTime;

  function debug() {
    // disabled?
    if (!debug.enabled) return;

    var self = debug;

    // set `diff` timestamp
    var curr = +new Date();
    var ms = curr - (prevTime || curr);
    self.diff = ms;
    self.prev = prevTime;
    self.curr = curr;
    prevTime = curr;

    // turn the `arguments` into a proper Array
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }

    args[0] = exports.coerce(args[0]);

    if ('string' !== typeof args[0]) {
      // anything else let's inspect with %O
      args.unshift('%O');
    }

    // apply any `formatters` transformations
    var index = 0;
    args[0] = args[0].replace(/%([a-zA-Z%])/g, function(match, format) {
      // if we encounter an escaped % then don't increase the array index
      if (match === '%%') return match;
      index++;
      var formatter = exports.formatters[format];
      if ('function' === typeof formatter) {
        var val = args[index];
        match = formatter.call(self, val);

        // now we need to remove `args[index]` since it's inlined in the `format`
        args.splice(index, 1);
        index--;
      }
      return match;
    });

    // apply env-specific formatting (colors, etc.)
    exports.formatArgs.call(self, args);

    var logFn = debug.log || exports.log || console.log.bind(console);
    logFn.apply(self, args);
  }

  debug.namespace = namespace;
  debug.enabled = exports.enabled(namespace);
  debug.useColors = exports.useColors();
  debug.color = selectColor(namespace);
  debug.destroy = destroy;

  // env-specific initialization logic for debug instances
  if ('function' === typeof exports.init) {
    exports.init(debug);
  }

  exports.instances.push(debug);

  return debug;
}

function destroy () {
  var index = exports.instances.indexOf(this);
  if (index !== -1) {
    exports.instances.splice(index, 1);
    return true;
  } else {
    return false;
  }
}

/**
 * Enables a debug mode by namespaces. This can include modes
 * separated by a colon and wildcards.
 *
 * @param {String} namespaces
 * @api public
 */

function enable(namespaces) {
  exports.save(namespaces);

  exports.names = [];
  exports.skips = [];

  var i;
  var split = (typeof namespaces === 'string' ? namespaces : '').split(/[\s,]+/);
  var len = split.length;

  for (i = 0; i < len; i++) {
    if (!split[i]) continue; // ignore empty strings
    namespaces = split[i].replace(/\*/g, '.*?');
    if (namespaces[0] === '-') {
      exports.skips.push(new RegExp('^' + namespaces.substr(1) + '$'));
    } else {
      exports.names.push(new RegExp('^' + namespaces + '$'));
    }
  }

  for (i = 0; i < exports.instances.length; i++) {
    var instance = exports.instances[i];
    instance.enabled = exports.enabled(instance.namespace);
  }
}

/**
 * Disable debug output.
 *
 * @api public
 */

function disable() {
  exports.enable('');
}

/**
 * Returns true if the given mode name is enabled, false otherwise.
 *
 * @param {String} name
 * @return {Boolean}
 * @api public
 */

function enabled(name) {
  if (name[name.length - 1] === '*') {
    return true;
  }
  var i, len;
  for (i = 0, len = exports.skips.length; i < len; i++) {
    if (exports.skips[i].test(name)) {
      return false;
    }
  }
  for (i = 0, len = exports.names.length; i < len; i++) {
    if (exports.names[i].test(name)) {
      return true;
    }
  }
  return false;
}

/**
 * Coerce `val`.
 *
 * @param {Mixed} val
 * @return {Mixed}
 * @api private
 */

function coerce(val) {
  if (val instanceof Error) return val.stack || val.message;
  return val;
}


/***/ }),

/***/ 4364:
/***/ (function(module, exports) {

/**
 * Helpers.
 */

var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var y = d * 365.25;

/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */

module.exports = function(val, options) {
  options = options || {};
  var type = typeof val;
  if (type === 'string' && val.length > 0) {
    return parse(val);
  } else if (type === 'number' && isNaN(val) === false) {
    return options.long ? fmtLong(val) : fmtShort(val);
  }
  throw new Error(
    'val is not a non-empty string or a valid number. val=' +
      JSON.stringify(val)
  );
};

/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */

function parse(str) {
  str = String(str);
  if (str.length > 100) {
    return;
  }
  var match = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(
    str
  );
  if (!match) {
    return;
  }
  var n = parseFloat(match[1]);
  var type = (match[2] || 'ms').toLowerCase();
  switch (type) {
    case 'years':
    case 'year':
    case 'yrs':
    case 'yr':
    case 'y':
      return n * y;
    case 'days':
    case 'day':
    case 'd':
      return n * d;
    case 'hours':
    case 'hour':
    case 'hrs':
    case 'hr':
    case 'h':
      return n * h;
    case 'minutes':
    case 'minute':
    case 'mins':
    case 'min':
    case 'm':
      return n * m;
    case 'seconds':
    case 'second':
    case 'secs':
    case 'sec':
    case 's':
      return n * s;
    case 'milliseconds':
    case 'millisecond':
    case 'msecs':
    case 'msec':
    case 'ms':
      return n;
    default:
      return undefined;
  }
}

/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtShort(ms) {
  if (ms >= d) {
    return Math.round(ms / d) + 'd';
  }
  if (ms >= h) {
    return Math.round(ms / h) + 'h';
  }
  if (ms >= m) {
    return Math.round(ms / m) + 'm';
  }
  if (ms >= s) {
    return Math.round(ms / s) + 's';
  }
  return ms + 'ms';
}

/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtLong(ms) {
  return plural(ms, d, 'day') ||
    plural(ms, h, 'hour') ||
    plural(ms, m, 'minute') ||
    plural(ms, s, 'second') ||
    ms + ' ms';
}

/**
 * Pluralization helper.
 */

function plural(ms, n, name) {
  if (ms < n) {
    return;
  }
  if (ms < n * 1.5) {
    return Math.floor(ms / n) + ' ' + name;
  }
  return Math.ceil(ms / n) + ' ' + name + 's';
}


/***/ }),

/***/ 4365:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Expose `Emitter`.
 */

if (true) {
  module.exports = Emitter;
}

/**
 * Initialize a new `Emitter`.
 *
 * @api public
 */

function Emitter(obj) {
  if (obj) return mixin(obj);
};

/**
 * Mixin the emitter properties.
 *
 * @param {Object} obj
 * @return {Object}
 * @api private
 */

function mixin(obj) {
  for (var key in Emitter.prototype) {
    obj[key] = Emitter.prototype[key];
  }
  return obj;
}

/**
 * Listen on the given `event` with `fn`.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.on =
Emitter.prototype.addEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};
  (this._callbacks['$' + event] = this._callbacks['$' + event] || [])
    .push(fn);
  return this;
};

/**
 * Adds an `event` listener that will be invoked a single
 * time then automatically removed.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.once = function(event, fn){
  function on() {
    this.off(event, on);
    fn.apply(this, arguments);
  }

  on.fn = fn;
  this.on(event, on);
  return this;
};

/**
 * Remove the given callback for `event` or all
 * registered callbacks.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.off =
Emitter.prototype.removeListener =
Emitter.prototype.removeAllListeners =
Emitter.prototype.removeEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};

  // all
  if (0 == arguments.length) {
    this._callbacks = {};
    return this;
  }

  // specific event
  var callbacks = this._callbacks['$' + event];
  if (!callbacks) return this;

  // remove all handlers
  if (1 == arguments.length) {
    delete this._callbacks['$' + event];
    return this;
  }

  // remove specific handler
  var cb;
  for (var i = 0; i < callbacks.length; i++) {
    cb = callbacks[i];
    if (cb === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
  }
  return this;
};

/**
 * Emit `event` with the given args.
 *
 * @param {String} event
 * @param {Mixed} ...
 * @return {Emitter}
 */

Emitter.prototype.emit = function(event){
  this._callbacks = this._callbacks || {};
  var args = [].slice.call(arguments, 1)
    , callbacks = this._callbacks['$' + event];

  if (callbacks) {
    callbacks = callbacks.slice(0);
    for (var i = 0, len = callbacks.length; i < len; ++i) {
      callbacks[i].apply(this, args);
    }
  }

  return this;
};

/**
 * Return array of callbacks for `event`.
 *
 * @param {String} event
 * @return {Array}
 * @api public
 */

Emitter.prototype.listeners = function(event){
  this._callbacks = this._callbacks || {};
  return this._callbacks['$' + event] || [];
};

/**
 * Check if this emitter has `event` handlers.
 *
 * @param {String} event
 * @return {Boolean}
 * @api public
 */

Emitter.prototype.hasListeners = function(event){
  return !! this.listeners(event).length;
};


/***/ }),

/***/ 4366:
/***/ (function(module, exports, __webpack_require__) {

/*global Blob,File*/

/**
 * Module requirements
 */

var isArray = __webpack_require__(4367);
var isBuf = __webpack_require__(4368);
var toString = Object.prototype.toString;
var withNativeBlob = typeof Blob === 'function' || (typeof Blob !== 'undefined' && toString.call(Blob) === '[object BlobConstructor]');
var withNativeFile = typeof File === 'function' || (typeof File !== 'undefined' && toString.call(File) === '[object FileConstructor]');

/**
 * Replaces every Buffer | ArrayBuffer in packet with a numbered placeholder.
 * Anything with blobs or files should be fed through removeBlobs before coming
 * here.
 *
 * @param {Object} packet - socket.io event packet
 * @return {Object} with deconstructed packet and list of buffers
 * @api public
 */

exports.deconstructPacket = function(packet) {
  var buffers = [];
  var packetData = packet.data;
  var pack = packet;
  pack.data = _deconstructPacket(packetData, buffers);
  pack.attachments = buffers.length; // number of binary 'attachments'
  return {packet: pack, buffers: buffers};
};

function _deconstructPacket(data, buffers) {
  if (!data) return data;

  if (isBuf(data)) {
    var placeholder = { _placeholder: true, num: buffers.length };
    buffers.push(data);
    return placeholder;
  } else if (isArray(data)) {
    var newData = new Array(data.length);
    for (var i = 0; i < data.length; i++) {
      newData[i] = _deconstructPacket(data[i], buffers);
    }
    return newData;
  } else if (typeof data === 'object' && !(data instanceof Date)) {
    var newData = {};
    for (var key in data) {
      newData[key] = _deconstructPacket(data[key], buffers);
    }
    return newData;
  }
  return data;
}

/**
 * Reconstructs a binary packet from its placeholder packet and buffers
 *
 * @param {Object} packet - event packet with placeholders
 * @param {Array} buffers - binary buffers to put in placeholder positions
 * @return {Object} reconstructed packet
 * @api public
 */

exports.reconstructPacket = function(packet, buffers) {
  packet.data = _reconstructPacket(packet.data, buffers);
  packet.attachments = undefined; // no longer useful
  return packet;
};

function _reconstructPacket(data, buffers) {
  if (!data) return data;

  if (data && data._placeholder) {
    return buffers[data.num]; // appropriate buffer (should be natural order anyway)
  } else if (isArray(data)) {
    for (var i = 0; i < data.length; i++) {
      data[i] = _reconstructPacket(data[i], buffers);
    }
  } else if (typeof data === 'object') {
    for (var key in data) {
      data[key] = _reconstructPacket(data[key], buffers);
    }
  }

  return data;
}

/**
 * Asynchronously removes Blobs or Files from data via
 * FileReader's readAsArrayBuffer method. Used before encoding
 * data as msgpack. Calls callback with the blobless data.
 *
 * @param {Object} data
 * @param {Function} callback
 * @api private
 */

exports.removeBlobs = function(data, callback) {
  function _removeBlobs(obj, curKey, containingObject) {
    if (!obj) return obj;

    // convert any blob
    if ((withNativeBlob && obj instanceof Blob) ||
        (withNativeFile && obj instanceof File)) {
      pendingBlobs++;

      // async filereader
      var fileReader = new FileReader();
      fileReader.onload = function() { // this.result == arraybuffer
        if (containingObject) {
          containingObject[curKey] = this.result;
        }
        else {
          bloblessData = this.result;
        }

        // if nothing pending its callback time
        if(! --pendingBlobs) {
          callback(bloblessData);
        }
      };

      fileReader.readAsArrayBuffer(obj); // blob -> arraybuffer
    } else if (isArray(obj)) { // handle array
      for (var i = 0; i < obj.length; i++) {
        _removeBlobs(obj[i], i, obj);
      }
    } else if (typeof obj === 'object' && !isBuf(obj)) { // and object
      for (var key in obj) {
        _removeBlobs(obj[key], key, obj);
      }
    }
  }

  var pendingBlobs = 0;
  var bloblessData = data;
  _removeBlobs(bloblessData);
  if (!pendingBlobs) {
    callback(bloblessData);
  }
};


/***/ }),

/***/ 4367:
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = Array.isArray || function (arr) {
  return toString.call(arr) == '[object Array]';
};


/***/ }),

/***/ 4368:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Buffer) {
module.exports = isBuf;

var withNativeBuffer = typeof Buffer === 'function' && typeof Buffer.isBuffer === 'function';
var withNativeArrayBuffer = typeof ArrayBuffer === 'function';

var isView = function (obj) {
  return typeof ArrayBuffer.isView === 'function' ? ArrayBuffer.isView(obj) : (obj.buffer instanceof ArrayBuffer);
};

/**
 * Returns true if obj is a buffer or an arraybuffer.
 *
 * @api private
 */

function isBuf(obj) {
  return (withNativeBuffer && Buffer.isBuffer(obj)) ||
          (withNativeArrayBuffer && (obj instanceof ArrayBuffer || isView(obj)));
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4369:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Module dependencies.
 */

var eio = __webpack_require__(4370);
var Socket = __webpack_require__(4395);
var Emitter = __webpack_require__(4365);
var parser = __webpack_require__(4361);
var on = __webpack_require__(4397);
var bind = __webpack_require__(4398);
var debug = __webpack_require__(4359)('socket.io-client:manager');
var indexOf = __webpack_require__(4394);
var Backoff = __webpack_require__(4399);

/**
 * IE6+ hasOwnProperty
 */

var has = Object.prototype.hasOwnProperty;

/**
 * Module exports
 */

module.exports = Manager;

/**
 * `Manager` constructor.
 *
 * @param {String} engine instance or engine uri/opts
 * @param {Object} options
 * @api public
 */

function Manager (uri, opts) {
  if (!(this instanceof Manager)) return new Manager(uri, opts);
  if (uri && ('object' === typeof uri)) {
    opts = uri;
    uri = undefined;
  }
  opts = opts || {};

  opts.path = opts.path || '/socket.io';
  this.nsps = {};
  this.subs = [];
  this.opts = opts;
  this.reconnection(opts.reconnection !== false);
  this.reconnectionAttempts(opts.reconnectionAttempts || Infinity);
  this.reconnectionDelay(opts.reconnectionDelay || 1000);
  this.reconnectionDelayMax(opts.reconnectionDelayMax || 5000);
  this.randomizationFactor(opts.randomizationFactor || 0.5);
  this.backoff = new Backoff({
    min: this.reconnectionDelay(),
    max: this.reconnectionDelayMax(),
    jitter: this.randomizationFactor()
  });
  this.timeout(null == opts.timeout ? 20000 : opts.timeout);
  this.readyState = 'closed';
  this.uri = uri;
  this.connecting = [];
  this.lastPing = null;
  this.encoding = false;
  this.packetBuffer = [];
  var _parser = opts.parser || parser;
  this.encoder = new _parser.Encoder();
  this.decoder = new _parser.Decoder();
  this.autoConnect = opts.autoConnect !== false;
  if (this.autoConnect) this.open();
}

/**
 * Propagate given event to sockets and emit on `this`
 *
 * @api private
 */

Manager.prototype.emitAll = function () {
  this.emit.apply(this, arguments);
  for (var nsp in this.nsps) {
    if (has.call(this.nsps, nsp)) {
      this.nsps[nsp].emit.apply(this.nsps[nsp], arguments);
    }
  }
};

/**
 * Update `socket.id` of all sockets
 *
 * @api private
 */

Manager.prototype.updateSocketIds = function () {
  for (var nsp in this.nsps) {
    if (has.call(this.nsps, nsp)) {
      this.nsps[nsp].id = this.generateId(nsp);
    }
  }
};

/**
 * generate `socket.id` for the given `nsp`
 *
 * @param {String} nsp
 * @return {String}
 * @api private
 */

Manager.prototype.generateId = function (nsp) {
  return (nsp === '/' ? '' : (nsp + '#')) + this.engine.id;
};

/**
 * Mix in `Emitter`.
 */

Emitter(Manager.prototype);

/**
 * Sets the `reconnection` config.
 *
 * @param {Boolean} true/false if it should automatically reconnect
 * @return {Manager} self or value
 * @api public
 */

Manager.prototype.reconnection = function (v) {
  if (!arguments.length) return this._reconnection;
  this._reconnection = !!v;
  return this;
};

/**
 * Sets the reconnection attempts config.
 *
 * @param {Number} max reconnection attempts before giving up
 * @return {Manager} self or value
 * @api public
 */

Manager.prototype.reconnectionAttempts = function (v) {
  if (!arguments.length) return this._reconnectionAttempts;
  this._reconnectionAttempts = v;
  return this;
};

/**
 * Sets the delay between reconnections.
 *
 * @param {Number} delay
 * @return {Manager} self or value
 * @api public
 */

Manager.prototype.reconnectionDelay = function (v) {
  if (!arguments.length) return this._reconnectionDelay;
  this._reconnectionDelay = v;
  this.backoff && this.backoff.setMin(v);
  return this;
};

Manager.prototype.randomizationFactor = function (v) {
  if (!arguments.length) return this._randomizationFactor;
  this._randomizationFactor = v;
  this.backoff && this.backoff.setJitter(v);
  return this;
};

/**
 * Sets the maximum delay between reconnections.
 *
 * @param {Number} delay
 * @return {Manager} self or value
 * @api public
 */

Manager.prototype.reconnectionDelayMax = function (v) {
  if (!arguments.length) return this._reconnectionDelayMax;
  this._reconnectionDelayMax = v;
  this.backoff && this.backoff.setMax(v);
  return this;
};

/**
 * Sets the connection timeout. `false` to disable
 *
 * @return {Manager} self or value
 * @api public
 */

Manager.prototype.timeout = function (v) {
  if (!arguments.length) return this._timeout;
  this._timeout = v;
  return this;
};

/**
 * Starts trying to reconnect if reconnection is enabled and we have not
 * started reconnecting yet
 *
 * @api private
 */

Manager.prototype.maybeReconnectOnOpen = function () {
  // Only try to reconnect if it's the first time we're connecting
  if (!this.reconnecting && this._reconnection && this.backoff.attempts === 0) {
    // keeps reconnection from firing twice for the same reconnection loop
    this.reconnect();
  }
};

/**
 * Sets the current transport `socket`.
 *
 * @param {Function} optional, callback
 * @return {Manager} self
 * @api public
 */

Manager.prototype.open =
Manager.prototype.connect = function (fn, opts) {
  debug('readyState %s', this.readyState);
  if (~this.readyState.indexOf('open')) return this;

  debug('opening %s', this.uri);
  this.engine = eio(this.uri, this.opts);
  var socket = this.engine;
  var self = this;
  this.readyState = 'opening';
  this.skipReconnect = false;

  // emit `open`
  var openSub = on(socket, 'open', function () {
    self.onopen();
    fn && fn();
  });

  // emit `connect_error`
  var errorSub = on(socket, 'error', function (data) {
    debug('connect_error');
    self.cleanup();
    self.readyState = 'closed';
    self.emitAll('connect_error', data);
    if (fn) {
      var err = new Error('Connection error');
      err.data = data;
      fn(err);
    } else {
      // Only do this if there is no fn to handle the error
      self.maybeReconnectOnOpen();
    }
  });

  // emit `connect_timeout`
  if (false !== this._timeout) {
    var timeout = this._timeout;
    debug('connect attempt will timeout after %d', timeout);

    // set timer
    var timer = setTimeout(function () {
      debug('connect attempt timed out after %d', timeout);
      openSub.destroy();
      socket.close();
      socket.emit('error', 'timeout');
      self.emitAll('connect_timeout', timeout);
    }, timeout);

    this.subs.push({
      destroy: function () {
        clearTimeout(timer);
      }
    });
  }

  this.subs.push(openSub);
  this.subs.push(errorSub);

  return this;
};

/**
 * Called upon transport open.
 *
 * @api private
 */

Manager.prototype.onopen = function () {
  debug('open');

  // clear old subs
  this.cleanup();

  // mark as open
  this.readyState = 'open';
  this.emit('open');

  // add new subs
  var socket = this.engine;
  this.subs.push(on(socket, 'data', bind(this, 'ondata')));
  this.subs.push(on(socket, 'ping', bind(this, 'onping')));
  this.subs.push(on(socket, 'pong', bind(this, 'onpong')));
  this.subs.push(on(socket, 'error', bind(this, 'onerror')));
  this.subs.push(on(socket, 'close', bind(this, 'onclose')));
  this.subs.push(on(this.decoder, 'decoded', bind(this, 'ondecoded')));
};

/**
 * Called upon a ping.
 *
 * @api private
 */

Manager.prototype.onping = function () {
  this.lastPing = new Date();
  this.emitAll('ping');
};

/**
 * Called upon a packet.
 *
 * @api private
 */

Manager.prototype.onpong = function () {
  this.emitAll('pong', new Date() - this.lastPing);
};

/**
 * Called with data.
 *
 * @api private
 */

Manager.prototype.ondata = function (data) {
  this.decoder.add(data);
};

/**
 * Called when parser fully decodes a packet.
 *
 * @api private
 */

Manager.prototype.ondecoded = function (packet) {
  this.emit('packet', packet);
};

/**
 * Called upon socket error.
 *
 * @api private
 */

Manager.prototype.onerror = function (err) {
  debug('error', err);
  this.emitAll('error', err);
};

/**
 * Creates a new socket for the given `nsp`.
 *
 * @return {Socket}
 * @api public
 */

Manager.prototype.socket = function (nsp, opts) {
  var socket = this.nsps[nsp];
  if (!socket) {
    socket = new Socket(this, nsp, opts);
    this.nsps[nsp] = socket;
    var self = this;
    socket.on('connecting', onConnecting);
    socket.on('connect', function () {
      socket.id = self.generateId(nsp);
    });

    if (this.autoConnect) {
      // manually call here since connecting event is fired before listening
      onConnecting();
    }
  }

  function onConnecting () {
    if (!~indexOf(self.connecting, socket)) {
      self.connecting.push(socket);
    }
  }

  return socket;
};

/**
 * Called upon a socket close.
 *
 * @param {Socket} socket
 */

Manager.prototype.destroy = function (socket) {
  var index = indexOf(this.connecting, socket);
  if (~index) this.connecting.splice(index, 1);
  if (this.connecting.length) return;

  this.close();
};

/**
 * Writes a packet.
 *
 * @param {Object} packet
 * @api private
 */

Manager.prototype.packet = function (packet) {
  debug('writing packet %j', packet);
  var self = this;
  if (packet.query && packet.type === 0) packet.nsp += '?' + packet.query;

  if (!self.encoding) {
    // encode, then write to engine with result
    self.encoding = true;
    this.encoder.encode(packet, function (encodedPackets) {
      for (var i = 0; i < encodedPackets.length; i++) {
        self.engine.write(encodedPackets[i], packet.options);
      }
      self.encoding = false;
      self.processPacketQueue();
    });
  } else { // add packet to the queue
    self.packetBuffer.push(packet);
  }
};

/**
 * If packet buffer is non-empty, begins encoding the
 * next packet in line.
 *
 * @api private
 */

Manager.prototype.processPacketQueue = function () {
  if (this.packetBuffer.length > 0 && !this.encoding) {
    var pack = this.packetBuffer.shift();
    this.packet(pack);
  }
};

/**
 * Clean up transport subscriptions and packet buffer.
 *
 * @api private
 */

Manager.prototype.cleanup = function () {
  debug('cleanup');

  var subsLength = this.subs.length;
  for (var i = 0; i < subsLength; i++) {
    var sub = this.subs.shift();
    sub.destroy();
  }

  this.packetBuffer = [];
  this.encoding = false;
  this.lastPing = null;

  this.decoder.destroy();
};

/**
 * Close the current socket.
 *
 * @api private
 */

Manager.prototype.close =
Manager.prototype.disconnect = function () {
  debug('disconnect');
  this.skipReconnect = true;
  this.reconnecting = false;
  if ('opening' === this.readyState) {
    // `onclose` will not fire because
    // an open event never happened
    this.cleanup();
  }
  this.backoff.reset();
  this.readyState = 'closed';
  if (this.engine) this.engine.close();
};

/**
 * Called upon engine close.
 *
 * @api private
 */

Manager.prototype.onclose = function (reason) {
  debug('onclose');

  this.cleanup();
  this.backoff.reset();
  this.readyState = 'closed';
  this.emit('close', reason);

  if (this._reconnection && !this.skipReconnect) {
    this.reconnect();
  }
};

/**
 * Attempt a reconnection.
 *
 * @api private
 */

Manager.prototype.reconnect = function () {
  if (this.reconnecting || this.skipReconnect) return this;

  var self = this;

  if (this.backoff.attempts >= this._reconnectionAttempts) {
    debug('reconnect failed');
    this.backoff.reset();
    this.emitAll('reconnect_failed');
    this.reconnecting = false;
  } else {
    var delay = this.backoff.duration();
    debug('will wait %dms before reconnect attempt', delay);

    this.reconnecting = true;
    var timer = setTimeout(function () {
      if (self.skipReconnect) return;

      debug('attempting reconnect');
      self.emitAll('reconnect_attempt', self.backoff.attempts);
      self.emitAll('reconnecting', self.backoff.attempts);

      // check again for the case socket closed in above events
      if (self.skipReconnect) return;

      self.open(function (err) {
        if (err) {
          debug('reconnect attempt error');
          self.reconnecting = false;
          self.reconnect();
          self.emitAll('reconnect_error', err.data);
        } else {
          debug('reconnect success');
          self.onreconnect();
        }
      });
    }, delay);

    this.subs.push({
      destroy: function () {
        clearTimeout(timer);
      }
    });
  }
};

/**
 * Called upon successful reconnect.
 *
 * @api private
 */

Manager.prototype.onreconnect = function () {
  var attempt = this.backoff.attempts;
  this.reconnecting = false;
  this.backoff.reset();
  this.updateSocketIds();
  this.emitAll('reconnect', attempt);
};


/***/ }),

/***/ 4370:
/***/ (function(module, exports, __webpack_require__) {


module.exports = __webpack_require__(4371);

/**
 * Exports parser
 *
 * @api public
 *
 */
module.exports.parser = __webpack_require__(4379);


/***/ }),

/***/ 4371:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module dependencies.
 */

var transports = __webpack_require__(4372);
var Emitter = __webpack_require__(4387);
var debug = __webpack_require__(4359)('engine.io-client:socket');
var index = __webpack_require__(4394);
var parser = __webpack_require__(4379);
var parseuri = __webpack_require__(4358);
var parseqs = __webpack_require__(4388);

/**
 * Module exports.
 */

module.exports = Socket;

/**
 * Socket constructor.
 *
 * @param {String|Object} uri or options
 * @param {Object} options
 * @api public
 */

function Socket (uri, opts) {
  if (!(this instanceof Socket)) return new Socket(uri, opts);

  opts = opts || {};

  if (uri && 'object' === typeof uri) {
    opts = uri;
    uri = null;
  }

  if (uri) {
    uri = parseuri(uri);
    opts.hostname = uri.host;
    opts.secure = uri.protocol === 'https' || uri.protocol === 'wss';
    opts.port = uri.port;
    if (uri.query) opts.query = uri.query;
  } else if (opts.host) {
    opts.hostname = parseuri(opts.host).host;
  }

  this.secure = null != opts.secure ? opts.secure
    : (typeof location !== 'undefined' && 'https:' === location.protocol);

  if (opts.hostname && !opts.port) {
    // if no port is specified manually, use the protocol default
    opts.port = this.secure ? '443' : '80';
  }

  this.agent = opts.agent || false;
  this.hostname = opts.hostname ||
    (typeof location !== 'undefined' ? location.hostname : 'localhost');
  this.port = opts.port || (typeof location !== 'undefined' && location.port
      ? location.port
      : (this.secure ? 443 : 80));
  this.query = opts.query || {};
  if ('string' === typeof this.query) this.query = parseqs.decode(this.query);
  this.upgrade = false !== opts.upgrade;
  this.path = (opts.path || '/engine.io').replace(/\/$/, '') + '/';
  this.forceJSONP = !!opts.forceJSONP;
  this.jsonp = false !== opts.jsonp;
  this.forceBase64 = !!opts.forceBase64;
  this.enablesXDR = !!opts.enablesXDR;
  this.withCredentials = false !== opts.withCredentials;
  this.timestampParam = opts.timestampParam || 't';
  this.timestampRequests = opts.timestampRequests;
  this.transports = opts.transports || ['polling', 'websocket'];
  this.transportOptions = opts.transportOptions || {};
  this.readyState = '';
  this.writeBuffer = [];
  this.prevBufferLen = 0;
  this.policyPort = opts.policyPort || 843;
  this.rememberUpgrade = opts.rememberUpgrade || false;
  this.binaryType = null;
  this.onlyBinaryUpgrades = opts.onlyBinaryUpgrades;
  this.perMessageDeflate = false !== opts.perMessageDeflate ? (opts.perMessageDeflate || {}) : false;

  if (true === this.perMessageDeflate) this.perMessageDeflate = {};
  if (this.perMessageDeflate && null == this.perMessageDeflate.threshold) {
    this.perMessageDeflate.threshold = 1024;
  }

  // SSL options for Node.js client
  this.pfx = opts.pfx || null;
  this.key = opts.key || null;
  this.passphrase = opts.passphrase || null;
  this.cert = opts.cert || null;
  this.ca = opts.ca || null;
  this.ciphers = opts.ciphers || null;
  this.rejectUnauthorized = opts.rejectUnauthorized === undefined ? true : opts.rejectUnauthorized;
  this.forceNode = !!opts.forceNode;

  // detect ReactNative environment
  this.isReactNative = (typeof navigator !== 'undefined' && typeof navigator.product === 'string' && navigator.product.toLowerCase() === 'reactnative');

  // other options for Node.js or ReactNative client
  if (typeof self === 'undefined' || this.isReactNative) {
    if (opts.extraHeaders && Object.keys(opts.extraHeaders).length > 0) {
      this.extraHeaders = opts.extraHeaders;
    }

    if (opts.localAddress) {
      this.localAddress = opts.localAddress;
    }
  }

  // set on handshake
  this.id = null;
  this.upgrades = null;
  this.pingInterval = null;
  this.pingTimeout = null;

  // set on heartbeat
  this.pingIntervalTimer = null;
  this.pingTimeoutTimer = null;

  this.open();
}

Socket.priorWebsocketSuccess = false;

/**
 * Mix in `Emitter`.
 */

Emitter(Socket.prototype);

/**
 * Protocol version.
 *
 * @api public
 */

Socket.protocol = parser.protocol; // this is an int

/**
 * Expose deps for legacy compatibility
 * and standalone browser access.
 */

Socket.Socket = Socket;
Socket.Transport = __webpack_require__(4378);
Socket.transports = __webpack_require__(4372);
Socket.parser = __webpack_require__(4379);

/**
 * Creates transport of the given type.
 *
 * @param {String} transport name
 * @return {Transport}
 * @api private
 */

Socket.prototype.createTransport = function (name) {
  debug('creating transport "%s"', name);
  var query = clone(this.query);

  // append engine.io protocol identifier
  query.EIO = parser.protocol;

  // transport name
  query.transport = name;

  // per-transport options
  var options = this.transportOptions[name] || {};

  // session id if we already have one
  if (this.id) query.sid = this.id;

  var transport = new transports[name]({
    query: query,
    socket: this,
    agent: options.agent || this.agent,
    hostname: options.hostname || this.hostname,
    port: options.port || this.port,
    secure: options.secure || this.secure,
    path: options.path || this.path,
    forceJSONP: options.forceJSONP || this.forceJSONP,
    jsonp: options.jsonp || this.jsonp,
    forceBase64: options.forceBase64 || this.forceBase64,
    enablesXDR: options.enablesXDR || this.enablesXDR,
    withCredentials: options.withCredentials || this.withCredentials,
    timestampRequests: options.timestampRequests || this.timestampRequests,
    timestampParam: options.timestampParam || this.timestampParam,
    policyPort: options.policyPort || this.policyPort,
    pfx: options.pfx || this.pfx,
    key: options.key || this.key,
    passphrase: options.passphrase || this.passphrase,
    cert: options.cert || this.cert,
    ca: options.ca || this.ca,
    ciphers: options.ciphers || this.ciphers,
    rejectUnauthorized: options.rejectUnauthorized || this.rejectUnauthorized,
    perMessageDeflate: options.perMessageDeflate || this.perMessageDeflate,
    extraHeaders: options.extraHeaders || this.extraHeaders,
    forceNode: options.forceNode || this.forceNode,
    localAddress: options.localAddress || this.localAddress,
    requestTimeout: options.requestTimeout || this.requestTimeout,
    protocols: options.protocols || void (0),
    isReactNative: this.isReactNative
  });

  return transport;
};

function clone (obj) {
  var o = {};
  for (var i in obj) {
    if (obj.hasOwnProperty(i)) {
      o[i] = obj[i];
    }
  }
  return o;
}

/**
 * Initializes transport to use and starts probe.
 *
 * @api private
 */
Socket.prototype.open = function () {
  var transport;
  if (this.rememberUpgrade && Socket.priorWebsocketSuccess && this.transports.indexOf('websocket') !== -1) {
    transport = 'websocket';
  } else if (0 === this.transports.length) {
    // Emit error on next tick so it can be listened to
    var self = this;
    setTimeout(function () {
      self.emit('error', 'No transports available');
    }, 0);
    return;
  } else {
    transport = this.transports[0];
  }
  this.readyState = 'opening';

  // Retry with the next transport if the transport is disabled (jsonp: false)
  try {
    transport = this.createTransport(transport);
  } catch (e) {
    this.transports.shift();
    this.open();
    return;
  }

  transport.open();
  this.setTransport(transport);
};

/**
 * Sets the current transport. Disables the existing one (if any).
 *
 * @api private
 */

Socket.prototype.setTransport = function (transport) {
  debug('setting transport %s', transport.name);
  var self = this;

  if (this.transport) {
    debug('clearing existing transport %s', this.transport.name);
    this.transport.removeAllListeners();
  }

  // set up transport
  this.transport = transport;

  // set up transport listeners
  transport
  .on('drain', function () {
    self.onDrain();
  })
  .on('packet', function (packet) {
    self.onPacket(packet);
  })
  .on('error', function (e) {
    self.onError(e);
  })
  .on('close', function () {
    self.onClose('transport close');
  });
};

/**
 * Probes a transport.
 *
 * @param {String} transport name
 * @api private
 */

Socket.prototype.probe = function (name) {
  debug('probing transport "%s"', name);
  var transport = this.createTransport(name, { probe: 1 });
  var failed = false;
  var self = this;

  Socket.priorWebsocketSuccess = false;

  function onTransportOpen () {
    if (self.onlyBinaryUpgrades) {
      var upgradeLosesBinary = !this.supportsBinary && self.transport.supportsBinary;
      failed = failed || upgradeLosesBinary;
    }
    if (failed) return;

    debug('probe transport "%s" opened', name);
    transport.send([{ type: 'ping', data: 'probe' }]);
    transport.once('packet', function (msg) {
      if (failed) return;
      if ('pong' === msg.type && 'probe' === msg.data) {
        debug('probe transport "%s" pong', name);
        self.upgrading = true;
        self.emit('upgrading', transport);
        if (!transport) return;
        Socket.priorWebsocketSuccess = 'websocket' === transport.name;

        debug('pausing current transport "%s"', self.transport.name);
        self.transport.pause(function () {
          if (failed) return;
          if ('closed' === self.readyState) return;
          debug('changing transport and sending upgrade packet');

          cleanup();

          self.setTransport(transport);
          transport.send([{ type: 'upgrade' }]);
          self.emit('upgrade', transport);
          transport = null;
          self.upgrading = false;
          self.flush();
        });
      } else {
        debug('probe transport "%s" failed', name);
        var err = new Error('probe error');
        err.transport = transport.name;
        self.emit('upgradeError', err);
      }
    });
  }

  function freezeTransport () {
    if (failed) return;

    // Any callback called by transport should be ignored since now
    failed = true;

    cleanup();

    transport.close();
    transport = null;
  }

  // Handle any error that happens while probing
  function onerror (err) {
    var error = new Error('probe error: ' + err);
    error.transport = transport.name;

    freezeTransport();

    debug('probe transport "%s" failed because of error: %s', name, err);

    self.emit('upgradeError', error);
  }

  function onTransportClose () {
    onerror('transport closed');
  }

  // When the socket is closed while we're probing
  function onclose () {
    onerror('socket closed');
  }

  // When the socket is upgraded while we're probing
  function onupgrade (to) {
    if (transport && to.name !== transport.name) {
      debug('"%s" works - aborting "%s"', to.name, transport.name);
      freezeTransport();
    }
  }

  // Remove all listeners on the transport and on self
  function cleanup () {
    transport.removeListener('open', onTransportOpen);
    transport.removeListener('error', onerror);
    transport.removeListener('close', onTransportClose);
    self.removeListener('close', onclose);
    self.removeListener('upgrading', onupgrade);
  }

  transport.once('open', onTransportOpen);
  transport.once('error', onerror);
  transport.once('close', onTransportClose);

  this.once('close', onclose);
  this.once('upgrading', onupgrade);

  transport.open();
};

/**
 * Called when connection is deemed open.
 *
 * @api public
 */

Socket.prototype.onOpen = function () {
  debug('socket open');
  this.readyState = 'open';
  Socket.priorWebsocketSuccess = 'websocket' === this.transport.name;
  this.emit('open');
  this.flush();

  // we check for `readyState` in case an `open`
  // listener already closed the socket
  if ('open' === this.readyState && this.upgrade && this.transport.pause) {
    debug('starting upgrade probes');
    for (var i = 0, l = this.upgrades.length; i < l; i++) {
      this.probe(this.upgrades[i]);
    }
  }
};

/**
 * Handles a packet.
 *
 * @api private
 */

Socket.prototype.onPacket = function (packet) {
  if ('opening' === this.readyState || 'open' === this.readyState ||
      'closing' === this.readyState) {
    debug('socket receive: type "%s", data "%s"', packet.type, packet.data);

    this.emit('packet', packet);

    // Socket is live - any packet counts
    this.emit('heartbeat');

    switch (packet.type) {
      case 'open':
        this.onHandshake(JSON.parse(packet.data));
        break;

      case 'pong':
        this.setPing();
        this.emit('pong');
        break;

      case 'error':
        var err = new Error('server error');
        err.code = packet.data;
        this.onError(err);
        break;

      case 'message':
        this.emit('data', packet.data);
        this.emit('message', packet.data);
        break;
    }
  } else {
    debug('packet received with socket readyState "%s"', this.readyState);
  }
};

/**
 * Called upon handshake completion.
 *
 * @param {Object} handshake obj
 * @api private
 */

Socket.prototype.onHandshake = function (data) {
  this.emit('handshake', data);
  this.id = data.sid;
  this.transport.query.sid = data.sid;
  this.upgrades = this.filterUpgrades(data.upgrades);
  this.pingInterval = data.pingInterval;
  this.pingTimeout = data.pingTimeout;
  this.onOpen();
  // In case open handler closes socket
  if ('closed' === this.readyState) return;
  this.setPing();

  // Prolong liveness of socket on heartbeat
  this.removeListener('heartbeat', this.onHeartbeat);
  this.on('heartbeat', this.onHeartbeat);
};

/**
 * Resets ping timeout.
 *
 * @api private
 */

Socket.prototype.onHeartbeat = function (timeout) {
  clearTimeout(this.pingTimeoutTimer);
  var self = this;
  self.pingTimeoutTimer = setTimeout(function () {
    if ('closed' === self.readyState) return;
    self.onClose('ping timeout');
  }, timeout || (self.pingInterval + self.pingTimeout));
};

/**
 * Pings server every `this.pingInterval` and expects response
 * within `this.pingTimeout` or closes connection.
 *
 * @api private
 */

Socket.prototype.setPing = function () {
  var self = this;
  clearTimeout(self.pingIntervalTimer);
  self.pingIntervalTimer = setTimeout(function () {
    debug('writing ping packet - expecting pong within %sms', self.pingTimeout);
    self.ping();
    self.onHeartbeat(self.pingTimeout);
  }, self.pingInterval);
};

/**
* Sends a ping packet.
*
* @api private
*/

Socket.prototype.ping = function () {
  var self = this;
  this.sendPacket('ping', function () {
    self.emit('ping');
  });
};

/**
 * Called on `drain` event
 *
 * @api private
 */

Socket.prototype.onDrain = function () {
  this.writeBuffer.splice(0, this.prevBufferLen);

  // setting prevBufferLen = 0 is very important
  // for example, when upgrading, upgrade packet is sent over,
  // and a nonzero prevBufferLen could cause problems on `drain`
  this.prevBufferLen = 0;

  if (0 === this.writeBuffer.length) {
    this.emit('drain');
  } else {
    this.flush();
  }
};

/**
 * Flush write buffers.
 *
 * @api private
 */

Socket.prototype.flush = function () {
  if ('closed' !== this.readyState && this.transport.writable &&
    !this.upgrading && this.writeBuffer.length) {
    debug('flushing %d packets in socket', this.writeBuffer.length);
    this.transport.send(this.writeBuffer);
    // keep track of current length of writeBuffer
    // splice writeBuffer and callbackBuffer on `drain`
    this.prevBufferLen = this.writeBuffer.length;
    this.emit('flush');
  }
};

/**
 * Sends a message.
 *
 * @param {String} message.
 * @param {Function} callback function.
 * @param {Object} options.
 * @return {Socket} for chaining.
 * @api public
 */

Socket.prototype.write =
Socket.prototype.send = function (msg, options, fn) {
  this.sendPacket('message', msg, options, fn);
  return this;
};

/**
 * Sends a packet.
 *
 * @param {String} packet type.
 * @param {String} data.
 * @param {Object} options.
 * @param {Function} callback function.
 * @api private
 */

Socket.prototype.sendPacket = function (type, data, options, fn) {
  if ('function' === typeof data) {
    fn = data;
    data = undefined;
  }

  if ('function' === typeof options) {
    fn = options;
    options = null;
  }

  if ('closing' === this.readyState || 'closed' === this.readyState) {
    return;
  }

  options = options || {};
  options.compress = false !== options.compress;

  var packet = {
    type: type,
    data: data,
    options: options
  };
  this.emit('packetCreate', packet);
  this.writeBuffer.push(packet);
  if (fn) this.once('flush', fn);
  this.flush();
};

/**
 * Closes the connection.
 *
 * @api private
 */

Socket.prototype.close = function () {
  if ('opening' === this.readyState || 'open' === this.readyState) {
    this.readyState = 'closing';

    var self = this;

    if (this.writeBuffer.length) {
      this.once('drain', function () {
        if (this.upgrading) {
          waitForUpgrade();
        } else {
          close();
        }
      });
    } else if (this.upgrading) {
      waitForUpgrade();
    } else {
      close();
    }
  }

  function close () {
    self.onClose('forced close');
    debug('socket closing - telling transport to close');
    self.transport.close();
  }

  function cleanupAndClose () {
    self.removeListener('upgrade', cleanupAndClose);
    self.removeListener('upgradeError', cleanupAndClose);
    close();
  }

  function waitForUpgrade () {
    // wait for upgrade to finish since we can't send packets while pausing a transport
    self.once('upgrade', cleanupAndClose);
    self.once('upgradeError', cleanupAndClose);
  }

  return this;
};

/**
 * Called upon transport error
 *
 * @api private
 */

Socket.prototype.onError = function (err) {
  debug('socket error %j', err);
  Socket.priorWebsocketSuccess = false;
  this.emit('error', err);
  this.onClose('transport error', err);
};

/**
 * Called upon transport close.
 *
 * @api private
 */

Socket.prototype.onClose = function (reason, desc) {
  if ('opening' === this.readyState || 'open' === this.readyState || 'closing' === this.readyState) {
    debug('socket close with reason: "%s"', reason);
    var self = this;

    // clear timers
    clearTimeout(this.pingIntervalTimer);
    clearTimeout(this.pingTimeoutTimer);

    // stop event from firing again for transport
    this.transport.removeAllListeners('close');

    // ensure transport won't stay open
    this.transport.close();

    // ignore further transport communication
    this.transport.removeAllListeners();

    // set ready state
    this.readyState = 'closed';

    // clear session id
    this.id = null;

    // emit close event
    this.emit('close', reason, desc);

    // clean buffers after, so users can still
    // grab the buffers on `close` event
    self.writeBuffer = [];
    self.prevBufferLen = 0;
  }
};

/**
 * Filters upgrades, returning only those matching client transports.
 *
 * @param {Array} server upgrades
 * @api private
 *
 */

Socket.prototype.filterUpgrades = function (upgrades) {
  var filteredUpgrades = [];
  for (var i = 0, j = upgrades.length; i < j; i++) {
    if (~index(this.transports, upgrades[i])) filteredUpgrades.push(upgrades[i]);
  }
  return filteredUpgrades;
};


/***/ }),

/***/ 4372:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module dependencies
 */

var XMLHttpRequest = __webpack_require__(4373);
var XHR = __webpack_require__(4376);
var JSONP = __webpack_require__(4391);
var websocket = __webpack_require__(4392);

/**
 * Export transports.
 */

exports.polling = polling;
exports.websocket = websocket;

/**
 * Polling transport polymorphic constructor.
 * Decides on xhr vs jsonp based on feature detection.
 *
 * @api private
 */

function polling (opts) {
  var xhr;
  var xd = false;
  var xs = false;
  var jsonp = false !== opts.jsonp;

  if (typeof location !== 'undefined') {
    var isSSL = 'https:' === location.protocol;
    var port = location.port;

    // some user agents have empty `location.port`
    if (!port) {
      port = isSSL ? 443 : 80;
    }

    xd = opts.hostname !== location.hostname || port !== opts.port;
    xs = opts.secure !== isSSL;
  }

  opts.xdomain = xd;
  opts.xscheme = xs;
  xhr = new XMLHttpRequest(opts);

  if ('open' in xhr && !opts.forceJSONP) {
    return new XHR(opts);
  } else {
    if (!jsonp) throw new Error('JSONP disabled');
    return new JSONP(opts);
  }
}


/***/ }),

/***/ 4373:
/***/ (function(module, exports, __webpack_require__) {

// browser shim for xmlhttprequest module

var hasCORS = __webpack_require__(4374);
var globalThis = __webpack_require__(4375);

module.exports = function (opts) {
  var xdomain = opts.xdomain;

  // scheme must be same when usign XDomainRequest
  // http://blogs.msdn.com/b/ieinternals/archive/2010/05/13/xdomainrequest-restrictions-limitations-and-workarounds.aspx
  var xscheme = opts.xscheme;

  // XDomainRequest has a flow of not sending cookie, therefore it should be disabled as a default.
  // https://github.com/Automattic/engine.io-client/pull/217
  var enablesXDR = opts.enablesXDR;

  // XMLHttpRequest can be disabled on IE
  try {
    if ('undefined' !== typeof XMLHttpRequest && (!xdomain || hasCORS)) {
      return new XMLHttpRequest();
    }
  } catch (e) { }

  // Use XDomainRequest for IE8 if enablesXDR is true
  // because loading bar keeps flashing when using jsonp-polling
  // https://github.com/yujiosaka/socke.io-ie8-loading-example
  try {
    if ('undefined' !== typeof XDomainRequest && !xscheme && enablesXDR) {
      return new XDomainRequest();
    }
  } catch (e) { }

  if (!xdomain) {
    try {
      return new globalThis[['Active'].concat('Object').join('X')]('Microsoft.XMLHTTP');
    } catch (e) { }
  }
};


/***/ }),

/***/ 4374:
/***/ (function(module, exports) {


/**
 * Module exports.
 *
 * Logic borrowed from Modernizr:
 *
 *   - https://github.com/Modernizr/Modernizr/blob/master/feature-detects/cors.js
 */

try {
  module.exports = typeof XMLHttpRequest !== 'undefined' &&
    'withCredentials' in new XMLHttpRequest();
} catch (err) {
  // if XMLHttp support is disabled in IE then it will throw
  // when trying to create
  module.exports = false;
}


/***/ }),

/***/ 4375:
/***/ (function(module, exports) {

module.exports = (function () {
  if (typeof self !== 'undefined') {
    return self;
  } else if (typeof window !== 'undefined') {
    return window;
  } else {
    return Function('return this')(); // eslint-disable-line no-new-func
  }
})();


/***/ }),

/***/ 4376:
/***/ (function(module, exports, __webpack_require__) {

/* global attachEvent */

/**
 * Module requirements.
 */

var XMLHttpRequest = __webpack_require__(4373);
var Polling = __webpack_require__(4377);
var Emitter = __webpack_require__(4387);
var inherit = __webpack_require__(4389);
var debug = __webpack_require__(4359)('engine.io-client:polling-xhr');
var globalThis = __webpack_require__(4375);

/**
 * Module exports.
 */

module.exports = XHR;
module.exports.Request = Request;

/**
 * Empty function
 */

function empty () {}

/**
 * XHR Polling constructor.
 *
 * @param {Object} opts
 * @api public
 */

function XHR (opts) {
  Polling.call(this, opts);
  this.requestTimeout = opts.requestTimeout;
  this.extraHeaders = opts.extraHeaders;

  if (typeof location !== 'undefined') {
    var isSSL = 'https:' === location.protocol;
    var port = location.port;

    // some user agents have empty `location.port`
    if (!port) {
      port = isSSL ? 443 : 80;
    }

    this.xd = (typeof location !== 'undefined' && opts.hostname !== location.hostname) ||
      port !== opts.port;
    this.xs = opts.secure !== isSSL;
  }
}

/**
 * Inherits from Polling.
 */

inherit(XHR, Polling);

/**
 * XHR supports binary
 */

XHR.prototype.supportsBinary = true;

/**
 * Creates a request.
 *
 * @param {String} method
 * @api private
 */

XHR.prototype.request = function (opts) {
  opts = opts || {};
  opts.uri = this.uri();
  opts.xd = this.xd;
  opts.xs = this.xs;
  opts.agent = this.agent || false;
  opts.supportsBinary = this.supportsBinary;
  opts.enablesXDR = this.enablesXDR;
  opts.withCredentials = this.withCredentials;

  // SSL options for Node.js client
  opts.pfx = this.pfx;
  opts.key = this.key;
  opts.passphrase = this.passphrase;
  opts.cert = this.cert;
  opts.ca = this.ca;
  opts.ciphers = this.ciphers;
  opts.rejectUnauthorized = this.rejectUnauthorized;
  opts.requestTimeout = this.requestTimeout;

  // other options for Node.js client
  opts.extraHeaders = this.extraHeaders;

  return new Request(opts);
};

/**
 * Sends data.
 *
 * @param {String} data to send.
 * @param {Function} called upon flush.
 * @api private
 */

XHR.prototype.doWrite = function (data, fn) {
  var isBinary = typeof data !== 'string' && data !== undefined;
  var req = this.request({ method: 'POST', data: data, isBinary: isBinary });
  var self = this;
  req.on('success', fn);
  req.on('error', function (err) {
    self.onError('xhr post error', err);
  });
  this.sendXhr = req;
};

/**
 * Starts a poll cycle.
 *
 * @api private
 */

XHR.prototype.doPoll = function () {
  debug('xhr poll');
  var req = this.request();
  var self = this;
  req.on('data', function (data) {
    self.onData(data);
  });
  req.on('error', function (err) {
    self.onError('xhr poll error', err);
  });
  this.pollXhr = req;
};

/**
 * Request constructor
 *
 * @param {Object} options
 * @api public
 */

function Request (opts) {
  this.method = opts.method || 'GET';
  this.uri = opts.uri;
  this.xd = !!opts.xd;
  this.xs = !!opts.xs;
  this.async = false !== opts.async;
  this.data = undefined !== opts.data ? opts.data : null;
  this.agent = opts.agent;
  this.isBinary = opts.isBinary;
  this.supportsBinary = opts.supportsBinary;
  this.enablesXDR = opts.enablesXDR;
  this.withCredentials = opts.withCredentials;
  this.requestTimeout = opts.requestTimeout;

  // SSL options for Node.js client
  this.pfx = opts.pfx;
  this.key = opts.key;
  this.passphrase = opts.passphrase;
  this.cert = opts.cert;
  this.ca = opts.ca;
  this.ciphers = opts.ciphers;
  this.rejectUnauthorized = opts.rejectUnauthorized;

  // other options for Node.js client
  this.extraHeaders = opts.extraHeaders;

  this.create();
}

/**
 * Mix in `Emitter`.
 */

Emitter(Request.prototype);

/**
 * Creates the XHR object and sends the request.
 *
 * @api private
 */

Request.prototype.create = function () {
  var opts = { agent: this.agent, xdomain: this.xd, xscheme: this.xs, enablesXDR: this.enablesXDR };

  // SSL options for Node.js client
  opts.pfx = this.pfx;
  opts.key = this.key;
  opts.passphrase = this.passphrase;
  opts.cert = this.cert;
  opts.ca = this.ca;
  opts.ciphers = this.ciphers;
  opts.rejectUnauthorized = this.rejectUnauthorized;

  var xhr = this.xhr = new XMLHttpRequest(opts);
  var self = this;

  try {
    debug('xhr open %s: %s', this.method, this.uri);
    xhr.open(this.method, this.uri, this.async);
    try {
      if (this.extraHeaders) {
        xhr.setDisableHeaderCheck && xhr.setDisableHeaderCheck(true);
        for (var i in this.extraHeaders) {
          if (this.extraHeaders.hasOwnProperty(i)) {
            xhr.setRequestHeader(i, this.extraHeaders[i]);
          }
        }
      }
    } catch (e) {}

    if ('POST' === this.method) {
      try {
        if (this.isBinary) {
          xhr.setRequestHeader('Content-type', 'application/octet-stream');
        } else {
          xhr.setRequestHeader('Content-type', 'text/plain;charset=UTF-8');
        }
      } catch (e) {}
    }

    try {
      xhr.setRequestHeader('Accept', '*/*');
    } catch (e) {}

    // ie6 check
    if ('withCredentials' in xhr) {
      xhr.withCredentials = this.withCredentials;
    }

    if (this.requestTimeout) {
      xhr.timeout = this.requestTimeout;
    }

    if (this.hasXDR()) {
      xhr.onload = function () {
        self.onLoad();
      };
      xhr.onerror = function () {
        self.onError(xhr.responseText);
      };
    } else {
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 2) {
          try {
            var contentType = xhr.getResponseHeader('Content-Type');
            if (self.supportsBinary && contentType === 'application/octet-stream' || contentType === 'application/octet-stream; charset=UTF-8') {
              xhr.responseType = 'arraybuffer';
            }
          } catch (e) {}
        }
        if (4 !== xhr.readyState) return;
        if (200 === xhr.status || 1223 === xhr.status) {
          self.onLoad();
        } else {
          // make sure the `error` event handler that's user-set
          // does not throw in the same tick and gets caught here
          setTimeout(function () {
            self.onError(typeof xhr.status === 'number' ? xhr.status : 0);
          }, 0);
        }
      };
    }

    debug('xhr data %s', this.data);
    xhr.send(this.data);
  } catch (e) {
    // Need to defer since .create() is called directly fhrom the constructor
    // and thus the 'error' event can only be only bound *after* this exception
    // occurs.  Therefore, also, we cannot throw here at all.
    setTimeout(function () {
      self.onError(e);
    }, 0);
    return;
  }

  if (typeof document !== 'undefined') {
    this.index = Request.requestsCount++;
    Request.requests[this.index] = this;
  }
};

/**
 * Called upon successful response.
 *
 * @api private
 */

Request.prototype.onSuccess = function () {
  this.emit('success');
  this.cleanup();
};

/**
 * Called if we have data.
 *
 * @api private
 */

Request.prototype.onData = function (data) {
  this.emit('data', data);
  this.onSuccess();
};

/**
 * Called upon error.
 *
 * @api private
 */

Request.prototype.onError = function (err) {
  this.emit('error', err);
  this.cleanup(true);
};

/**
 * Cleans up house.
 *
 * @api private
 */

Request.prototype.cleanup = function (fromError) {
  if ('undefined' === typeof this.xhr || null === this.xhr) {
    return;
  }
  // xmlhttprequest
  if (this.hasXDR()) {
    this.xhr.onload = this.xhr.onerror = empty;
  } else {
    this.xhr.onreadystatechange = empty;
  }

  if (fromError) {
    try {
      this.xhr.abort();
    } catch (e) {}
  }

  if (typeof document !== 'undefined') {
    delete Request.requests[this.index];
  }

  this.xhr = null;
};

/**
 * Called upon load.
 *
 * @api private
 */

Request.prototype.onLoad = function () {
  var data;
  try {
    var contentType;
    try {
      contentType = this.xhr.getResponseHeader('Content-Type');
    } catch (e) {}
    if (contentType === 'application/octet-stream' || contentType === 'application/octet-stream; charset=UTF-8') {
      data = this.xhr.response || this.xhr.responseText;
    } else {
      data = this.xhr.responseText;
    }
  } catch (e) {
    this.onError(e);
  }
  if (null != data) {
    this.onData(data);
  }
};

/**
 * Check if it has XDomainRequest.
 *
 * @api private
 */

Request.prototype.hasXDR = function () {
  return typeof XDomainRequest !== 'undefined' && !this.xs && this.enablesXDR;
};

/**
 * Aborts the request.
 *
 * @api public
 */

Request.prototype.abort = function () {
  this.cleanup();
};

/**
 * Aborts pending requests when unloading the window. This is needed to prevent
 * memory leaks (e.g. when using IE) and to ensure that no spurious error is
 * emitted.
 */

Request.requestsCount = 0;
Request.requests = {};

if (typeof document !== 'undefined') {
  if (typeof attachEvent === 'function') {
    attachEvent('onunload', unloadHandler);
  } else if (typeof addEventListener === 'function') {
    var terminationEvent = 'onpagehide' in globalThis ? 'pagehide' : 'unload';
    addEventListener(terminationEvent, unloadHandler, false);
  }
}

function unloadHandler () {
  for (var i in Request.requests) {
    if (Request.requests.hasOwnProperty(i)) {
      Request.requests[i].abort();
    }
  }
}


/***/ }),

/***/ 4377:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module dependencies.
 */

var Transport = __webpack_require__(4378);
var parseqs = __webpack_require__(4388);
var parser = __webpack_require__(4379);
var inherit = __webpack_require__(4389);
var yeast = __webpack_require__(4390);
var debug = __webpack_require__(4359)('engine.io-client:polling');

/**
 * Module exports.
 */

module.exports = Polling;

/**
 * Is XHR2 supported?
 */

var hasXHR2 = (function () {
  var XMLHttpRequest = __webpack_require__(4373);
  var xhr = new XMLHttpRequest({ xdomain: false });
  return null != xhr.responseType;
})();

/**
 * Polling interface.
 *
 * @param {Object} opts
 * @api private
 */

function Polling (opts) {
  var forceBase64 = (opts && opts.forceBase64);
  if (!hasXHR2 || forceBase64) {
    this.supportsBinary = false;
  }
  Transport.call(this, opts);
}

/**
 * Inherits from Transport.
 */

inherit(Polling, Transport);

/**
 * Transport name.
 */

Polling.prototype.name = 'polling';

/**
 * Opens the socket (triggers polling). We write a PING message to determine
 * when the transport is open.
 *
 * @api private
 */

Polling.prototype.doOpen = function () {
  this.poll();
};

/**
 * Pauses polling.
 *
 * @param {Function} callback upon buffers are flushed and transport is paused
 * @api private
 */

Polling.prototype.pause = function (onPause) {
  var self = this;

  this.readyState = 'pausing';

  function pause () {
    debug('paused');
    self.readyState = 'paused';
    onPause();
  }

  if (this.polling || !this.writable) {
    var total = 0;

    if (this.polling) {
      debug('we are currently polling - waiting to pause');
      total++;
      this.once('pollComplete', function () {
        debug('pre-pause polling complete');
        --total || pause();
      });
    }

    if (!this.writable) {
      debug('we are currently writing - waiting to pause');
      total++;
      this.once('drain', function () {
        debug('pre-pause writing complete');
        --total || pause();
      });
    }
  } else {
    pause();
  }
};

/**
 * Starts polling cycle.
 *
 * @api public
 */

Polling.prototype.poll = function () {
  debug('polling');
  this.polling = true;
  this.doPoll();
  this.emit('poll');
};

/**
 * Overloads onData to detect payloads.
 *
 * @api private
 */

Polling.prototype.onData = function (data) {
  var self = this;
  debug('polling got data %s', data);
  var callback = function (packet, index, total) {
    // if its the first message we consider the transport open
    if ('opening' === self.readyState) {
      self.onOpen();
    }

    // if its a close packet, we close the ongoing requests
    if ('close' === packet.type) {
      self.onClose();
      return false;
    }

    // otherwise bypass onData and handle the message
    self.onPacket(packet);
  };

  // decode payload
  parser.decodePayload(data, this.socket.binaryType, callback);

  // if an event did not trigger closing
  if ('closed' !== this.readyState) {
    // if we got data we're not polling
    this.polling = false;
    this.emit('pollComplete');

    if ('open' === this.readyState) {
      this.poll();
    } else {
      debug('ignoring poll - transport state "%s"', this.readyState);
    }
  }
};

/**
 * For polling, send a close packet.
 *
 * @api private
 */

Polling.prototype.doClose = function () {
  var self = this;

  function close () {
    debug('writing close packet');
    self.write([{ type: 'close' }]);
  }

  if ('open' === this.readyState) {
    debug('transport open - closing');
    close();
  } else {
    // in case we're trying to close while
    // handshaking is in progress (GH-164)
    debug('transport not open - deferring close');
    this.once('open', close);
  }
};

/**
 * Writes a packets payload.
 *
 * @param {Array} data packets
 * @param {Function} drain callback
 * @api private
 */

Polling.prototype.write = function (packets) {
  var self = this;
  this.writable = false;
  var callbackfn = function () {
    self.writable = true;
    self.emit('drain');
  };

  parser.encodePayload(packets, this.supportsBinary, function (data) {
    self.doWrite(data, callbackfn);
  });
};

/**
 * Generates uri for connection.
 *
 * @api private
 */

Polling.prototype.uri = function () {
  var query = this.query || {};
  var schema = this.secure ? 'https' : 'http';
  var port = '';

  // cache busting is forced
  if (false !== this.timestampRequests) {
    query[this.timestampParam] = yeast();
  }

  if (!this.supportsBinary && !query.sid) {
    query.b64 = 1;
  }

  query = parseqs.encode(query);

  // avoid port if default for schema
  if (this.port && (('https' === schema && Number(this.port) !== 443) ||
     ('http' === schema && Number(this.port) !== 80))) {
    port = ':' + this.port;
  }

  // prepend ? to query
  if (query.length) {
    query = '?' + query;
  }

  var ipv6 = this.hostname.indexOf(':') !== -1;
  return schema + '://' + (ipv6 ? '[' + this.hostname + ']' : this.hostname) + port + this.path + query;
};


/***/ }),

/***/ 4378:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module dependencies.
 */

var parser = __webpack_require__(4379);
var Emitter = __webpack_require__(4387);

/**
 * Module exports.
 */

module.exports = Transport;

/**
 * Transport abstract constructor.
 *
 * @param {Object} options.
 * @api private
 */

function Transport (opts) {
  this.path = opts.path;
  this.hostname = opts.hostname;
  this.port = opts.port;
  this.secure = opts.secure;
  this.query = opts.query;
  this.timestampParam = opts.timestampParam;
  this.timestampRequests = opts.timestampRequests;
  this.readyState = '';
  this.agent = opts.agent || false;
  this.socket = opts.socket;
  this.enablesXDR = opts.enablesXDR;
  this.withCredentials = opts.withCredentials;

  // SSL options for Node.js client
  this.pfx = opts.pfx;
  this.key = opts.key;
  this.passphrase = opts.passphrase;
  this.cert = opts.cert;
  this.ca = opts.ca;
  this.ciphers = opts.ciphers;
  this.rejectUnauthorized = opts.rejectUnauthorized;
  this.forceNode = opts.forceNode;

  // results of ReactNative environment detection
  this.isReactNative = opts.isReactNative;

  // other options for Node.js client
  this.extraHeaders = opts.extraHeaders;
  this.localAddress = opts.localAddress;
}

/**
 * Mix in `Emitter`.
 */

Emitter(Transport.prototype);

/**
 * Emits an error.
 *
 * @param {String} str
 * @return {Transport} for chaining
 * @api public
 */

Transport.prototype.onError = function (msg, desc) {
  var err = new Error(msg);
  err.type = 'TransportError';
  err.description = desc;
  this.emit('error', err);
  return this;
};

/**
 * Opens the transport.
 *
 * @api public
 */

Transport.prototype.open = function () {
  if ('closed' === this.readyState || '' === this.readyState) {
    this.readyState = 'opening';
    this.doOpen();
  }

  return this;
};

/**
 * Closes the transport.
 *
 * @api private
 */

Transport.prototype.close = function () {
  if ('opening' === this.readyState || 'open' === this.readyState) {
    this.doClose();
    this.onClose();
  }

  return this;
};

/**
 * Sends multiple packets.
 *
 * @param {Array} packets
 * @api private
 */

Transport.prototype.send = function (packets) {
  if ('open' === this.readyState) {
    this.write(packets);
  } else {
    throw new Error('Transport not open');
  }
};

/**
 * Called upon open
 *
 * @api private
 */

Transport.prototype.onOpen = function () {
  this.readyState = 'open';
  this.writable = true;
  this.emit('open');
};

/**
 * Called with data.
 *
 * @param {String} data
 * @api private
 */

Transport.prototype.onData = function (data) {
  var packet = parser.decodePacket(data, this.socket.binaryType);
  this.onPacket(packet);
};

/**
 * Called with a decoded packet.
 */

Transport.prototype.onPacket = function (packet) {
  this.emit('packet', packet);
};

/**
 * Called upon close.
 *
 * @api private
 */

Transport.prototype.onClose = function () {
  this.readyState = 'closed';
  this.emit('close');
};


/***/ }),

/***/ 4379:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module dependencies.
 */

var keys = __webpack_require__(4380);
var hasBinary = __webpack_require__(4381);
var sliceBuffer = __webpack_require__(4383);
var after = __webpack_require__(4384);
var utf8 = __webpack_require__(4385);

var base64encoder;
if (typeof ArrayBuffer !== 'undefined') {
  base64encoder = __webpack_require__(4311);
}

/**
 * Check if we are running an android browser. That requires us to use
 * ArrayBuffer with polling transports...
 *
 * http://ghinda.net/jpeg-blob-ajax-android/
 */

var isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);

/**
 * Check if we are running in PhantomJS.
 * Uploading a Blob with PhantomJS does not work correctly, as reported here:
 * https://github.com/ariya/phantomjs/issues/11395
 * @type boolean
 */
var isPhantomJS = typeof navigator !== 'undefined' && /PhantomJS/i.test(navigator.userAgent);

/**
 * When true, avoids using Blobs to encode payloads.
 * @type boolean
 */
var dontSendBlobs = isAndroid || isPhantomJS;

/**
 * Current protocol version.
 */

exports.protocol = 3;

/**
 * Packet types.
 */

var packets = exports.packets = {
    open:     0    // non-ws
  , close:    1    // non-ws
  , ping:     2
  , pong:     3
  , message:  4
  , upgrade:  5
  , noop:     6
};

var packetslist = keys(packets);

/**
 * Premade error packet.
 */

var err = { type: 'error', data: 'parser error' };

/**
 * Create a blob api even for blob builder when vendor prefixes exist
 */

var Blob = __webpack_require__(4386);

/**
 * Encodes a packet.
 *
 *     <packet type id> [ <data> ]
 *
 * Example:
 *
 *     5hello world
 *     3
 *     4
 *
 * Binary is encoded in an identical principle
 *
 * @api private
 */

exports.encodePacket = function (packet, supportsBinary, utf8encode, callback) {
  if (typeof supportsBinary === 'function') {
    callback = supportsBinary;
    supportsBinary = false;
  }

  if (typeof utf8encode === 'function') {
    callback = utf8encode;
    utf8encode = null;
  }

  var data = (packet.data === undefined)
    ? undefined
    : packet.data.buffer || packet.data;

  if (typeof ArrayBuffer !== 'undefined' && data instanceof ArrayBuffer) {
    return encodeArrayBuffer(packet, supportsBinary, callback);
  } else if (typeof Blob !== 'undefined' && data instanceof Blob) {
    return encodeBlob(packet, supportsBinary, callback);
  }

  // might be an object with { base64: true, data: dataAsBase64String }
  if (data && data.base64) {
    return encodeBase64Object(packet, callback);
  }

  // Sending data as a utf-8 string
  var encoded = packets[packet.type];

  // data fragment is optional
  if (undefined !== packet.data) {
    encoded += utf8encode ? utf8.encode(String(packet.data), { strict: false }) : String(packet.data);
  }

  return callback('' + encoded);

};

function encodeBase64Object(packet, callback) {
  // packet data is an object { base64: true, data: dataAsBase64String }
  var message = 'b' + exports.packets[packet.type] + packet.data.data;
  return callback(message);
}

/**
 * Encode packet helpers for binary types
 */

function encodeArrayBuffer(packet, supportsBinary, callback) {
  if (!supportsBinary) {
    return exports.encodeBase64Packet(packet, callback);
  }

  var data = packet.data;
  var contentArray = new Uint8Array(data);
  var resultBuffer = new Uint8Array(1 + data.byteLength);

  resultBuffer[0] = packets[packet.type];
  for (var i = 0; i < contentArray.length; i++) {
    resultBuffer[i+1] = contentArray[i];
  }

  return callback(resultBuffer.buffer);
}

function encodeBlobAsArrayBuffer(packet, supportsBinary, callback) {
  if (!supportsBinary) {
    return exports.encodeBase64Packet(packet, callback);
  }

  var fr = new FileReader();
  fr.onload = function() {
    exports.encodePacket({ type: packet.type, data: fr.result }, supportsBinary, true, callback);
  };
  return fr.readAsArrayBuffer(packet.data);
}

function encodeBlob(packet, supportsBinary, callback) {
  if (!supportsBinary) {
    return exports.encodeBase64Packet(packet, callback);
  }

  if (dontSendBlobs) {
    return encodeBlobAsArrayBuffer(packet, supportsBinary, callback);
  }

  var length = new Uint8Array(1);
  length[0] = packets[packet.type];
  var blob = new Blob([length.buffer, packet.data]);

  return callback(blob);
}

/**
 * Encodes a packet with binary data in a base64 string
 *
 * @param {Object} packet, has `type` and `data`
 * @return {String} base64 encoded message
 */

exports.encodeBase64Packet = function(packet, callback) {
  var message = 'b' + exports.packets[packet.type];
  if (typeof Blob !== 'undefined' && packet.data instanceof Blob) {
    var fr = new FileReader();
    fr.onload = function() {
      var b64 = fr.result.split(',')[1];
      callback(message + b64);
    };
    return fr.readAsDataURL(packet.data);
  }

  var b64data;
  try {
    b64data = String.fromCharCode.apply(null, new Uint8Array(packet.data));
  } catch (e) {
    // iPhone Safari doesn't let you apply with typed arrays
    var typed = new Uint8Array(packet.data);
    var basic = new Array(typed.length);
    for (var i = 0; i < typed.length; i++) {
      basic[i] = typed[i];
    }
    b64data = String.fromCharCode.apply(null, basic);
  }
  message += btoa(b64data);
  return callback(message);
};

/**
 * Decodes a packet. Changes format to Blob if requested.
 *
 * @return {Object} with `type` and `data` (if any)
 * @api private
 */

exports.decodePacket = function (data, binaryType, utf8decode) {
  if (data === undefined) {
    return err;
  }
  // String data
  if (typeof data === 'string') {
    if (data.charAt(0) === 'b') {
      return exports.decodeBase64Packet(data.substr(1), binaryType);
    }

    if (utf8decode) {
      data = tryDecode(data);
      if (data === false) {
        return err;
      }
    }
    var type = data.charAt(0);

    if (Number(type) != type || !packetslist[type]) {
      return err;
    }

    if (data.length > 1) {
      return { type: packetslist[type], data: data.substring(1) };
    } else {
      return { type: packetslist[type] };
    }
  }

  var asArray = new Uint8Array(data);
  var type = asArray[0];
  var rest = sliceBuffer(data, 1);
  if (Blob && binaryType === 'blob') {
    rest = new Blob([rest]);
  }
  return { type: packetslist[type], data: rest };
};

function tryDecode(data) {
  try {
    data = utf8.decode(data, { strict: false });
  } catch (e) {
    return false;
  }
  return data;
}

/**
 * Decodes a packet encoded in a base64 string
 *
 * @param {String} base64 encoded message
 * @return {Object} with `type` and `data` (if any)
 */

exports.decodeBase64Packet = function(msg, binaryType) {
  var type = packetslist[msg.charAt(0)];
  if (!base64encoder) {
    return { type: type, data: { base64: true, data: msg.substr(1) } };
  }

  var data = base64encoder.decode(msg.substr(1));

  if (binaryType === 'blob' && Blob) {
    data = new Blob([data]);
  }

  return { type: type, data: data };
};

/**
 * Encodes multiple messages (payload).
 *
 *     <length>:data
 *
 * Example:
 *
 *     11:hello world2:hi
 *
 * If any contents are binary, they will be encoded as base64 strings. Base64
 * encoded strings are marked with a b before the length specifier
 *
 * @param {Array} packets
 * @api private
 */

exports.encodePayload = function (packets, supportsBinary, callback) {
  if (typeof supportsBinary === 'function') {
    callback = supportsBinary;
    supportsBinary = null;
  }

  var isBinary = hasBinary(packets);

  if (supportsBinary && isBinary) {
    if (Blob && !dontSendBlobs) {
      return exports.encodePayloadAsBlob(packets, callback);
    }

    return exports.encodePayloadAsArrayBuffer(packets, callback);
  }

  if (!packets.length) {
    return callback('0:');
  }

  function setLengthHeader(message) {
    return message.length + ':' + message;
  }

  function encodeOne(packet, doneCallback) {
    exports.encodePacket(packet, !isBinary ? false : supportsBinary, false, function(message) {
      doneCallback(null, setLengthHeader(message));
    });
  }

  map(packets, encodeOne, function(err, results) {
    return callback(results.join(''));
  });
};

/**
 * Async array map using after
 */

function map(ary, each, done) {
  var result = new Array(ary.length);
  var next = after(ary.length, done);

  var eachWithIndex = function(i, el, cb) {
    each(el, function(error, msg) {
      result[i] = msg;
      cb(error, result);
    });
  };

  for (var i = 0; i < ary.length; i++) {
    eachWithIndex(i, ary[i], next);
  }
}

/*
 * Decodes data when a payload is maybe expected. Possible binary contents are
 * decoded from their base64 representation
 *
 * @param {String} data, callback method
 * @api public
 */

exports.decodePayload = function (data, binaryType, callback) {
  if (typeof data !== 'string') {
    return exports.decodePayloadAsBinary(data, binaryType, callback);
  }

  if (typeof binaryType === 'function') {
    callback = binaryType;
    binaryType = null;
  }

  var packet;
  if (data === '') {
    // parser error - ignoring payload
    return callback(err, 0, 1);
  }

  var length = '', n, msg;

  for (var i = 0, l = data.length; i < l; i++) {
    var chr = data.charAt(i);

    if (chr !== ':') {
      length += chr;
      continue;
    }

    if (length === '' || (length != (n = Number(length)))) {
      // parser error - ignoring payload
      return callback(err, 0, 1);
    }

    msg = data.substr(i + 1, n);

    if (length != msg.length) {
      // parser error - ignoring payload
      return callback(err, 0, 1);
    }

    if (msg.length) {
      packet = exports.decodePacket(msg, binaryType, false);

      if (err.type === packet.type && err.data === packet.data) {
        // parser error in individual packet - ignoring payload
        return callback(err, 0, 1);
      }

      var ret = callback(packet, i + n, l);
      if (false === ret) return;
    }

    // advance cursor
    i += n;
    length = '';
  }

  if (length !== '') {
    // parser error - ignoring payload
    return callback(err, 0, 1);
  }

};

/**
 * Encodes multiple messages (payload) as binary.
 *
 * <1 = binary, 0 = string><number from 0-9><number from 0-9>[...]<number
 * 255><data>
 *
 * Example:
 * 1 3 255 1 2 3, if the binary contents are interpreted as 8 bit integers
 *
 * @param {Array} packets
 * @return {ArrayBuffer} encoded payload
 * @api private
 */

exports.encodePayloadAsArrayBuffer = function(packets, callback) {
  if (!packets.length) {
    return callback(new ArrayBuffer(0));
  }

  function encodeOne(packet, doneCallback) {
    exports.encodePacket(packet, true, true, function(data) {
      return doneCallback(null, data);
    });
  }

  map(packets, encodeOne, function(err, encodedPackets) {
    var totalLength = encodedPackets.reduce(function(acc, p) {
      var len;
      if (typeof p === 'string'){
        len = p.length;
      } else {
        len = p.byteLength;
      }
      return acc + len.toString().length + len + 2; // string/binary identifier + separator = 2
    }, 0);

    var resultArray = new Uint8Array(totalLength);

    var bufferIndex = 0;
    encodedPackets.forEach(function(p) {
      var isString = typeof p === 'string';
      var ab = p;
      if (isString) {
        var view = new Uint8Array(p.length);
        for (var i = 0; i < p.length; i++) {
          view[i] = p.charCodeAt(i);
        }
        ab = view.buffer;
      }

      if (isString) { // not true binary
        resultArray[bufferIndex++] = 0;
      } else { // true binary
        resultArray[bufferIndex++] = 1;
      }

      var lenStr = ab.byteLength.toString();
      for (var i = 0; i < lenStr.length; i++) {
        resultArray[bufferIndex++] = parseInt(lenStr[i]);
      }
      resultArray[bufferIndex++] = 255;

      var view = new Uint8Array(ab);
      for (var i = 0; i < view.length; i++) {
        resultArray[bufferIndex++] = view[i];
      }
    });

    return callback(resultArray.buffer);
  });
};

/**
 * Encode as Blob
 */

exports.encodePayloadAsBlob = function(packets, callback) {
  function encodeOne(packet, doneCallback) {
    exports.encodePacket(packet, true, true, function(encoded) {
      var binaryIdentifier = new Uint8Array(1);
      binaryIdentifier[0] = 1;
      if (typeof encoded === 'string') {
        var view = new Uint8Array(encoded.length);
        for (var i = 0; i < encoded.length; i++) {
          view[i] = encoded.charCodeAt(i);
        }
        encoded = view.buffer;
        binaryIdentifier[0] = 0;
      }

      var len = (encoded instanceof ArrayBuffer)
        ? encoded.byteLength
        : encoded.size;

      var lenStr = len.toString();
      var lengthAry = new Uint8Array(lenStr.length + 1);
      for (var i = 0; i < lenStr.length; i++) {
        lengthAry[i] = parseInt(lenStr[i]);
      }
      lengthAry[lenStr.length] = 255;

      if (Blob) {
        var blob = new Blob([binaryIdentifier.buffer, lengthAry.buffer, encoded]);
        doneCallback(null, blob);
      }
    });
  }

  map(packets, encodeOne, function(err, results) {
    return callback(new Blob(results));
  });
};

/*
 * Decodes data when a payload is maybe expected. Strings are decoded by
 * interpreting each byte as a key code for entries marked to start with 0. See
 * description of encodePayloadAsBinary
 *
 * @param {ArrayBuffer} data, callback method
 * @api public
 */

exports.decodePayloadAsBinary = function (data, binaryType, callback) {
  if (typeof binaryType === 'function') {
    callback = binaryType;
    binaryType = null;
  }

  var bufferTail = data;
  var buffers = [];

  while (bufferTail.byteLength > 0) {
    var tailArray = new Uint8Array(bufferTail);
    var isString = tailArray[0] === 0;
    var msgLength = '';

    for (var i = 1; ; i++) {
      if (tailArray[i] === 255) break;

      // 310 = char length of Number.MAX_VALUE
      if (msgLength.length > 310) {
        return callback(err, 0, 1);
      }

      msgLength += tailArray[i];
    }

    bufferTail = sliceBuffer(bufferTail, 2 + msgLength.length);
    msgLength = parseInt(msgLength);

    var msg = sliceBuffer(bufferTail, 0, msgLength);
    if (isString) {
      try {
        msg = String.fromCharCode.apply(null, new Uint8Array(msg));
      } catch (e) {
        // iPhone Safari doesn't let you apply to typed arrays
        var typed = new Uint8Array(msg);
        msg = '';
        for (var i = 0; i < typed.length; i++) {
          msg += String.fromCharCode(typed[i]);
        }
      }
    }

    buffers.push(msg);
    bufferTail = sliceBuffer(bufferTail, msgLength);
  }

  var total = buffers.length;
  buffers.forEach(function(buffer, i) {
    callback(exports.decodePacket(buffer, binaryType, true), i, total);
  });
};


/***/ }),

/***/ 4380:
/***/ (function(module, exports) {


/**
 * Gets the keys for an object.
 *
 * @return {Array} keys
 * @api private
 */

module.exports = Object.keys || function keys (obj){
  var arr = [];
  var has = Object.prototype.hasOwnProperty;

  for (var i in obj) {
    if (has.call(obj, i)) {
      arr.push(i);
    }
  }
  return arr;
};


/***/ }),

/***/ 4381:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Buffer) {/* global Blob File */

/*
 * Module requirements.
 */

var isArray = __webpack_require__(4382);

var toString = Object.prototype.toString;
var withNativeBlob = typeof Blob === 'function' ||
                        typeof Blob !== 'undefined' && toString.call(Blob) === '[object BlobConstructor]';
var withNativeFile = typeof File === 'function' ||
                        typeof File !== 'undefined' && toString.call(File) === '[object FileConstructor]';

/**
 * Module exports.
 */

module.exports = hasBinary;

/**
 * Checks for binary data.
 *
 * Supports Buffer, ArrayBuffer, Blob and File.
 *
 * @param {Object} anything
 * @api public
 */

function hasBinary (obj) {
  if (!obj || typeof obj !== 'object') {
    return false;
  }

  if (isArray(obj)) {
    for (var i = 0, l = obj.length; i < l; i++) {
      if (hasBinary(obj[i])) {
        return true;
      }
    }
    return false;
  }

  if ((typeof Buffer === 'function' && Buffer.isBuffer && Buffer.isBuffer(obj)) ||
    (typeof ArrayBuffer === 'function' && obj instanceof ArrayBuffer) ||
    (withNativeBlob && obj instanceof Blob) ||
    (withNativeFile && obj instanceof File)
  ) {
    return true;
  }

  // see: https://github.com/Automattic/has-binary/pull/4
  if (obj.toJSON && typeof obj.toJSON === 'function' && arguments.length === 1) {
    return hasBinary(obj.toJSON(), true);
  }

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key) && hasBinary(obj[key])) {
      return true;
    }
  }

  return false;
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4382:
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = Array.isArray || function (arr) {
  return toString.call(arr) == '[object Array]';
};


/***/ }),

/***/ 4383:
/***/ (function(module, exports) {

/**
 * An abstraction for slicing an arraybuffer even when
 * ArrayBuffer.prototype.slice is not supported
 *
 * @api public
 */

module.exports = function(arraybuffer, start, end) {
  var bytes = arraybuffer.byteLength;
  start = start || 0;
  end = end || bytes;

  if (arraybuffer.slice) { return arraybuffer.slice(start, end); }

  if (start < 0) { start += bytes; }
  if (end < 0) { end += bytes; }
  if (end > bytes) { end = bytes; }

  if (start >= bytes || start >= end || bytes === 0) {
    return new ArrayBuffer(0);
  }

  var abv = new Uint8Array(arraybuffer);
  var result = new Uint8Array(end - start);
  for (var i = start, ii = 0; i < end; i++, ii++) {
    result[ii] = abv[i];
  }
  return result.buffer;
};


/***/ }),

/***/ 4384:
/***/ (function(module, exports) {

module.exports = after

function after(count, callback, err_cb) {
    var bail = false
    err_cb = err_cb || noop
    proxy.count = count

    return (count === 0) ? callback() : proxy

    function proxy(err, result) {
        if (proxy.count <= 0) {
            throw new Error('after called too many times')
        }
        --proxy.count

        // after first error, rest are passed to err_cb
        if (err) {
            bail = true
            callback(err)
            // future error callbacks will go to error handler
            callback = err_cb
        } else if (proxy.count === 0 && !bail) {
            callback(null, result)
        }
    }
}

function noop() {}


/***/ }),

/***/ 4385:
/***/ (function(module, exports) {

/*! https://mths.be/utf8js v2.1.2 by @mathias */

var stringFromCharCode = String.fromCharCode;

// Taken from https://mths.be/punycode
function ucs2decode(string) {
	var output = [];
	var counter = 0;
	var length = string.length;
	var value;
	var extra;
	while (counter < length) {
		value = string.charCodeAt(counter++);
		if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
			// high surrogate, and there is a next character
			extra = string.charCodeAt(counter++);
			if ((extra & 0xFC00) == 0xDC00) { // low surrogate
				output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
			} else {
				// unmatched surrogate; only append this code unit, in case the next
				// code unit is the high surrogate of a surrogate pair
				output.push(value);
				counter--;
			}
		} else {
			output.push(value);
		}
	}
	return output;
}

// Taken from https://mths.be/punycode
function ucs2encode(array) {
	var length = array.length;
	var index = -1;
	var value;
	var output = '';
	while (++index < length) {
		value = array[index];
		if (value > 0xFFFF) {
			value -= 0x10000;
			output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
			value = 0xDC00 | value & 0x3FF;
		}
		output += stringFromCharCode(value);
	}
	return output;
}

function checkScalarValue(codePoint, strict) {
	if (codePoint >= 0xD800 && codePoint <= 0xDFFF) {
		if (strict) {
			throw Error(
				'Lone surrogate U+' + codePoint.toString(16).toUpperCase() +
				' is not a scalar value'
			);
		}
		return false;
	}
	return true;
}
/*--------------------------------------------------------------------------*/

function createByte(codePoint, shift) {
	return stringFromCharCode(((codePoint >> shift) & 0x3F) | 0x80);
}

function encodeCodePoint(codePoint, strict) {
	if ((codePoint & 0xFFFFFF80) == 0) { // 1-byte sequence
		return stringFromCharCode(codePoint);
	}
	var symbol = '';
	if ((codePoint & 0xFFFFF800) == 0) { // 2-byte sequence
		symbol = stringFromCharCode(((codePoint >> 6) & 0x1F) | 0xC0);
	}
	else if ((codePoint & 0xFFFF0000) == 0) { // 3-byte sequence
		if (!checkScalarValue(codePoint, strict)) {
			codePoint = 0xFFFD;
		}
		symbol = stringFromCharCode(((codePoint >> 12) & 0x0F) | 0xE0);
		symbol += createByte(codePoint, 6);
	}
	else if ((codePoint & 0xFFE00000) == 0) { // 4-byte sequence
		symbol = stringFromCharCode(((codePoint >> 18) & 0x07) | 0xF0);
		symbol += createByte(codePoint, 12);
		symbol += createByte(codePoint, 6);
	}
	symbol += stringFromCharCode((codePoint & 0x3F) | 0x80);
	return symbol;
}

function utf8encode(string, opts) {
	opts = opts || {};
	var strict = false !== opts.strict;

	var codePoints = ucs2decode(string);
	var length = codePoints.length;
	var index = -1;
	var codePoint;
	var byteString = '';
	while (++index < length) {
		codePoint = codePoints[index];
		byteString += encodeCodePoint(codePoint, strict);
	}
	return byteString;
}

/*--------------------------------------------------------------------------*/

function readContinuationByte() {
	if (byteIndex >= byteCount) {
		throw Error('Invalid byte index');
	}

	var continuationByte = byteArray[byteIndex] & 0xFF;
	byteIndex++;

	if ((continuationByte & 0xC0) == 0x80) {
		return continuationByte & 0x3F;
	}

	// If we end up here, it’s not a continuation byte
	throw Error('Invalid continuation byte');
}

function decodeSymbol(strict) {
	var byte1;
	var byte2;
	var byte3;
	var byte4;
	var codePoint;

	if (byteIndex > byteCount) {
		throw Error('Invalid byte index');
	}

	if (byteIndex == byteCount) {
		return false;
	}

	// Read first byte
	byte1 = byteArray[byteIndex] & 0xFF;
	byteIndex++;

	// 1-byte sequence (no continuation bytes)
	if ((byte1 & 0x80) == 0) {
		return byte1;
	}

	// 2-byte sequence
	if ((byte1 & 0xE0) == 0xC0) {
		byte2 = readContinuationByte();
		codePoint = ((byte1 & 0x1F) << 6) | byte2;
		if (codePoint >= 0x80) {
			return codePoint;
		} else {
			throw Error('Invalid continuation byte');
		}
	}

	// 3-byte sequence (may include unpaired surrogates)
	if ((byte1 & 0xF0) == 0xE0) {
		byte2 = readContinuationByte();
		byte3 = readContinuationByte();
		codePoint = ((byte1 & 0x0F) << 12) | (byte2 << 6) | byte3;
		if (codePoint >= 0x0800) {
			return checkScalarValue(codePoint, strict) ? codePoint : 0xFFFD;
		} else {
			throw Error('Invalid continuation byte');
		}
	}

	// 4-byte sequence
	if ((byte1 & 0xF8) == 0xF0) {
		byte2 = readContinuationByte();
		byte3 = readContinuationByte();
		byte4 = readContinuationByte();
		codePoint = ((byte1 & 0x07) << 0x12) | (byte2 << 0x0C) |
			(byte3 << 0x06) | byte4;
		if (codePoint >= 0x010000 && codePoint <= 0x10FFFF) {
			return codePoint;
		}
	}

	throw Error('Invalid UTF-8 detected');
}

var byteArray;
var byteCount;
var byteIndex;
function utf8decode(byteString, opts) {
	opts = opts || {};
	var strict = false !== opts.strict;

	byteArray = ucs2decode(byteString);
	byteCount = byteArray.length;
	byteIndex = 0;
	var codePoints = [];
	var tmp;
	while ((tmp = decodeSymbol(strict)) !== false) {
		codePoints.push(tmp);
	}
	return ucs2encode(codePoints);
}

module.exports = {
	version: '2.1.2',
	encode: utf8encode,
	decode: utf8decode
};


/***/ }),

/***/ 4386:
/***/ (function(module, exports) {

/**
 * Create a blob builder even when vendor prefixes exist
 */

var BlobBuilder = typeof BlobBuilder !== 'undefined' ? BlobBuilder :
  typeof WebKitBlobBuilder !== 'undefined' ? WebKitBlobBuilder :
  typeof MSBlobBuilder !== 'undefined' ? MSBlobBuilder :
  typeof MozBlobBuilder !== 'undefined' ? MozBlobBuilder : 
  false;

/**
 * Check if Blob constructor is supported
 */

var blobSupported = (function() {
  try {
    var a = new Blob(['hi']);
    return a.size === 2;
  } catch(e) {
    return false;
  }
})();

/**
 * Check if Blob constructor supports ArrayBufferViews
 * Fails in Safari 6, so we need to map to ArrayBuffers there.
 */

var blobSupportsArrayBufferView = blobSupported && (function() {
  try {
    var b = new Blob([new Uint8Array([1,2])]);
    return b.size === 2;
  } catch(e) {
    return false;
  }
})();

/**
 * Check if BlobBuilder is supported
 */

var blobBuilderSupported = BlobBuilder
  && BlobBuilder.prototype.append
  && BlobBuilder.prototype.getBlob;

/**
 * Helper function that maps ArrayBufferViews to ArrayBuffers
 * Used by BlobBuilder constructor and old browsers that didn't
 * support it in the Blob constructor.
 */

function mapArrayBufferViews(ary) {
  return ary.map(function(chunk) {
    if (chunk.buffer instanceof ArrayBuffer) {
      var buf = chunk.buffer;

      // if this is a subarray, make a copy so we only
      // include the subarray region from the underlying buffer
      if (chunk.byteLength !== buf.byteLength) {
        var copy = new Uint8Array(chunk.byteLength);
        copy.set(new Uint8Array(buf, chunk.byteOffset, chunk.byteLength));
        buf = copy.buffer;
      }

      return buf;
    }

    return chunk;
  });
}

function BlobBuilderConstructor(ary, options) {
  options = options || {};

  var bb = new BlobBuilder();
  mapArrayBufferViews(ary).forEach(function(part) {
    bb.append(part);
  });

  return (options.type) ? bb.getBlob(options.type) : bb.getBlob();
};

function BlobConstructor(ary, options) {
  return new Blob(mapArrayBufferViews(ary), options || {});
};

if (typeof Blob !== 'undefined') {
  BlobBuilderConstructor.prototype = Blob.prototype;
  BlobConstructor.prototype = Blob.prototype;
}

module.exports = (function() {
  if (blobSupported) {
    return blobSupportsArrayBufferView ? Blob : BlobConstructor;
  } else if (blobBuilderSupported) {
    return BlobBuilderConstructor;
  } else {
    return undefined;
  }
})();


/***/ }),

/***/ 4387:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Expose `Emitter`.
 */

if (true) {
  module.exports = Emitter;
}

/**
 * Initialize a new `Emitter`.
 *
 * @api public
 */

function Emitter(obj) {
  if (obj) return mixin(obj);
};

/**
 * Mixin the emitter properties.
 *
 * @param {Object} obj
 * @return {Object}
 * @api private
 */

function mixin(obj) {
  for (var key in Emitter.prototype) {
    obj[key] = Emitter.prototype[key];
  }
  return obj;
}

/**
 * Listen on the given `event` with `fn`.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.on =
Emitter.prototype.addEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};
  (this._callbacks['$' + event] = this._callbacks['$' + event] || [])
    .push(fn);
  return this;
};

/**
 * Adds an `event` listener that will be invoked a single
 * time then automatically removed.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.once = function(event, fn){
  function on() {
    this.off(event, on);
    fn.apply(this, arguments);
  }

  on.fn = fn;
  this.on(event, on);
  return this;
};

/**
 * Remove the given callback for `event` or all
 * registered callbacks.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.off =
Emitter.prototype.removeListener =
Emitter.prototype.removeAllListeners =
Emitter.prototype.removeEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};

  // all
  if (0 == arguments.length) {
    this._callbacks = {};
    return this;
  }

  // specific event
  var callbacks = this._callbacks['$' + event];
  if (!callbacks) return this;

  // remove all handlers
  if (1 == arguments.length) {
    delete this._callbacks['$' + event];
    return this;
  }

  // remove specific handler
  var cb;
  for (var i = 0; i < callbacks.length; i++) {
    cb = callbacks[i];
    if (cb === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
  }

  // Remove event specific arrays for event types that no
  // one is subscribed for to avoid memory leak.
  if (callbacks.length === 0) {
    delete this._callbacks['$' + event];
  }

  return this;
};

/**
 * Emit `event` with the given args.
 *
 * @param {String} event
 * @param {Mixed} ...
 * @return {Emitter}
 */

Emitter.prototype.emit = function(event){
  this._callbacks = this._callbacks || {};

  var args = new Array(arguments.length - 1)
    , callbacks = this._callbacks['$' + event];

  for (var i = 1; i < arguments.length; i++) {
    args[i - 1] = arguments[i];
  }

  if (callbacks) {
    callbacks = callbacks.slice(0);
    for (var i = 0, len = callbacks.length; i < len; ++i) {
      callbacks[i].apply(this, args);
    }
  }

  return this;
};

/**
 * Return array of callbacks for `event`.
 *
 * @param {String} event
 * @return {Array}
 * @api public
 */

Emitter.prototype.listeners = function(event){
  this._callbacks = this._callbacks || {};
  return this._callbacks['$' + event] || [];
};

/**
 * Check if this emitter has `event` handlers.
 *
 * @param {String} event
 * @return {Boolean}
 * @api public
 */

Emitter.prototype.hasListeners = function(event){
  return !! this.listeners(event).length;
};


/***/ }),

/***/ 4388:
/***/ (function(module, exports) {

/**
 * Compiles a querystring
 * Returns string representation of the object
 *
 * @param {Object}
 * @api private
 */

exports.encode = function (obj) {
  var str = '';

  for (var i in obj) {
    if (obj.hasOwnProperty(i)) {
      if (str.length) str += '&';
      str += encodeURIComponent(i) + '=' + encodeURIComponent(obj[i]);
    }
  }

  return str;
};

/**
 * Parses a simple querystring into an object
 *
 * @param {String} qs
 * @api private
 */

exports.decode = function(qs){
  var qry = {};
  var pairs = qs.split('&');
  for (var i = 0, l = pairs.length; i < l; i++) {
    var pair = pairs[i].split('=');
    qry[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
  }
  return qry;
};


/***/ }),

/***/ 4389:
/***/ (function(module, exports) {


module.exports = function(a, b){
  var fn = function(){};
  fn.prototype = b.prototype;
  a.prototype = new fn;
  a.prototype.constructor = a;
};

/***/ }),

/***/ 4390:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_'.split('')
  , length = 64
  , map = {}
  , seed = 0
  , i = 0
  , prev;

/**
 * Return a string representing the specified number.
 *
 * @param {Number} num The number to convert.
 * @returns {String} The string representation of the number.
 * @api public
 */
function encode(num) {
  var encoded = '';

  do {
    encoded = alphabet[num % length] + encoded;
    num = Math.floor(num / length);
  } while (num > 0);

  return encoded;
}

/**
 * Return the integer value specified by the given string.
 *
 * @param {String} str The string to convert.
 * @returns {Number} The integer value represented by the string.
 * @api public
 */
function decode(str) {
  var decoded = 0;

  for (i = 0; i < str.length; i++) {
    decoded = decoded * length + map[str.charAt(i)];
  }

  return decoded;
}

/**
 * Yeast: A tiny growing id generator.
 *
 * @returns {String} A unique id.
 * @api public
 */
function yeast() {
  var now = encode(+new Date());

  if (now !== prev) return seed = 0, prev = now;
  return now +'.'+ encode(seed++);
}

//
// Map each character to its index.
//
for (; i < length; i++) map[alphabet[i]] = i;

//
// Expose the `yeast`, `encode` and `decode` functions.
//
yeast.encode = encode;
yeast.decode = decode;
module.exports = yeast;


/***/ }),

/***/ 4391:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module requirements.
 */

var Polling = __webpack_require__(4377);
var inherit = __webpack_require__(4389);
var globalThis = __webpack_require__(4375);

/**
 * Module exports.
 */

module.exports = JSONPPolling;

/**
 * Cached regular expressions.
 */

var rNewline = /\n/g;
var rEscapedNewline = /\\n/g;

/**
 * Global JSONP callbacks.
 */

var callbacks;

/**
 * Noop.
 */

function empty () { }

/**
 * JSONP Polling constructor.
 *
 * @param {Object} opts.
 * @api public
 */

function JSONPPolling (opts) {
  Polling.call(this, opts);

  this.query = this.query || {};

  // define global callbacks array if not present
  // we do this here (lazily) to avoid unneeded global pollution
  if (!callbacks) {
    // we need to consider multiple engines in the same page
    callbacks = globalThis.___eio = (globalThis.___eio || []);
  }

  // callback identifier
  this.index = callbacks.length;

  // add callback to jsonp global
  var self = this;
  callbacks.push(function (msg) {
    self.onData(msg);
  });

  // append to query string
  this.query.j = this.index;

  // prevent spurious errors from being emitted when the window is unloaded
  if (typeof addEventListener === 'function') {
    addEventListener('beforeunload', function () {
      if (self.script) self.script.onerror = empty;
    }, false);
  }
}

/**
 * Inherits from Polling.
 */

inherit(JSONPPolling, Polling);

/*
 * JSONP only supports binary as base64 encoded strings
 */

JSONPPolling.prototype.supportsBinary = false;

/**
 * Closes the socket.
 *
 * @api private
 */

JSONPPolling.prototype.doClose = function () {
  if (this.script) {
    this.script.parentNode.removeChild(this.script);
    this.script = null;
  }

  if (this.form) {
    this.form.parentNode.removeChild(this.form);
    this.form = null;
    this.iframe = null;
  }

  Polling.prototype.doClose.call(this);
};

/**
 * Starts a poll cycle.
 *
 * @api private
 */

JSONPPolling.prototype.doPoll = function () {
  var self = this;
  var script = document.createElement('script');

  if (this.script) {
    this.script.parentNode.removeChild(this.script);
    this.script = null;
  }

  script.async = true;
  script.src = this.uri();
  script.onerror = function (e) {
    self.onError('jsonp poll error', e);
  };

  var insertAt = document.getElementsByTagName('script')[0];
  if (insertAt) {
    insertAt.parentNode.insertBefore(script, insertAt);
  } else {
    (document.head || document.body).appendChild(script);
  }
  this.script = script;

  var isUAgecko = 'undefined' !== typeof navigator && /gecko/i.test(navigator.userAgent);

  if (isUAgecko) {
    setTimeout(function () {
      var iframe = document.createElement('iframe');
      document.body.appendChild(iframe);
      document.body.removeChild(iframe);
    }, 100);
  }
};

/**
 * Writes with a hidden iframe.
 *
 * @param {String} data to send
 * @param {Function} called upon flush.
 * @api private
 */

JSONPPolling.prototype.doWrite = function (data, fn) {
  var self = this;

  if (!this.form) {
    var form = document.createElement('form');
    var area = document.createElement('textarea');
    var id = this.iframeId = 'eio_iframe_' + this.index;
    var iframe;

    form.className = 'socketio';
    form.style.position = 'absolute';
    form.style.top = '-1000px';
    form.style.left = '-1000px';
    form.target = id;
    form.method = 'POST';
    form.setAttribute('accept-charset', 'utf-8');
    area.name = 'd';
    form.appendChild(area);
    document.body.appendChild(form);

    this.form = form;
    this.area = area;
  }

  this.form.action = this.uri();

  function complete () {
    initIframe();
    fn();
  }

  function initIframe () {
    if (self.iframe) {
      try {
        self.form.removeChild(self.iframe);
      } catch (e) {
        self.onError('jsonp polling iframe removal error', e);
      }
    }

    try {
      // ie6 dynamic iframes with target="" support (thanks Chris Lambacher)
      var html = '<iframe src="javascript:0" name="' + self.iframeId + '">';
      iframe = document.createElement(html);
    } catch (e) {
      iframe = document.createElement('iframe');
      iframe.name = self.iframeId;
      iframe.src = 'javascript:0';
    }

    iframe.id = self.iframeId;

    self.form.appendChild(iframe);
    self.iframe = iframe;
  }

  initIframe();

  // escape \n to prevent it from being converted into \r\n by some UAs
  // double escaping is required for escaped new lines because unescaping of new lines can be done safely on server-side
  data = data.replace(rEscapedNewline, '\\\n');
  this.area.value = data.replace(rNewline, '\\n');

  try {
    this.form.submit();
  } catch (e) {}

  if (this.iframe.attachEvent) {
    this.iframe.onreadystatechange = function () {
      if (self.iframe.readyState === 'complete') {
        complete();
      }
    };
  } else {
    this.iframe.onload = complete;
  }
};


/***/ }),

/***/ 4392:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Buffer) {/**
 * Module dependencies.
 */

var Transport = __webpack_require__(4378);
var parser = __webpack_require__(4379);
var parseqs = __webpack_require__(4388);
var inherit = __webpack_require__(4389);
var yeast = __webpack_require__(4390);
var debug = __webpack_require__(4359)('engine.io-client:websocket');

var BrowserWebSocket, NodeWebSocket;

if (typeof WebSocket !== 'undefined') {
  BrowserWebSocket = WebSocket;
} else if (typeof self !== 'undefined') {
  BrowserWebSocket = self.WebSocket || self.MozWebSocket;
}

if (typeof window === 'undefined') {
  try {
    NodeWebSocket = __webpack_require__(4393);
  } catch (e) { }
}

/**
 * Get either the `WebSocket` or `MozWebSocket` globals
 * in the browser or try to resolve WebSocket-compatible
 * interface exposed by `ws` for Node-like environment.
 */

var WebSocketImpl = BrowserWebSocket || NodeWebSocket;

/**
 * Module exports.
 */

module.exports = WS;

/**
 * WebSocket transport constructor.
 *
 * @api {Object} connection options
 * @api public
 */

function WS (opts) {
  var forceBase64 = (opts && opts.forceBase64);
  if (forceBase64) {
    this.supportsBinary = false;
  }
  this.perMessageDeflate = opts.perMessageDeflate;
  this.usingBrowserWebSocket = BrowserWebSocket && !opts.forceNode;
  this.protocols = opts.protocols;
  if (!this.usingBrowserWebSocket) {
    WebSocketImpl = NodeWebSocket;
  }
  Transport.call(this, opts);
}

/**
 * Inherits from Transport.
 */

inherit(WS, Transport);

/**
 * Transport name.
 *
 * @api public
 */

WS.prototype.name = 'websocket';

/*
 * WebSockets support binary
 */

WS.prototype.supportsBinary = true;

/**
 * Opens socket.
 *
 * @api private
 */

WS.prototype.doOpen = function () {
  if (!this.check()) {
    // let probe timeout
    return;
  }

  var uri = this.uri();
  var protocols = this.protocols;

  var opts = {};

  if (!this.isReactNative) {
    opts.agent = this.agent;
    opts.perMessageDeflate = this.perMessageDeflate;

    // SSL options for Node.js client
    opts.pfx = this.pfx;
    opts.key = this.key;
    opts.passphrase = this.passphrase;
    opts.cert = this.cert;
    opts.ca = this.ca;
    opts.ciphers = this.ciphers;
    opts.rejectUnauthorized = this.rejectUnauthorized;
  }

  if (this.extraHeaders) {
    opts.headers = this.extraHeaders;
  }
  if (this.localAddress) {
    opts.localAddress = this.localAddress;
  }

  try {
    this.ws =
      this.usingBrowserWebSocket && !this.isReactNative
        ? protocols
          ? new WebSocketImpl(uri, protocols)
          : new WebSocketImpl(uri)
        : new WebSocketImpl(uri, protocols, opts);
  } catch (err) {
    return this.emit('error', err);
  }

  if (this.ws.binaryType === undefined) {
    this.supportsBinary = false;
  }

  if (this.ws.supports && this.ws.supports.binary) {
    this.supportsBinary = true;
    this.ws.binaryType = 'nodebuffer';
  } else {
    this.ws.binaryType = 'arraybuffer';
  }

  this.addEventListeners();
};

/**
 * Adds event listeners to the socket
 *
 * @api private
 */

WS.prototype.addEventListeners = function () {
  var self = this;

  this.ws.onopen = function () {
    self.onOpen();
  };
  this.ws.onclose = function () {
    self.onClose();
  };
  this.ws.onmessage = function (ev) {
    self.onData(ev.data);
  };
  this.ws.onerror = function (e) {
    self.onError('websocket error', e);
  };
};

/**
 * Writes data to socket.
 *
 * @param {Array} array of packets.
 * @api private
 */

WS.prototype.write = function (packets) {
  var self = this;
  this.writable = false;

  // encodePacket efficient as it uses WS framing
  // no need for encodePayload
  var total = packets.length;
  for (var i = 0, l = total; i < l; i++) {
    (function (packet) {
      parser.encodePacket(packet, self.supportsBinary, function (data) {
        if (!self.usingBrowserWebSocket) {
          // always create a new object (GH-437)
          var opts = {};
          if (packet.options) {
            opts.compress = packet.options.compress;
          }

          if (self.perMessageDeflate) {
            var len = 'string' === typeof data ? Buffer.byteLength(data) : data.length;
            if (len < self.perMessageDeflate.threshold) {
              opts.compress = false;
            }
          }
        }

        // Sometimes the websocket has already been closed but the browser didn't
        // have a chance of informing us about it yet, in that case send will
        // throw an error
        try {
          if (self.usingBrowserWebSocket) {
            // TypeError is thrown when passing the second argument on Safari
            self.ws.send(data);
          } else {
            self.ws.send(data, opts);
          }
        } catch (e) {
          debug('websocket closed before onclose event');
        }

        --total || done();
      });
    })(packets[i]);
  }

  function done () {
    self.emit('flush');

    // fake drain
    // defer to next tick to allow Socket to clear writeBuffer
    setTimeout(function () {
      self.writable = true;
      self.emit('drain');
    }, 0);
  }
};

/**
 * Called upon close
 *
 * @api private
 */

WS.prototype.onClose = function () {
  Transport.prototype.onClose.call(this);
};

/**
 * Closes socket.
 *
 * @api private
 */

WS.prototype.doClose = function () {
  if (typeof this.ws !== 'undefined') {
    this.ws.close();
  }
};

/**
 * Generates uri for connection.
 *
 * @api private
 */

WS.prototype.uri = function () {
  var query = this.query || {};
  var schema = this.secure ? 'wss' : 'ws';
  var port = '';

  // avoid port if default for schema
  if (this.port && (('wss' === schema && Number(this.port) !== 443) ||
    ('ws' === schema && Number(this.port) !== 80))) {
    port = ':' + this.port;
  }

  // append timestamp to URI
  if (this.timestampRequests) {
    query[this.timestampParam] = yeast();
  }

  // communicate binary support capabilities
  if (!this.supportsBinary) {
    query.b64 = 1;
  }

  query = parseqs.encode(query);

  // prepend ? to query
  if (query.length) {
    query = '?' + query;
  }

  var ipv6 = this.hostname.indexOf(':') !== -1;
  return schema + '://' + (ipv6 ? '[' + this.hostname + ']' : this.hostname) + port + this.path + query;
};

/**
 * Feature detection for WebSocket.
 *
 * @return {Boolean} whether this transport is available.
 * @api public
 */

WS.prototype.check = function () {
  return !!WebSocketImpl && !('__initialize' in WebSocketImpl && this.name === WS.prototype.name);
};

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4393:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 4394:
/***/ (function(module, exports) {


var indexOf = [].indexOf;

module.exports = function(arr, obj){
  if (indexOf) return arr.indexOf(obj);
  for (var i = 0; i < arr.length; ++i) {
    if (arr[i] === obj) return i;
  }
  return -1;
};

/***/ }),

/***/ 4395:
/***/ (function(module, exports, __webpack_require__) {


/**
 * Module dependencies.
 */

var parser = __webpack_require__(4361);
var Emitter = __webpack_require__(4365);
var toArray = __webpack_require__(4396);
var on = __webpack_require__(4397);
var bind = __webpack_require__(4398);
var debug = __webpack_require__(4359)('socket.io-client:socket');
var parseqs = __webpack_require__(4388);
var hasBin = __webpack_require__(4381);

/**
 * Module exports.
 */

module.exports = exports = Socket;

/**
 * Internal events (blacklisted).
 * These events can't be emitted by the user.
 *
 * @api private
 */

var events = {
  connect: 1,
  connect_error: 1,
  connect_timeout: 1,
  connecting: 1,
  disconnect: 1,
  error: 1,
  reconnect: 1,
  reconnect_attempt: 1,
  reconnect_failed: 1,
  reconnect_error: 1,
  reconnecting: 1,
  ping: 1,
  pong: 1
};

/**
 * Shortcut to `Emitter#emit`.
 */

var emit = Emitter.prototype.emit;

/**
 * `Socket` constructor.
 *
 * @api public
 */

function Socket (io, nsp, opts) {
  this.io = io;
  this.nsp = nsp;
  this.json = this; // compat
  this.ids = 0;
  this.acks = {};
  this.receiveBuffer = [];
  this.sendBuffer = [];
  this.connected = false;
  this.disconnected = true;
  this.flags = {};
  if (opts && opts.query) {
    this.query = opts.query;
  }
  if (this.io.autoConnect) this.open();
}

/**
 * Mix in `Emitter`.
 */

Emitter(Socket.prototype);

/**
 * Subscribe to open, close and packet events
 *
 * @api private
 */

Socket.prototype.subEvents = function () {
  if (this.subs) return;

  var io = this.io;
  this.subs = [
    on(io, 'open', bind(this, 'onopen')),
    on(io, 'packet', bind(this, 'onpacket')),
    on(io, 'close', bind(this, 'onclose'))
  ];
};

/**
 * "Opens" the socket.
 *
 * @api public
 */

Socket.prototype.open =
Socket.prototype.connect = function () {
  if (this.connected) return this;

  this.subEvents();
  this.io.open(); // ensure open
  if ('open' === this.io.readyState) this.onopen();
  this.emit('connecting');
  return this;
};

/**
 * Sends a `message` event.
 *
 * @return {Socket} self
 * @api public
 */

Socket.prototype.send = function () {
  var args = toArray(arguments);
  args.unshift('message');
  this.emit.apply(this, args);
  return this;
};

/**
 * Override `emit`.
 * If the event is in `events`, it's emitted normally.
 *
 * @param {String} event name
 * @return {Socket} self
 * @api public
 */

Socket.prototype.emit = function (ev) {
  if (events.hasOwnProperty(ev)) {
    emit.apply(this, arguments);
    return this;
  }

  var args = toArray(arguments);
  var packet = {
    type: (this.flags.binary !== undefined ? this.flags.binary : hasBin(args)) ? parser.BINARY_EVENT : parser.EVENT,
    data: args
  };

  packet.options = {};
  packet.options.compress = !this.flags || false !== this.flags.compress;

  // event ack callback
  if ('function' === typeof args[args.length - 1]) {
    debug('emitting packet with ack id %d', this.ids);
    this.acks[this.ids] = args.pop();
    packet.id = this.ids++;
  }

  if (this.connected) {
    this.packet(packet);
  } else {
    this.sendBuffer.push(packet);
  }

  this.flags = {};

  return this;
};

/**
 * Sends a packet.
 *
 * @param {Object} packet
 * @api private
 */

Socket.prototype.packet = function (packet) {
  packet.nsp = this.nsp;
  this.io.packet(packet);
};

/**
 * Called upon engine `open`.
 *
 * @api private
 */

Socket.prototype.onopen = function () {
  debug('transport is open - connecting');

  // write connect packet if necessary
  if ('/' !== this.nsp) {
    if (this.query) {
      var query = typeof this.query === 'object' ? parseqs.encode(this.query) : this.query;
      debug('sending connect packet with query %s', query);
      this.packet({type: parser.CONNECT, query: query});
    } else {
      this.packet({type: parser.CONNECT});
    }
  }
};

/**
 * Called upon engine `close`.
 *
 * @param {String} reason
 * @api private
 */

Socket.prototype.onclose = function (reason) {
  debug('close (%s)', reason);
  this.connected = false;
  this.disconnected = true;
  delete this.id;
  this.emit('disconnect', reason);
};

/**
 * Called with socket packet.
 *
 * @param {Object} packet
 * @api private
 */

Socket.prototype.onpacket = function (packet) {
  var sameNamespace = packet.nsp === this.nsp;
  var rootNamespaceError = packet.type === parser.ERROR && packet.nsp === '/';

  if (!sameNamespace && !rootNamespaceError) return;

  switch (packet.type) {
    case parser.CONNECT:
      this.onconnect();
      break;

    case parser.EVENT:
      this.onevent(packet);
      break;

    case parser.BINARY_EVENT:
      this.onevent(packet);
      break;

    case parser.ACK:
      this.onack(packet);
      break;

    case parser.BINARY_ACK:
      this.onack(packet);
      break;

    case parser.DISCONNECT:
      this.ondisconnect();
      break;

    case parser.ERROR:
      this.emit('error', packet.data);
      break;
  }
};

/**
 * Called upon a server event.
 *
 * @param {Object} packet
 * @api private
 */

Socket.prototype.onevent = function (packet) {
  var args = packet.data || [];
  debug('emitting event %j', args);

  if (null != packet.id) {
    debug('attaching ack callback to event');
    args.push(this.ack(packet.id));
  }

  if (this.connected) {
    emit.apply(this, args);
  } else {
    this.receiveBuffer.push(args);
  }
};

/**
 * Produces an ack callback to emit with an event.
 *
 * @api private
 */

Socket.prototype.ack = function (id) {
  var self = this;
  var sent = false;
  return function () {
    // prevent double callbacks
    if (sent) return;
    sent = true;
    var args = toArray(arguments);
    debug('sending ack %j', args);

    self.packet({
      type: hasBin(args) ? parser.BINARY_ACK : parser.ACK,
      id: id,
      data: args
    });
  };
};

/**
 * Called upon a server acknowlegement.
 *
 * @param {Object} packet
 * @api private
 */

Socket.prototype.onack = function (packet) {
  var ack = this.acks[packet.id];
  if ('function' === typeof ack) {
    debug('calling ack %s with %j', packet.id, packet.data);
    ack.apply(this, packet.data);
    delete this.acks[packet.id];
  } else {
    debug('bad ack %s', packet.id);
  }
};

/**
 * Called upon server connect.
 *
 * @api private
 */

Socket.prototype.onconnect = function () {
  this.connected = true;
  this.disconnected = false;
  this.emit('connect');
  this.emitBuffered();
};

/**
 * Emit buffered events (received and emitted).
 *
 * @api private
 */

Socket.prototype.emitBuffered = function () {
  var i;
  for (i = 0; i < this.receiveBuffer.length; i++) {
    emit.apply(this, this.receiveBuffer[i]);
  }
  this.receiveBuffer = [];

  for (i = 0; i < this.sendBuffer.length; i++) {
    this.packet(this.sendBuffer[i]);
  }
  this.sendBuffer = [];
};

/**
 * Called upon server disconnect.
 *
 * @api private
 */

Socket.prototype.ondisconnect = function () {
  debug('server disconnect (%s)', this.nsp);
  this.destroy();
  this.onclose('io server disconnect');
};

/**
 * Called upon forced client/server side disconnections,
 * this method ensures the manager stops tracking us and
 * that reconnections don't get triggered for this.
 *
 * @api private.
 */

Socket.prototype.destroy = function () {
  if (this.subs) {
    // clean subscriptions to avoid reconnections
    for (var i = 0; i < this.subs.length; i++) {
      this.subs[i].destroy();
    }
    this.subs = null;
  }

  this.io.destroy(this);
};

/**
 * Disconnects the socket manually.
 *
 * @return {Socket} self
 * @api public
 */

Socket.prototype.close =
Socket.prototype.disconnect = function () {
  if (this.connected) {
    debug('performing disconnect (%s)', this.nsp);
    this.packet({ type: parser.DISCONNECT });
  }

  // remove socket from pool
  this.destroy();

  if (this.connected) {
    // fire events
    this.onclose('io client disconnect');
  }
  return this;
};

/**
 * Sets the compress flag.
 *
 * @param {Boolean} if `true`, compresses the sending data
 * @return {Socket} self
 * @api public
 */

Socket.prototype.compress = function (compress) {
  this.flags.compress = compress;
  return this;
};

/**
 * Sets the binary flag
 *
 * @param {Boolean} whether the emitted data contains binary
 * @return {Socket} self
 * @api public
 */

Socket.prototype.binary = function (binary) {
  this.flags.binary = binary;
  return this;
};


/***/ }),

/***/ 4396:
/***/ (function(module, exports) {

module.exports = toArray

function toArray(list, index) {
    var array = []

    index = index || 0

    for (var i = index || 0; i < list.length; i++) {
        array[i - index] = list[i]
    }

    return array
}


/***/ }),

/***/ 4397:
/***/ (function(module, exports) {


/**
 * Module exports.
 */

module.exports = on;

/**
 * Helper for subscriptions.
 *
 * @param {Object|EventEmitter} obj with `Emitter` mixin or `EventEmitter`
 * @param {String} event name
 * @param {Function} callback
 * @api public
 */

function on (obj, ev, fn) {
  obj.on(ev, fn);
  return {
    destroy: function () {
      obj.removeListener(ev, fn);
    }
  };
}


/***/ }),

/***/ 4398:
/***/ (function(module, exports) {

/**
 * Slice reference.
 */

var slice = [].slice;

/**
 * Bind `obj` to `fn`.
 *
 * @param {Object} obj
 * @param {Function|String} fn or string
 * @return {Function}
 * @api public
 */

module.exports = function(obj, fn){
  if ('string' == typeof fn) fn = obj[fn];
  if ('function' != typeof fn) throw new Error('bind() requires a function');
  var args = slice.call(arguments, 2);
  return function(){
    return fn.apply(obj, args.concat(slice.call(arguments)));
  }
};


/***/ }),

/***/ 4399:
/***/ (function(module, exports) {


/**
 * Expose `Backoff`.
 */

module.exports = Backoff;

/**
 * Initialize backoff timer with `opts`.
 *
 * - `min` initial timeout in milliseconds [100]
 * - `max` max timeout [10000]
 * - `jitter` [0]
 * - `factor` [2]
 *
 * @param {Object} opts
 * @api public
 */

function Backoff(opts) {
  opts = opts || {};
  this.ms = opts.min || 100;
  this.max = opts.max || 10000;
  this.factor = opts.factor || 2;
  this.jitter = opts.jitter > 0 && opts.jitter <= 1 ? opts.jitter : 0;
  this.attempts = 0;
}

/**
 * Return the backoff duration.
 *
 * @return {Number}
 * @api public
 */

Backoff.prototype.duration = function(){
  var ms = this.ms * Math.pow(this.factor, this.attempts++);
  if (this.jitter) {
    var rand =  Math.random();
    var deviation = Math.floor(rand * this.jitter * ms);
    ms = (Math.floor(rand * 10) & 1) == 0  ? ms - deviation : ms + deviation;
  }
  return Math.min(ms, this.max) | 0;
};

/**
 * Reset the number of attempts.
 *
 * @api public
 */

Backoff.prototype.reset = function(){
  this.attempts = 0;
};

/**
 * Set the minimum duration
 *
 * @api public
 */

Backoff.prototype.setMin = function(min){
  this.ms = min;
};

/**
 * Set the maximum duration
 *
 * @api public
 */

Backoff.prototype.setMax = function(max){
  this.max = max;
};

/**
 * Set the jitter
 *
 * @api public
 */

Backoff.prototype.setJitter = function(jitter){
  this.jitter = jitter;
};



/***/ }),

/***/ 4400:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var has = Object.prototype.hasOwnProperty
  , prefix = '~';

/**
 * Constructor to create a storage for our `EE` objects.
 * An `Events` instance is a plain object whose properties are event names.
 *
 * @constructor
 * @private
 */
function Events() {}

//
// We try to not inherit from `Object.prototype`. In some engines creating an
// instance in this way is faster than calling `Object.create(null)` directly.
// If `Object.create(null)` is not supported we prefix the event names with a
// character to make sure that the built-in object properties are not
// overridden or used as an attack vector.
//
if (Object.create) {
  Events.prototype = Object.create(null);

  //
  // This hack is needed because the `__proto__` property is still inherited in
  // some old browsers like Android 4, iPhone 5.1, Opera 11 and Safari 5.
  //
  if (!new Events().__proto__) prefix = false;
}

/**
 * Representation of a single event listener.
 *
 * @param {Function} fn The listener function.
 * @param {*} context The context to invoke the listener with.
 * @param {Boolean} [once=false] Specify if the listener is a one-time listener.
 * @constructor
 * @private
 */
function EE(fn, context, once) {
  this.fn = fn;
  this.context = context;
  this.once = once || false;
}

/**
 * Add a listener for a given event.
 *
 * @param {EventEmitter} emitter Reference to the `EventEmitter` instance.
 * @param {(String|Symbol)} event The event name.
 * @param {Function} fn The listener function.
 * @param {*} context The context to invoke the listener with.
 * @param {Boolean} once Specify if the listener is a one-time listener.
 * @returns {EventEmitter}
 * @private
 */
function addListener(emitter, event, fn, context, once) {
  if (typeof fn !== 'function') {
    throw new TypeError('The listener must be a function');
  }

  var listener = new EE(fn, context || emitter, once)
    , evt = prefix ? prefix + event : event;

  if (!emitter._events[evt]) emitter._events[evt] = listener, emitter._eventsCount++;
  else if (!emitter._events[evt].fn) emitter._events[evt].push(listener);
  else emitter._events[evt] = [emitter._events[evt], listener];

  return emitter;
}

/**
 * Clear event by name.
 *
 * @param {EventEmitter} emitter Reference to the `EventEmitter` instance.
 * @param {(String|Symbol)} evt The Event name.
 * @private
 */
function clearEvent(emitter, evt) {
  if (--emitter._eventsCount === 0) emitter._events = new Events();
  else delete emitter._events[evt];
}

/**
 * Minimal `EventEmitter` interface that is molded against the Node.js
 * `EventEmitter` interface.
 *
 * @constructor
 * @public
 */
function EventEmitter() {
  this._events = new Events();
  this._eventsCount = 0;
}

/**
 * Return an array listing the events for which the emitter has registered
 * listeners.
 *
 * @returns {Array}
 * @public
 */
EventEmitter.prototype.eventNames = function eventNames() {
  var names = []
    , events
    , name;

  if (this._eventsCount === 0) return names;

  for (name in (events = this._events)) {
    if (has.call(events, name)) names.push(prefix ? name.slice(1) : name);
  }

  if (Object.getOwnPropertySymbols) {
    return names.concat(Object.getOwnPropertySymbols(events));
  }

  return names;
};

/**
 * Return the listeners registered for a given event.
 *
 * @param {(String|Symbol)} event The event name.
 * @returns {Array} The registered listeners.
 * @public
 */
EventEmitter.prototype.listeners = function listeners(event) {
  var evt = prefix ? prefix + event : event
    , handlers = this._events[evt];

  if (!handlers) return [];
  if (handlers.fn) return [handlers.fn];

  for (var i = 0, l = handlers.length, ee = new Array(l); i < l; i++) {
    ee[i] = handlers[i].fn;
  }

  return ee;
};

/**
 * Return the number of listeners listening to a given event.
 *
 * @param {(String|Symbol)} event The event name.
 * @returns {Number} The number of listeners.
 * @public
 */
EventEmitter.prototype.listenerCount = function listenerCount(event) {
  var evt = prefix ? prefix + event : event
    , listeners = this._events[evt];

  if (!listeners) return 0;
  if (listeners.fn) return 1;
  return listeners.length;
};

/**
 * Calls each of the listeners registered for a given event.
 *
 * @param {(String|Symbol)} event The event name.
 * @returns {Boolean} `true` if the event had listeners, else `false`.
 * @public
 */
EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
  var evt = prefix ? prefix + event : event;

  if (!this._events[evt]) return false;

  var listeners = this._events[evt]
    , len = arguments.length
    , args
    , i;

  if (listeners.fn) {
    if (listeners.once) this.removeListener(event, listeners.fn, undefined, true);

    switch (len) {
      case 1: return listeners.fn.call(listeners.context), true;
      case 2: return listeners.fn.call(listeners.context, a1), true;
      case 3: return listeners.fn.call(listeners.context, a1, a2), true;
      case 4: return listeners.fn.call(listeners.context, a1, a2, a3), true;
      case 5: return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
      case 6: return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
    }

    for (i = 1, args = new Array(len -1); i < len; i++) {
      args[i - 1] = arguments[i];
    }

    listeners.fn.apply(listeners.context, args);
  } else {
    var length = listeners.length
      , j;

    for (i = 0; i < length; i++) {
      if (listeners[i].once) this.removeListener(event, listeners[i].fn, undefined, true);

      switch (len) {
        case 1: listeners[i].fn.call(listeners[i].context); break;
        case 2: listeners[i].fn.call(listeners[i].context, a1); break;
        case 3: listeners[i].fn.call(listeners[i].context, a1, a2); break;
        case 4: listeners[i].fn.call(listeners[i].context, a1, a2, a3); break;
        default:
          if (!args) for (j = 1, args = new Array(len -1); j < len; j++) {
            args[j - 1] = arguments[j];
          }

          listeners[i].fn.apply(listeners[i].context, args);
      }
    }
  }

  return true;
};

/**
 * Add a listener for a given event.
 *
 * @param {(String|Symbol)} event The event name.
 * @param {Function} fn The listener function.
 * @param {*} [context=this] The context to invoke the listener with.
 * @returns {EventEmitter} `this`.
 * @public
 */
EventEmitter.prototype.on = function on(event, fn, context) {
  return addListener(this, event, fn, context, false);
};

/**
 * Add a one-time listener for a given event.
 *
 * @param {(String|Symbol)} event The event name.
 * @param {Function} fn The listener function.
 * @param {*} [context=this] The context to invoke the listener with.
 * @returns {EventEmitter} `this`.
 * @public
 */
EventEmitter.prototype.once = function once(event, fn, context) {
  return addListener(this, event, fn, context, true);
};

/**
 * Remove the listeners of a given event.
 *
 * @param {(String|Symbol)} event The event name.
 * @param {Function} fn Only remove the listeners that match this function.
 * @param {*} context Only remove the listeners that have this context.
 * @param {Boolean} once Only remove one-time listeners.
 * @returns {EventEmitter} `this`.
 * @public
 */
EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
  var evt = prefix ? prefix + event : event;

  if (!this._events[evt]) return this;
  if (!fn) {
    clearEvent(this, evt);
    return this;
  }

  var listeners = this._events[evt];

  if (listeners.fn) {
    if (
      listeners.fn === fn &&
      (!once || listeners.once) &&
      (!context || listeners.context === context)
    ) {
      clearEvent(this, evt);
    }
  } else {
    for (var i = 0, events = [], length = listeners.length; i < length; i++) {
      if (
        listeners[i].fn !== fn ||
        (once && !listeners[i].once) ||
        (context && listeners[i].context !== context)
      ) {
        events.push(listeners[i]);
      }
    }

    //
    // Reset the array, or remove it completely if we have no more listeners.
    //
    if (events.length) this._events[evt] = events.length === 1 ? events[0] : events;
    else clearEvent(this, evt);
  }

  return this;
};

/**
 * Remove all listeners, or those of the specified event.
 *
 * @param {(String|Symbol)} [event] The event name.
 * @returns {EventEmitter} `this`.
 * @public
 */
EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
  var evt;

  if (event) {
    evt = prefix ? prefix + event : event;
    if (this._events[evt]) clearEvent(this, evt);
  } else {
    this._events = new Events();
    this._eventsCount = 0;
  }

  return this;
};

//
// Alias methods names because people roll like that.
//
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.addListener = EventEmitter.prototype.on;

//
// Expose the prefix.
//
EventEmitter.prefixed = prefix;

//
// Allow `EventEmitter` to be imported as module namespace.
//
EventEmitter.EventEmitter = EventEmitter;

//
// Expose the module.
//
if (true) {
  module.exports = EventEmitter;
}


/***/ }),

/***/ 4401:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {const path = __webpack_require__(64),
stripTrailingSep = thePath => {
    if (thePath[thePath.length - 1] === path.sep) {
        return thePath.slice(0, -1);
    }
    return thePath;
};

module.exports = function (thePath, potentialParent) {
    // For inside-directory checking, we want to allow trailing slashes, so normalize.
    thePath = stripTrailingSep(thePath);
    potentialParent = stripTrailingSep(potentialParent);

    // Node treats only Windows as case-insensitive in its path module; we follow those conventions.
    if (global.process.platform === 'win32') {
        thePath = thePath.toLowerCase();
        potentialParent = potentialParent.toLowerCase();
    }

    return thePath.lastIndexOf(potentialParent, 0) === 0 && (

    thePath[potentialParent.length] === path.sep ||
    thePath[potentialParent.length] === undefined);

};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(19)))

/***/ }),

/***/ 4402:
/***/ (function(module, exports, __webpack_require__) {

// ###### WARNING: DO NOT REQUIRE NON-ISOMORPHIC LIBRARIES HERE
let _ = __webpack_require__(61),
async = __webpack_require__(664),

EventProcessor = __webpack_require__(4403),

// ###### WARNING: DO NOT REQUIRE NON-ISOMORPHIC LIBRARIES HERE

// Character detection to node encoding map
CHARDET_BUFF_MAP = {
  ASCII: 'ascii',
  'UTF-8': 'utf8',
  'UTF-16LE': 'utf16le',
  'ISO-8859-1': 'latin1' },


detectEncoding = buff => CHARDET_BUFF_MAP[chardet.detect(buff)],

isBrowser = false,


// TODO: Implement these using a dependency injection model like awilix
fs,
os,
app,
path,
dialog,
chardet,
session,
PostmanFs,
CookieJar,
dryRunRequest,
CookieManager,
getSystemProxy,
SerializedError,
collectionRunner,
sanitizeFilename,
postmanCollectionSdk,

defaultWorkingDir,

activeRuns = {};

/**
                  * Helper function to get the file extension given a mime-type
                  * @param {String} mimeType
                  */
function __getProbableExtension(mimeType) {
  var mimeExtensions = [
  {
    typeSubstring: 'text',
    extension: '.txt' },

  {
    typeSubstring: 'json',
    extension: '.json' },

  {
    typeSubstring: 'javascript',
    extension: '.js' },

  {
    typeSubstring: 'pdf',
    extension: '.pdf' },

  {
    typeSubstring: 'png',
    extension: '.png' },

  {
    typeSubstring: 'jpg',
    extension: '.jpg' },

  {
    typeSubstring: 'jpeg',
    extension: '.jpg' },

  {
    typeSubstring: 'gif',
    extension: '.gif' },

  {
    typeSubstring: 'excel',
    extension: '.xls' },

  {
    typeSubstring: 'zip',
    extension: '.zip' },

  {
    typeSubstring: 'compressed',
    extension: '.zip' },

  {
    typeSubstring: 'audio/wav',
    extension: '.wav' },

  {
    typeSubstring: 'tiff',
    extension: '.tiff' },

  {
    typeSubstring: 'shockwave',
    extension: '.swf' },

  {
    typeSubstring: 'powerpoint',
    extension: '.ppt' },

  {
    typeSubstring: 'mpeg',
    extension: '.mpg' },

  {
    typeSubstring: 'quicktime',
    extension: '.mov' },

  {
    typeSubstring: 'html',
    extension: '.html' },

  {
    typeSubstring: 'css',
    extension: '.css' }];



  for (var i = 0; i < mimeExtensions.length; i++) {
    if (mimeType.indexOf(mimeExtensions[i].typeSubstring) > -1) {
      return mimeExtensions[i].extension;
    }
  }

  return '';
}


// #region API Functions

/**
 * @private
 */
function trackRun(executionId, run, processor) {
  // Set the processor as the runs processor
  run.processor = processor;

  activeRuns[executionId] = run;
}

/**
   * @private
   */
function addAborter(executionId, aborter) {
  activeRuns[executionId] && (activeRuns[executionId].aborter = aborter);
}

/**
   * @private
   */
function removeAborter(executionId) {
  activeRuns[executionId] && delete activeRuns[executionId].aborter;
}

/**
   * @private
   * Sanitizes options to be sent to runtime. Mostly converting objects into SDK instances.
   *
   * @param {Object} rawOptions
   */
function sanitizeRunOptions(rawOptions) {
  if (!rawOptions) {
    return;
  }

  if (rawOptions.useSystemProxy && !!getSystemProxy) {
    rawOptions.systemProxy = getSystemProxy;
  }

  if (rawOptions.proxies) {
    rawOptions.proxies = new postmanCollectionSdk.ProxyConfigList({}, rawOptions.proxies);
  }

  rawOptions.certificates = new postmanCollectionSdk.CertificateList({}, rawOptions.certificates);
}

/**
   * @private
   * Save the given stream to a file the user chooses
   *
   * @param {Object} contentInfo
   * @param {Buffer} stream
   */
function saveStreamToFile(contentInfo, stream, cb) {
  let name;

  // sdkResponse override
  if (contentInfo && contentInfo.fileName) {
    name = contentInfo.fileName || '';
  }

  if (_.isEmpty(name)) {
    name = 'response';
    name = contentInfo && contentInfo.mimeType ? `${name}${__getProbableExtension(contentInfo.mimeType)}` : name;
  }

  // TODO: Implement browser specific logic here
  if (isBrowser) {
    return;
  }

  // WARNING: All usages below require native dependencies hence be careful in browser environment

  name = sanitizeFilename(name, { replacement: '-' });

  dialog.showSaveDialog({
    title: 'Select path to save file',
    defaultPath: name // Default filename to be used
  }).then(result => {
    if (result.canceled) {
      // If the request was cancelled then don't do anything, not even call the callback;
      return cb(null, false);
    }

    fs.writeFile(result.filePath, stream, err => {
      return cb(err, true);
    });
  }).
  catch(cb);
}

/**
   * Abort and cleanup an existing collection run
   *
   * @param {String} executionId - The execution id to terminate or dispose
   * @param {Function} emit - emitter to call to denote the execution has terminated/disposed
   */
function disposeRun(executionId, emit = _.noop) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  const run = activeRuns[executionId];

  run.host && run.host.dispose && run.host.dispose();

  // dispose the reference
  activeRuns[executionId] = null;

  emit({ id: executionId, event: '__dispose__' });
}

/**
   * @public
   * Stops and disposes an existing collection run
   *
   * @param {String} executionId - The execution id to terminate or dispose
   * @param {Function} emit - emitter to call to denote the execution has terminated/disposed
   */
function stopRun(executionId, emit) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  const run = activeRuns[executionId];

  run.aborter && run.aborter.abort();
  run.abort();

  // Force call the stop event as postman-runtime will no longer call any event
  run.processor.call('abort', [null]);

  disposeRun(executionId, emit);
}

/**
   * @public
   * Pause the current collection run
   *
   * @param {String} executionId
   */
function pauseRun(executionId) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  activeRuns[executionId].pause();
}

/**
   * @public
   * Resume the paused current collection run
   *
   * @param {String} executionId
   */
function resumeRun(executionId) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  activeRuns[executionId].resume();
}

/**
   * @public
   * Start a collection run with the given collection and variables
   *
   * @param {Object} info
   * @param {Object} collection
   * @param {Object} variables
   * @param {Object} options
   */
function startRun(info, collection, variables, options = {}, emit) {
  const sdkCollection = new postmanCollectionSdk.Collection(collection),
  cookiePartitionId = options && options.cookiePartitionId,

  // Create an event processor instance and handling runtime events
  eventProccessor = new EventProcessor(info.schema, (event, data, refs) => {
    emit({ id: info.id, event, data, refs });
  });

  let cookieJar;

  // We have the CookieJar
  if (CookieJar) {
    cookieJar = new CookieJar(cookiePartitionId, {
      programmaticAccess: options.cookieConfiguration,
      readFromDB: !_.get(info, 'cookie.runtimeWithEmptyJar', false),
      writeToDB: !_.get(info, 'cookie.disableRealtimeWrite', false),
      onCookieAccessDenied: domain => {
        let message = `Unable to access "${domain}" cookie store.` +
        ' Try whitelisting the domain in "Manage Cookies" screen.' +
        ' View more detailed instructions in the Learning Center: https://go.pstmn.io/docs-cookies';

        emit({
          name: 'log',
          namespace: 'console',
          data: {
            id: info.id,
            cursor: {},
            level: 'warn',
            messages: [message] } });


      } });


    _.set(options, ['requester', 'cookieJar'], cookieJar);
  }

  // fileResolver defined and we have PostmanFs
  if (options.fileResolver && !!PostmanFs) {
    let { workingDir, insecureFileRead, fileWhitelist } = options.fileResolver;

    _.set(options, 'fileResolver', new PostmanFs(workingDir || defaultWorkingDir, insecureFileRead, fileWhitelist));
  }

  // sanitize
  sanitizeRunOptions(options);

  // add variables
  variables.environment && (options.environment = new postmanCollectionSdk.VariableScope(variables.environment));
  variables.globals && (options.globals = new postmanCollectionSdk.VariableScope(variables.globals));

  collectionRunner.run(sdkCollection, options, function (err, run) {
    if (err) {
      pm.logger.error('RuntimeExecutionService~startRun - Error in starting the run', err);

      this.emit({ id: info.id, event: '__dispose__', error: true });
      return;
    }

    trackRun(info.id, run, eventProccessor);

    // Intercept beforeRequest and response and done events
    eventProccessor.intercept('beforeRequest', (_, __, ___, ____, aborter) => {
      addAborter(info.id, aborter);
    });

    eventProccessor.intercept('response', (err, _, response) => {
      removeAborter(info.id);

      // If the response is present, and download is set then
      if (!err && response && info.download) {
        saveStreamToFile(response.contentInfo(), response.stream, (err, success) => {
          // If there is an error success then emit the download event
          (err || success) && eventProccessor.call('download', [err]);
        });
      }
    });

    eventProccessor.intercept('done', () => {
      if (info.cookie && info.cookie.saveAfterRun && cookieJar && typeof cookieJar.updateStore === 'function') {
        // TODO - DECIDE on what to do with cookies when there was an error in done
        cookieJar.updateStore(() => {
          disposeRun(info.id, emit);
        });

        return;
      }
      disposeRun(info.id, emit);
    });

    // Note: .handlers should be called after all interceptors have been attached
    // else events not part of schema will be ignored
    run.start(eventProccessor.handlers());
  });
}

/**
   * @public
   * LivePreview: Calling runtime's `dryRunRequest` to get previewed request
   *
   * @param {Request} request
   * @param {Object} info
   * @param {Object} options
   * @param {Function} cb
   */
function previewRequest(request, options = {}, cb) {
  let requestToPreview = new postmanCollectionSdk.Request(request),
  dryRunOptions = _.pick(options, ['implicitCacheControl', 'implicitTraceHeader', 'protocolProfileBehavior']);

  options.cookiePartitionId && CookieJar && (
  dryRunOptions.cookieJar = new CookieJar(options.cookiePartitionId, { readFromDB: true, writeToDB: false }));

  try {
    dryRunRequest(requestToPreview, dryRunOptions, (err, previewedRequest) => {
      cb(err, previewedRequest && previewedRequest.toJSON());
    });
  }
  catch (e) {
    pm.logger.error('RuntimeExecutionService~previewRequest.dryRunRequest', e);
  }
}

/**
   * Checks if the given path is within the working directory
   */
function isInWorkingDir(workingDir, path) {
  return Boolean(new PostmanFs(workingDir)._resolve(path, []));
}

/**
   * Create Temporary File
   * @param name
   * @param content
   */
function createTemporaryFile(name, content, cb) {
  const basePath = app.getPath('temp'),
  tempFilePath = path.join(basePath, name);

  async.waterfall([
  // Attempt to clear the file if it already exists.
  // Note: We ignore the error here
  next => fs.unlink(tempFilePath, () => next()),

  // Write the contents of the temp directory
  next => fs.writeFile(tempFilePath, content, next)],
  err => {
    cb(err && new SerializedError(err), tempFilePath);
  });
}

/**
   * Read file from filesystem
   * @param {String} id
   * @param {String} path
   */
function readFile(path, cb) {
  fs.readFile(path, (err, content) => {
    if (!err) {
      try {
        // From here on we will try detect the encoding and convert the buffer accordingly
        content = content.toString(detectEncoding(content));
      } catch (e) {
        err = new Error('Failed to detect encoding of the file content');
      }
    }

    return cb(err && new SerializedError(err), content);
  });
}

/**
   * Check if the given path has the required file-system access
   * @param {String} id
   * @param {String} path
   * @param {Boolean} writable
   */
function accessFile(path, writeable, cb) {
  // If no path is given then there is nothing to check
  if (!path) {
    return cb();
  }

  const perm = writeable ? fs.constants.R_OK | fs.constants.W_OK : fs.constants.R_OK;

  fs.access(path, perm, err => {
    cb(err && new SerializedError(err));
  });
}

/**
   * Handle CookieManager queries
   *
   * @param {String} method
   * @param {String} partitionId
   * @param {Object} options
   * @param {Function} cb
   */
function cookieHandler(method, partitionId, options, cb) {
  if (!(typeof CookieManager.prototype[method] === 'function' && partitionId && options)) {
    return cb(new TypeError('Illegal invocation'));
  }

  CookieManager.prototype[method].call({
    cookieStore: CookieManager.getCookieStore(partitionId) },
  options, cb);
}

/**
   * Listen to `changed` event on cookies of a partition
   *
   * @param {String} partitionId
   * @param {Function} cb
   */
function attachCookiesChangeListener(partitionId, cb) {
  const partition = session.fromPartition(partitionId);

  partition && partition.cookies.on('changed', cb);
}

// #endregion

// We have two places that this is going to be used main process in electron and the we agent, hence we expose two API's here
module.exports = function () {
  // IMPORTANT: Do not remove this comment. Used by webpack to ignore this section
};


module.exports.Browser = async function () {
  const postmanRuntime = await __webpack_require__.e(/* import() | postman-runtime */ 13).then(__webpack_require__.t.bind(null, 5484, 7));

  chardet = __webpack_require__(4406);
  postmanCollectionSdk = __webpack_require__(790);
  SerializedError = __webpack_require__(4404);

  collectionRunner = new postmanRuntime.Runner();
  dryRunRequest = postmanRuntime.Requester && postmanRuntime.Requester.dryRun;

  isBrowser = true;


  return {
    startRun,
    stopRun,
    pauseRun,
    resumeRun,

    previewRequest,
    saveStreamToFile };

};

/***/ }),

/***/ 4403:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Buffer) {const async = __webpack_require__(664),
SerializedError = __webpack_require__(4404),
sid = __webpack_require__(4346),

noOp = () => {},
get = (obj, path, defaultValue = undefined) => {
  const travel = regexp =>
  String.prototype.split.
  call(path, regexp).
  filter(Boolean).
  reduce((res, key) => res !== null && res !== undefined ? res[key] : res, obj);
  const result = travel(/[,[\]]+?/) || travel(/[,[\].]+?/);
  return result === undefined || result === obj ? defaultValue : result;
},

DEFAULT_CHUNK_SIZE = 10 * 1024 * 1024;let

Node = class Node {
  constructor(schema, manager) {
    // Replacement key for the property
    this.key = schema.key;

    // The source data structure
    this.from = schema.from || false;

    // The target data structure
    this.to = schema.to || false;

    // Create the selectation object chain
    if (schema.select) {
      // Create the selecters
      this.select = Object.
      keys(schema.select).
      map(k => {
        // If the value is false or null then we need to skip this selection
        if (schema.select[k] === false || schema.select[k] === null) {
          return false;
        }

        let N = {};

        // If the selection is a type of object then create new node
        if (typeof schema.select[k] === 'object') {
          N = new Node(schema.select[k], manager);
        }

        N._key = k;

        return N;
      }).
      filter(Boolean);
    } else {
      this.select = false;
    }

    // Create the mutations
    this.replace = schema.replace || false;

    // Create stream
    this.stream = schema.stream || false;

    // Set the streamEmitter
    this.manager = manager;

    // Array to save the ref id
    this._ref = [];
  }

  refs() {
    if (!this.select) {
      return this._ref;
    }

    return this.select.reduce((A, N) => {
      if (!(N instanceof Node)) {
        return A;
      }

      return A.concat(...N.refs());

    }, this._ref);
  }

  saveRef(id, data, options) {
    this._ref.push(id);
    this.manager.saveRef(id, { data, options });
  }

  $replace(input) {
    if (this.replace === false) {
      return input;
    }

    if (this.replace.call && typeof input === 'function') {
      return input();
    } else if (this.replace.fn && typeof input[this.replace.fn] === 'function') {
      return input[this.replace.fn]();
    } else if (this.replace.set) {
      return get(input, this.replace.set);
    } else if (Array.isArray(input) && this.replace.slice) {
      input[this.replace.slice.to] = input.slice.apply(input, this.replace.slice.from);

      return input;
    } else if (Array.isArray(this.replace.error)) {
      this.replace.error.forEach(e => {
        input[e] = input[e] && new SerializedError(input[e]);
      });

      return input;
    } else if (this.replace.stream && typeof Buffer !== 'undefined') {// If Buffer is undefined we can't stream
      // Streaming will work only if the input is a string or buffer
      if (!(typeof input === 'string' || Buffer.isBuffer(input))) {
        return input;
      }

      const chunk = this.replace.chunk || DEFAULT_CHUNK_SIZE;

      // If length if the input is smaller than the chunk size then just directly send it back
      // Streaming is not required;
      if (input.length <= chunk) {
        return input;
      }

      const id = sid.generate();

      this.saveRef(id, input, { chunk });

      return { $ref: id };
    } else if (this.replace.limit) {
      // Check on the existance of the .length property
      if (!input.length || input.length <= this.replace.limit) {
        return input;
      }

      if (this.replace.drop) {
        return { ___dropped___: true };
      } else if (typeof Buffer !== 'undefined' && Buffer.isBuffer(input)) {
        return { ___truncated___: true, data: input.subarray(0, this.replace.limit) };
      } else if (typeof input === 'string') {
        return { ___truncated___: true, data: input.substring(0, this.replace.limit) };
      }

      return { ___truncated___: true };
    } else
    {
      return input || this.replace.default;
    }
  }

  $select(input) {
    if (this.select === false) {
      return input;
    }

    return this.select.reduce((A, T) => {
      let parsed = input[T._key];

      // if the parsed value is a function then bind the parent input
      if (typeof parsed === 'function') {
        parsed = parsed.bind(input);
      }

      // If T is not an instance of a node then its a leaf
      if (parsed !== undefined && parsed !== null && T instanceof Node) {
        parsed = T.parse(parsed);
      }

      if (T.error !== false && (
      T.key === 'error' ||
      T.key === 'err' ||
      T._key === 'error' ||
      T._key === 'err') && Boolean(parsed)) {
        parsed = new SerializedError(parsed);
      }

      A[T.key || T._key] = parsed;

      return A;
    }, Array.isArray(input) && this.to !== 'object' ? [] : {});
  }

  /**
     * The argument to parse with node
     * @param {Array|Object} arg
     */
  parse(arg) {
    return [
    this.$replace.bind(this),
    this.$select.bind(this)].
    reduce((acc, fn) => fn(acc), arg);
  }};let


EventProcessor = class EventProcessor {
  constructor(schema = {}, emitter = noOp) {
    // Save the emitter to output the final data
    this.emitter = emitter;

    // This is streamer interface which can be used to send chunked data
    this.emitQueue = async.queue(({ event, data, refs }, done) => {
      // Send the chunk of data with the given id to the process otherside
      emitter(event, data, refs);

      // Defer the next transmit to the next event loop cycle
      setTimeout(done, 0);
    });

    // Now lets crate the processor map
    this.events = new Map([]);

    // Iterate over all the events process then
    Object.keys(schema).forEach(event => {
      // Set the root node to the events
      this.events.set(event, new Set([new Node(schema[event], this)]));
    });

    this.streams = new Map([]);
  }

  saveRef(id, data) {
    // We can later chose to save the refs to a file and stream from there
    this.streams.set(id, data);
  }

  intercept(event, fn) {
    if (this.events.has(event)) {
      this.events.get(event).add(fn);
    } else {
      this.events.set(event, new Set([fn]));
    }
  }

  streamPending(refs) {
    refs.forEach(ref => {
      const { data, options } = this.streams.get(ref),
      chunk = options.chunk || 1 * 1024 * 1024; // Default to 1MB chunks

      // We start from the start index until the chunks runout
      for (var i = 0, ii = 0; i < data.length; i += chunk, ii++) {
        const subarray = data.subarray(i, Math.min(i + chunk, data.length));

        this.emitQueue.push({
          event: '__ref__',
          data: {
            id: ref,
            meta: { index: ii, offset: i, length: subarray.length },
            data: subarray } });


      }

      this.emitQueue.push({
        event: '__ref__',
        data: {
          id: ref,
          meta: { end: true } } });



      // Finally clear refs to get garbage collected
      this.streams.delete(ref);
    });
  }

  call(event, args) {
    // Check if the events still exists in the map, else return
    if (!this.events.has(event)) {return;}

    // Iterate through each of the handlers for this event and fire them one after another
    this.events.
    get(event).
    forEach(handler => {
      if (handler instanceof Node) {
        // Call the parser funciton with the incoming arguments
        // Note: .refs must always be called after .parse. Refs are not generated
        // Until data is parsed;
        const data = handler.parse(args),
        refs = handler.refs();

        // 1. Emit the event first (Order is important)
        this.emitQueue.push({ event, data, refs });

        // 2. Start streaming the pending refs
        this.streamPending(refs);
      } else if (typeof handler === 'function') {
        setTimeout(() => {handler(...args);}, 0);
      }
    });
  }

  handlers() {
    return [...this.events.keys()].reduce((acc, name) => {
      acc[name] = (...args) => {this.call(name, args);};

      return acc;
    }, {});
  }};


module.exports = EventProcessor;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4404:
/***/ (function(module, exports, __webpack_require__) {

var stacktrace = __webpack_require__(4405),
    hash = __webpack_require__(2575),
    uuid = __webpack_require__(650),
    SerialisedError;

SerialisedError = function (err, decorate) {
    var now = new Date(); // to hold date here before any more time is lost

    // If the function is called without the `new` operator, then we do it on behalf of the callee
	if (!(this instanceof SerialisedError)) {
		return new SerialisedError(err, decorate);
	}

    // Iterate on user-defined properties of error and mix in the default non ennumerable properties
	(typeof err === 'object') && (err !== null) &&
        Object.keys(err).concat(['name', 'message', 'stack']).forEach(function (key) {
    		this[key] = err[key];
    	}, this);

    // add additional meta information
    if (decorate) {
        this.checksum = hash.MD5(this);
        this.id = uuid.v4();
        this.timestamp = now.getTime();
        this.stacktrace = stacktrace.parse(this);
    }
};

module.exports = SerialisedError;


/***/ }),

/***/ 4405:
/***/ (function(module, exports) {

exports.get = function(belowFn) {
  var oldLimit = Error.stackTraceLimit;
  Error.stackTraceLimit = Infinity;

  var dummyObject = {};

  var v8Handler = Error.prepareStackTrace;
  Error.prepareStackTrace = function(dummyObject, v8StackTrace) {
    return v8StackTrace;
  };
  Error.captureStackTrace(dummyObject, belowFn || exports.get);

  var v8StackTrace = dummyObject.stack;
  Error.prepareStackTrace = v8Handler;
  Error.stackTraceLimit = oldLimit;

  return v8StackTrace;
};

exports.parse = function(err) {
  if (!err.stack) {
    return [];
  }

  var self = this;
  var lines = err.stack.split('\n').slice(1);

  return lines
    .map(function(line) {
      if (line.match(/^\s*[-]{4,}$/)) {
        return self._createParsedCallSite({
          fileName: line,
          lineNumber: null,
          functionName: null,
          typeName: null,
          methodName: null,
          columnNumber: null,
          'native': null,
        });
      }

      var lineMatch = line.match(/at (?:(.+)\s+)?\(?(?:(.+?):(\d+):(\d+)|([^)]+))\)?/);
      if (!lineMatch) {
        return;
      }

      var object = null;
      var method = null;
      var functionName = null;
      var typeName = null;
      var methodName = null;
      var isNative = (lineMatch[5] === 'native');

      if (lineMatch[1]) {
        var methodMatch = lineMatch[1].match(/([^\.]+)(?:\.(.+))?/);
        object = methodMatch[1];
        method = methodMatch[2];
        functionName = lineMatch[1];
        typeName = 'Object';
      }

      if (method) {
        typeName = object;
        methodName = method;
      }

      if (method === '<anonymous>') {
        methodName = null;
        functionName = '';
      }

      var properties = {
        fileName: lineMatch[2] || null,
        lineNumber: parseInt(lineMatch[3], 10) || null,
        functionName: functionName,
        typeName: typeName,
        methodName: methodName,
        columnNumber: parseInt(lineMatch[4], 10) || null,
        'native': isNative,
      };

      return self._createParsedCallSite(properties);
    })
    .filter(function(callSite) {
      return !!callSite;
    });
};

exports._createParsedCallSite = function(properties) {
  var methods = {};
  for (var property in properties) {
    var prefix = 'get';
    if (property === 'native') {
      prefix = 'is';
    }
    var method = prefix + property.substr(0, 1).toUpperCase() + property.substr(1);

    (function(property) {
      methods[method] = function() {
        return properties[property];
      }
    })(property);
  }

  var callSite = Object.create(methods);
  for (var property in properties) {
    callSite[property] = properties[property];
  }

  return callSite;
};


/***/ }),

/***/ 4406:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(Buffer) {
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const utf8_1 = __importDefault(__webpack_require__(4407));
const unicode = __importStar(__webpack_require__(4409));
const mbcs = __importStar(__webpack_require__(4410));
const sbcs = __importStar(__webpack_require__(4411));
const iso2022 = __importStar(__webpack_require__(4412));
let fsModule;
const loadFs = () => {
    if ( true && typeof module.exports === 'object') {
        fsModule = fsModule ? fsModule : __webpack_require__(144);
        return fsModule;
    }
    throw new Error('File system is not available');
};
const recognisers = [
    new utf8_1.default(),
    new unicode.UTF_16BE(),
    new unicode.UTF_16LE(),
    new unicode.UTF_32BE(),
    new unicode.UTF_32LE(),
    new mbcs.sjis(),
    new mbcs.big5(),
    new mbcs.euc_jp(),
    new mbcs.euc_kr(),
    new mbcs.gb_18030(),
    new iso2022.ISO_2022_JP(),
    new iso2022.ISO_2022_KR(),
    new iso2022.ISO_2022_CN(),
    new sbcs.ISO_8859_1(),
    new sbcs.ISO_8859_2(),
    new sbcs.ISO_8859_5(),
    new sbcs.ISO_8859_6(),
    new sbcs.ISO_8859_7(),
    new sbcs.ISO_8859_8(),
    new sbcs.ISO_8859_9(),
    new sbcs.windows_1251(),
    new sbcs.windows_1256(),
    new sbcs.KOI8_R(),
];
exports.detect = (buffer) => {
    const matches = exports.analyse(buffer);
    return matches.length > 0 ? matches[0].name : null;
};
exports.analyse = (buffer) => {
    const fByteStats = [];
    for (let i = 0; i < 256; i++)
        fByteStats[i] = 0;
    for (let i = buffer.length - 1; i >= 0; i--)
        fByteStats[buffer[i] & 0x00ff]++;
    let fC1Bytes = false;
    for (let i = 0x80; i <= 0x9f; i += 1) {
        if (fByteStats[i] !== 0) {
            fC1Bytes = true;
            break;
        }
    }
    const context = {
        fByteStats,
        fC1Bytes,
        fRawInput: buffer,
        fRawLength: buffer.length,
        fInputBytes: buffer,
        fInputLen: buffer.length,
    };
    const matches = recognisers
        .map((rec) => {
        return rec.match(context);
    })
        .filter((match) => {
        return !!match;
    })
        .sort((a, b) => {
        return b.confidence - a.confidence;
    });
    return matches;
};
exports.detectFile = (filepath, opts = {}) => new Promise((resolve, reject) => {
    let fd;
    const fs = loadFs();
    const handler = (err, buffer) => {
        if (fd) {
            fs.closeSync(fd);
        }
        if (err) {
            reject(err);
        }
        else {
            resolve(exports.detect(buffer));
        }
    };
    if (opts && opts.sampleSize) {
        fd = fs.openSync(filepath, 'r');
        const sample = Buffer.allocUnsafe(opts.sampleSize);
        fs.read(fd, sample, 0, opts.sampleSize, null, (err) => {
            handler(err, sample);
        });
        return;
    }
    fs.readFile(filepath, handler);
});
exports.detectFileSync = (filepath, opts = {}) => {
    const fs = loadFs();
    if (opts && opts.sampleSize) {
        const fd = fs.openSync(filepath, 'r');
        const sample = Buffer.allocUnsafe(opts.sampleSize);
        fs.readSync(fd, sample, 0, opts.sampleSize);
        fs.closeSync(fd);
        return exports.detect(sample);
    }
    return exports.detect(fs.readFileSync(filepath));
};
exports.default = {
    analyse: exports.analyse,
    detect: exports.detect,
    detectFileSync: exports.detectFileSync,
    detectFile: exports.detectFile,
};
//# sourceMappingURL=index.js.map
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(104).Buffer))

/***/ }),

/***/ 4407:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var match = __webpack_require__(4408).default;
class Utf8 {
    name() {
        return 'UTF-8';
    }
    match(det) {
        var hasBOM = false, numValid = 0, numInvalid = 0, input = det.fRawInput, trailBytes = 0, confidence;
        if (det.fRawLength >= 3 &&
            (input[0] & 0xff) == 0xef &&
            (input[1] & 0xff) == 0xbb &&
            (input[2] & 0xff) == 0xbf) {
            hasBOM = true;
        }
        for (var i = 0; i < det.fRawLength; i++) {
            var b = input[i];
            if ((b & 0x80) == 0)
                continue;
            if ((b & 0x0e0) == 0x0c0) {
                trailBytes = 1;
            }
            else if ((b & 0x0f0) == 0x0e0) {
                trailBytes = 2;
            }
            else if ((b & 0x0f8) == 0xf0) {
                trailBytes = 3;
            }
            else {
                numInvalid++;
                if (numInvalid > 5)
                    break;
                trailBytes = 0;
            }
            for (;;) {
                i++;
                if (i >= det.fRawLength)
                    break;
                if ((input[i] & 0xc0) != 0x080) {
                    numInvalid++;
                    break;
                }
                if (--trailBytes == 0) {
                    numValid++;
                    break;
                }
            }
        }
        confidence = 0;
        if (hasBOM && numInvalid == 0)
            confidence = 100;
        else if (hasBOM && numValid > numInvalid * 10)
            confidence = 80;
        else if (numValid > 3 && numInvalid == 0)
            confidence = 100;
        else if (numValid > 0 && numInvalid == 0)
            confidence = 80;
        else if (numValid == 0 && numInvalid == 0)
            confidence = 10;
        else if (numValid > numInvalid * 10)
            confidence = 25;
        else
            return null;
        return match(det, this, confidence);
    }
}
exports.default = Utf8;
//# sourceMappingURL=utf8.js.map

/***/ }),

/***/ 4408:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (det, rec, confidence, name, lang) => ({
    confidence,
    name: name || rec.name(det),
    lang,
});
//# sourceMappingURL=match.js.map

/***/ }),

/***/ 4409:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const match = __webpack_require__(4408).default;
class UTF_16BE {
    name() {
        return 'UTF-16BE';
    }
    match(det) {
        var input = det.fRawInput;
        if (input.length >= 2 &&
            (input[0] & 0xff) == 0xfe &&
            (input[1] & 0xff) == 0xff) {
            return match(det, this, 100);
        }
        return null;
    }
}
exports.UTF_16BE = UTF_16BE;
class UTF_16LE {
    name() {
        return 'UTF-16LE';
    }
    match(det) {
        var input = det.fRawInput;
        if (input.length >= 2 &&
            (input[0] & 0xff) == 0xff &&
            (input[1] & 0xff) == 0xfe) {
            if (input.length >= 4 && input[2] == 0x00 && input[3] == 0x00) {
                return null;
            }
            return match(det, this, 100);
        }
        return null;
    }
}
exports.UTF_16LE = UTF_16LE;
class UTF_32 {
    name() {
        return 'UTF-32';
    }
    getChar(input, index) {
        return -1;
    }
    match(det) {
        var input = det.fRawInput, limit = (det.fRawLength / 4) * 4, numValid = 0, numInvalid = 0, hasBOM = false, confidence = 0;
        if (limit == 0) {
            return null;
        }
        if (this.getChar(input, 0) == 0x0000feff) {
            hasBOM = true;
        }
        for (var i = 0; i < limit; i += 4) {
            var ch = this.getChar(input, i);
            if (ch < 0 || ch >= 0x10ffff || (ch >= 0xd800 && ch <= 0xdfff)) {
                numInvalid += 1;
            }
            else {
                numValid += 1;
            }
        }
        if (hasBOM && numInvalid == 0) {
            confidence = 100;
        }
        else if (hasBOM && numValid > numInvalid * 10) {
            confidence = 80;
        }
        else if (numValid > 3 && numInvalid == 0) {
            confidence = 100;
        }
        else if (numValid > 0 && numInvalid == 0) {
            confidence = 80;
        }
        else if (numValid > numInvalid * 10) {
            confidence = 25;
        }
        return confidence == 0 ? null : match(det, this, confidence);
    }
}
class UTF_32BE extends UTF_32 {
    name() {
        return 'UTF-32BE';
    }
    getChar(input, index) {
        return (((input[index + 0] & 0xff) << 24) |
            ((input[index + 1] & 0xff) << 16) |
            ((input[index + 2] & 0xff) << 8) |
            (input[index + 3] & 0xff));
    }
}
exports.UTF_32BE = UTF_32BE;
class UTF_32LE extends UTF_32 {
    name() {
        return 'UTF-32LE';
    }
    getChar(input, index) {
        return (((input[index + 3] & 0xff) << 24) |
            ((input[index + 2] & 0xff) << 16) |
            ((input[index + 1] & 0xff) << 8) |
            (input[index + 0] & 0xff));
    }
}
exports.UTF_32LE = UTF_32LE;
//# sourceMappingURL=unicode.js.map

/***/ }),

/***/ 4410:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var match = __webpack_require__(4408).default;
function binarySearch(arr, searchValue) {
    const find = (arr, searchValue, left, right) => {
        if (right < left)
            return -1;
        var mid = Math.floor((left + right) >>> 1);
        if (searchValue > arr[mid])
            return find(arr, searchValue, mid + 1, right);
        if (searchValue < arr[mid])
            return find(arr, searchValue, left, mid - 1);
        return mid;
    };
    return find(arr, searchValue, 0, arr.length - 1);
}
class IteratedChar {
    constructor() {
        this.charValue = 0;
        this.index = 0;
        this.nextIndex = 0;
        this.error = false;
        this.done = false;
    }
    reset() {
        this.charValue = 0;
        this.index = -1;
        this.nextIndex = 0;
        this.error = false;
        this.done = false;
    }
    nextByte(det) {
        if (this.nextIndex >= det.fRawLength) {
            this.done = true;
            return -1;
        }
        var byteValue = det.fRawInput[this.nextIndex++] & 0x00ff;
        return byteValue;
    }
}
class mbcs {
    constructor() {
        this.commonChars = [];
    }
    name() {
        return 'mbcs';
    }
    match(det) {
        var singleByteCharCount = 0, doubleByteCharCount = 0, commonCharCount = 0, badCharCount = 0, totalCharCount = 0, confidence = 0;
        var iter = new IteratedChar();
        detectBlock: {
            for (iter.reset(); this.nextChar(iter, det);) {
                totalCharCount++;
                if (iter.error) {
                    badCharCount++;
                }
                else {
                    var cv = iter.charValue & 0xffffffff;
                    if (cv <= 0xff) {
                        singleByteCharCount++;
                    }
                    else {
                        doubleByteCharCount++;
                        if (this.commonChars != null) {
                            if (binarySearch(this.commonChars, cv) >= 0) {
                                commonCharCount++;
                            }
                        }
                    }
                }
                if (badCharCount >= 2 && badCharCount * 5 >= doubleByteCharCount) {
                    break detectBlock;
                }
            }
            if (doubleByteCharCount <= 10 && badCharCount == 0) {
                if (doubleByteCharCount == 0 && totalCharCount < 10) {
                    confidence = 0;
                }
                else {
                    confidence = 10;
                }
                break detectBlock;
            }
            if (doubleByteCharCount < 20 * badCharCount) {
                confidence = 0;
                break detectBlock;
            }
            if (this.commonChars == null) {
                confidence = 30 + doubleByteCharCount - 20 * badCharCount;
                if (confidence > 100) {
                    confidence = 100;
                }
            }
            else {
                var maxVal = Math.log(parseFloat(doubleByteCharCount) / 4);
                var scaleFactor = 90.0 / maxVal;
                confidence = Math.floor(Math.log(commonCharCount + 1) * scaleFactor + 10);
                confidence = Math.min(confidence, 100);
            }
        }
        return confidence == 0 ? null : match(det, this, confidence);
    }
    nextChar(iter, det) {
        return true;
    }
}
class sjis extends mbcs {
    constructor() {
        super(...arguments);
        this.commonChars = [
            0x8140,
            0x8141,
            0x8142,
            0x8145,
            0x815b,
            0x8169,
            0x816a,
            0x8175,
            0x8176,
            0x82a0,
            0x82a2,
            0x82a4,
            0x82a9,
            0x82aa,
            0x82ab,
            0x82ad,
            0x82af,
            0x82b1,
            0x82b3,
            0x82b5,
            0x82b7,
            0x82bd,
            0x82be,
            0x82c1,
            0x82c4,
            0x82c5,
            0x82c6,
            0x82c8,
            0x82c9,
            0x82cc,
            0x82cd,
            0x82dc,
            0x82e0,
            0x82e7,
            0x82e8,
            0x82e9,
            0x82ea,
            0x82f0,
            0x82f1,
            0x8341,
            0x8343,
            0x834e,
            0x834f,
            0x8358,
            0x835e,
            0x8362,
            0x8367,
            0x8375,
            0x8376,
            0x8389,
            0x838a,
            0x838b,
            0x838d,
            0x8393,
            0x8e96,
            0x93fa,
            0x95aa,
        ];
    }
    name() {
        return 'Shift_JIS';
    }
    language() {
        return 'ja';
    }
    nextChar(iter, det) {
        iter.index = iter.nextIndex;
        iter.error = false;
        var firstByte;
        firstByte = iter.charValue = iter.nextByte(det);
        if (firstByte < 0)
            return false;
        if (firstByte <= 0x7f || (firstByte > 0xa0 && firstByte <= 0xdf))
            return true;
        var secondByte = iter.nextByte(det);
        if (secondByte < 0)
            return false;
        iter.charValue = (firstByte << 8) | secondByte;
        if (!((secondByte >= 0x40 && secondByte <= 0x7f) ||
            (secondByte >= 0x80 && secondByte <= 0xff))) {
            iter.error = true;
        }
        return true;
    }
}
exports.sjis = sjis;
class big5 extends mbcs {
    constructor() {
        super(...arguments);
        this.commonChars = [
            0xa140,
            0xa141,
            0xa142,
            0xa143,
            0xa147,
            0xa149,
            0xa175,
            0xa176,
            0xa440,
            0xa446,
            0xa447,
            0xa448,
            0xa451,
            0xa454,
            0xa457,
            0xa464,
            0xa46a,
            0xa46c,
            0xa477,
            0xa4a3,
            0xa4a4,
            0xa4a7,
            0xa4c1,
            0xa4ce,
            0xa4d1,
            0xa4df,
            0xa4e8,
            0xa4fd,
            0xa540,
            0xa548,
            0xa558,
            0xa569,
            0xa5cd,
            0xa5e7,
            0xa657,
            0xa661,
            0xa662,
            0xa668,
            0xa670,
            0xa6a8,
            0xa6b3,
            0xa6b9,
            0xa6d3,
            0xa6db,
            0xa6e6,
            0xa6f2,
            0xa740,
            0xa751,
            0xa759,
            0xa7da,
            0xa8a3,
            0xa8a5,
            0xa8ad,
            0xa8d1,
            0xa8d3,
            0xa8e4,
            0xa8fc,
            0xa9c0,
            0xa9d2,
            0xa9f3,
            0xaa6b,
            0xaaba,
            0xaabe,
            0xaacc,
            0xaafc,
            0xac47,
            0xac4f,
            0xacb0,
            0xacd2,
            0xad59,
            0xaec9,
            0xafe0,
            0xb0ea,
            0xb16f,
            0xb2b3,
            0xb2c4,
            0xb36f,
            0xb44c,
            0xb44e,
            0xb54c,
            0xb5a5,
            0xb5bd,
            0xb5d0,
            0xb5d8,
            0xb671,
            0xb7ed,
            0xb867,
            0xb944,
            0xbad8,
            0xbb44,
            0xbba1,
            0xbdd1,
            0xc2c4,
            0xc3b9,
            0xc440,
            0xc45f,
        ];
    }
    name() {
        return 'Big5';
    }
    language() {
        return 'zh';
    }
    nextChar(iter, det) {
        iter.index = iter.nextIndex;
        iter.error = false;
        var firstByte = (iter.charValue = iter.nextByte(det));
        if (firstByte < 0)
            return false;
        if (firstByte <= 0x7f || firstByte == 0xff)
            return true;
        var secondByte = iter.nextByte(det);
        if (secondByte < 0)
            return false;
        iter.charValue = (iter.charValue << 8) | secondByte;
        if (secondByte < 0x40 || secondByte == 0x7f || secondByte == 0xff)
            iter.error = true;
        return true;
    }
}
exports.big5 = big5;
function eucNextChar(iter, det) {
    iter.index = iter.nextIndex;
    iter.error = false;
    var firstByte = 0;
    var secondByte = 0;
    var thirdByte = 0;
    buildChar: {
        firstByte = iter.charValue = iter.nextByte(det);
        if (firstByte < 0) {
            iter.done = true;
            break buildChar;
        }
        if (firstByte <= 0x8d) {
            break buildChar;
        }
        secondByte = iter.nextByte(det);
        iter.charValue = (iter.charValue << 8) | secondByte;
        if (firstByte >= 0xa1 && firstByte <= 0xfe) {
            if (secondByte < 0xa1) {
                iter.error = true;
            }
            break buildChar;
        }
        if (firstByte == 0x8e) {
            if (secondByte < 0xa1) {
                iter.error = true;
            }
            break buildChar;
        }
        if (firstByte == 0x8f) {
            thirdByte = iter.nextByte(det);
            iter.charValue = (iter.charValue << 8) | thirdByte;
            if (thirdByte < 0xa1) {
                iter.error = true;
            }
        }
    }
    return iter.done == false;
}
class euc_jp extends mbcs {
    constructor() {
        super(...arguments);
        this.commonChars = [
            0xa1a1,
            0xa1a2,
            0xa1a3,
            0xa1a6,
            0xa1bc,
            0xa1ca,
            0xa1cb,
            0xa1d6,
            0xa1d7,
            0xa4a2,
            0xa4a4,
            0xa4a6,
            0xa4a8,
            0xa4aa,
            0xa4ab,
            0xa4ac,
            0xa4ad,
            0xa4af,
            0xa4b1,
            0xa4b3,
            0xa4b5,
            0xa4b7,
            0xa4b9,
            0xa4bb,
            0xa4bd,
            0xa4bf,
            0xa4c0,
            0xa4c1,
            0xa4c3,
            0xa4c4,
            0xa4c6,
            0xa4c7,
            0xa4c8,
            0xa4c9,
            0xa4ca,
            0xa4cb,
            0xa4ce,
            0xa4cf,
            0xa4d0,
            0xa4de,
            0xa4df,
            0xa4e1,
            0xa4e2,
            0xa4e4,
            0xa4e8,
            0xa4e9,
            0xa4ea,
            0xa4eb,
            0xa4ec,
            0xa4ef,
            0xa4f2,
            0xa4f3,
            0xa5a2,
            0xa5a3,
            0xa5a4,
            0xa5a6,
            0xa5a7,
            0xa5aa,
            0xa5ad,
            0xa5af,
            0xa5b0,
            0xa5b3,
            0xa5b5,
            0xa5b7,
            0xa5b8,
            0xa5b9,
            0xa5bf,
            0xa5c3,
            0xa5c6,
            0xa5c7,
            0xa5c8,
            0xa5c9,
            0xa5cb,
            0xa5d0,
            0xa5d5,
            0xa5d6,
            0xa5d7,
            0xa5de,
            0xa5e0,
            0xa5e1,
            0xa5e5,
            0xa5e9,
            0xa5ea,
            0xa5eb,
            0xa5ec,
            0xa5ed,
            0xa5f3,
            0xb8a9,
            0xb9d4,
            0xbaee,
            0xbbc8,
            0xbef0,
            0xbfb7,
            0xc4ea,
            0xc6fc,
            0xc7bd,
            0xcab8,
            0xcaf3,
            0xcbdc,
            0xcdd1,
        ];
        this.nextChar = eucNextChar;
    }
    name() {
        return 'EUC-JP';
    }
    language() {
        return 'ja';
    }
}
exports.euc_jp = euc_jp;
class euc_kr extends mbcs {
    constructor() {
        super(...arguments);
        this.commonChars = [
            0xb0a1,
            0xb0b3,
            0xb0c5,
            0xb0cd,
            0xb0d4,
            0xb0e6,
            0xb0ed,
            0xb0f8,
            0xb0fa,
            0xb0fc,
            0xb1b8,
            0xb1b9,
            0xb1c7,
            0xb1d7,
            0xb1e2,
            0xb3aa,
            0xb3bb,
            0xb4c2,
            0xb4cf,
            0xb4d9,
            0xb4eb,
            0xb5a5,
            0xb5b5,
            0xb5bf,
            0xb5c7,
            0xb5e9,
            0xb6f3,
            0xb7af,
            0xb7c2,
            0xb7ce,
            0xb8a6,
            0xb8ae,
            0xb8b6,
            0xb8b8,
            0xb8bb,
            0xb8e9,
            0xb9ab,
            0xb9ae,
            0xb9cc,
            0xb9ce,
            0xb9fd,
            0xbab8,
            0xbace,
            0xbad0,
            0xbaf1,
            0xbbe7,
            0xbbf3,
            0xbbfd,
            0xbcad,
            0xbcba,
            0xbcd2,
            0xbcf6,
            0xbdba,
            0xbdc0,
            0xbdc3,
            0xbdc5,
            0xbec6,
            0xbec8,
            0xbedf,
            0xbeee,
            0xbef8,
            0xbefa,
            0xbfa1,
            0xbfa9,
            0xbfc0,
            0xbfe4,
            0xbfeb,
            0xbfec,
            0xbff8,
            0xc0a7,
            0xc0af,
            0xc0b8,
            0xc0ba,
            0xc0bb,
            0xc0bd,
            0xc0c7,
            0xc0cc,
            0xc0ce,
            0xc0cf,
            0xc0d6,
            0xc0da,
            0xc0e5,
            0xc0fb,
            0xc0fc,
            0xc1a4,
            0xc1a6,
            0xc1b6,
            0xc1d6,
            0xc1df,
            0xc1f6,
            0xc1f8,
            0xc4a1,
            0xc5cd,
            0xc6ae,
            0xc7cf,
            0xc7d1,
            0xc7d2,
            0xc7d8,
            0xc7e5,
            0xc8ad,
        ];
        this.nextChar = eucNextChar;
    }
    name() {
        return 'EUC-KR';
    }
    language() {
        return 'ko';
    }
}
exports.euc_kr = euc_kr;
class gb_18030 extends mbcs {
    constructor() {
        super(...arguments);
        this.commonChars = [
            0xa1a1,
            0xa1a2,
            0xa1a3,
            0xa1a4,
            0xa1b0,
            0xa1b1,
            0xa1f1,
            0xa1f3,
            0xa3a1,
            0xa3ac,
            0xa3ba,
            0xb1a8,
            0xb1b8,
            0xb1be,
            0xb2bb,
            0xb3c9,
            0xb3f6,
            0xb4f3,
            0xb5bd,
            0xb5c4,
            0xb5e3,
            0xb6af,
            0xb6d4,
            0xb6e0,
            0xb7a2,
            0xb7a8,
            0xb7bd,
            0xb7d6,
            0xb7dd,
            0xb8b4,
            0xb8df,
            0xb8f6,
            0xb9ab,
            0xb9c9,
            0xb9d8,
            0xb9fa,
            0xb9fd,
            0xbacd,
            0xbba7,
            0xbbd6,
            0xbbe1,
            0xbbfa,
            0xbcbc,
            0xbcdb,
            0xbcfe,
            0xbdcc,
            0xbecd,
            0xbedd,
            0xbfb4,
            0xbfc6,
            0xbfc9,
            0xc0b4,
            0xc0ed,
            0xc1cb,
            0xc2db,
            0xc3c7,
            0xc4dc,
            0xc4ea,
            0xc5cc,
            0xc6f7,
            0xc7f8,
            0xc8ab,
            0xc8cb,
            0xc8d5,
            0xc8e7,
            0xc9cf,
            0xc9fa,
            0xcab1,
            0xcab5,
            0xcac7,
            0xcad0,
            0xcad6,
            0xcaf5,
            0xcafd,
            0xccec,
            0xcdf8,
            0xceaa,
            0xcec4,
            0xced2,
            0xcee5,
            0xcfb5,
            0xcfc2,
            0xcfd6,
            0xd0c2,
            0xd0c5,
            0xd0d0,
            0xd0d4,
            0xd1a7,
            0xd2aa,
            0xd2b2,
            0xd2b5,
            0xd2bb,
            0xd2d4,
            0xd3c3,
            0xd3d0,
            0xd3fd,
            0xd4c2,
            0xd4da,
            0xd5e2,
            0xd6d0,
        ];
    }
    name() {
        return 'GB18030';
    }
    language() {
        return 'zh';
    }
    nextChar(iter, det) {
        iter.index = iter.nextIndex;
        iter.error = false;
        var firstByte = 0;
        var secondByte = 0;
        var thirdByte = 0;
        var fourthByte = 0;
        buildChar: {
            firstByte = iter.charValue = iter.nextByte(det);
            if (firstByte < 0) {
                iter.done = true;
                break buildChar;
            }
            if (firstByte <= 0x80) {
                break buildChar;
            }
            secondByte = iter.nextByte(det);
            iter.charValue = (iter.charValue << 8) | secondByte;
            if (firstByte >= 0x81 && firstByte <= 0xfe) {
                if ((secondByte >= 0x40 && secondByte <= 0x7e) ||
                    (secondByte >= 80 && secondByte <= 0xfe)) {
                    break buildChar;
                }
                if (secondByte >= 0x30 && secondByte <= 0x39) {
                    thirdByte = iter.nextByte(det);
                    if (thirdByte >= 0x81 && thirdByte <= 0xfe) {
                        fourthByte = iter.nextByte(det);
                        if (fourthByte >= 0x30 && fourthByte <= 0x39) {
                            iter.charValue =
                                (iter.charValue << 16) | (thirdByte << 8) | fourthByte;
                            break buildChar;
                        }
                    }
                }
                iter.error = true;
                break buildChar;
            }
        }
        return iter.done == false;
    }
}
exports.gb_18030 = gb_18030;
//# sourceMappingURL=mbcs.js.map

/***/ }),

/***/ 4411:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var match = __webpack_require__(4408).default;
var N_GRAM_MASK = 0xffffff;
class NGramParser {
    constructor(theNgramList, theByteMap) {
        this.byteIndex = 0;
        this.ngram = 0;
        this.ngramCount = 0;
        this.hitCount = 0;
        this.spaceChar = 0x20;
        this.ngramList = theNgramList;
        this.byteMap = theByteMap;
    }
    search(table, value) {
        var index = 0;
        if (table[index + 32] <= value)
            index += 32;
        if (table[index + 16] <= value)
            index += 16;
        if (table[index + 8] <= value)
            index += 8;
        if (table[index + 4] <= value)
            index += 4;
        if (table[index + 2] <= value)
            index += 2;
        if (table[index + 1] <= value)
            index += 1;
        if (table[index] > value)
            index -= 1;
        if (index < 0 || table[index] != value)
            return -1;
        return index;
    }
    lookup(thisNgram) {
        this.ngramCount += 1;
        if (this.search(this.ngramList, thisNgram) >= 0) {
            this.hitCount += 1;
        }
    }
    addByte(b) {
        this.ngram = ((this.ngram << 8) + (b & 0xff)) & N_GRAM_MASK;
        this.lookup(this.ngram);
    }
    nextByte(det) {
        if (this.byteIndex >= det.fInputLen)
            return -1;
        return det.fInputBytes[this.byteIndex++] & 0xff;
    }
    parse(det, spaceCh) {
        var b, ignoreSpace = false;
        this.spaceChar = spaceCh;
        while ((b = this.nextByte(det)) >= 0) {
            var mb = this.byteMap[b];
            if (mb != 0) {
                if (!(mb == this.spaceChar && ignoreSpace)) {
                    this.addByte(mb);
                }
                ignoreSpace = mb == this.spaceChar;
            }
        }
        this.addByte(this.spaceChar);
        var rawPercent = this.hitCount / this.ngramCount;
        if (rawPercent > 0.33)
            return 98;
        return Math.floor(rawPercent * 300.0);
    }
}
class NGramsPlusLang {
    constructor(la, ng) {
        this.fLang = la;
        this.fNGrams = ng;
    }
}
const isFlatNgrams = (val) => Array.isArray(val) && isFinite(val[0]);
class sbcs {
    constructor() {
        this.spaceChar = 0x20;
    }
    ngrams() {
        return [];
    }
    byteMap() {
        return [];
    }
    name(input) {
        return 'sbcs';
    }
    match(det) {
        var ngrams = this.ngrams();
        if (isFlatNgrams(ngrams)) {
            var parser = new NGramParser(ngrams, this.byteMap());
            var confidence = parser.parse(det, this.spaceChar);
            return confidence <= 0 ? null : match(det, this, confidence);
        }
        var bestConfidenceSoFar = -1;
        var lang = null;
        for (var i = ngrams.length - 1; i >= 0; i--) {
            var ngl = ngrams[i];
            var parser = new NGramParser(ngl.fNGrams, this.byteMap());
            var confidence = parser.parse(det, this.spaceChar);
            if (confidence > bestConfidenceSoFar) {
                bestConfidenceSoFar = confidence;
                lang = ngl.fLang;
            }
        }
        var name = this.name(det);
        return bestConfidenceSoFar <= 0
            ? null
            : match(det, this, bestConfidenceSoFar, name, lang);
    }
}
class ISO_8859_1 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xaa,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xb5,
            0x20,
            0x20,
            0x20,
            0x20,
            0xba,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0x20,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0x20,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0xff,
        ];
    }
    ngrams() {
        return [
            new NGramsPlusLang('da', [
                0x206166,
                0x206174,
                0x206465,
                0x20656e,
                0x206572,
                0x20666f,
                0x206861,
                0x206920,
                0x206d65,
                0x206f67,
                0x2070e5,
                0x207369,
                0x207374,
                0x207469,
                0x207669,
                0x616620,
                0x616e20,
                0x616e64,
                0x617220,
                0x617420,
                0x646520,
                0x64656e,
                0x646572,
                0x646574,
                0x652073,
                0x656420,
                0x656465,
                0x656e20,
                0x656e64,
                0x657220,
                0x657265,
                0x657320,
                0x657420,
                0x666f72,
                0x676520,
                0x67656e,
                0x676572,
                0x696765,
                0x696c20,
                0x696e67,
                0x6b6520,
                0x6b6b65,
                0x6c6572,
                0x6c6967,
                0x6c6c65,
                0x6d6564,
                0x6e6465,
                0x6e6520,
                0x6e6720,
                0x6e6765,
                0x6f6720,
                0x6f6d20,
                0x6f7220,
                0x70e520,
                0x722064,
                0x722065,
                0x722073,
                0x726520,
                0x737465,
                0x742073,
                0x746520,
                0x746572,
                0x74696c,
                0x766572,
            ]),
            new NGramsPlusLang('de', [
                0x20616e,
                0x206175,
                0x206265,
                0x206461,
                0x206465,
                0x206469,
                0x206569,
                0x206765,
                0x206861,
                0x20696e,
                0x206d69,
                0x207363,
                0x207365,
                0x20756e,
                0x207665,
                0x20766f,
                0x207765,
                0x207a75,
                0x626572,
                0x636820,
                0x636865,
                0x636874,
                0x646173,
                0x64656e,
                0x646572,
                0x646965,
                0x652064,
                0x652073,
                0x65696e,
                0x656974,
                0x656e20,
                0x657220,
                0x657320,
                0x67656e,
                0x68656e,
                0x687420,
                0x696368,
                0x696520,
                0x696e20,
                0x696e65,
                0x697420,
                0x6c6963,
                0x6c6c65,
                0x6e2061,
                0x6e2064,
                0x6e2073,
                0x6e6420,
                0x6e6465,
                0x6e6520,
                0x6e6720,
                0x6e6765,
                0x6e7465,
                0x722064,
                0x726465,
                0x726569,
                0x736368,
                0x737465,
                0x742064,
                0x746520,
                0x74656e,
                0x746572,
                0x756e64,
                0x756e67,
                0x766572,
            ]),
            new NGramsPlusLang('en', [
                0x206120,
                0x20616e,
                0x206265,
                0x20636f,
                0x20666f,
                0x206861,
                0x206865,
                0x20696e,
                0x206d61,
                0x206f66,
                0x207072,
                0x207265,
                0x207361,
                0x207374,
                0x207468,
                0x20746f,
                0x207768,
                0x616964,
                0x616c20,
                0x616e20,
                0x616e64,
                0x617320,
                0x617420,
                0x617465,
                0x617469,
                0x642061,
                0x642074,
                0x652061,
                0x652073,
                0x652074,
                0x656420,
                0x656e74,
                0x657220,
                0x657320,
                0x666f72,
                0x686174,
                0x686520,
                0x686572,
                0x696420,
                0x696e20,
                0x696e67,
                0x696f6e,
                0x697320,
                0x6e2061,
                0x6e2074,
                0x6e6420,
                0x6e6720,
                0x6e7420,
                0x6f6620,
                0x6f6e20,
                0x6f7220,
                0x726520,
                0x727320,
                0x732061,
                0x732074,
                0x736169,
                0x737420,
                0x742074,
                0x746572,
                0x746861,
                0x746865,
                0x74696f,
                0x746f20,
                0x747320,
            ]),
            new NGramsPlusLang('es', [
                0x206120,
                0x206361,
                0x20636f,
                0x206465,
                0x20656c,
                0x20656e,
                0x206573,
                0x20696e,
                0x206c61,
                0x206c6f,
                0x207061,
                0x20706f,
                0x207072,
                0x207175,
                0x207265,
                0x207365,
                0x20756e,
                0x207920,
                0x612063,
                0x612064,
                0x612065,
                0x61206c,
                0x612070,
                0x616369,
                0x61646f,
                0x616c20,
                0x617220,
                0x617320,
                0x6369f3,
                0x636f6e,
                0x646520,
                0x64656c,
                0x646f20,
                0x652064,
                0x652065,
                0x65206c,
                0x656c20,
                0x656e20,
                0x656e74,
                0x657320,
                0x657374,
                0x69656e,
                0x69f36e,
                0x6c6120,
                0x6c6f73,
                0x6e2065,
                0x6e7465,
                0x6f2064,
                0x6f2065,
                0x6f6e20,
                0x6f7220,
                0x6f7320,
                0x706172,
                0x717565,
                0x726120,
                0x726573,
                0x732064,
                0x732065,
                0x732070,
                0x736520,
                0x746520,
                0x746f20,
                0x756520,
                0xf36e20,
            ]),
            new NGramsPlusLang('fr', [
                0x206175,
                0x20636f,
                0x206461,
                0x206465,
                0x206475,
                0x20656e,
                0x206574,
                0x206c61,
                0x206c65,
                0x207061,
                0x20706f,
                0x207072,
                0x207175,
                0x207365,
                0x20736f,
                0x20756e,
                0x20e020,
                0x616e74,
                0x617469,
                0x636520,
                0x636f6e,
                0x646520,
                0x646573,
                0x647520,
                0x652061,
                0x652063,
                0x652064,
                0x652065,
                0x65206c,
                0x652070,
                0x652073,
                0x656e20,
                0x656e74,
                0x657220,
                0x657320,
                0x657420,
                0x657572,
                0x696f6e,
                0x697320,
                0x697420,
                0x6c6120,
                0x6c6520,
                0x6c6573,
                0x6d656e,
                0x6e2064,
                0x6e6520,
                0x6e7320,
                0x6e7420,
                0x6f6e20,
                0x6f6e74,
                0x6f7572,
                0x717565,
                0x72206c,
                0x726520,
                0x732061,
                0x732064,
                0x732065,
                0x73206c,
                0x732070,
                0x742064,
                0x746520,
                0x74696f,
                0x756520,
                0x757220,
            ]),
            new NGramsPlusLang('it', [
                0x20616c,
                0x206368,
                0x20636f,
                0x206465,
                0x206469,
                0x206520,
                0x20696c,
                0x20696e,
                0x206c61,
                0x207065,
                0x207072,
                0x20756e,
                0x612063,
                0x612064,
                0x612070,
                0x612073,
                0x61746f,
                0x636865,
                0x636f6e,
                0x64656c,
                0x646920,
                0x652061,
                0x652063,
                0x652064,
                0x652069,
                0x65206c,
                0x652070,
                0x652073,
                0x656c20,
                0x656c6c,
                0x656e74,
                0x657220,
                0x686520,
                0x692061,
                0x692063,
                0x692064,
                0x692073,
                0x696120,
                0x696c20,
                0x696e20,
                0x696f6e,
                0x6c6120,
                0x6c6520,
                0x6c6920,
                0x6c6c61,
                0x6e6520,
                0x6e6920,
                0x6e6f20,
                0x6e7465,
                0x6f2061,
                0x6f2064,
                0x6f2069,
                0x6f2073,
                0x6f6e20,
                0x6f6e65,
                0x706572,
                0x726120,
                0x726520,
                0x736920,
                0x746120,
                0x746520,
                0x746920,
                0x746f20,
                0x7a696f,
            ]),
            new NGramsPlusLang('nl', [
                0x20616c,
                0x206265,
                0x206461,
                0x206465,
                0x206469,
                0x206565,
                0x20656e,
                0x206765,
                0x206865,
                0x20696e,
                0x206d61,
                0x206d65,
                0x206f70,
                0x207465,
                0x207661,
                0x207665,
                0x20766f,
                0x207765,
                0x207a69,
                0x61616e,
                0x616172,
                0x616e20,
                0x616e64,
                0x617220,
                0x617420,
                0x636874,
                0x646520,
                0x64656e,
                0x646572,
                0x652062,
                0x652076,
                0x65656e,
                0x656572,
                0x656e20,
                0x657220,
                0x657273,
                0x657420,
                0x67656e,
                0x686574,
                0x696520,
                0x696e20,
                0x696e67,
                0x697320,
                0x6e2062,
                0x6e2064,
                0x6e2065,
                0x6e2068,
                0x6e206f,
                0x6e2076,
                0x6e6465,
                0x6e6720,
                0x6f6e64,
                0x6f6f72,
                0x6f7020,
                0x6f7220,
                0x736368,
                0x737465,
                0x742064,
                0x746520,
                0x74656e,
                0x746572,
                0x76616e,
                0x766572,
                0x766f6f,
            ]),
            new NGramsPlusLang('no', [
                0x206174,
                0x206176,
                0x206465,
                0x20656e,
                0x206572,
                0x20666f,
                0x206861,
                0x206920,
                0x206d65,
                0x206f67,
                0x2070e5,
                0x207365,
                0x20736b,
                0x20736f,
                0x207374,
                0x207469,
                0x207669,
                0x20e520,
                0x616e64,
                0x617220,
                0x617420,
                0x646520,
                0x64656e,
                0x646574,
                0x652073,
                0x656420,
                0x656e20,
                0x656e65,
                0x657220,
                0x657265,
                0x657420,
                0x657474,
                0x666f72,
                0x67656e,
                0x696b6b,
                0x696c20,
                0x696e67,
                0x6b6520,
                0x6b6b65,
                0x6c6520,
                0x6c6c65,
                0x6d6564,
                0x6d656e,
                0x6e2073,
                0x6e6520,
                0x6e6720,
                0x6e6765,
                0x6e6e65,
                0x6f6720,
                0x6f6d20,
                0x6f7220,
                0x70e520,
                0x722073,
                0x726520,
                0x736f6d,
                0x737465,
                0x742073,
                0x746520,
                0x74656e,
                0x746572,
                0x74696c,
                0x747420,
                0x747465,
                0x766572,
            ]),
            new NGramsPlusLang('pt', [
                0x206120,
                0x20636f,
                0x206461,
                0x206465,
                0x20646f,
                0x206520,
                0x206573,
                0x206d61,
                0x206e6f,
                0x206f20,
                0x207061,
                0x20706f,
                0x207072,
                0x207175,
                0x207265,
                0x207365,
                0x20756d,
                0x612061,
                0x612063,
                0x612064,
                0x612070,
                0x616465,
                0x61646f,
                0x616c20,
                0x617220,
                0x617261,
                0x617320,
                0x636f6d,
                0x636f6e,
                0x646120,
                0x646520,
                0x646f20,
                0x646f73,
                0x652061,
                0x652064,
                0x656d20,
                0x656e74,
                0x657320,
                0x657374,
                0x696120,
                0x696361,
                0x6d656e,
                0x6e7465,
                0x6e746f,
                0x6f2061,
                0x6f2063,
                0x6f2064,
                0x6f2065,
                0x6f2070,
                0x6f7320,
                0x706172,
                0x717565,
                0x726120,
                0x726573,
                0x732061,
                0x732064,
                0x732065,
                0x732070,
                0x737461,
                0x746520,
                0x746f20,
                0x756520,
                0xe36f20,
                0xe7e36f,
            ]),
            new NGramsPlusLang('sv', [
                0x206174,
                0x206176,
                0x206465,
                0x20656e,
                0x2066f6,
                0x206861,
                0x206920,
                0x20696e,
                0x206b6f,
                0x206d65,
                0x206f63,
                0x2070e5,
                0x20736b,
                0x20736f,
                0x207374,
                0x207469,
                0x207661,
                0x207669,
                0x20e472,
                0x616465,
                0x616e20,
                0x616e64,
                0x617220,
                0x617474,
                0x636820,
                0x646520,
                0x64656e,
                0x646572,
                0x646574,
                0x656420,
                0x656e20,
                0x657220,
                0x657420,
                0x66f672,
                0x67656e,
                0x696c6c,
                0x696e67,
                0x6b6120,
                0x6c6c20,
                0x6d6564,
                0x6e2073,
                0x6e6120,
                0x6e6465,
                0x6e6720,
                0x6e6765,
                0x6e696e,
                0x6f6368,
                0x6f6d20,
                0x6f6e20,
                0x70e520,
                0x722061,
                0x722073,
                0x726120,
                0x736b61,
                0x736f6d,
                0x742073,
                0x746120,
                0x746520,
                0x746572,
                0x74696c,
                0x747420,
                0x766172,
                0xe47220,
                0xf67220,
            ]),
        ];
    }
    name(input) {
        return input && input.fC1Bytes ? 'windows-1252' : 'ISO-8859-1';
    }
}
exports.ISO_8859_1 = ISO_8859_1;
class ISO_8859_2 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xb1,
            0x20,
            0xb3,
            0x20,
            0xb5,
            0xb6,
            0x20,
            0x20,
            0xb9,
            0xba,
            0xbb,
            0xbc,
            0x20,
            0xbe,
            0xbf,
            0x20,
            0xb1,
            0x20,
            0xb3,
            0x20,
            0xb5,
            0xb6,
            0xb7,
            0x20,
            0xb9,
            0xba,
            0xbb,
            0xbc,
            0x20,
            0xbe,
            0xbf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0x20,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0x20,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0x20,
        ];
    }
    ngrams() {
        return [
            new NGramsPlusLang('cs', [
                0x206120,
                0x206279,
                0x20646f,
                0x206a65,
                0x206e61,
                0x206e65,
                0x206f20,
                0x206f64,
                0x20706f,
                0x207072,
                0x2070f8,
                0x20726f,
                0x207365,
                0x20736f,
                0x207374,
                0x20746f,
                0x207620,
                0x207679,
                0x207a61,
                0x612070,
                0x636520,
                0x636820,
                0x652070,
                0x652073,
                0x652076,
                0x656d20,
                0x656eed,
                0x686f20,
                0x686f64,
                0x697374,
                0x6a6520,
                0x6b7465,
                0x6c6520,
                0x6c6920,
                0x6e6120,
                0x6ee920,
                0x6eec20,
                0x6eed20,
                0x6f2070,
                0x6f646e,
                0x6f6a69,
                0x6f7374,
                0x6f7520,
                0x6f7661,
                0x706f64,
                0x706f6a,
                0x70726f,
                0x70f865,
                0x736520,
                0x736f75,
                0x737461,
                0x737469,
                0x73746e,
                0x746572,
                0x746eed,
                0x746f20,
                0x752070,
                0xbe6520,
                0xe16eed,
                0xe9686f,
                0xed2070,
                0xed2073,
                0xed6d20,
                0xf86564,
            ]),
            new NGramsPlusLang('hu', [
                0x206120,
                0x20617a,
                0x206265,
                0x206567,
                0x20656c,
                0x206665,
                0x206861,
                0x20686f,
                0x206973,
                0x206b65,
                0x206b69,
                0x206bf6,
                0x206c65,
                0x206d61,
                0x206d65,
                0x206d69,
                0x206e65,
                0x20737a,
                0x207465,
                0x20e973,
                0x612061,
                0x61206b,
                0x61206d,
                0x612073,
                0x616b20,
                0x616e20,
                0x617a20,
                0x62616e,
                0x62656e,
                0x656779,
                0x656b20,
                0x656c20,
                0x656c65,
                0x656d20,
                0x656e20,
                0x657265,
                0x657420,
                0x657465,
                0x657474,
                0x677920,
                0x686f67,
                0x696e74,
                0x697320,
                0x6b2061,
                0x6bf67a,
                0x6d6567,
                0x6d696e,
                0x6e2061,
                0x6e616b,
                0x6e656b,
                0x6e656d,
                0x6e7420,
                0x6f6779,
                0x732061,
                0x737a65,
                0x737a74,
                0x737ae1,
                0x73e967,
                0x742061,
                0x747420,
                0x74e173,
                0x7a6572,
                0xe16e20,
                0xe97320,
            ]),
            new NGramsPlusLang('pl', [
                0x20637a,
                0x20646f,
                0x206920,
                0x206a65,
                0x206b6f,
                0x206d61,
                0x206d69,
                0x206e61,
                0x206e69,
                0x206f64,
                0x20706f,
                0x207072,
                0x207369,
                0x207720,
                0x207769,
                0x207779,
                0x207a20,
                0x207a61,
                0x612070,
                0x612077,
                0x616e69,
                0x636820,
                0x637a65,
                0x637a79,
                0x646f20,
                0x647a69,
                0x652070,
                0x652073,
                0x652077,
                0x65207a,
                0x65676f,
                0x656a20,
                0x656d20,
                0x656e69,
                0x676f20,
                0x696120,
                0x696520,
                0x69656a,
                0x6b6120,
                0x6b6920,
                0x6b6965,
                0x6d6965,
                0x6e6120,
                0x6e6961,
                0x6e6965,
                0x6f2070,
                0x6f7761,
                0x6f7769,
                0x706f6c,
                0x707261,
                0x70726f,
                0x70727a,
                0x727a65,
                0x727a79,
                0x7369ea,
                0x736b69,
                0x737461,
                0x776965,
                0x796368,
                0x796d20,
                0x7a6520,
                0x7a6965,
                0x7a7920,
                0xf37720,
            ]),
            new NGramsPlusLang('ro', [
                0x206120,
                0x206163,
                0x206361,
                0x206365,
                0x20636f,
                0x206375,
                0x206465,
                0x206469,
                0x206c61,
                0x206d61,
                0x207065,
                0x207072,
                0x207365,
                0x2073e3,
                0x20756e,
                0x20ba69,
                0x20ee6e,
                0x612063,
                0x612064,
                0x617265,
                0x617420,
                0x617465,
                0x617520,
                0x636172,
                0x636f6e,
                0x637520,
                0x63e320,
                0x646520,
                0x652061,
                0x652063,
                0x652064,
                0x652070,
                0x652073,
                0x656120,
                0x656920,
                0x656c65,
                0x656e74,
                0x657374,
                0x692061,
                0x692063,
                0x692064,
                0x692070,
                0x696520,
                0x696920,
                0x696e20,
                0x6c6120,
                0x6c6520,
                0x6c6f72,
                0x6c7569,
                0x6e6520,
                0x6e7472,
                0x6f7220,
                0x70656e,
                0x726520,
                0x726561,
                0x727520,
                0x73e320,
                0x746520,
                0x747275,
                0x74e320,
                0x756920,
                0x756c20,
                0xba6920,
                0xee6e20,
            ]),
        ];
    }
    name(det) {
        return det && det.fC1Bytes ? 'windows-1250' : 'ISO-8859-2';
    }
}
exports.ISO_8859_2 = ISO_8859_2;
class ISO_8859_5 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0x20,
            0xfe,
            0xff,
            0xd0,
            0xd1,
            0xd2,
            0xd3,
            0xd4,
            0xd5,
            0xd6,
            0xd7,
            0xd8,
            0xd9,
            0xda,
            0xdb,
            0xdc,
            0xdd,
            0xde,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xd0,
            0xd1,
            0xd2,
            0xd3,
            0xd4,
            0xd5,
            0xd6,
            0xd7,
            0xd8,
            0xd9,
            0xda,
            0xdb,
            0xdc,
            0xdd,
            0xde,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0x20,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0x20,
            0xfe,
            0xff,
        ];
    }
    ngrams() {
        return [
            0x20d220,
            0x20d2de,
            0x20d4de,
            0x20d7d0,
            0x20d820,
            0x20dad0,
            0x20dade,
            0x20ddd0,
            0x20ddd5,
            0x20ded1,
            0x20dfde,
            0x20dfe0,
            0x20e0d0,
            0x20e1de,
            0x20e1e2,
            0x20e2de,
            0x20e7e2,
            0x20ede2,
            0xd0ddd8,
            0xd0e2ec,
            0xd3de20,
            0xd5dbec,
            0xd5ddd8,
            0xd5e1e2,
            0xd5e220,
            0xd820df,
            0xd8d520,
            0xd8d820,
            0xd8ef20,
            0xdbd5dd,
            0xdbd820,
            0xdbecdd,
            0xddd020,
            0xddd520,
            0xddd8d5,
            0xddd8ef,
            0xddde20,
            0xddded2,
            0xde20d2,
            0xde20df,
            0xde20e1,
            0xded220,
            0xded2d0,
            0xded3de,
            0xded920,
            0xdedbec,
            0xdedc20,
            0xdee1e2,
            0xdfdedb,
            0xdfe0d5,
            0xdfe0d8,
            0xdfe0de,
            0xe0d0d2,
            0xe0d5d4,
            0xe1e2d0,
            0xe1e2d2,
            0xe1e2d8,
            0xe1ef20,
            0xe2d5db,
            0xe2de20,
            0xe2dee0,
            0xe2ec20,
            0xe7e2de,
            0xebe520,
        ];
    }
    name() {
        return 'ISO-8859-5';
    }
    language() {
        return 'ru';
    }
}
exports.ISO_8859_5 = ISO_8859_5;
class ISO_8859_6 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xc1,
            0xc2,
            0xc3,
            0xc4,
            0xc5,
            0xc6,
            0xc7,
            0xc8,
            0xc9,
            0xca,
            0xcb,
            0xcc,
            0xcd,
            0xce,
            0xcf,
            0xd0,
            0xd1,
            0xd2,
            0xd3,
            0xd4,
            0xd5,
            0xd6,
            0xd7,
            0xd8,
            0xd9,
            0xda,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
        ];
    }
    ngrams() {
        return [
            0x20c7e4,
            0x20c7e6,
            0x20c8c7,
            0x20d9e4,
            0x20e1ea,
            0x20e4e4,
            0x20e5e6,
            0x20e8c7,
            0xc720c7,
            0xc7c120,
            0xc7ca20,
            0xc7d120,
            0xc7e420,
            0xc7e4c3,
            0xc7e4c7,
            0xc7e4c8,
            0xc7e4ca,
            0xc7e4cc,
            0xc7e4cd,
            0xc7e4cf,
            0xc7e4d3,
            0xc7e4d9,
            0xc7e4e2,
            0xc7e4e5,
            0xc7e4e8,
            0xc7e4ea,
            0xc7e520,
            0xc7e620,
            0xc7e6ca,
            0xc820c7,
            0xc920c7,
            0xc920e1,
            0xc920e4,
            0xc920e5,
            0xc920e8,
            0xca20c7,
            0xcf20c7,
            0xcfc920,
            0xd120c7,
            0xd1c920,
            0xd320c7,
            0xd920c7,
            0xd9e4e9,
            0xe1ea20,
            0xe420c7,
            0xe4c920,
            0xe4e920,
            0xe4ea20,
            0xe520c7,
            0xe5c720,
            0xe5c920,
            0xe5e620,
            0xe620c7,
            0xe720c7,
            0xe7c720,
            0xe8c7e4,
            0xe8e620,
            0xe920c7,
            0xea20c7,
            0xea20e5,
            0xea20e8,
            0xeac920,
            0xead120,
            0xeae620,
        ];
    }
    name() {
        return 'ISO-8859-6';
    }
    language() {
        return 'ar';
    }
}
exports.ISO_8859_6 = ISO_8859_6;
class ISO_8859_7 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xa1,
            0xa2,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xdc,
            0x20,
            0xdd,
            0xde,
            0xdf,
            0x20,
            0xfc,
            0x20,
            0xfd,
            0xfe,
            0xc0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0x20,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xdc,
            0xdd,
            0xde,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0x20,
        ];
    }
    ngrams() {
        return [
            0x20e1ed,
            0x20e1f0,
            0x20e3e9,
            0x20e4e9,
            0x20e5f0,
            0x20e720,
            0x20eae1,
            0x20ece5,
            0x20ede1,
            0x20ef20,
            0x20f0e1,
            0x20f0ef,
            0x20f0f1,
            0x20f3f4,
            0x20f3f5,
            0x20f4e7,
            0x20f4ef,
            0xdfe120,
            0xe120e1,
            0xe120f4,
            0xe1e920,
            0xe1ed20,
            0xe1f0fc,
            0xe1f220,
            0xe3e9e1,
            0xe5e920,
            0xe5f220,
            0xe720f4,
            0xe7ed20,
            0xe7f220,
            0xe920f4,
            0xe9e120,
            0xe9eade,
            0xe9f220,
            0xeae1e9,
            0xeae1f4,
            0xece520,
            0xed20e1,
            0xed20e5,
            0xed20f0,
            0xede120,
            0xeff220,
            0xeff520,
            0xf0eff5,
            0xf0f1ef,
            0xf0fc20,
            0xf220e1,
            0xf220e5,
            0xf220ea,
            0xf220f0,
            0xf220f4,
            0xf3e520,
            0xf3e720,
            0xf3f4ef,
            0xf4e120,
            0xf4e1e9,
            0xf4e7ed,
            0xf4e7f2,
            0xf4e9ea,
            0xf4ef20,
            0xf4eff5,
            0xf4f9ed,
            0xf9ed20,
            0xfeed20,
        ];
    }
    name(det) {
        return det && det.fC1Bytes ? 'windows-1253' : 'ISO-8859-7';
    }
    language() {
        return 'el';
    }
}
exports.ISO_8859_7 = ISO_8859_7;
class ISO_8859_8 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xb5,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
        ];
    }
    ngrams() {
        return [
            new NGramsPlusLang('he', [
                0x20e0e5,
                0x20e0e7,
                0x20e0e9,
                0x20e0fa,
                0x20e1e9,
                0x20e1ee,
                0x20e4e0,
                0x20e4e5,
                0x20e4e9,
                0x20e4ee,
                0x20e4f2,
                0x20e4f9,
                0x20e4fa,
                0x20ece0,
                0x20ece4,
                0x20eee0,
                0x20f2ec,
                0x20f9ec,
                0xe0fa20,
                0xe420e0,
                0xe420e1,
                0xe420e4,
                0xe420ec,
                0xe420ee,
                0xe420f9,
                0xe4e5e0,
                0xe5e020,
                0xe5ed20,
                0xe5ef20,
                0xe5f820,
                0xe5fa20,
                0xe920e4,
                0xe9e420,
                0xe9e5fa,
                0xe9e9ed,
                0xe9ed20,
                0xe9ef20,
                0xe9f820,
                0xe9fa20,
                0xec20e0,
                0xec20e4,
                0xece020,
                0xece420,
                0xed20e0,
                0xed20e1,
                0xed20e4,
                0xed20ec,
                0xed20ee,
                0xed20f9,
                0xeee420,
                0xef20e4,
                0xf0e420,
                0xf0e920,
                0xf0e9ed,
                0xf2ec20,
                0xf820e4,
                0xf8e9ed,
                0xf9ec20,
                0xfa20e0,
                0xfa20e1,
                0xfa20e4,
                0xfa20ec,
                0xfa20ee,
                0xfa20f9,
            ]),
            new NGramsPlusLang('he', [
                0x20e0e5,
                0x20e0ec,
                0x20e4e9,
                0x20e4ec,
                0x20e4ee,
                0x20e4f0,
                0x20e9f0,
                0x20ecf2,
                0x20ecf9,
                0x20ede5,
                0x20ede9,
                0x20efe5,
                0x20efe9,
                0x20f8e5,
                0x20f8e9,
                0x20fae0,
                0x20fae5,
                0x20fae9,
                0xe020e4,
                0xe020ec,
                0xe020ed,
                0xe020fa,
                0xe0e420,
                0xe0e5e4,
                0xe0ec20,
                0xe0ee20,
                0xe120e4,
                0xe120ed,
                0xe120fa,
                0xe420e4,
                0xe420e9,
                0xe420ec,
                0xe420ed,
                0xe420ef,
                0xe420f8,
                0xe420fa,
                0xe4ec20,
                0xe5e020,
                0xe5e420,
                0xe7e020,
                0xe9e020,
                0xe9e120,
                0xe9e420,
                0xec20e4,
                0xec20ed,
                0xec20fa,
                0xecf220,
                0xecf920,
                0xede9e9,
                0xede9f0,
                0xede9f8,
                0xee20e4,
                0xee20ed,
                0xee20fa,
                0xeee120,
                0xeee420,
                0xf2e420,
                0xf920e4,
                0xf920ed,
                0xf920fa,
                0xf9e420,
                0xfae020,
                0xfae420,
                0xfae5e9,
            ]),
        ];
    }
    name(det) {
        return det && det.fC1Bytes ? 'windows-1255' : 'ISO-8859-8';
    }
    language() {
        return 'he';
    }
}
exports.ISO_8859_8 = ISO_8859_8;
class ISO_8859_9 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xaa,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xb5,
            0x20,
            0x20,
            0x20,
            0x20,
            0xba,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0x20,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0x69,
            0xfe,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0x20,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0xff,
        ];
    }
    ngrams() {
        return [
            0x206261,
            0x206269,
            0x206275,
            0x206461,
            0x206465,
            0x206765,
            0x206861,
            0x20696c,
            0x206b61,
            0x206b6f,
            0x206d61,
            0x206f6c,
            0x207361,
            0x207461,
            0x207665,
            0x207961,
            0x612062,
            0x616b20,
            0x616c61,
            0x616d61,
            0x616e20,
            0x616efd,
            0x617220,
            0x617261,
            0x6172fd,
            0x6173fd,
            0x617961,
            0x626972,
            0x646120,
            0x646520,
            0x646920,
            0x652062,
            0x65206b,
            0x656469,
            0x656e20,
            0x657220,
            0x657269,
            0x657369,
            0x696c65,
            0x696e20,
            0x696e69,
            0x697220,
            0x6c616e,
            0x6c6172,
            0x6c6520,
            0x6c6572,
            0x6e2061,
            0x6e2062,
            0x6e206b,
            0x6e6461,
            0x6e6465,
            0x6e6520,
            0x6e6920,
            0x6e696e,
            0x6efd20,
            0x72696e,
            0x72fd6e,
            0x766520,
            0x796120,
            0x796f72,
            0xfd6e20,
            0xfd6e64,
            0xfd6efd,
            0xfdf0fd,
        ];
    }
    name(det) {
        return det && det.fC1Bytes ? 'windows-1254' : 'ISO-8859-9';
    }
    language() {
        return 'tr';
    }
}
exports.ISO_8859_9 = ISO_8859_9;
class windows_1251 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x90,
            0x83,
            0x20,
            0x83,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x9a,
            0x20,
            0x9c,
            0x9d,
            0x9e,
            0x9f,
            0x90,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x9a,
            0x20,
            0x9c,
            0x9d,
            0x9e,
            0x9f,
            0x20,
            0xa2,
            0xa2,
            0xbc,
            0x20,
            0xb4,
            0x20,
            0x20,
            0xb8,
            0x20,
            0xba,
            0x20,
            0x20,
            0x20,
            0x20,
            0xbf,
            0x20,
            0x20,
            0xb3,
            0xb3,
            0xb4,
            0xb5,
            0x20,
            0x20,
            0xb8,
            0x20,
            0xba,
            0x20,
            0xbc,
            0xbe,
            0xbe,
            0xbf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0xff,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0xf0,
            0xf1,
            0xf2,
            0xf3,
            0xf4,
            0xf5,
            0xf6,
            0xf7,
            0xf8,
            0xf9,
            0xfa,
            0xfb,
            0xfc,
            0xfd,
            0xfe,
            0xff,
        ];
    }
    ngrams() {
        return [
            0x20e220,
            0x20e2ee,
            0x20e4ee,
            0x20e7e0,
            0x20e820,
            0x20eae0,
            0x20eaee,
            0x20ede0,
            0x20ede5,
            0x20eee1,
            0x20efee,
            0x20eff0,
            0x20f0e0,
            0x20f1ee,
            0x20f1f2,
            0x20f2ee,
            0x20f7f2,
            0x20fdf2,
            0xe0ede8,
            0xe0f2fc,
            0xe3ee20,
            0xe5ebfc,
            0xe5ede8,
            0xe5f1f2,
            0xe5f220,
            0xe820ef,
            0xe8e520,
            0xe8e820,
            0xe8ff20,
            0xebe5ed,
            0xebe820,
            0xebfced,
            0xede020,
            0xede520,
            0xede8e5,
            0xede8ff,
            0xedee20,
            0xedeee2,
            0xee20e2,
            0xee20ef,
            0xee20f1,
            0xeee220,
            0xeee2e0,
            0xeee3ee,
            0xeee920,
            0xeeebfc,
            0xeeec20,
            0xeef1f2,
            0xefeeeb,
            0xeff0e5,
            0xeff0e8,
            0xeff0ee,
            0xf0e0e2,
            0xf0e5e4,
            0xf1f2e0,
            0xf1f2e2,
            0xf1f2e8,
            0xf1ff20,
            0xf2e5eb,
            0xf2ee20,
            0xf2eef0,
            0xf2fc20,
            0xf7f2ee,
            0xfbf520,
        ];
    }
    name() {
        return 'windows-1251';
    }
    language() {
        return 'ru';
    }
}
exports.windows_1251 = windows_1251;
class windows_1256 extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x81,
            0x20,
            0x83,
            0x20,
            0x20,
            0x20,
            0x20,
            0x88,
            0x20,
            0x8a,
            0x20,
            0x9c,
            0x8d,
            0x8e,
            0x8f,
            0x90,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x98,
            0x20,
            0x9a,
            0x20,
            0x9c,
            0x20,
            0x20,
            0x9f,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xaa,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xb5,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xc0,
            0xc1,
            0xc2,
            0xc3,
            0xc4,
            0xc5,
            0xc6,
            0xc7,
            0xc8,
            0xc9,
            0xca,
            0xcb,
            0xcc,
            0xcd,
            0xce,
            0xcf,
            0xd0,
            0xd1,
            0xd2,
            0xd3,
            0xd4,
            0xd5,
            0xd6,
            0x20,
            0xd8,
            0xd9,
            0xda,
            0xdb,
            0xdc,
            0xdd,
            0xde,
            0xdf,
            0xe0,
            0xe1,
            0xe2,
            0xe3,
            0xe4,
            0xe5,
            0xe6,
            0xe7,
            0xe8,
            0xe9,
            0xea,
            0xeb,
            0xec,
            0xed,
            0xee,
            0xef,
            0x20,
            0x20,
            0x20,
            0x20,
            0xf4,
            0x20,
            0x20,
            0x20,
            0x20,
            0xf9,
            0x20,
            0xfb,
            0xfc,
            0x20,
            0x20,
            0xff,
        ];
    }
    ngrams() {
        return [
            0x20c7e1,
            0x20c7e4,
            0x20c8c7,
            0x20dae1,
            0x20dded,
            0x20e1e1,
            0x20e3e4,
            0x20e6c7,
            0xc720c7,
            0xc7c120,
            0xc7ca20,
            0xc7d120,
            0xc7e120,
            0xc7e1c3,
            0xc7e1c7,
            0xc7e1c8,
            0xc7e1ca,
            0xc7e1cc,
            0xc7e1cd,
            0xc7e1cf,
            0xc7e1d3,
            0xc7e1da,
            0xc7e1de,
            0xc7e1e3,
            0xc7e1e6,
            0xc7e1ed,
            0xc7e320,
            0xc7e420,
            0xc7e4ca,
            0xc820c7,
            0xc920c7,
            0xc920dd,
            0xc920e1,
            0xc920e3,
            0xc920e6,
            0xca20c7,
            0xcf20c7,
            0xcfc920,
            0xd120c7,
            0xd1c920,
            0xd320c7,
            0xda20c7,
            0xdae1ec,
            0xdded20,
            0xe120c7,
            0xe1c920,
            0xe1ec20,
            0xe1ed20,
            0xe320c7,
            0xe3c720,
            0xe3c920,
            0xe3e420,
            0xe420c7,
            0xe520c7,
            0xe5c720,
            0xe6c7e1,
            0xe6e420,
            0xec20c7,
            0xed20c7,
            0xed20e3,
            0xed20e6,
            0xedc920,
            0xedd120,
            0xede420,
        ];
    }
    name() {
        return 'windows-1256';
    }
    language() {
        return 'ar';
    }
}
exports.windows_1256 = windows_1256;
class KOI8_R extends sbcs {
    byteMap() {
        return [
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x00,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x61,
            0x62,
            0x63,
            0x64,
            0x65,
            0x66,
            0x67,
            0x68,
            0x69,
            0x6a,
            0x6b,
            0x6c,
            0x6d,
            0x6e,
            0x6f,
            0x70,
            0x71,
            0x72,
            0x73,
            0x74,
            0x75,
            0x76,
            0x77,
            0x78,
            0x79,
            0x7a,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xa3,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xa3,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0x20,
            0xc0,
            0xc1,
            0xc2,
            0xc3,
            0xc4,
            0xc5,
            0xc6,
            0xc7,
            0xc8,
            0xc9,
            0xca,
            0xcb,
            0xcc,
            0xcd,
            0xce,
            0xcf,
            0xd0,
            0xd1,
            0xd2,
            0xd3,
            0xd4,
            0xd5,
            0xd6,
            0xd7,
            0xd8,
            0xd9,
            0xda,
            0xdb,
            0xdc,
            0xdd,
            0xde,
            0xdf,
            0xc0,
            0xc1,
            0xc2,
            0xc3,
            0xc4,
            0xc5,
            0xc6,
            0xc7,
            0xc8,
            0xc9,
            0xca,
            0xcb,
            0xcc,
            0xcd,
            0xce,
            0xcf,
            0xd0,
            0xd1,
            0xd2,
            0xd3,
            0xd4,
            0xd5,
            0xd6,
            0xd7,
            0xd8,
            0xd9,
            0xda,
            0xdb,
            0xdc,
            0xdd,
            0xde,
            0xdf,
        ];
    }
    ngrams() {
        return [
            0x20c4cf,
            0x20c920,
            0x20cbc1,
            0x20cbcf,
            0x20cec1,
            0x20cec5,
            0x20cfc2,
            0x20d0cf,
            0x20d0d2,
            0x20d2c1,
            0x20d3cf,
            0x20d3d4,
            0x20d4cf,
            0x20d720,
            0x20d7cf,
            0x20dac1,
            0x20dcd4,
            0x20ded4,
            0xc1cec9,
            0xc1d4d8,
            0xc5ccd8,
            0xc5cec9,
            0xc5d3d4,
            0xc5d420,
            0xc7cf20,
            0xc920d0,
            0xc9c520,
            0xc9c920,
            0xc9d120,
            0xccc5ce,
            0xccc920,
            0xccd8ce,
            0xcec120,
            0xcec520,
            0xcec9c5,
            0xcec9d1,
            0xcecf20,
            0xcecfd7,
            0xcf20d0,
            0xcf20d3,
            0xcf20d7,
            0xcfc7cf,
            0xcfca20,
            0xcfccd8,
            0xcfcd20,
            0xcfd3d4,
            0xcfd720,
            0xcfd7c1,
            0xd0cfcc,
            0xd0d2c5,
            0xd0d2c9,
            0xd0d2cf,
            0xd2c1d7,
            0xd2c5c4,
            0xd3d120,
            0xd3d4c1,
            0xd3d4c9,
            0xd3d4d7,
            0xd4c5cc,
            0xd4cf20,
            0xd4cfd2,
            0xd4d820,
            0xd9c820,
            0xded4cf,
        ];
    }
    name() {
        return 'KOI8-R';
    }
    language() {
        return 'ru';
    }
}
exports.KOI8_R = KOI8_R;
//# sourceMappingURL=sbcs.js.map

/***/ }),

/***/ 4412:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var match = __webpack_require__(4408).default;
class ISO_2022 {
    constructor() {
        this.escapeSequences = [];
    }
    name() {
        return 'ISO_2022';
    }
    match(det) {
        var i, j;
        var escN;
        var hits = 0;
        var misses = 0;
        var shifts = 0;
        var quality;
        var text = det.fInputBytes;
        var textLen = det.fInputLen;
        scanInput: for (i = 0; i < textLen; i++) {
            if (text[i] == 0x1b) {
                checkEscapes: for (escN = 0; escN < this.escapeSequences.length; escN++) {
                    var seq = this.escapeSequences[escN];
                    if (textLen - i < seq.length)
                        continue checkEscapes;
                    for (j = 1; j < seq.length; j++)
                        if (seq[j] != text[i + j])
                            continue checkEscapes;
                    hits++;
                    i += seq.length - 1;
                    continue scanInput;
                }
                misses++;
            }
            if (text[i] == 0x0e || text[i] == 0x0f)
                shifts++;
        }
        if (hits == 0)
            return null;
        quality = (100 * hits - 100 * misses) / (hits + misses);
        if (hits + shifts < 5)
            quality -= (5 - (hits + shifts)) * 10;
        return quality <= 0 ? null : match(det, this, quality);
    }
}
class ISO_2022_JP extends ISO_2022 {
    constructor() {
        super(...arguments);
        this.escapeSequences = [
            [0x1b, 0x24, 0x28, 0x43],
            [0x1b, 0x24, 0x28, 0x44],
            [0x1b, 0x24, 0x40],
            [0x1b, 0x24, 0x41],
            [0x1b, 0x24, 0x42],
            [0x1b, 0x26, 0x40],
            [0x1b, 0x28, 0x42],
            [0x1b, 0x28, 0x48],
            [0x1b, 0x28, 0x49],
            [0x1b, 0x28, 0x4a],
            [0x1b, 0x2e, 0x41],
            [0x1b, 0x2e, 0x46],
        ];
    }
    name() {
        return 'ISO-2022-JP';
    }
}
exports.ISO_2022_JP = ISO_2022_JP;
class ISO_2022_KR extends ISO_2022 {
    constructor() {
        super(...arguments);
        this.escapeSequences = [[0x1b, 0x24, 0x29, 0x43]];
    }
    name() {
        return 'ISO-2022-KR';
    }
}
exports.ISO_2022_KR = ISO_2022_KR;
class ISO_2022_CN extends ISO_2022 {
    constructor() {
        super(...arguments);
        this.escapeSequences = [
            [0x1b, 0x24, 0x29, 0x41],
            [0x1b, 0x24, 0x29, 0x47],
            [0x1b, 0x24, 0x2a, 0x48],
            [0x1b, 0x24, 0x29, 0x45],
            [0x1b, 0x24, 0x2b, 0x49],
            [0x1b, 0x24, 0x2b, 0x4a],
            [0x1b, 0x24, 0x2b, 0x4b],
            [0x1b, 0x24, 0x2b, 0x4c],
            [0x1b, 0x24, 0x2b, 0x4d],
            [0x1b, 0x4e],
            [0x1b, 0x4f],
        ];
    }
    name() {
        return 'ISO-2022-CN';
    }
}
exports.ISO_2022_CN = ISO_2022_CN;
//# sourceMappingURL=iso2022.js.map

/***/ }),

/***/ 4413:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {const fs = __webpack_require__(144),
path = __webpack_require__(64),
Readable = __webpack_require__(226).Readable,
util = __webpack_require__(81),

_ = __webpack_require__(61),

pathIsInside = __webpack_require__(4401),

PPERM_ERR = 'PPERM: insecure file access outside working directory',
FUNCTION = 'function',
DEPRECATED_SYNC_WRITE_STREAM = 'SyncWriteStream',
EXPERIMENTAL_PROMISE = 'promises',

// Use simple character check instead of regex to prevent regex attack
/**
 * Windows root directory can be of the following from
 *
 * | File System | Actual           | Modified          |
 * |-------------|------------------|-------------------|
 * | LFS (Local) | C:\Program       | /C:/Program       |
 * | UNC         | \\Server\Program | ///Server/Program |
 */
isWindowsRoot = function (path) {
  const drive = path.charAt(1);

  return path.charAt(0) === '/' && (
  drive >= 'A' && drive <= 'Z' || drive >= 'a' && drive <= 'z') &&
  path.charAt(2) === ':' ||
  path.slice(0, 3) === '///'; // Modified UNC path
};

/**
    * Postman file resolver wrapper over fs
    *
    * @param {String} workingDir
    * @param {Boolean=false} insecureFileRead
    * @param {String[]} fileWhitelist
    */
function PostmanFs(workingDir, insecureFileRead = false, fileWhitelist = []) {
  this._fs = fs;
  this._path = path;
  this.constants = this._fs.constants;

  this.workingDir = workingDir;
  this.insecureFileRead = insecureFileRead;
  this.fileWhitelist = fileWhitelist;

  this.isWindows = global.process.platform === 'win32';
}

/**
   * Private method to resole the path based based on working directory
   *
   * @param {String} relOrAbsPath - Relative or absolute path to resolve
   * @param {Boolean} insecureFileRead - Resolve path outside of working directory
   * @param {String[]} whiteList - A list of absolute path to whitelist
   *
   * @returns {String} The resolved path
   */
PostmanFs.prototype._resolve = function (relOrAbsPath, insecureFileRead, whiteList = []) {
  // Special handling for windows absolute paths to work cross platform
  this.isWindows && isWindowsRoot(relOrAbsPath) && (relOrAbsPath = relOrAbsPath.substring(1));

  // Resolve the path from the working directory. The file should always be resolved so that
  // cross os variations are mitigated
  let resolvedPath = this._path.resolve(this.workingDir, relOrAbsPath);

  // Check file is within working directory
  if (!insecureFileRead && // insecureFile read disabled
  !pathIsInside(resolvedPath, this.workingDir) && // File not inside working directory
  !_.includes(whiteList, resolvedPath)) {// File not in whitelist
    // Exit
    return;
  }

  return resolvedPath;
};

/**
    * Asynchronous path resolver function
    *
    * @param {String} relOrAbsPath - Relative or absolute path to resolve
    * @param {String|String[]} [whiteList] - A optional list of additional absolute path to whitelist
    * @param {Function} callback -
    */
PostmanFs.prototype.resolvePath = function (relOrAbsPath, whiteList, callback) {
  if (!callback && typeof whiteList === 'function') {
    callback = whiteList;
    whiteList = [];
  }

  let resolvedPath = this._resolve(relOrAbsPath, this.insecureFileRead, _.concat(this.fileWhitelist, whiteList));

  if (!resolvedPath) {
    return callback(new Error(PPERM_ERR));
  }

  return callback(null, resolvedPath);
};

/**
    * Synchronous path resolver function
    *
    * @param {String} relOrAbsPath - Relative or absolute path to resolve
    * @param {String|String[]} [whiteList] - A optional list of additional absolute path to whitelist
    *
    * @returns {String} The resolved path
    */
PostmanFs.prototype.resolvePathSync = function (relOrAbsPath, whiteList) {
  // Resolve the path from the working directory
  const resolvedPath = this._resolve(relOrAbsPath, this.insecureFileRead, _.concat(this.fileWhitelist, whiteList));

  if (!resolvedPath) {
    throw new Error(PPERM_ERR);
  }

  return resolvedPath;
};

// Attach all functions in fs to postman-fs
Object.getOwnPropertyNames(fs).map(prop => {
  // Bail-out early to prevent fs module from logging warning for deprecated and experimental methods
  if (prop === DEPRECATED_SYNC_WRITE_STREAM || prop === EXPERIMENTAL_PROMISE || typeof fs[prop] !== FUNCTION) {
    return;
  }

  PostmanFs.prototype[prop] = fs[prop];
});

// Override the required functions
PostmanFs.prototype.stat = function (path, callback) {
  this.resolvePath(path, (err, resolvedPath) => {
    if (err) {
      return callback(err);
    }

    return this._fs.stat(resolvedPath, callback);
  });
};

PostmanFs.prototype.createReadStream = function (path, options) {
  try {
    return this._fs.createReadStream(this.resolvePathSync(path), options);
  } catch (err) {
    // Create a fake read steam that emits and error and
    const ErrorReadStream = function () {
      // Replicating behavior of fs module of disabling emitClose on destroy
      Readable.call(this, { emitClose: false });

      // Emit the error event with insure file access error
      this.emit('error', new Error(PPERM_ERR));

      // Options exists and disables autoClose then don't destroy
      options && !options.autoClose || this.destroy();
    };

    util.inherits(ErrorReadStream, Readable);

    return new ErrorReadStream();
  }
};

// @note: This will always allow reading file outside of working directory. Because we
// only use this function to read certificate files in `postman-runtime` and working directory
// restrictions don't apply to certificates.
PostmanFs.prototype.readFile = function (path, ...args) {
  let resolvedPath = this._resolve(path, true);

  return this._fs.readFile(resolvedPath, ...args);
};

module.exports = PostmanFs;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(19)))

/***/ }),

/***/ 4415:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 4416:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var React = __webpack_require__(2);
var PropTypes = __webpack_require__(1649);

var ALL_INITIALIZERS = [];
var READY_INITIALIZERS = [];

function isWebpackReady(getModuleIds) {
  if (( false ? undefined : _typeof(__webpack_require__.m)) !== 'object') {
    return false;
  }

  return getModuleIds().every(function (moduleId) {
    return typeof moduleId !== 'undefined' && typeof __webpack_require__.m[moduleId] !== 'undefined';
  });
}

function load(loader) {
  var promise = loader();

  var state = {
    loading: true,
    loaded: null,
    error: null
  };

  state.promise = promise.then(function (loaded) {
    state.loading = false;
    state.loaded = loaded;
    return loaded;
  }).catch(function (err) {
    state.loading = false;
    state.error = err;
    throw err;
  });

  return state;
}

function loadMap(obj) {
  var state = {
    loading: false,
    loaded: {},
    error: null
  };

  var promises = [];

  try {
    Object.keys(obj).forEach(function (key) {
      var result = load(obj[key]);

      if (!result.loading) {
        state.loaded[key] = result.loaded;
        state.error = result.error;
      } else {
        state.loading = true;
      }

      promises.push(result.promise);

      result.promise.then(function (res) {
        state.loaded[key] = res;
      }).catch(function (err) {
        state.error = err;
      });
    });
  } catch (err) {
    state.error = err;
  }

  state.promise = Promise.all(promises).then(function (res) {
    state.loading = false;
    return res;
  }).catch(function (err) {
    state.loading = false;
    throw err;
  });

  return state;
}

function resolve(obj) {
  return obj && obj.__esModule ? obj.default : obj;
}

function render(loaded, props) {
  return React.createElement(resolve(loaded), props);
}

function createLoadableComponent(loadFn, options) {
  var _class, _temp;

  if (!options.loading) {
    throw new Error('react-loadable requires a `loading` component');
  }

  var opts = Object.assign({
    loader: null,
    loading: null,
    delay: 200,
    timeout: null,
    render: render,
    webpack: null,
    modules: null
  }, options);

  var res = null;

  function init() {
    if (!res) {
      res = loadFn(opts.loader);
    }
    return res.promise;
  }

  ALL_INITIALIZERS.push(init);

  if (typeof opts.webpack === 'function') {
    READY_INITIALIZERS.push(function () {
      if (isWebpackReady(opts.webpack)) {
        return init();
      }
    });
  }

  return _temp = _class = function (_React$Component) {
    _inherits(LoadableComponent, _React$Component);

    function LoadableComponent(props) {
      _classCallCheck(this, LoadableComponent);

      var _this = _possibleConstructorReturn(this, _React$Component.call(this, props));

      init();

      _this.state = {
        error: res.error,
        pastDelay: false,
        timedOut: false,
        loading: res.loading,
        loaded: res.loaded
      };
      return _this;
    }

    LoadableComponent.preload = function preload() {
      return init();
    };

    LoadableComponent.prototype.componentWillMount = function componentWillMount() {
      var _this2 = this;

      this._mounted = true;

      if (this.context.loadable && Array.isArray(opts.modules)) {
        opts.modules.forEach(function (moduleName) {
          _this2.context.loadable.report(moduleName);
        });
      }

      if (!res.loading) {
        return;
      }

      if (typeof opts.delay === 'number') {
        if (opts.delay === 0) {
          this.setState({ pastDelay: true });
        } else {
          this._delay = setTimeout(function () {
            _this2.setState({ pastDelay: true });
          }, opts.delay);
        }
      }

      if (typeof opts.timeout === 'number') {
        this._timeout = setTimeout(function () {
          _this2.setState({ timedOut: true });
        }, opts.timeout);
      }

      var update = function update() {
        if (!_this2._mounted) {
          return;
        }

        _this2.setState({
          error: res.error,
          loaded: res.loaded,
          loading: res.loading
        });

        _this2._clearTimeouts();
      };

      res.promise.then(function () {
        update();
      }).catch(function (err) {
        update();
        throw err;
      });
    };

    LoadableComponent.prototype.componentWillUnmount = function componentWillUnmount() {
      this._mounted = false;
      this._clearTimeouts();
    };

    LoadableComponent.prototype._clearTimeouts = function _clearTimeouts() {
      clearTimeout(this._delay);
      clearTimeout(this._timeout);
    };

    LoadableComponent.prototype.render = function render() {
      if (this.state.loading || this.state.error) {
        return React.createElement(opts.loading, {
          isLoading: this.state.loading,
          pastDelay: this.state.pastDelay,
          timedOut: this.state.timedOut,
          error: this.state.error
        });
      } else if (this.state.loaded) {
        return opts.render(this.state.loaded, this.props);
      } else {
        return null;
      }
    };

    return LoadableComponent;
  }(React.Component), _class.contextTypes = {
    loadable: PropTypes.shape({
      report: PropTypes.func.isRequired
    })
  }, _temp;
}

function Loadable(opts) {
  return createLoadableComponent(load, opts);
}

function LoadableMap(opts) {
  if (typeof opts.render !== 'function') {
    throw new Error('LoadableMap requires a `render(loaded, props)` function');
  }

  return createLoadableComponent(loadMap, opts);
}

Loadable.Map = LoadableMap;

var Capture = function (_React$Component2) {
  _inherits(Capture, _React$Component2);

  function Capture() {
    _classCallCheck(this, Capture);

    return _possibleConstructorReturn(this, _React$Component2.apply(this, arguments));
  }

  Capture.prototype.getChildContext = function getChildContext() {
    return {
      loadable: {
        report: this.props.report
      }
    };
  };

  Capture.prototype.render = function render() {
    return React.Children.only(this.props.children);
  };

  return Capture;
}(React.Component);

Capture.propTypes = {
  report: PropTypes.func.isRequired
};
Capture.childContextTypes = {
  loadable: PropTypes.shape({
    report: PropTypes.func.isRequired
  }).isRequired
};


Loadable.Capture = Capture;

function flushInitializers(initializers) {
  var promises = [];

  while (initializers.length) {
    var init = initializers.pop();
    promises.push(init());
  }

  return Promise.all(promises).then(function () {
    if (initializers.length) {
      return flushInitializers(initializers);
    }
  });
}

Loadable.preloadAll = function () {
  return new Promise(function (resolve, reject) {
    flushInitializers(ALL_INITIALIZERS).then(resolve, reject);
  });
};

Loadable.preloadReady = function () {
  return new Promise(function (resolve, reject) {
    // We always will resolve, errors should be handled within loading UIs.
    flushInitializers(READY_INITIALIZERS).then(resolve, resolve);
  });
};

module.exports = Loadable;

/***/ }),

/***/ 62:
/***/ (function(module, exports) {

module.exports = require("electron");

/***/ }),

/***/ 64:
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),

/***/ 740:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _modules_services_DBResourceWatcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(741);


/**
                                                                           *
                                                                           */
function bootWLModels(cb) {
  _modules_services_DBResourceWatcher__WEBPACK_IMPORTED_MODULE_0__["default"].subscribeToEventBus();
  pm.logger.info('DBWatcher~boot - Success');
  cb();
}

/* harmony default export */ __webpack_exports__["default"] = (bootWLModels);

/***/ }),

/***/ 86:
/***/ (function(module, exports) {

module.exports = require("os");

/***/ }),

/***/ 9:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async_series__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _boot_bootConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(60);
/* harmony import */ var _boot_bootConfig__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_boot_bootConfig__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _boot_bootLogger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63);
/* harmony import */ var _boot_bootMessaging__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(204);
/* harmony import */ var _boot_bootWLModels__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(212);
/* harmony import */ var _boot_bootDBWatcher__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(740);
/* harmony import */ var _boot_bootAppModels__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(743);
/* harmony import */ var _boot_bootSettings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4243);
/* harmony import */ var _boot_bootTelemetry__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4246);
/* harmony import */ var _boot_bootCrashReporter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4248);
/* harmony import */ var _boot_bootIndependentServices__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4283);
/* harmony import */ var _boot_bootSession__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4293);
/* harmony import */ var _boot_bootRequester__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4294);
/* harmony import */ var _boot_booted__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4329);
/* harmony import */ var _boot_bootThemeManager__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4330);
/* harmony import */ var _boot_bootConfigurations__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4337);
/* harmony import */ var _runtime_api_AgentManager__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4345);
/* harmony import */ var _utils_DisableProcessThrottling__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4414);




















const windowConfig = {
  process: 'requester',
  ui: true };


window.pm = {};

pm.init = done => {
  async_series__WEBPACK_IMPORTED_MODULE_0___default()([
  _boot_bootConfig__WEBPACK_IMPORTED_MODULE_1___default.a.init(windowConfig),
  _boot_bootLogger__WEBPACK_IMPORTED_MODULE_2__["default"],
  _boot_bootMessaging__WEBPACK_IMPORTED_MODULE_3__["default"],
  _boot_bootCrashReporter__WEBPACK_IMPORTED_MODULE_9__["default"],
  _boot_bootTelemetry__WEBPACK_IMPORTED_MODULE_8__["default"],
  _boot_bootConfigurations__WEBPACK_IMPORTED_MODULE_15__["initializeConfigurations"],
  _boot_bootSettings__WEBPACK_IMPORTED_MODULE_7__["default"],
  _boot_bootWLModels__WEBPACK_IMPORTED_MODULE_4__["default"],
  _boot_bootSession__WEBPACK_IMPORTED_MODULE_11__["bootSession"],
  _boot_bootIndependentServices__WEBPACK_IMPORTED_MODULE_10__["default"],
  _boot_bootAppModels__WEBPACK_IMPORTED_MODULE_6__["default"],
  _runtime_api_AgentManager__WEBPACK_IMPORTED_MODULE_16__["default"],
  _boot_bootDBWatcher__WEBPACK_IMPORTED_MODULE_5__["default"],
  _boot_bootThemeManager__WEBPACK_IMPORTED_MODULE_14__["default"],
  _boot_bootRequester__WEBPACK_IMPORTED_MODULE_12__["default"]],
  err => {
    Object(_boot_booted__WEBPACK_IMPORTED_MODULE_13__["default"])(err);
    if (err) {
      pm.logger.error('Error in requester boot sequence', err);
    }

    // Disabling throttling for this process. This is to prevent electron from
    // throttling actions for this process even if it is running in the background
    Object(_utils_DisableProcessThrottling__WEBPACK_IMPORTED_MODULE_17__["default"])();

    done && done(err);
  });
};

/* harmony default export */ __webpack_exports__["default"] = (pm);

/***/ })

/******/ });