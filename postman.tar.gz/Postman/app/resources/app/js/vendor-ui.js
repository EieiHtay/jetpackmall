(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[8],{

/***/ 4284:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_, process) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Shortcuts; });
/* harmony import */ var _ShortcutsList__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4285);
/* harmony import */ var _constants_SettingsTypeConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2876);
/* harmony import */ var _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(774);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1545);
/* harmony import */ var _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2114);
/* harmony import */ var _api_dev_services_SaveAsNewAPIService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1550);
/* harmony import */ var _modules_view_manager_ActiveViewManager__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1796);
/* harmony import */ var _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1540);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};











const SHORTCUT_THROTTLE_INTERVAL = 500;

let throttledUndoClose = _.throttle(_services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].undoClose, SHORTCUT_THROTTLE_INTERVAL);

/**
                                                                                           * Save API Schema
                                                                                           * @param {Object} editor Editor Model. In this case - APIEditorModel
                                                                                           */
function saveAPISchema(editor) {
  let schemaStore = _.get(editor, 'apiTabStore.model.activeVersion.schema');
  schemaStore && schemaStore.saveSchema(editor.getViewModel('schema'), editor.getViewModel('activeType'), editor.getViewModel('activeLanguage')).
  then(() => {
    editor.setBaseResource({
      id: schemaStore.apiId,
      versionId: schemaStore.versionId,
      schemaId: schemaStore.schemaId,
      schema: editor.getViewModel('schema'),
      activeType: editor.getViewModel('activeType'),
      activeLanguage: editor.getViewModel('activeLanguage') });

    editor.resetUpdatesBuffer();
  }).
  catch(() => {});
}

function saveAsNewAPI(editor) {
  let type = editor.getViewModel('activeType'),
  language = editor.getViewModel('activeLanguage'),
  schema = editor.getViewModel('schema');

  return Object(_api_dev_services_SaveAsNewAPIService__WEBPACK_IMPORTED_MODULE_6__["default"])(type, language, schema).then(() => {
    editor.setAndPersistBaseResource({
      id: editor.apiTabStore.model.activeVersion.schema.apiId,
      versionId: editor.apiTabStore.model.activeVersion.schema.versionId,
      schemaId: editor.apiTabStore.model.activeVersion.schema.schemaId,
      schema: editor.apiTabStore.model.activeVersion.schema.schema,
      activeType: editor.apiTabStore.model.activeVersion.schema.type,
      activeLanguage: editor.apiTabStore.model.activeVersion.schema.language });

    editor.resetUpdatesBuffer();
  });
}let
Shortcuts = class Shortcuts {

  constructor() {
    const isTestChannel = window.RELEASE_CHANNEL === 'test';

    switch (process.platform) {
      case 'darwin':
        this.defaultShortcuts = Object(_ShortcutsList__WEBPACK_IMPORTED_MODULE_0__["getDarwinShortcuts"])();
        break;
      case 'win32':
        this.defaultShortcuts = Object(_ShortcutsList__WEBPACK_IMPORTED_MODULE_0__["getWindowsShortcuts"])();
        break;
      case 'linux':
        this.defaultShortcuts = Object(_ShortcutsList__WEBPACK_IMPORTED_MODULE_0__["getLinuxShortcuts"])();
        break;
      default:
        this.defaultShortcuts = Object(_ShortcutsList__WEBPACK_IMPORTED_MODULE_0__["getDarwinShortcuts"])();
        break;}


    this.handlers = _.reduce(_.keys(this.defaultShortcuts), (acc, shortcut) => {
      if (!isTestChannel && this.defaultShortcuts[shortcut].menuShortcut || !_.isFunction(this[shortcut])) {
        return acc;
      }
      return _extends({},
      acc, {
        [shortcut]: this[shortcut] });

    }, {});

    this.menuActionHandlers = {};
  }

  getShortcuts() {
    return _.reduce(this.defaultShortcuts, (finalShortcuts, shortcutObj) => {
      return _extends({},
      finalShortcuts, {
        [shortcutObj.name]: shortcutObj.shortcut });

    }, {});
  }

  handle(eventName, handler) {
    if (handler) {
      return handler;
    }

    let defaultHandler = this.handlers[eventName];
    if (defaultHandler) {
      return defaultHandler;
    }
    return _.noop;
  }

  registerMenuAction(action, handler) {
    if (this.menuActionHandlers[action]) {
      pm.logger.warn('Shortcuts~registerMenuActions: Error while registering handler - A handler for the action already exists');
      return;
    }

    this.menuActionHandlers[action] = handler;
  }

  getMenuActionHandler(action) {
    return this.menuActionHandlers[action];
  }

  checkConstraints(meta) {
    if (!meta) {
      return false;
    }

    if (meta.isGlobal) {
      return true;
    }

    let allowedViewsSet = new Set(meta.allowedViews),
    activeView = _modules_view_manager_ActiveViewManager__WEBPACK_IMPORTED_MODULE_7__["default"].activeView;

    return allowedViewsSet.has(activeView);
  }

  /** Custom handlers **/

  // Tabs
  // openNewTab, closeCurrentTab, forceCloseCurrentTab, switchToNextTab, switchToPreviousTab
  // these are handled in App.js

  switchToTab1() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(1);
  }

  switchToTab2() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(2);
  }

  switchToTab3() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(3);
  }

  switchToTab4() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(4);
  }

  switchToTab5() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(5);
  }

  switchToTab6() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(6);
  }

  switchToTab7() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(7);
  }

  switchToTab8() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusAtPosition(8);
  }

  switchToLastTab() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].focusLast();
  }

  reopenLastClosedTab() {
    throttledUndoClose();
  }

  // Request
  requestUrl() {
    pm.mediator.trigger('focusRequestUrl');
  }

  saveCurrentRequest() {
    let currentEditorId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').activeEditor;

    if (!currentEditorId) {
      return;
    }

    /**
       * Added extra handling for saving API schema with cmd+s in API tab,
       * since CustomViewsWriter does not have access to editor.
       * Editor is required to save the changes to the APISchemaStore.
       */
    let editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('EditorStore').find(currentEditorId),
    resourceURL = editor && new URL(editor.resource),
    model = resourceURL && resourceURL.pathname;

    model && model.startsWith('//') && (model = model.slice(2));
    if (model === 'api') {

      if (editor.model.isConflicted) {
        let conflictType = editor.model.conflictState && editor.model.conflictState.type;
        if (conflictType === 'deleted') {
          pm.mediator.trigger('showSwitchDeletedVersionModal',
          () => {
            return saveAsNewAPI(editor.model).then(() => {
            });
          },
          () => {
            return _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"]._close(editor);
          });

        } else if (conflictType === 'updated') {
          pm.mediator.trigger('showSwitchConflictedVersionModal',
          () => {
            return saveAPISchema(editor.model);
          },
          () => {
            return saveAsNewAPI(editor.model).then(() => {
            });
          });

        }
      } else
      {

        /**
        * added this check to prevent spamming.
        * not making save schema call when either the tab is not dirty or already a save schema call is in progress.
        */
        if (!editor.model.isDirty || _.get(editor, 'model.apiTabStore.model.activeVersion.schema.isSavingSchema')) {
          return;
        }

        return saveAPISchema(editor.model);
      }
    }

    // if editor state is dirty and the user cannot edit the request then show a modal which
    // provides option to save the request in a different collection or create a fork of the
    // collection and update the request in newly created fork
    if (model === 'request' && editor.model.isDirty && !editor.model.isEditable) {
      const requestId = editor.model.requestId,
      collectionId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RequestStore').find(requestId) &&
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RequestStore').find(requestId).collection;

      pm.mediator.trigger('showForkRecommendationModal', {
        editorId: currentEditorId,
        collectionId: collectionId });


      return;
    }

    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].requestSave({ id: currentEditorId });
  }

  saveCurrentRequestAs() {
    let currentEditorId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').activeEditor,
    editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('EditorStore').find(currentEditorId);

    if (!editor) {
      return;
    }

    _services_EditorService__WEBPACK_IMPORTED_MODULE_4__["default"].saveAs({ id: currentEditorId });
  }

  sendCurrentRequest() {
    let currentEditorId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').activeEditor,
    editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('EditorStore').find(currentEditorId);

    if (!editor || !editor.model) {
      return;
    }

    // if agent is not ready, bail
    if (!pm.runtime.agent.isReady) {
      return;
    }

    // Do not send request if the editor is in Comment Mode
    if (editor.model.getAdditionalData('commentMode')) {
      return;
    }

    let sendIndividualRequest = _.get(editor.model, 'actions.sendIndividualRequest'),
    resourceType = _.get(editor.model, 'info.model');

    resourceType === 'request' && _.isFunction(sendIndividualRequest) && sendIndividualRequest(editor.model);
  }

  sendAndDownloadCurrentRequest() {
    let currentEditorId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').activeEditor,
    editor = currentEditorId && Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('EditorStore').find(currentEditorId),
    editorModel = editor && editor.model;

    if (!editor || !editorModel) {
      return;
    }

    // if agent is not ready, bail
    if (!pm.runtime.agent.isReady) {
      return;
    }

    // Do not send request if the editor is in Comment Mode
    if (editor.model.getAdditionalData('commentMode')) {
      return;
    }

    let sendAndDownloadRequest = _.get(editorModel, 'actions.sendAndDownloadRequest'),
    resourceType = _.get(editorModel, 'info.model');

    resourceType === 'request' && _.isFunction(sendAndDownloadRequest) && sendAndDownloadRequest(editorModel);
  }


  scrollToResponse() {
    pm.mediator.trigger('handleScrollToBottomShortcut');
  }

  scrollToRequest() {
    pm.mediator.trigger('handleScrollToTopShortcut');
  }

  // Sidebar
  search() {
    pm.mediator.trigger('focusSearchBox');
  }

  toggleSidebar() {
    pm.mediator.trigger('toggleSidebar');
  }

  // Modals
  import() {
    pm.mediator.trigger('openImportModal');
  }

  manageEnvironments() {
    pm.mediator.trigger('showManageEnvironmentModal', 'Manage');
  }

  settings() {
    pm.mediator.trigger('openSettingsModal');
  }

  shortcutCheats() {
    pm.mediator.trigger('openSettingsModal', _constants_SettingsTypeConstants__WEBPACK_IMPORTED_MODULE_1__["SETTINGS_SHORTCUTS"]);
  }

  // Windows
  openCreateNewModal() {
    pm.mediator.trigger('openCreateNewXModal');
  }

  newRequesterWindow() {
    pm.mediator.trigger('newRequesterWindow');
  }

  newRunnerWindow() {
    pm.mediator.trigger('newRunnerWindow');
  }

  newConsoleWindow() {
    pm.mediator.trigger('newConsoleWindow');
  }

  toggleFindReplace() {
    const store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(_constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_8__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"]);
  }

  closeCurrentWindow() {
    pm.mediator.trigger('closeRequesterWindow');
  }

  // UI
  increaseUIZoom() {
    pm.uiZoom.increase();
  }

  decreaseUIZoom() {
    pm.uiZoom.decrease();
  }

  resetUIZoom() {
    pm.uiZoom.reset();
  }

  toggleLayout() {
    pm.app.toggleLayout();
  }

  switchPane() {
    pm.mediator.trigger('switchPane');
  }

  toggleWorkspaceView() {
    let currentView = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').viewMode;

    if (currentView === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_2__["WORKSPACE_BROWSER_VIEW"]) {
      _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_5__["default"].openBuildMode();
    } else
    {
      _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_5__["default"].openBrowseMode();
    }
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61), __webpack_require__(31)))

/***/ }),

/***/ 4285:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_, process) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDarwinShortcuts", function() { return getDarwinShortcuts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowsShortcuts", function() { return getWindowsShortcuts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLinuxShortcuts", function() { return getLinuxShortcuts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getShortcuts", function() { return getShortcuts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getShortcutByName", function() { return getShortcutByName; });
/* harmony import */ var _constants_DefaultShortcutConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4286);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};
const isDarwin = window ? _.includes(navigator.platform, 'Mac') : process.platform === 'darwin';

let getDefaultShortcuts = function () {
  return _.reduce(_constants_DefaultShortcutConstants__WEBPACK_IMPORTED_MODULE_0__["default"], (shortcuts, shortcut) => {
    return _extends({},
    shortcuts, {
      [shortcut.name]: shortcut });

  }, {});
};

let getDarwinShortcuts = function () {
  return getDefaultShortcuts();
};

let getWindowsShortcuts = function () {
  return getDefaultShortcuts();
};

let getLinuxShortcuts = function () {
  return getDefaultShortcuts();
};

let getShortcuts = function () {
  return isDarwin ? getDarwinShortcuts() : getWindowsShortcuts();
};

let getShortcutByName = function (name) {
  return isDarwin ? _.get(getDarwinShortcuts(), name + '.keyLabelDarwin') : _.get(getWindowsShortcuts(), name + '.keyLabel');
};


/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61), __webpack_require__(31)))

/***/ }),

/***/ 4286:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var DEFAULT_SHORTCUT_CONSTANTS = [
// Tabs
{
  name: 'openNewTab',
  label: 'Open New Tab',
  shortcut: 'mod+t',
  keyLabel: 'Ctrl+T',
  keyLabelDarwin: '⌘T',
  menuShortcut: true },

{
  name: 'closeCurrentTab',
  label: 'Close Tab',
  shortcut: 'mod+w',
  keyLabel: 'Ctrl+W',
  keyLabelDarwin: '⌘W',
  electronOnly: true,
  menuShortcut: true },

{
  name: 'forceCloseCurrentTab',
  label: 'Force Close Tab',
  shortcut: 'mod+alt+w',
  keyLabel: 'Ctrl+Alt+W',
  keyLabelDarwin: '⌥⌘W',
  electronOnly: true,
  menuShortcut: true },

{
  name: 'switchToNextTab',
  label: 'Switch To Next Tab',
  shortcut: ['mod+shift+]', 'ctrl+tab'],
  keyLabel: 'Ctrl+Tab',
  keyLabelDarwin: '⇧⌘ ]',
  menuShortcut: true },

{
  name: 'switchToPreviousTab',
  label: 'Switch To Previous Tab',
  shortcut: ['mod+shift+[', 'ctrl+shift+tab'],
  keyLabel: 'Ctrl+Shift+Tab',
  keyLabelDarwin: '⇧⌘ [',
  menuShortcut: true },

{
  name: 'reopenLastClosedTab',
  shortcut: 'mod+shift+t',
  keyLabel: 'Ctrl+Shift+t',
  keyLabelDarwin: '⇧⌘T',
  label: 'Reopen Last Closed Tab' },

{
  name: 'switchToTab1',
  shortcut: 'mod+1',
  keyLabel: 'Ctrl+1',
  keyLabelDarwin: '⌘1' },

{
  name: 'switchToTab2',
  shortcut: 'mod+2',
  keyLabel: 'Ctrl+2',
  keyLabelDarwin: '⌘2' },

{
  name: 'switchToTab3',
  shortcut: 'mod+3',
  keyLabel: 'Ctrl+3',
  keyLabelDarwin: '⌘3' },

{
  name: 'switchToTab4',
  shortcut: 'mod+4',
  keyLabel: 'Ctrl+4',
  keyLabelDarwin: '⌘4' },

{
  name: 'switchToTab5',
  shortcut: 'mod+5',
  keyLabel: 'Ctrl+5',
  keyLabelDarwin: '⌘5' },

{
  name: 'switchToTab6',
  shortcut: 'mod+6',
  keyLabel: 'Ctrl+6',
  keyLabelDarwin: '⌘6' },

{
  name: 'switchToTab7',
  shortcut: 'mod+7',
  keyLabel: 'Ctrl+7',
  keyLabelDarwin: '⌘7' },

{
  name: 'switchToTab8',
  shortcut: 'mod+8',
  keyLabel: 'Ctrl+8',
  keyLabelDarwin: '⌘8' },

{
  name: 'switchToLastTab',
  label: 'Switch To Last Tab',
  shortcut: 'mod+9',
  keyLabel: 'Ctrl+9',
  keyLabelDarwin: '⌘9' },


// Request
{
  name: 'requestUrl',
  label: 'Request URL',
  shortcut: 'mod+l',
  keyLabel: 'Ctrl+L',
  keyLabelDarwin: '⌘L' },

{
  name: 'saveCurrentRequest',
  label: 'Save Request',
  shortcut: 'mod+s',
  keyLabel: 'Ctrl+S',
  keyLabelDarwin: '⌘S' },

{
  name: 'saveCurrentRequestAs',
  label: 'Save Request As',
  shortcut: 'mod+shift+s',
  keyLabel: 'Ctrl+Shift+S',
  keyLabelDarwin: '⇧⌘S' },

{
  name: 'sendCurrentRequest',
  label: 'Send Request',
  shortcut: 'mod+enter',
  keyLabel: 'Ctrl+Enter',
  keyLabelDarwin: '⌘↵' },

{
  name: 'sendAndDownloadCurrentRequest',
  label: 'Send And Download Request',
  shortcut: 'mod+alt+enter',
  keyLabel: 'Ctrl+Alt+Enter',
  keyLabelDarwin: '⌥⌘↵' },

{
  name: 'scrollToRequest',
  label: 'Scroll To Request',
  shortcut: 'mod+alt+up',
  keyLabel: 'Ctrl+Alt+↑',
  keyLabelDarwin: '⌥⌘↑' },

{
  name: 'scrollToResponse',
  label: 'Scroll To Response',
  shortcut: 'mod+alt+down',
  keyLabel: 'Ctrl+Alt+↓',
  keyLabelDarwin: '⌥⌘↓' },


// Sidebar
{
  name: 'search',
  label: 'Search Sidebar',
  shortcut: 'mod+f',
  keyLabel: 'Ctrl+F',
  keyLabelDarwin: '⌘F' },

{
  name: 'toggleSidebar',
  label: 'Toggle Sidebar',
  shortcut: 'mod+\\',
  keyLabel: 'Ctrl+\\',
  keyLabelDarwin: '⌘\\',
  menuShortcut: true },

{
  name: 'select',
  label: 'Select Item',
  shortcut: 'enter',
  keyLabel: 'Enter',
  keyLabelDarwin: '↵' },

{
  name: 'nextItem',
  label: 'Next Item',
  shortcut: 'down',
  keyLabel: '↓',
  keyLabelDarwin: '↓' },

{
  name: 'prevItem',
  label: 'Previous Item',
  shortcut: 'up',
  keyLabel: '↑',
  keyLabelDarwin: '↑' },

{
  name: 'expandItem',
  label: 'Expand Item',
  shortcut: 'right',
  keyLabel: '→',
  keyLabelDarwin: '→' },

{
  name: 'collapseItem',
  label: 'Collapse Item',
  shortcut: 'left',
  keyLabel: '←',
  keyLabelDarwin: '←' },

{
  name: 'rename',
  label: 'Rename Item',
  shortcut: 'mod+e',
  keyLabel: 'Ctrl+E',
  keyLabelDarwin: '⌘E' },

{
  name: 'groupItems',
  label: 'Group Items',
  shortcut: 'mod+g',
  keyLabel: 'Ctrl+G',
  keyLabelDarwin: '⌘G' },

{
  name: 'moveItemUp',
  label: 'Move Item Up',
  shortcut: 'mod+shift+up',
  keyLabel: 'Ctrl + Shift + ↑',
  keyLabelDarwin: '⇧⌘↑' },

{
  name: 'moveItemDown',
  label: 'Move Item Down',
  shortcut: 'mod+shift+down',
  keyLabel: 'Ctrl + Shift + ↓',
  keyLabelDarwin: '⇧⌘↓' },

{
  name: 'cut',
  label: 'Cut Item',
  shortcut: 'mod+x',
  keyLabel: 'Ctrl+X',
  keyLabelDarwin: '⌘X' },

{
  name: 'copy',
  label: 'Copy Item',
  shortcut: 'mod+c',
  keyLabel: 'Ctrl+C',
  keyLabelDarwin: '⌘C' },

{
  name: 'paste',
  label: 'Paste Item',
  shortcut: 'mod+v',
  keyLabel: 'Ctrl+V',
  keyLabelDarwin: '⌘V' },

{
  name: 'duplicate',
  label: 'Duplicate Item',
  shortcut: 'mod+d',
  keyLabel: 'Ctrl+D',
  keyLabelDarwin: '⌘D' },

{
  name: 'delete',
  label: 'Delete Item',
  shortcut: ['del', 'backspace'],
  keyLabel: 'Del',
  keyLabelDarwin: '⌫' },

{
  name: 'multiselectNextItem',
  shortcut: 'shift+down',
  keyLabel: 'Shift+↓',
  keyLabelDarwin: '⇧↓' },

{
  name: 'multiselectPrevItem',
  shortcut: 'shift+up',
  keyLabel: 'Shift+↑',
  keyLabelDarwin: '⇧↑' },


// Windows & Modals
{
  name: 'toggleFindReplace',
  label: 'Find',
  shortcut: 'mod+shift+f',
  keyLabel: 'Ctrl+Shift+F',
  keyLabelDarwin: '⇧⌘F' },

{
  name: 'import',
  label: 'Import',
  shortcut: 'mod+o',
  keyLabel: 'Ctrl+O',
  keyLabelDarwin: '⌘O',
  menuShortcut: true },

{
  name: 'manageEnvironments',
  label: 'Manage Environments',
  shortcut: 'mod+alt+e',
  keyLabel: 'Ctrl+Alt+E',
  keyLabelDarwin: '⌥⌘E' },

{
  name: 'settings',
  label: 'Settings',
  shortcut: 'mod+,',
  keyLabel: 'Ctrl+,',
  keyLabelDarwin: '⌘,',
  menuShortcut: true },

{
  name: 'shortcutCheats',
  label: 'Open Shortcut Help',
  shortcut: 'mod+/',
  keyLabel: 'Ctrl+/',
  keyLabelDarwin: '⌘/' },

{
  name: 'openCreateNewModal',
  label: 'New...',
  shortcut: 'mod+n',
  keyLabel: 'Ctrl+N',
  keyLabelDarwin: '⌘N',
  menuShortcut: true },

{
  name: 'newConsoleWindow',
  label: 'New Console Window',
  shortcut: 'mod+alt+c',
  keyLabel: 'Ctrl+Alt+C',
  keyLabelDarwin: '⌥⌘C',
  menuShortcut: true },

{
  name: 'newRequesterWindow',
  label: 'New Postman Window',
  shortcut: 'mod+shift+n',
  keyLabel: 'Ctrl+Shift+N',
  keyLabelDarwin: '⇧⌘N',
  menuShortcut: true },

{
  name: 'newRunnerWindow',
  label: 'New Runner Window',
  shortcut: 'mod+shift+r',
  keyLabel: 'Ctrl+Shift+R',
  keyLabelDarwin: '⇧⌘R',
  menuShortcut: true },


// Interface
{
  name: 'increaseUIZoom',
  label: 'Zoom In',
  shortcut: 'mod+=',
  keyLabel: 'Ctrl++',
  keyLabelDarwin: '⌘+',
  menuShortcut: true },

{
  name: 'decreaseUIZoom',
  label: 'Zoom Out',
  shortcut: 'mod+-',
  keyLabel: 'Ctrl+-',
  keyLabelDarwin: '⌘-',
  menuShortcut: true },

{
  name: 'resetUIZoom',
  label: 'Reset Zoom',
  shortcut: 'mod+0',
  keyLabel: 'Ctrl+0',
  keyLabelDarwin: '⌘0' },

{
  name: 'toggleLayout',
  label: 'Toggle Two-Pane View',
  shortcut: 'mod+alt+v',
  keyLabel: 'Ctrl+Alt+V',
  keyLabelDarwin: '⌥⌘V',
  menuShortcut: true },

{
  name: 'switchPane',
  shortcut: 'mod+alt+tab',
  keyLabel: 'Ctrl+Alt+Tab',
  keyLabelDarwin: '⌥⌘Tab' },

{
  name: 'submit',
  label: 'Submit Modal',
  shortcut: 'mod+enter',
  keyLabel: 'Ctrl+↵',
  keyLabelDarwin: '⌘↵' },

{
  name: 'quit',
  label: 'Quit Modal',
  shortcut: 'esc',
  keyLabel: 'Esc',
  keyLabelDarwin: 'esc' },

{
  name: 'space',
  label: 'Space',
  shortcut: 'space',
  keyLabel: 'space',
  keyLabelDarwin: 'space' },

{
  name: 'focusNext',
  label: 'Focus Next Item',
  shortcut: 'tab',
  keyLabel: 'tab',
  keyLabelDarwin: 'tab' },

{
  name: 'leftCell',
  shortcut: 'left' },

{
  name: 'rightCell',
  shortcut: 'right' },

{
  name: 'upCell',
  shortcut: 'up' },

{
  name: 'downCell',
  shortcut: 'down' },

{
  name: 'tabCell',
  shortcut: 'tab' },

{
  name: 'shiftTabCell',
  shortcut: 'shift+tab' },

{
  name: 'shiftUpSelect',
  shortcut: 'shift+up' },

{
  name: 'shiftDownSelect',
  shortcut: 'shift+down' },

{
  name: 'shiftLeftSelect',
  shortcut: 'shift+left' },

{
  name: 'shiftRightSelect',
  shortcut: 'shift+right' },

{
  name: 'onEscape',
  shortcut: 'esc' },

{
  name: 'toggleWorkspaceView',
  label: 'Switch Workspace View',
  shortcut: 'mod+.',
  keyLabel: 'Ctrl+.',
  keyLabelDarwin: '⌘.',
  electronOnly: true }];



/* harmony default export */ __webpack_exports__["default"] = (DEFAULT_SHORTCUT_CONSTANTS);

/***/ }),

/***/ 4287:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ToastManager; });
let ToastManager = class ToastManager {
  constructor() {
    this.notificationQueue = [];
    this.isPaused = false;
  }

  isVisible() {
    var notifs = !document.getElementsByClassName('notification'),
    tooltips = !document.getElementsByClassName('tooltip'),
    fullscreenModals = !document.getElementsByClassName('modal-fullscreen');

    return !(notifs && tooltips && fullscreenModals);
  }

  enqueue(callback, priority) {
    this.notificationQueue.push({
      callback: callback,
      priority: priority });


    this.process();
  }

  dequeue() {
    var minPriority = _.min(_.map(this.notificationQueue, 'priority'));
    var toRunIndex = _.findKey(this.notificationQueue, function (element) {
      return element.priority === minPriority;
    });
    return this.notificationQueue.splice(toRunIndex, 1)[0];
  }

  process() {
    if (this.isVisible() || this.isPaused) {
      setTimeout(() => {
        this.process();
      }, 1000); // Try again after 1 second
    } else
    {
      this.isPaused = true;
      this.dequeue().callback();

      setTimeout(() => {
        this.isPaused = false;
      }, 2000); // Separation between notifications
    }
  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4291:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEventBus", function() { return getEventBus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setNotificationComponent", function() { return setNotificationComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachLinkListeners", function() { return attachLinkListeners; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRef", function() { return getRef; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_getBaseOptions", function() { return _getBaseOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_show", function() { return _show; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "error", function() { return error; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "info", function() { return info; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "success", function() { return success; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warn", function() { return warn; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_sanitise_user_content__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1123);
/* harmony import */ var _postman_sanitise_user_content__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_sanitise_user_content__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_DashboardService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2078);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(612);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_messaging_Toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4292);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1222);








const getEventBus = function () {
  if (!this.eventBusChannel) this.eventBusChannel = pm.eventBus.channel('notifications');
  return this.eventBusChannel;
};

const setNotificationComponent = function (ref) {
  this._ref = ref;
  this.attachLinkListeners();

  // Listen for notifications from windows with no UI
  if (_.get(pm, 'windowConfig.ui')) {
    this.getEventBus().subscribe(options => {
      this._show(options);
    });
  }
};

const attachLinkListeners = function () {
  if (!this._ref) {
    return;
  }

  let notificationWrapper = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this._ref);
  if (!notificationWrapper) {
    return;
  }

  notificationWrapper.addEventListener('click', e => {
    let classList = e.target.classList,
    allowClicks = ['toast-dismiss', 'toast-primary-action', 'toast-secondary-action'];

    if (_.isEmpty(_.intersection(classList, allowClicks))) {
      // This check is there if the target is SVG (close icon)
      // and its parent is 'toast-dismiss'
      const maxParentNodeLookupCount = 4;
      let currentTarget = e.target,
      targetClass = currentTarget.className,
      notificationClass = 'notifications-wrapper',
      lookUpCount = 0;

      while (targetClass && targetClass !== notificationClass) {
        if (lookUpCount > maxParentNodeLookupCount) {
          break;
        }

        // Do not prevent if the icon is a child node of toast-dismiss
        if (targetClass === 'toast-dismiss') {
          return;
        }

        currentTarget = _.get(currentTarget, 'parentNode', null);
        targetClass = _.get(currentTarget, 'className', null);
        lookUpCount++;
      }

      e.preventDefault();
      e.stopPropagation();
    }

    if (e.target.tagName !== 'A') {
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    let link = e.target.href;
    if (link) {
      Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__["openExternalLink"])(link);
    } else
    {
      try {
        let slug = e.target.dataset.slug;
        if (slug === 'invite_users') {
          Object(_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["openInviteUsers"])();
        }
      }
      catch (e) {
        pm.logger.error(e);
      }
    }
  });
};

const getRef = function () {
  return this._ref;
};

const _getBaseOptions = function (persist, timeout) {
  return {
    position: 'tr',
    dismissible: true,
    autoDismiss: persist ? 0 : timeout };

};

/**
    * Returns level for type for the react notification system
    *
    * @param {*} type
    */
function getLevelForType(type) {
  let map = {
    success: 'success',
    error: 'error',
    warn: 'warning',
    info: 'info' };

  return map[type];
}

const _show = function (options) {
  if (!this._ref) {
    _.get(pm, 'windowConfig.ui') ? pm.logger.error('Notification System not initialized') : this.getEventBus().publish(options);
    return;
  }

  let {
    type = 'info',
    message,
    dedupeId,
    primaryAction = null,
    secondaryAction = null,
    persist = false,
    timeout = 3000,
    title = null,
    primaryButtonLabel = '',
    secondaryButtonLabel = '',
    enableActions = null,
    noIcon = false,
    isDismissable = true,
    onDismiss = null,
    onView = _.noop,

    // HACK: quick fix for 100K. cleanup.
    skipSanitise = false } =
  options;

  // react notification system takes seconds timeout
  timeout /= 1000;
  let notificationId = uuid_v4__WEBPACK_IMPORTED_MODULE_4___default()(),
  notification = _.extend(
  this._getBaseOptions(persist, timeout), {
    uid: notificationId,
    level: getLevelForType(type),
    children:
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_messaging_Toast__WEBPACK_IMPORTED_MODULE_5__["default"], {
      isDismissable: isDismissable,
      noIcon: noIcon,
      uid: notificationId,
      dismiss: this._ref.removeNotification,
      type: type,
      title: title || null,
      message: message,
      primaryAction: primaryAction,
      secondaryAction: secondaryAction,
      onDismiss: onDismiss,
      onView: onView }) });





  if (dedupeId) {
    notification = _.extend(notification, { uid: `${getLevelForType(type)}-${dedupeId}` });
  }

  this._ref.addNotification(notification);
};

const error = function (message, options) {
  message || (message = 'Something went wrong. Please try again.');
  options || (options = {});

  this._show(
  _.extend(options, {
    type: 'error',
    message: message }));


};

const info = function (message, options) {
  if (!message) {
    return;
  }

  options || (options = {});

  this._show(
  _.extend(options, {
    type: 'info',
    message: message }));


};

const success = function (message, options) {
  if (!message) {
    return;
  }

  options || (options = {});

  this._show(
  _.extend(options, {
    type: 'success',
    message: message }));


};

const warn = function (message, options) {
  if (!message) {
    return;
  }

  options || (options = {});

  this._show(
  _.extend(options, {
    type: 'warn',
    message: message }));


};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4292:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Toast; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base_Icons_InformationIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2066);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1883);
/* harmony import */ var _base_Markdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1783);
/* harmony import */ var _services_UIEventService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1755);







let

Toast = class Toast extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor() {
    super();

    this.handlePrimaryAction = this.handlePrimaryAction.bind(this);
    this.handleSecondaryAction = this.handleSecondaryAction.bind(this);
    this.dismissToast = this.dismissToast.bind(this);
  }

  componentDidMount() {
    this.props.onView && this.props.onView();
    this.unsubscribeHandler = this.props.dismissEvent && _services_UIEventService__WEBPACK_IMPORTED_MODULE_7__["default"].subscribe(this.props.dismissEvent, this.dismissToast);
  }

  componentWillUnmount() {
    this.unsubscribeHandler && this.unsubscribeHandler();
  }

  handlePrimaryAction() {
    if (this.props.primaryAction && this.props.primaryAction.onClick) {
      this.props.primaryAction.onClick();
    }
    this.props.isDismissable && this.props.dismiss(this.props.uid);
  }

  handleSecondaryAction() {
    if (this.props.secondaryAction && this.props.secondaryAction.onClick) {
      this.props.secondaryAction.onClick();
    }
    this.props.isDismissable && this.props.dismiss(this.props.uid);
  }

  dismissToast() {
    // The notification system provides a handler
    // to remove the toast
    this.props.dismiss(this.props.uid);
    this.props.onDismiss && this.props.onDismiss(this.props.uid);
  }

  getTypeClass() {
    let typeClass = this.props.type ? `toast-${this.props.type}` : 'toast-info';
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'toast': true,
      [typeClass]: true });

  }

  getActions() {
    const { primaryAction = null, secondaryAction = null } = this.props;

    if (primaryAction || secondaryAction) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'toast-actions' },

          primaryAction &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'toast-primary-action',
              type: 'primary',
              size: 'small',
              disabled: primaryAction.disabled,
              onClick: this.handlePrimaryAction },

            primaryAction.label),



          secondaryAction &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({ 'toast-secondary-action': true, 'toast-secondary-action-only': !primaryAction }),
              type: 'text',
              disabled: secondaryAction.disabled,
              onClick: this.handleSecondaryAction },

            secondaryAction.label)));




    }
  }

  getContentClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'toast-content': true,
      'toast-content-shrink': this.props.isDismissable });

  }

  render() {
    const {
      title,
      message,
      onMessageLinkClick,
      disabled,
      isDismissable,
      noIcon } =
    this.props;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getTypeClass() },

        !noIcon &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_InformationIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'toast-icon' }),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getContentClasses() },

          title &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'toast-title' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Markdown__WEBPACK_IMPORTED_MODULE_6__["default"], {
              source: title,
              onLinkClick: onMessageLinkClick })),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'toast-body' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Markdown__WEBPACK_IMPORTED_MODULE_6__["default"], {
              source: message,
              onLinkClick: onMessageLinkClick })),


          this.getActions()),


        isDismissable &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'toast-dismiss',
            onClick: this.dismissToast },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__["default"], {
            className: 'toast-close',
            size: 'xs' }))));





  }};


Toast.defaultProps = {
  type: 'info',
  message: '',
  disabled: false,
  isDismissable: true,
  noIcon: false,
  onMessageLinkClick: null };


Toast.propTypes = {
  type: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOf(['error', 'success', 'warn', 'info']),
  message: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  isDismissable: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  noIcon: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  dismiss: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired,
  onMessageLinkClick: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func };

/***/ }),

/***/ 4293:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findSession", function() { return findSession; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearOrphanSessions", function() { return clearOrphanSessions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bootSession", function() { return bootSession; });
/* harmony import */ var _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(765);
/* harmony import */ var _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(770);
/* harmony import */ var _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(756);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(612);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(742);
/* harmony import */ var _utils_default_workspace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1234);
/* harmony import */ var _electron_ElectronService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1223);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};







let getDefaultSession = window => {
  return Object(_utils_default_workspace__WEBPACK_IMPORTED_MODULE_5__["defaultUserWorkspaceId"])().
  then(defaultWorkspaceId => {
    if (!defaultWorkspaceId) {
      return Promise.reject(new Error('Could not find default workspace while booting session'));
    }

    return _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_2__["default"].get({ id: defaultWorkspaceId });
  }).
  then(defaultWorkspace => {
    if (!defaultWorkspace) {
      return Promise.reject(new Error('Could not find default workspace while booting session'));
    }

    return defaultWorkspace;
  }).
  then(defaultWorkspace => {
    return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].
    create({
      id: uuid_v4__WEBPACK_IMPORTED_MODULE_3___default()(),
      window: window.id,
      workspace: defaultWorkspace.id,
      state: {} }).

    then(sessionCreatedEvent => {
      return Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["getEventData"])(sessionCreatedEvent);
    });
  });
};

let findSession = (window, options) => {
  return Promise.resolve()

  // First, check if this window is supposed to be opened with a workspace (New window with workspace pre-selected)
  .then(() => {
    // If this window is not being opened with a pre-selected workspace, move on
    if (!options.session || !options.session.workspace) {
      return;
    }

    // If this window is supposed to be opened with a workspace, just create the session
    // with that workspace and move on
    return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].
    getSessionFor(window.id, options.session.workspace).
    then(session => {
      // If the window is not supposed to have pre-selected state, move on
      if (!options.session.state) {
        return session;
      }

      // Otherwise, update the session's state with whatever is supplied
      return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].
      update({
        id: session.id,
        state: _extends({},
        session.state,
        options.session.state) }).


      then(sessionUpdatedEvent => {
        return Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["getEventData"])(sessionUpdatedEvent);
      });
    });
  })

  // First, check if this window is supposed to be opened with a defined session (restore flow)
  .then(session => {
    // If we've already found a session, move on
    if (session) {
      return session;
    }

    // If this window is not being restored, move on
    if (!options.session || !window.activeSession) {
      return;
    }

    return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].
    get({ id: window.activeSession }).
    then(session => {
      if (!session || session.window !== window.id) {
        return;
      }

      return session;
    });
  })

  // If the window's activeSession exists, continue, or else try finding another suitable session
  .then(session => {
    if (session) {
      return session;
    }

    // Active session on this window does not exist, trying to find some other session on this window
    return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].
    getAll({ window: pm.window.id }).
    then(allSessions => {
      if (allSessions && allSessions[0]) {
        return allSessions[0];
      }

      // There are no sessions on this window, creating one
      return getDefaultSession(window);
    });
  })

  // Verify if the session being restored points to a valid workspace.
  .then(session => {
    return _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_2__["default"].
    get({ id: session.workspace }).
    then(workspace => {
      // If the workspace being pointed to does not exist, delete this session and restart the session boot
      if (workspace) {
        return session;
      }

      return getDefaultSession(window);
    });
  });
};

let clearOrphanSessions = (activeWindowId, { activeSessionId }) => {
  // Find all sessions, if for a session, the window / workspace does not exist, delete the session
  return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].
  getAll().
  then(allSessions => {
    // First, take the currently active session out of the picture.
    // Don't want to ever delete that
    _.remove(allSessions, session => session.id === activeSessionId);
    return allSessions;
  }).
  then(allSessions => {
    // Remove all sessions with an invalid window ID
    return Promise.all(
    _.map(allSessions, session => {
      return _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0___default.a.get({ id: session.window }).
      then(window => {
        if (window) {
          return session;
        }

        return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].delete({ id: session.id }).
        then(sessionDeletedEvent => {
          return;
        }).
        catch(e => {
          pm.logger.error(`Failed to clear orphan sessions on window ${session.window}`, e);
          return session;
        });
      });
    }));

  }).
  then(sessions => {
    // Clean the result, remove all undefined values from the previous loop
    return _.compact(sessions);
  }).
  then(allSessions => {
    // Now, remove all sessions on the currentWindow, with an invalid workspace
    return Promise.all(
    _.map(allSessions, session => {
      return _modules_controllers_WorkspaceController__WEBPACK_IMPORTED_MODULE_2__["default"].get({ id: session.workspace }).
      then(workspace => {
        if (session.window === activeWindowId && !workspace) {
          return _modules_controllers_WorkspaceSessionController__WEBPACK_IMPORTED_MODULE_1__["default"].delete({ id: session.id }).
          catch(e => {
            pm.logger.error(`Failed to clear orphan sessions with workspace ${session.workspace}`, e);
          });
        }
      });
    }));

  });
};

// IMPORTANT: DO NOT REORDER PROMISES HERE
// 1. Getting launch params from window
// 2. Get / create a window
// 3. Find a suitable session (find / create). Session create should always be after window create, otherwise this might be pruned
// 4. Update the new window with the new session's ID
// 5. Complete the boot process
// 6. Start pruning orphan sessions
let bootSession = cb => {
  return Object(_electron_ElectronService__WEBPACK_IMPORTED_MODULE_6__["getLaunchParams"])()

  // First, initialize the WindowController
  .then(windowParams => {
    return _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0___default.a.bootstrap(...windowParams);
  })

  // Find the window being restored / opened
  .then(windowParams => {
    let window = windowParams[0],
    options = windowParams[1];

    return _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0___default.a.
    getCurrentWindow().
    then(currentWindow => {
      if (currentWindow) {
        return currentWindow;
      }

      // Worst case scenario
      return Promise.reject(new Error('Window to open does not exist ' + pm.window.id));
    })

    // Try to find the session that the window opened wants to open
    .then(() => findSession(...windowParams))

    // Update the Window table to indicate the new session is the active session
    .then(session => {
      return _common_controllers_WindowController__WEBPACK_IMPORTED_MODULE_0___default.a.update({
        id: window.id,
        activeSession: session.id });

    })

    // Complete the boot process
    .then(() => {
      pm.logger.info('Session~boot - Success');
      cb && cb(null);
    }).

    catch(e => {
      pm.logger.error('Session~boot - Failed', e);
      cb && cb(e);
    })

    // Prune any sessions that are invalid
    .then(() => clearOrphanSessions()).
    catch(() => {});
  });
};


/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4295:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _stores_store_handler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4296);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(742);



const STORE_HANDLER_TIMEOUT = 15 * 1000; // 15 seconds

/**
 *
 */
function bootStore(cb) {

  Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["subscribeToQueue"])(_stores_store_handler__WEBPACK_IMPORTED_MODULE_0__["handleModelEventOnStore"], STORE_HANDLER_TIMEOUT);
  pm.logger.info('Store~boot - Success');
  cb && cb(null);
}

/* harmony default export */ __webpack_exports__["default"] = (bootStore);

/***/ }),

/***/ 4296:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleModelEventOnStore", function() { return handleModelEventOnStore; });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(751);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(742);



/**
                                                                                                                         *
                                                                                                                         * @param {Object} modelEvent
                                                                                                                         */
function handleModelEventOnStore(modelEvent, callback) {
  let eventNamespace = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventNamespace"])(modelEvent),
  storeListeners = _.get(pm, ['stores', '_listeners']),
  activeListenersFor = new Set(),
  matchedListeners = [];

  // @todo: this may have issues, when a top level event does not have a store initialized
  // but low level events have stores initialized
  if (!storeListeners) {
    return callback();
  }

  storeListeners.forEach(storeListenerForNamespace => {
    _.forEach(_.keys(storeListenerForNamespace), listenerName => {
      activeListenersFor.add(listenerName);
    });
  });

  let start = performance.now();

  performance.mark(`${modelEvent.name}:${modelEvent.namespace}:${start}:start`);

  Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["processEventSync"])(modelEvent, Array.from(activeListenersFor), function processEventOnStore(event) {
    if (!storeListeners.has(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventNamespace"])(event))) {
      return;
    }
    let storeListenersForNamespace = storeListeners.get(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventNamespace"])(event)),
    action = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventName"])(event),
    listeners = storeListenersForNamespace[action];

    _.forEach(listeners, function (listener) {
      // we create new functions instead of binding
      // listener is already bound with the `store`, we can't find it, or change it
      listener && matchedListeners.push(function () {
        listener(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventData"])(event), Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventMeta"])(event), modelEvent);
      });
    });
  });

  // wrapping all the individual listeners for an event in a transactions
  Object(mobx__WEBPACK_IMPORTED_MODULE_0__["transaction"])(function () {
    // listeners are synchronous anyway
    _.forEach(matchedListeners, function invokeStoreListener(listener) {
      listener && listener();
    });
  });

  performance.mark(`${modelEvent.name}:${modelEvent.namespace}:${start}:end`);

  performance.measure(`${modelEvent.name}:${modelEvent.namespace}:measure`, `${modelEvent.name}:${modelEvent.namespace}:${start}:start`, `${modelEvent.name}:${modelEvent.namespace}:${start}:end`);

  callback();
}


/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4297:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _controllers_Shortcuts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4284);


/**
                                                      *
                                                      * @param {*} cb
                                                      */
function bootShortcuts(cb) {
  _.assign(window.pm, { shortcuts: new _controllers_Shortcuts__WEBPACK_IMPORTED_MODULE_0__["default"]() });

  // Registering menu action handlers
  pm.app.registerMenuActions();

  pm.logger.info('Shortcuts~boot - Success');
  return cb && cb(null);
}

/* harmony default export */ __webpack_exports__["default"] = (bootShortcuts);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4302:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var electron__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(62);
/* harmony import */ var electron__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(electron__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_1__);


const _ = __webpack_require__(61);

const DEFAULT_ZOOM_LEVEL = 0;

const ZOOM_SCALE_FACTORS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.8, 0.9, 1.0, 1.1, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0, 4.0, 5.0];

const MIN_ZOOM_FACTOR = _.first(ZOOM_SCALE_FACTORS),
MAX_ZOOM_FACTOR = _.last(ZOOM_SCALE_FACTORS),
DEFAULT_ZOOM_FACTOR = 1.0;

var UIZoom = backbone__WEBPACK_IMPORTED_MODULE_1___default.a.Model.extend({
  initialize: function () {
    this._loadZoomFactor();
    this.applyCurrentZoom();
  },

  increase: function () {
    let nextZoomFactor = this.getNextZoomFactor(this.currentZoomFactor);

    this._validateZoomFactor(nextZoomFactor) && this._setZoomFactor(nextZoomFactor);
    this.trigger('change');
  },

  decrease: function () {
    let previousZoomFactor = this.getPreviousZoomFactor(this.currentZoomFactor);

    this._validateZoomFactor(previousZoomFactor) && this._setZoomFactor(previousZoomFactor);
    this.trigger('change');
  },

  reset: function () {
    this._setZoomFactor(DEFAULT_ZOOM_FACTOR);
    this.trigger('change');
  },

  getNextZoomFactor: function (zoomFactor) {
    return _.find(ZOOM_SCALE_FACTORS, nextZoom => zoomFactor < nextZoom);
  },

  getPreviousZoomFactor: function (zoomFactor) {
    return _.findLast(ZOOM_SCALE_FACTORS, prevZoom => zoomFactor > prevZoom);
  },

  getMaxZoomFactor: function () {
    return MAX_ZOOM_FACTOR;
  },

  getMinZoomFactor: function () {
    return MIN_ZOOM_FACTOR;
  },

  applyCurrentZoom: function () {
    electron__WEBPACK_IMPORTED_MODULE_0__["webFrame"].setZoomFactor(this.currentZoomFactor);
  },

  _loadZoomFactor: function () {
    let initialZoomFactor = pm.settings.getSetting('zoomFactor'),
    zoomFactor = initialZoomFactor;

    if (!zoomFactor) {
      zoomFactor = this._loadZoomFactorFromLevel();
    }

    zoomFactor = this._normalizeZoomFactor(zoomFactor);
    initialZoomFactor !== zoomFactor && this._saveZoomFactor(zoomFactor);
    this.currentZoomFactor = zoomFactor;
  },

  _setZoomFactor: function (zoomFactor) {
    this.currentZoomFactor = zoomFactor;
    this.applyCurrentZoom();
    this._saveZoomFactor(this.currentZoomFactor);
  },

  _saveZoomFactor: function (zoomFactor) {
    pm.settings.setSetting('zoomFactor', zoomFactor);
  },

  _validateZoomFactor: function (zoomFactor) {
    return Number.isFinite(zoomFactor) &&
    zoomFactor <= MAX_ZOOM_FACTOR && zoomFactor >= MIN_ZOOM_FACTOR;
  },

  /**
        * This function normalizes the invalid zoomFactor to the nearest supported zoomFactor
        * @param {Number} zoomfactor
        */
  _normalizeZoomFactor: function (zoomFactor) {
    // For invalid zoom factors set to default
    if (!Number.isFinite(zoomFactor)) {
      return DEFAULT_ZOOM_FACTOR;
    }

    // Otherwise normalize to nearest supported zoom factor
    if (zoomFactor > MAX_ZOOM_FACTOR) {
      return MAX_ZOOM_FACTOR;
    } else
    if (zoomFactor < MIN_ZOOM_FACTOR) {
      return MIN_ZOOM_FACTOR;
    } else {
      return zoomFactor;
    }
  },

  getCurrentScaleFactor: function () {
    return 1 + this.currentZoomLevel * 0.05;
  },

  /**
      * Valid zoom levels in apps before v7.22.0 were in range [-10, 10]
      * The new zoom levels introduced in are in range [0, 16]
      * This function returns the zoom scale factor associated with the older zoom levels
      */
  _loadZoomFactorFromLevel: function () {
    this.currentZoomLevel = pm.settings.getSetting('uiZoom') || DEFAULT_ZOOM_LEVEL;

    return this.getCurrentScaleFactor();
  } });


/* harmony default export */ __webpack_exports__["default"] = (UIZoom);

/***/ }),

/***/ 4330:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return bootThemeManager; });
/* harmony import */ var _controllers_theme_ThemeManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1787);
/* harmony import */ var _controllers_theme_ThemeDomDelegator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4331);



/**
                                                                            * Initialize Theme Dom delegator with current theme and eventBus
                                                                            *
                                                                            * @param {*} cb
                                                                            */
function bootThemeManager(cb) {
  let currentTheme = _controllers_theme_ThemeManager__WEBPACK_IMPORTED_MODULE_0__["default"].getCurrentTheme();
  _controllers_theme_ThemeDomDelegator__WEBPACK_IMPORTED_MODULE_1__["default"].init(currentTheme);
  pm.logger.info('ThemeManager~boot - Success');
  cb && cb(null);
}

/***/ }),

/***/ 4331:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ThemeHelpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4332);
/* harmony import */ var _themes_design_system_light_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4333);
var _themes_design_system_light_json__WEBPACK_IMPORTED_MODULE_1___namespace = /*#__PURE__*/__webpack_require__.t(4333, 1);
/* harmony import */ var _themes_design_system_dark_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4334);
var _themes_design_system_dark_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(4334, 1);
/* harmony import */ var _themes_light_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4335);
var _themes_light_json__WEBPACK_IMPORTED_MODULE_3___namespace = /*#__PURE__*/__webpack_require__.t(4335, 1);
/* harmony import */ var _themes_dark_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4336);
var _themes_dark_json__WEBPACK_IMPORTED_MODULE_4___namespace = /*#__PURE__*/__webpack_require__.t(4336, 1);






const THEME_LIGHT = 'light',
THEME_DARK = 'dark';

const THEME_COLORS_MAP = {
  light: _themes_light_json__WEBPACK_IMPORTED_MODULE_3__,
  dark: _themes_dark_json__WEBPACK_IMPORTED_MODULE_4__ };


const DESIGN_SYSTEM_THEME_COLORS_MAP = {
  light: _themes_design_system_light_json__WEBPACK_IMPORTED_MODULE_1__,
  dark: _themes_design_system_dark_json__WEBPACK_IMPORTED_MODULE_2__ };


const $loader = document.getElementsByClassName('pm-loader')[0];

/**
                                                                  * Theme manager delegator to manipulate DOM
                                                                  */
/* harmony default export */ __webpack_exports__["default"] = ({

  /**
                 * Initialize the ThemeDomDeligator
                 * Removes the old theme and updates new theme to the dom
                 * Attaches handler to event themeChanged
                 * @param {string} theme - The name of the theme
                 * @param {Object} eventBus
                 * @public
                 */
  init(theme) {
    this._applyTheme(theme);
    this._subscribeThemeChange();
    this._hideLoading();
  },

  /**
     * Removes the old theme and initiate the theme updation process
     * @param {String} theme- The name of theme to be applied
     * @private
     */
  _applyTheme(theme) {
    let currentTheme = theme;
    currentTheme = currentTheme === THEME_LIGHT || currentTheme === THEME_DARK ? currentTheme : THEME_LIGHT;
    this._useTheme(currentTheme);
    this._triggerMediator(currentTheme);
    this._addThemeClass(currentTheme);
  },

  /**
     * Attaches a handler to themeChanged event
     * @param {Object} eventBus
     * @private
     */
  _subscribeThemeChange() {
    let appEventsChannel = pm.eventBus.channel('theme-events');
    appEventsChannel.subscribe(event => {
      if (event.name === 'themeChanged') {
        this._applyTheme(event.data.apptheme.currentTheme);
        pm.settings._updateCache('postmanTheme', event.data.apptheme.currentTheme);
      }
    });
  },

  /**
     * Adds the current theme name to app root level class
     * @param {String} theme- The name of theme to be added
     * @private
     */
  _addThemeClass(theme) {
    let rootEl = document.getElementsByClassName('app-root')[0];
    rootEl.dataset.theme = theme;
  },

  /**
     * Uses the given theme
     * @param {string} theme- The name of theme
     * @private
     */
  _useTheme(theme) {
    let themeColors = THEME_COLORS_MAP[theme];
    let designSystemThemeColors = DESIGN_SYSTEM_THEME_COLORS_MAP[theme];
    let style = document.getElementById('theme');
    style.innerHTML = `
      :root {
        ${Object(_ThemeHelpers__WEBPACK_IMPORTED_MODULE_0__["generateCSSVariables"])(themeColors)}
        ${Object(_ThemeHelpers__WEBPACK_IMPORTED_MODULE_0__["populateThemedDesignTokens"])(designSystemThemeColors)}
      }
    `;
  },

  /* TODO:  Need to move this to store and observe on reactions */
  _triggerMediator(theme) {
    if (pm.mediator) {
      pm.mediator.trigger('themeChange', theme);
    }
  },

  _hideLoading() {
    $loader && $loader.classList.add('is-hidden');
  } });

/***/ }),

/***/ 4332:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lighten", function() { return lighten; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "darken", function() { return darken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isLightColor", function() { return isLightColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hexToRGB", function() { return hexToRGB; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateCSSVariables", function() { return generateCSSVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "populateThemedDesignTokens", function() { return populateThemedDesignTokens; });
/**
 * To lighten or darken a color
 *
 * HEX --> RGB --> HSL -->   Change L value   --> RGB --> HEX
 *                          by given shade %
 *
 *
 */

const shades = {
  one: 0.04,
  two: 0.08,
  three: 0.15,
  four: 0.25 },

highlightOpacity = 0.2;


/**
                         *
                         * @param {*} hex
                         */
function hexToHSL(hex) {
  let { r, g, b } = hexToRGB(hex),
  max = 0,
  min = 0;

  r /= 255, g /= 255, b /= 255,
  max = Math.max(r, g, b),
  min = Math.min(r, g, b);

  var h,
  s,
  l = (max + min) / 2;
  if (max == min) {
    h = s = 0; // achromatic
  } else
  {
    var d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;}

    h /= 6;
  }

  return { h, s, l };
}

/**
   * hue to rgb
   */
function _hue2rgb(p, q, t) {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;

  return p;
}

/**
   * RGB to HEX
   */
function _rgbToHex(rgb) {
  var hex = Number(rgb).toString(16);
  if (hex.length < 2) {
    hex = '0' + hex;
  }
  return hex;
}

/**
   * HSL to HEX
   */
function hslToHEX(h, s, l) {
  var r, g, b;
  if (l < 0) {
    l = 0;
  }
  if (l > 1) {
    l = 1;
  }
  if (s == 0) {
    r = g = b = l; // achromatic
  } else {
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    var p = 2 * l - q;
    r = _hue2rgb(p, q, h + 1 / 3);
    g = _hue2rgb(p, q, h);
    b = _hue2rgb(p, q, h - 1 / 3);
  }

  r = Math.round(r * 255);
  g = Math.round(g * 255);
  b = Math.round(b * 255);

  return `#${_rgbToHex(r)}${_rgbToHex(g)}${_rgbToHex(b)}`;
}

/**
   * Lighten the color by given percentage
   */
function lighten(color, percentage) {
  let hsl = hexToHSL(color);
  return hslToHEX(hsl.h, hsl.s, hsl.l + percentage);
}

/**
   * Darken the color by given percentage
   */
function darken(color, percentage) {
  let hsl = hexToHSL(color);
  return hslToHEX(hsl.h, hsl.s, hsl.l - percentage);
}

/**
   * Check if color is perceived as light color
   *  https://en.wikipedia.org/wiki/Luma_(video)
   */
function isLightColor({ r, g, b }) {
  0.2126 * r + 0.7152 * g + 0.0722 * b > 180;
}

/**
   * Convert hex to hexToRGB
   */
function hexToRGB(hex) {
  let result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16) };

}

/**
   *
   * @param {*} theme - Object of theme colors
   */
function generateCSSVariables(theme) {
  let cssColorVariables = [];
  for (let key in theme) {
    cssColorVariables.push(`${key}: ${theme[key]};`);
    let { l } = hexToHSL(theme[key]);
    if (_.includes(key, 'accent') || _.includes(key, 'brand')) {
      let { r, g, b } = hexToRGB(theme[key]);
      cssColorVariables.push(`${key}--highlight: rgba(${r}, ${g}, ${b}, ${highlightOpacity});`);
    }
    for (let shade in shades) {
      if (l > 0.50) {
        cssColorVariables.push(`${key}--shade--${shade}: ${darken(theme[key], shades[shade])};`);
      } else
      {
        cssColorVariables.push(`${key}--shade--${shade}: ${lighten(theme[key], shades[shade])};`);
      }
    }
  }

  return cssColorVariables.join('');
}

/**
   * This function iterates through JSON of themed dependent design tokens,
   * populate each key-value pair into a CSS variable syntax and join them
   * into a single string.
   *
   * @param {*} theme - Object of themed design tokens
   */
function populateThemedDesignTokens(theme) {
  let themedDesignTokens = [];
  for (let key in theme) {
    themedDesignTokens.push(`${key}: ${theme[key]};`);
  }
  return themedDesignTokens.join('');
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4333:
/***/ (function(module) {

module.exports = JSON.parse("{\"--color-content-primary\":\"#1A1A1A\",\"--color-content-secondary\":\"#666666\",\"--color-content-tertiary\":\"#999999\",\"--color-content-brand-primary\":\"#C73500\",\"--color-content-brand-secondary\":\"#145EA9\",\"--color-content-accent-error\":\"#B32E14\",\"--color-content-accent-success\":\"#127347\",\"--color-content-accent-warning\":\"#7D6517\",\"--color-background-primary\":\"#FFFFFF\",\"--color-background-secondary\":\"#F7F7F7\",\"--color-background-tertiary\":\"#EBEBEB\",\"--color-border-regular\":\"#E3E3E3\",\"--color-border-strong\":\"#D9D9D9\",\"--color-highlight-background-primary\":\"#F2F2F2\",\"--color-highlight-background-secondary\":\"#EBEBEB\",\"--color-highlight-background-tertiary\":\"#E3E3E3\"}");

/***/ }),

/***/ 4334:
/***/ (function(module) {

module.exports = JSON.parse("{\"--color-content-primary\":\"#FFFFFF\",\"--color-content-secondary\":\"#BFBFBF\",\"--color-content-tertiary\":\"#808080\",\"--color-content-brand-primary\":\"#FF7542\",\"--color-content-brand-secondary\":\"#80BFFF\",\"--color-content-accent-error\":\"#EEA495\",\"--color-content-accent-success\":\"#41E199\",\"--color-content-accent-warning\":\"#FFBD1F\",\"--color-background-primary\":\"#262626\",\"--color-background-secondary\":\"#2E2E2E\",\"--color-background-tertiary\":\"#363636\",\"--color-border-regular\":\"#3D3D3D\",\"--color-border-strong\":\"#4D4D4D\",\"--color-highlight-background-primary\":\"#333333\",\"--color-highlight-background-secondary\":\"#3B3B3B\",\"--color-highlight-background-tertiary\":\"#424242\"}");

/***/ }),

/***/ 4335:
/***/ (function(module) {

module.exports = JSON.parse("{\"--bg-primary\":\"#FFFFFF\",\"--bg-secondary\":\"#FAFAFA\",\"--bg-tertiary\":\"#ECECEC\",\"--hairline-regular\":\"#EAEAEA\",\"--hairline-strong\":\"#D4D4D4\",\"--content-primary\":\"#505050\",\"--content-secondary\":\"#808080\",\"--content-tertiary\":\"#A9A9A9\",\"--brand-primary\":\"#F26B3A\",\"--brand-secondary\":\"#097BED\",\"--accent-error\":\"#ED4B48\",\"--accent-warning\":\"#FFB400\",\"--accent-success\":\"#26B47F\",\"--color-darkest\":\"#282828\",\"--dark-bg-primary\":\"#303030\",\"--dark-bg-secondary\":\"#333333\",\"--dark-bg-tertiary\":\"#464646\",\"--dark-hairline-regular\":\"#3C3C3C\",\"--dark-hairline-strong\":\"#5A5A5A\",\"--dark-content-primary\":\"#F0F0F0\",\"--dark-content-secondary\":\"#808080\",\"--dark-color-lightest\":\"#FFFFFF\"}");

/***/ }),

/***/ 4336:
/***/ (function(module) {

module.exports = JSON.parse("{\"--bg-primary\":\"#282828\",\"--bg-secondary\":\"#303030\",\"--bg-tertiary\":\"#404040\",\"--hairline-regular\":\"#434343\",\"--hairline-strong\":\"#464646\",\"--content-primary\":\"#f0f0f0\",\"--content-secondary\":\"#969696\",\"--content-tertiary\":\"#6F6F6F\",\"--brand-primary\":\"#F26B3A\",\"--brand-secondary\":\"#097BED\",\"--accent-error\":\"#ED4B48\",\"--accent-warning\":\"#FFB400\",\"--accent-success\":\"#26B47F\",\"--color-darkest\":\"#ffffff\",\"--dark-bg-primary\":\"#303030\",\"--dark-bg-secondary\":\"#333333\",\"--dark-bg-tertiary\":\"#464646\",\"--dark-hairline-regular\":\"#3C3C3C\",\"--dark-hairline-strong\":\"#5A5A5A\",\"--dark-content-primary\":\"#F0F0F0\",\"--dark-content-secondary\":\"#808080\",\"--dark-color-lightest\":\"#FFFFFF\"}");

/***/ }),

/***/ 4418:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Theme", function() { return Theme; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1891);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_2__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const theme = {
  light: _postman_design_system__WEBPACK_IMPORTED_MODULE_2__["light"], dark: _postman_design_system__WEBPACK_IMPORTED_MODULE_2__["dark"] };


// wrapper Theme component which exposes the design tokens based on current theme
const Theme = ({ children }) => {

  const [currentTheme, setCurrentTheme] = react__WEBPACK_IMPORTED_MODULE_0___default.a.useState(_extends({
    name: pm.settings.getSetting('postmanTheme') },
  theme[pm.settings.getSetting('postmanTheme')]));

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    pm.settings.on('setSetting:postmanTheme', () => {
      setCurrentTheme(_extends({
        name: pm.settings.getSetting('postmanTheme') },
      theme[pm.settings.getSetting('postmanTheme')]));

    });
  }, []);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(styled_components__WEBPACK_IMPORTED_MODULE_1__["ThemeProvider"], { theme: currentTheme }, children);
};

/***/ })

}]);