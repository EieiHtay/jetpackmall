(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[16],{

/***/ 5839:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1791);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceCollectionsBrowser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5840);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceEnvironmentsBrowser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5846);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceMonitorsBrowser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5848);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceMocksBrowser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5850);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceHistoryBrowser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5852);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceIntegrationsBrowser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5855);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceActivityBrowser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5857);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1763);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1269);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(748);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(742);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(749);
/* harmony import */ var _WorkspaceBrowserItems_WorkspaceOfflineView__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5865);
/* harmony import */ var _components_workspaces_WorkspaceActionDropdown__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4736);
/* harmony import */ var _api_dev_components_api_browse_WorkspaceAPIBrowser_WorkspaceAPIBrowser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5866);
/* harmony import */ var _modules_view_manager_ActiveViewManager__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1796);
/* harmony import */ var _common_constants_views__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1797);
/* harmony import */ var _common_constants_views__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_common_constants_views__WEBPACK_IMPORTED_MODULE_19__);
var _class;



















let


WorkspaceBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_10__["observer"])(_class = class WorkspaceBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: 'apis' };


    this.handleTabSelect = this.handleTabSelect.bind(this);
    this.handleWorkspaceAction = this.handleWorkspaceAction.bind(this);
  }

  componentDidMount() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('WorkspaceLifecycleStore').isSwitching) {
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('WorkspaceLifecycleStore').resetLifecycle(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceSessionStore').workspace);
    }

    _modules_view_manager_ActiveViewManager__WEBPACK_IMPORTED_MODULE_18__["default"].updateActiveView(_common_constants_views__WEBPACK_IMPORTED_MODULE_19__["WORKSPACE_BROWSER"]);
  }

  componentDidUpdate() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('WorkspaceLifecycleStore').isSwitching) {
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('WorkspaceLifecycleStore').resetLifecycle(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceSessionStore').workspace);
    }
  }

  handleTabSelect(tab) {
    this.setState({ activeTab: tab });
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEvent('workspace', 'browse', tab);
  }

  handleWorkspaceAction(action) {
    let workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id;
    switch (action) {
      case 'add_dependencies':
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEvent('workspace', 'initiate_add_to_ws', 'browse');
        pm.mediator.trigger('openBulkAddToWorkspaceModal', workspaceId);
        break;

      case 'details':
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEvent('workspace', 'view_details');
        pm.mediator.trigger('openWorkspaceDetailsModal', Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id);
        break;

      case 'join':
        let joinWorkspaceEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_13__["createEvent"])('join', 'workspace', { model: 'workspace', workspace: { id: workspaceId } });

        Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_11__["default"])(joinWorkspaceEvent).
        then(() => {
          Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceStore').switch(workspaceId);
        }).
        catch(e => {
          Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('WorkspaceLifecycleStore').resetLifecycle(workspaceId);
        });
        break;}

  }

  render() {
    let isOffline = !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('SyncStatusStore').isSocketConnected;

    if (isOffline) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser__container' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceOfflineView__WEBPACK_IMPORTED_MODULE_15__["default"], null)));


    }

    let isJoining = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('WorkspaceLifecycleStore').isJoining(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id);
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser__container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser__tabs' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tabs"], {
              type: 'primary',
              defaultActive: 'collections',
              activeRef: this.state.activeTab,
              onChange: this.handleTabSelect },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'apis' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'APIs')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'collections' }, 'Collections'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'history', className: 'requester-library-tab--history' }, 'History'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'environments', className: 'requester-library-tab--collections' }, 'Environments'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'monitors', className: 'requester-library-tab--environments' }, 'Monitors'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'mocks', className: 'requester-library-tab--environments' }, 'Mocks'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'integrations', className: 'requester-library-tab--environments' }, 'Integrations'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'activity', className: 'requester-library-tab--environments' }, 'Activity')),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser__tabs__actions' },

            !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceStore').isMember &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                type: 'primary',
                size: 'small',
                disabled: isJoining || Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').isLoading,
                onClick: this.handleWorkspaceAction.bind(this, 'join'),
                className: 'join__button' },


              isJoining ?
              'Joining' :
              'Join'),




            !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceStore').isMember &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                type: 'secondary',
                size: 'small',
                onClick: this.handleWorkspaceAction.bind(this, 'details'),
                className: 'details__button' }, 'Workspace details'),





            Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceStore').isMember &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                type: 'secondary',
                size: 'small',
                className: 'options__button',
                onClick: this.handleWorkspaceAction.bind(this, 'add_dependencies') }, 'Add to workspace'),





            Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveWorkspaceStore').isMember &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceActionDropdown__WEBPACK_IMPORTED_MODULE_16__["default"], {
              workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id,
              tooltipPlacement: 'left' }))),





        this.state.activeTab === 'collections' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceCollectionsBrowser__WEBPACK_IMPORTED_MODULE_3__["WorkspaceCollectionsBrowser"], {
          collections: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').collections,
          archivedCollections: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').archivedCollections }),



        this.state.activeTab === 'environments' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceEnvironmentsBrowser__WEBPACK_IMPORTED_MODULE_4__["WorkspaceEnvironmentsBrowser"], {
          workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id }),



        this.state.activeTab === 'monitors' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceMonitorsBrowser__WEBPACK_IMPORTED_MODULE_5__["WorkspaceMonitorsBrowser"], {
          workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id }),



        this.state.activeTab === 'mocks' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceMocksBrowser__WEBPACK_IMPORTED_MODULE_6__["WorkspaceMocksBrowser"], {
          workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id }),



        this.state.activeTab === 'integrations' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceIntegrationsBrowser__WEBPACK_IMPORTED_MODULE_8__["WorkspaceIntegrationsBrowser"], {
          integrations: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').integrations }),



        this.state.activeTab === 'activity' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceActivityBrowser__WEBPACK_IMPORTED_MODULE_9__["WorkspaceActivityBrowser"], {
          isSignedIn: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('CurrentUserStore').isLoggedIn,
          workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id }),



        this.state.activeTab === 'history' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceBrowserItems_WorkspaceHistoryBrowser__WEBPACK_IMPORTED_MODULE_7__["WorkspaceHistoryBrowser"], {
          workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('ActiveBrowseWorkspaceStore').id }),



        this.state.activeTab === 'apis' &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_dev_components_api_browse_WorkspaceAPIBrowser_WorkspaceAPIBrowser__WEBPACK_IMPORTED_MODULE_17__["WorkspaceAPIBrowser"], {
          apis: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('APIListStore').values })));




  }}) || _class;

/***/ }),

/***/ 5840:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceCollectionsBrowser", function() { return WorkspaceCollectionsBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4873);
/* harmony import */ var _components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2125);
/* harmony import */ var _components_base_Icons_ShareIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5844);
/* harmony import */ var _components_base_Icons_ForkIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5845);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1793);
/* harmony import */ var _components_empty_states_CollectionsEmpty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5712);
/* harmony import */ var _components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5702);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1537);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4861);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(749);
/* harmony import */ var _utils_CollectionActionsUtil__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4868);
/* harmony import */ var _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5842);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1763);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(784);
/* harmony import */ var _components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1808);
/* harmony import */ var _components_base_InlineEditor__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1766);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2078);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(748);
/* harmony import */ var _components_collections_CollectionMetaIcons__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4749);
/* harmony import */ var _components_collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3961);
/* harmony import */ var _modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3929);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(2467);
var _class;




























let WorkspaceCollectionsBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_15__["observer"])(_class = class WorkspaceCollectionsBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      filterQuery: '',
      sortType: _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_14__["LIBRARY_SORT_TYPE_NAME"] };


    this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);
    this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);
    this.handleSortTypeChange = this.handleSortTypeChange.bind(this);
    this.handleAction = this.handleAction.bind(this);
    this.handleRefreshDebounced = _.debounce(this.handleRefresh, 5000, {
      leading: true,
      trailing: false });

  }

  getFilteredCollections() {
    return _.chain(this.props.collections).
    filter(collection => _.includes(_.toLower(collection.name), _.toLower(this.state.filterQuery))).
    sortBy([this.getSortFunction(this.state.sortType)]).
    value();
  }

  handleFilterQueryChange(filterQuery) {
    this.setState({ filterQuery });
  }

  handleFilterQueryCancel() {
    this.setState({ filterQuery: '' });
  }

  handleSortTypeChange(sortType) {
    this.setState({ sortType });
  }

  getSortFunction(type) {
    switch (type) {
      case _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_14__["LIBRARY_SORT_TYPE_NAME"]:
        return collection => _.toLower(collection.name);

      case _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_14__["LIBRARY_SORT_TYPE_LAST_MODIFIED"]:
        return collection => new moment__WEBPACK_IMPORTED_MODULE_10___default.a(collection.updatedAt);

      case _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_14__["LIBRARY_SORT_TYPE_DATE_CREATED"]:
        return collection => new moment__WEBPACK_IMPORTED_MODULE_10___default.a(collection.createdAt);

      case _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_14__["LIBRARY_SORT_TYPE_OWNER"]:
        return collection => _.toLower(_utils_util__WEBPACK_IMPORTED_MODULE_16__["default"].getUserNameForId(collection.owner, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('CurrentUserStore')));}

  }

  handleAction(collection, action) {
    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
      pm.mediator.trigger('joinWorkspace');
      return;
    }
    Object(_utils_CollectionActionsUtil__WEBPACK_IMPORTED_MODULE_13__["default"])(collection.id, action, {}, { origin: 'browse' });
  }

  handleShare(collection) {
    Object(_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_23__["shareCollection"])(collection.uid, { origin: 'browse' });
  }

  getActions(collection) {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('PermissionStore'),
    currentUserStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('CurrentUserStore'),
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').id,
    collectionId = collection.id,
    isForked = _.get(collection, 'isForked', false);

    return [
    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_MANAGE_ROLES"],
      label: 'Manage Roles',
      isEnabled: Boolean(currentUserStore.team) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_DUPLICATE"],
      label: 'Duplicate',
      isEnabled: permissionStore.can('addCollection', 'workspace', workspaceId) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_FORK"],
      label: 'Create a fork',
      isEnabled: true },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_PULL_REQUEST"],
      label: 'Create Pull Request',
      isEnabled: isForked },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_MERGE"],
      label: 'Merge changes',
      isEnabled: isForked },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_DOWNLOAD"],
      label: 'Export',
      isEnabled: true },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_ADD_MONITOR"],
      label: 'Monitor Collection',
      isEnabled: permissionStore.can('addMonitor', 'collection', collectionId) && permissionStore.can('addMonitor', 'workspace', workspaceId) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_ADD_MOCK"],
      label: 'Mock Collection',
      isEnabled: permissionStore.can('addMock', 'collection', collectionId) && permissionStore.can('addMock', 'workspace', workspaceId) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_PUBLISH_DOCS"],
      label: 'Publish Docs',
      isEnabled: permissionStore.can('publish', 'collection', collectionId) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_REMOVE_FROM_WORKSPACE"],
      label: 'Remove from workspace',
      isEnabled: permissionStore.can('removeCollection', 'workspace', workspaceId) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      isEnabled: permissionStore.can('delete', 'collection', collectionId) }];


  }

  getDisabledText(isDisabled, actionType) {
    if (isDisabled) {
      let defaultMessage = 'You do not have permissions to perform this action.',
      manageRolesMessage = 'You need to be signed-in to a team to perform this action';

      switch (actionType) {
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_MANAGE_ROLES"]:
          return manageRolesMessage;
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_MERGE"]:
          return 'This collection is not a fork';
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_PULL_REQUEST"]:
          return 'This collection is not a fork';
        default:
          return defaultMessage;}

    }
  }

  getMenuItems(collection) {
    return _.map(this.getActions(collection), action => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled, action.type) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label)));


    });
  }

  handleCollectionClick(collectionId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_20__["default"].addEvent('documentation', 'view', 'browse');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_19__["openEntity"])('collections', collectionId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  handleRefresh() {
    let workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').id;
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').fetchWorkspace(workspaceId);
  }

  render() {
    let collections = this.getFilteredCollections(),
    archivedResources = {
      archivedCollectionsCount: this.props.archivedCollections && this.props.archivedCollections.length || 0 };


    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('PermissionStore');

    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_17__["default"], null));

    }
    if (_.isEmpty(this.props.collections)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container collections empty' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CollectionsEmpty__WEBPACK_IMPORTED_MODULE_8__["default"], {
              isMember: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').isMember,
              workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('ActiveBrowseWorkspaceStore').id })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_3__["default"], {
            archivedResources: archivedResources,
            label: 'COLLECTIONS',
            showWarning: true,
            onClick: _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_19__["openArchivedCollections"] })));



    }
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container collections' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__["WorkspaceBrowserFilter"], {
            onFilterQueryChange: this.handleFilterQueryChange,
            onFilterQueryCancel: this.handleFilterQueryCancel,
            filterQuery: this.state.filterQuery,
            onSortTypeChange: this.handleSortTypeChange,
            sortType: this.state.sortType }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'text',
              onClick: this.handleRefreshDebounced }, 'Refresh')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections__list' },

          _.isEmpty(collections) && this.state.filterQuery &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_9__["default"], null),


          _.map(collections, collection => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { key: collection.id, className: 'collections__list__item' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections__item__header' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections__item__label__wrapper' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections__item__label' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                          type: 'text',
                          className: 'collection-name',
                          onClick: this.handleCollectionClick.bind(this, collection.uid) },

                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, collection.name),
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_CollectionMetaIcons__WEBPACK_IMPORTED_MODULE_21__["default"], { collection: collection }),

                        collection.isForked &&
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
                          className: 'collection__item__fork-label',
                          forkInfo: _.get(collection, 'forkInfo') }))),




                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections__item__owner' },
                      _utils_util__WEBPACK_IMPORTED_MODULE_16__["default"].getUserNameForId(collection.owner, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_12__["getStore"])('CurrentUserStore')))),


                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entities__item__action_wrapper' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                        onClick: this.handleShare.bind(this, collection),
                        type: 'secondary',
                        size: 'small' },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_ShareIcon__WEBPACK_IMPORTED_MODULE_5__["default"], { className: 'share-icon' }),
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Share')),

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], {
                        className: 'entities_item__action__dropdown',
                        onSelect: this.handleAction.bind(this, collection) },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], {
                          dropdownStyle: 'nocaret',
                          type: 'custom' },

                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_24__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
                          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'entities_item__action__dropdown-btn' }))),


                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
                          'align-right': true },

                        this.getMenuItems(collection))))),




                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_InlineEditor__WEBPACK_IMPORTED_MODULE_18__["default"], {
                  isViewMore: true,
                  className: 'collections__item__description',
                  placeholder: 'Make things easier for your teammates with a complete request description.',
                  value: collection.description })));



          })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_3__["default"], {
          archivedResources: archivedResources,
          label: 'COLLECTIONS',
          showWarning: true,
          onClick: _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_19__["openArchivedCollections"] })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5841:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceBrowserFilter", function() { return WorkspaceBrowserFilter; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1882);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1793);
/* harmony import */ var _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5842);
/* harmony import */ var _constants_LibrarySortTypeLabelMap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5843);








let WorkspaceBrowserFilter = class WorkspaceBrowserFilter extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser-filter-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser-filter' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
            inputStyle: 'search',
            placeholder: 'Type to filter',
            onChange: this.props.onFilterQueryChange,
            onCancel: this.props.onFilterQueryCancel,
            query: this.props.filterQuery }),


          _.isFunction(this.props.onSortTypeChange) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser-filter__actions' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-browser-filter__actions__meta' }, 'Sort by: '),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["Dropdown"], {
                onSelect: this.props.onSortTypeChange },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["DropdownButton"], { type: 'secondary', size: 'small' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { className: 'workspace-browser-filter__actions-sort-button' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, _constants_LibrarySortTypeLabelMap__WEBPACK_IMPORTED_MODULE_5__["default"][this.props.sortType]))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["DropdownMenu"], { 'align-left': true },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], { refKey: _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_4__["LIBRARY_SORT_TYPE_NAME"] },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Name')),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], { refKey: _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_4__["LIBRARY_SORT_TYPE_LAST_MODIFIED"] },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Last Modified')),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], { refKey: _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_4__["LIBRARY_SORT_TYPE_OWNER"] },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Owner')),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], { refKey: _constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_4__["LIBRARY_SORT_TYPE_DATE_CREATED"] },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Date Created'))))))));








  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5842:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LIBRARY_SORT_TYPE_NAME", function() { return LIBRARY_SORT_TYPE_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LIBRARY_SORT_TYPE_LAST_MODIFIED", function() { return LIBRARY_SORT_TYPE_LAST_MODIFIED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LIBRARY_SORT_TYPE_OWNER", function() { return LIBRARY_SORT_TYPE_OWNER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LIBRARY_SORT_TYPE_DATE_CREATED", function() { return LIBRARY_SORT_TYPE_DATE_CREATED; });
const LIBRARY_SORT_TYPE_NAME = 'name';
const LIBRARY_SORT_TYPE_LAST_MODIFIED = 'last-modified';
const LIBRARY_SORT_TYPE_OWNER = 'owner';
const LIBRARY_SORT_TYPE_DATE_CREATED = 'date-created';

/***/ }),

/***/ 5843:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5842);



const sortTypeLabelMap = {};

sortTypeLabelMap[_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_0__["LIBRARY_SORT_TYPE_NAME"]] = 'Name';
sortTypeLabelMap[_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_0__["LIBRARY_SORT_TYPE_LAST_MODIFIED"]] = 'Last Modified';
sortTypeLabelMap[_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_0__["LIBRARY_SORT_TYPE_OWNER"]] = 'Owner';
sortTypeLabelMap[_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_0__["LIBRARY_SORT_TYPE_DATE_CREATED"]] = 'Date Created';

/* harmony default export */ __webpack_exports__["default"] = (sortTypeLabelMap);

/***/ }),

/***/ 5844:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ShareIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '12', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'share', d: 'M10 6C5.3 6 1.2 9.2.06 13.76L0 14c2.56-2.56 6.04-4 9.66-4H10v4l6-6-6-6v4z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#000', fillRule: 'nonzero', xlinkHref: '#share' }));



function ShareIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 5845:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ForkIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16', fill: 'none', xmlns: 'http://www.w3.org/2000/svg' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'fork-icon', d: 'M5.24942 14.0002L11.3338 14.0002C12.8056 14.0002 14.0002 12.8064 14.0002 11.3346V8.42903L15.0572 9.48527L16.0002 8.54231L13.8048 6.34771C13.5446 6.08755 13.1227 6.08755 12.8618 6.34771L10.6664 8.54311L11.6094 9.48607L12.6664 8.42903V11.3346C12.6664 12.0713 12.0687 12.6674 11.3336 12.6674H5.24929C5.00757 11.7342 4.26908 11.0035 3.3336 10.761V5.23922C4.48203 4.94162 5.33359 3.90802 5.33359 2.66662C5.33359 1.19399 4.13903 0.000227928 2.6664 0.000227928C1.19376 0.000227928 0 1.19401 0 2.66822C0 3.90878 0.851559 4.94236 2 5.24002V10.7618C0.851559 11.0586 0 12.093 0 13.3336C0 14.8062 1.19374 16 2.6664 16C3.9087 16 4.95309 15.1505 5.24942 14.0002ZM12.6672 5.23904C12.9589 5.2807 13.1777 5.30153 13.3236 5.30153C13.4739 5.30153 13.6994 5.2807 14 5.23904C15.1477 4.94144 16 3.90784 16 2.66644C16 1.19381 14.8062 4.76837e-05 13.3336 4.76837e-05C11.861 4.76837e-05 10.6664 1.19381 10.6672 2.66724C10.6672 3.9078 11.5195 4.94138 12.6672 5.23904ZM13.3415 1.07858C14.1699 1.07858 14.8415 1.75015 14.8415 2.57858C14.8415 3.407 14.1699 4.07858 13.3415 4.07858C12.5131 4.07858 11.8415 3.407 11.8415 2.57858C11.8415 1.75015 12.5131 1.07858 13.3415 1.07858Z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#A9A9A9', fillRule: 'evenodd', xlinkHref: '#fork-icon' }));



function ForkIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 5846:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceEnvironmentsBrowser", function() { return WorkspaceEnvironmentsBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2125);
/* harmony import */ var _components_base_Icons_ShareIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5844);
/* harmony import */ var _components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5841);
/* harmony import */ var _runtime_components_variables_environment_EnvironmentsEmpty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5847);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _utils_uid_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(768);
/* harmony import */ var _runtime_helpers_EnvironmentActionUtil__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5539);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1793);
/* harmony import */ var _components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1808);
/* harmony import */ var _components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5702);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(784);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2078);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(748);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2467);
/* harmony import */ var _runtime_components_variables_environment_EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4754);
/* harmony import */ var _modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3929);
/* harmony import */ var _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5538);
var _class;






















let WorkspaceEnvironmentsBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_6__["observer"])(_class = class WorkspaceEnvironmentsBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { filterQuery: '' };

    this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);
    this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);
    this.handleAction = this.handleAction.bind(this);
    this.handleRefresh = this.handleRefresh.bind(this);

    this.permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore');
  }

  componentDidMount() {
    this.fetchEnvironments(this.props.workspaceId);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.workspaceId !== nextProps.workspaceId) {
      this.fetchEnvironments(nextProps.workspaceId);
    }
  }

  fetchEnvironments(id) {
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').fetchWorkspaceEnvironment(id);
  }

  getFilteredEnvironments(environments) {
    return _.filter(environments, environment => _.includes(_.toLower(environment.name), _.toLower(this.state.filterQuery)));
  }

  handleFilterQueryChange(filterQuery) {
    this.setState({ filterQuery });
  }

  handleFilterQueryCancel() {
    this.setState({ filterQuery: '' });
  }

  handleAction(environment, action) {
    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
      pm.mediator.trigger('joinWorkspace');
      return;
    }
    Object(_runtime_helpers_EnvironmentActionUtil__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_8__["decomposeUID"])(environment.id).modelId, action, {}, { origin: 'browse' });
  }

  handleShare(environment) {
    Object(_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_18__["shareEnvironment"])(environment.uid, { origin: 'browse' });
  }

  getActions(environment) {
    const workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id,
    environmentId = Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_8__["decomposeUID"])(environment.id).modelId,
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore');
    return [
    {
      type: _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__["ACTION_MANAGE_ROLES"],
      label: 'Manage Roles',
      isEnabled: !!currentUser.team // Enable it if the user belongs to a team
    },
    {
      type: _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__["ACTION_TYPE_DUPLICATE"],
      label: 'Duplicate',
      isEnabled: this.permissionStore.can('addEnvironment', 'workspace', environmentId) },

    {
      type: _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__["ACTION_TYPE_DOWNLOAD"],
      label: 'Export',
      isEnabled: true },

    {
      type: _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__["ACTION_REMOVE_FROM_WORKSPACE"],
      label: 'Remove from workspace',
      isEnabled: this.permissionStore.can('removeEnvironment', 'workspace', workspaceId) },

    {
      type: _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      isEnabled: this.permissionStore.can('delete', 'environment', environmentId) }];


  }

  getDisabledText(isDisabled, actionType) {
    if (!isDisabled) {
      return;
    }

    let defaultMessage = 'You do not have permissions to perform this action.',
    manageRolesMessage = 'You need to be signed-in to a team to perform this action';

    switch (actionType) {
      case _runtime_constants_EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_19__["ACTION_MANAGE_ROLES"]:
        return manageRolesMessage;
      default:
        return defaultMessage;}

  }


  getMenuItems(environment) {
    return _.map(this.getActions(environment), action => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["MenuItem"], {
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled, action.type) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label)));


    });
  }

  handleEnvironmentClick(environmentId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_15__["default"].addEvent('environment', 'view_in_web', 'browse');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_14__["openEntity"])('environments', environmentId, this.props.workspaceId);
  }

  handleRefresh() {
    this.fetchEnvironments(this.props.workspaceId);
  }

  render() {
    let environments = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').environments,
    filteredEnvironments = this.getFilteredEnvironments(environments);

    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_11__["default"], null));

    }

    if (_.isEmpty(environments)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container environments empty' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_variables_environment_EnvironmentsEmpty__WEBPACK_IMPORTED_MODULE_5__["default"], {
            isMember: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').isMember,
            workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id })));



    }
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container environments' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_4__["WorkspaceBrowserFilter"], {
            onFilterQueryChange: this.handleFilterQueryChange,
            onFilterQueryCancel: this.handleFilterQueryCancel,
            filterQuery: this.state.filterQuery }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              onClick: this.handleRefresh }, 'Refresh')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environments__list' },

          _.isEmpty(filteredEnvironments) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_12__["default"], null),


          _.map(filteredEnvironments, environment => {
            const canShareEnvironment = this.permissionStore.can('share', 'environment', environment.id);
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { key: environment.id, className: 'environments__list__item' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environments__item__label' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                      type: 'text',
                      className: 'environment-name',
                      onClick: this.handleEnvironmentClick.bind(this, environment.uid) },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, environment.name),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_variables_environment_EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_17__["default"], { environmentId: environment.id })),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment__owner' },
                    _utils_util__WEBPACK_IMPORTED_MODULE_13__["default"].getUserNameForId(environment.owner, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore')))),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment__item__actions' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                      className: 'environment__item__action environment__item__action--share',
                      type: 'secondary',
                      size: 'small',
                      onClick: this.handleShare.bind(this, environment),
                      disabled: !canShareEnvironment,
                      tooltip: this.getDisabledText(!canShareEnvironment) || 'Share Environment' },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_ShareIcon__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'share-icon' }),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Share')),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["Dropdown"], {
                      className: 'entities_item__action__dropdown',
                      onSelect: this.handleAction.bind(this, environment) },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["DropdownButton"], {
                        dropdownStyle: 'nocaret',
                        type: 'custom' },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_16__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_2__["default"], { className: 'entities_item__action__dropdown-btn' }))),


                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["DropdownMenu"], {
                        'align-right': true },

                      this.getMenuItems(environment))))));





          }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5847:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentsEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* harmony import */ var _js_constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2110);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1222);




let

EnvironmentsEmpty = class EnvironmentsEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleCreateEnvironment = this.handleCreateEnvironment.bind(this);
    this.handleAddEnvironments = this.handleAddEnvironments.bind(this);
    this.openLink = this.openLink.bind(this);
  }

  handleAddEnvironments() {
    if (this.props.isMember) {
      pm.mediator.trigger('openBulkAddToWorkspaceModal', this.props.workspaceId, 'environments');
    } else {
      pm.mediator.trigger('joinWorkspace');
    }
  }

  handleCreateEnvironment() {
    if (this.props.isMember) {
      pm.mediator.trigger('showManageEnvironmentModal', _js_constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_3__["MANAGE_ENVIRONMENT_VIEW_ADD_ENV"]);
    } else {
      pm.mediator.trigger('joinWorkspace');
    }
  }

  openLink(url) {
    url && Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__["openExternalLink"])(url);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--environment' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'Looks like this workspace doesn\u2019t have any environments'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              className: 'learn-more-link',
              onClick: this.openLink.bind(this, _js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__["ENVIRONMENT_DOCS"]) }, 'Environments'),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' give you the ability to customize requests using '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              className: 'learn-more-link',
              onClick: this.openLink.bind(this, _js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__["VARIABLE_DOCS"]) }, 'variables'),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, '. You can easily switch between different setups without changing your requests.')),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'primary',
              onClick: this.handleAddEnvironments }, 'Add environments to this workspace')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action--text' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              onClick: this.handleCreateEnvironment }, 'or create an environment'))));






  }};

/***/ }),

/***/ 5848:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceMonitorsBrowser", function() { return WorkspaceMonitorsBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2125);
/* harmony import */ var _components_empty_states_MonitorsEmpty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5849);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _modules_controllers_MonitorController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1249);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(784);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1793);
/* harmony import */ var _components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1808);
/* harmony import */ var _components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5702);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2078);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(748);
/* harmony import */ var _utils_uid_helper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(768);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2467);
var _class;

















let WorkspaceMonitorsBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class WorkspaceMonitorsBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      filterQuery: '',
      monitors: [],
      isLoading: false };


    this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);
    this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);
    this.handleAction = this.handleAction.bind(this);
    this.handleCreateMonitor = this.handleCreateMonitor.bind(this);
    this.fetchWorkspaceMonitors = this.fetchWorkspaceMonitors.bind(this);
    this.handleRefreshDebounced = _.debounce(this.fetchWorkspaceMonitors, 5000, {
      leading: true,
      trailing: false });

  }

  componentDidMount() {
    this.fetchWorkspaceMonitors();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.workspaceId !== nextProps.workspaceId) {
      this.fetchWorkspaceMonitors();
    }
  }

  fetchWorkspaceMonitors() {
    this.setState({ isLoading: true });
    _modules_controllers_MonitorController__WEBPACK_IMPORTED_MODULE_7__["default"].getAll({ workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').id }).then(list => {
      this.setState({
        monitors: list,
        isLoading: false });

    }).catch(err => {
      console.log('Error in fetching monitors', err);
    });
  }

  getFilteredMonitors() {
    return _.filter(this.state.monitors, monitor => _.includes(_.toLower(monitor.name), _.toLower(this.state.filterQuery)));
  }

  handleFilterQueryChange(filterQuery) {
    this.setState({ filterQuery });
  }

  handleFilterQueryCancel() {
    this.setState({ filterQuery: '' });
  }

  handleAction(monitor, action) {
    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
      pm.mediator.trigger('joinWorkspace');
      return;
    }
    switch (action) {
      case 'edit':
        break;
      case 'delete':
        pm.mediator.trigger('showDeleteMonitorModal', monitor, this.fetchWorkspaceMonitors, { origin: 'browse' });
        break;}

  }

  getActions(monitor) {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
    collectionId = Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_14__["decomposeUID"])(monitor.collection).modelId;

    return [
    {
      type: 'delete',
      label: 'Delete',
      isEnabled: permissionStore.can('deleteMonitor', 'collection', collectionId) }];


  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getMenuItems(monitor) {
    let actions = this.getActions(monitor);

    return _.map(actions, action => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], {
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label)));


    });
  }

  handleMonitorClick(monitorId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__["default"].addEvent('monitor', 'view_run_details', 'browse');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_12__["openEntity"])('monitors', monitorId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  handleEditMonitor(monitorId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__["default"].addEvent('monitor', 'browse_action', 'edit');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_12__["editEntity"])('monitors', monitorId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  handleCreateMonitor() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
      pm.mediator.trigger(
      'openCreateNewMonitorModal',
      {
        workspaceId: this.props.workspaceId,
        from: 'browse' },

      this.fetchWorkspaceMonitors);

    } else
    {
      pm.mediator.trigger('joinWorkspace');
    }
  }

  render() {
    let monitors = this.getFilteredMonitors();
    if (this.state.isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_10__["default"], null));

    }

    if (_.isEmpty(this.state.monitors)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container monitors empty' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_MonitorsEmpty__WEBPACK_IMPORTED_MODULE_4__["default"], {
            isMember: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').isMember,
            workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').id,
            onSuccessCreate: this.fetchWorkspaceMonitors })));



    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container monitors' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('h1', { className: 'workspace-title' }, 'Monitors'),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'primary',
              size: 'small',
              onClick: this.handleCreateMonitor }, 'Monitor a collection')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__["WorkspaceBrowserFilter"], {
            onFilterQueryChange: this.handleFilterQueryChange,
            onFilterQueryCancel: this.handleFilterQueryCancel,
            filterQuery: this.state.filterQuery }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'text',
              onClick: this.handleRefreshDebounced }, 'Refresh')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'monitors__list' },

          _.isEmpty(monitors) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_11__["default"], null),


          _.map(monitors, monitor => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'monitors__list__item',
                  key: monitor.id },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'monitors__item__label' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      type: 'text',
                      className: 'monitor-name',
                      onClick: this.handleMonitorClick.bind(this, monitor.id) },

                    monitor.name),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'monitor-owner' },
                    _utils_util__WEBPACK_IMPORTED_MODULE_8__["default"].getUserNameForId(monitor.createdBy, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore')))),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entities__item__action_wrapper' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      type: 'secondary',
                      size: 'small',
                      onClick: this.handleEditMonitor.bind(this, monitor.id) }, 'Edit'),



                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["Dropdown"], {
                      className: 'entities_item__action__dropdown',
                      onSelect: this.handleAction.bind(this, monitor) },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownButton"], {
                        dropdownStyle: 'nocaret',
                        type: 'custom' },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_15__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'entities_item__action__dropdown-btn' }))),


                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownMenu"], {
                        'align-right': true },

                      this.getMenuItems(monitor))))));





          }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5849:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MonitorsEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1222);



let
MonitorsEmpty = class MonitorsEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleCreateMonitor = this.handleCreateMonitor.bind(this);
    this.openLink = this.openLink.bind(this);
  }

  handleCreateMonitor() {
    if (this.props.isMember) {
      pm.mediator.trigger(
      'openCreateNewMonitorModal',
      {
        workspaceId: this.props.workspaceId,
        from: 'browse' },

      this.props.onSuccessCreate);

    } else
    {
      pm.mediator.trigger('joinWorkspace');
    }
  }

  openLink(url) {
    url && Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__["openExternalLink"])(url);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--monitors' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'monitors-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'Looks like this workspace doesn\u2019t have any monitors'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              className: 'learn-more-link',
              onClick: this.openLink.bind(this, _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__["MONITORING_DOCS"]) }, 'Monitor your collections'),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' to schedule automated tests to check for performance and response.')),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'primary',
              onClick: this.handleCreateMonitor }, 'Create a monitor in this workspace'))));






  }};

/***/ }),

/***/ 5850:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceMocksBrowser", function() { return WorkspaceMocksBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2125);
/* harmony import */ var _components_base_Icons_CopyIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1790);
/* harmony import */ var _components_empty_states_MocksEmpty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5851);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _modules_controllers_MockController__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1251);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(784);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1793);
/* harmony import */ var _components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1808);
/* harmony import */ var _components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5702);
/* harmony import */ var _utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1735);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(748);
/* harmony import */ var _utils_uid_helper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(768);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2467);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2078);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4870);
var _class;





















let WorkspaceMocksBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_6__["observer"])(_class = class WorkspaceMocksBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      filterQuery: '',
      mocks: [],
      isLoading: false };


    this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);
    this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);
    this.fetchWorkspaceMocks = this.fetchWorkspaceMocks.bind(this);
    this.handleAction = this.handleAction.bind(this);
    this.handleRefreshDebounced = _.debounce(this.fetchWorkspaceMocks, 5000, {
      leading: true,
      trailing: false });

  }

  componentDidMount() {
    this.fetchWorkspaceMocks();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.workspaceId !== nextProps.workspaceId) {
      this.fetchWorkspaceMocks();
    }
  }

  fetchWorkspaceMocks() {
    this.setState({ isLoading: true });
    _modules_controllers_MockController__WEBPACK_IMPORTED_MODULE_8__["default"].getAll({
      workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id,
      populate: true }).
    then(list => {
      this.setState({
        mocks: list,
        isLoading: false });

    }).catch(err => {
      console.log('Error in fetching mocks', err);
    });
  }

  handleEditMock(mock) {
    _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_19__["default"].edit(
    {
      collectionId: Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_15__["decomposeUID"])(mock.collection.id).modelId,
      opts: { from: 'browse' },
      mock: {
        mockId: mock.id,
        name: mock.name,
        isPrivate: !mock.published,
        mockUrl: mock.url,
        versionId: mock.collection && mock.collection.versionTag,
        environmentId: mock.environment && Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_15__["decomposeUID"])(mock.environment.id).modelId } },


    this.fetchWorkspaceMocks);

  }

  getFilteredMocks() {
    return _.filter(this.state.mocks, mock => _.includes(_.toLower(mock.url), _.toLower(this.state.filterQuery)));
  }

  handleFilterQueryChange(filterQuery) {
    this.setState({ filterQuery });
  }

  handleFilterQueryCancel() {
    this.setState({ filterQuery: '' });
  }

  handleCollectionClick(collectionId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_14__["default"].addEvent('documentation', 'view', 'browse');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_17__["openEntity"])('collections', collectionId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  handleEnvironmentClick(environmentId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_14__["default"].addEvent('environment', 'view_in_web', 'browse');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_17__["openEntity"])('environments', environmentId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  handleMockNameClick(mockId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_14__["default"].addEventV2({
      category: 'mock',
      action: 'view_in_web',
      label: 'browse',
      entityId: mockId });


    // Redirects the user to mock call logs view
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_17__["openMockCallLogs"])(mockId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  handleAction(mock, action) {
    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
      pm.mediator.trigger('joinWorkspace');
      return;
    }
    switch (action) {
      case 'edit':
        this.handleEditMock(mock);
        break;
      case 'delete':
        pm.mediator.trigger('showDeleteMockModal', mock, this.fetchWorkspaceMocks, { origin: 'browse' });
        break;
      case 'copy':
        _utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_13__["default"].copy(mock.url);
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_14__["default"].addEventV2({
          category: 'mock',
          action: 'copy',
          label: 'browse_view',
          entityId: mock.id });

        pm.toasts.success('Mock URL copied');
        break;}

  }

  getActions(mock) {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore'),
    collectionId = Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_15__["decomposeUID"])(mock.collection.id).modelId;

    return [
    {
      type: 'edit',
      label: 'Edit',
      isEnabled: permissionStore.can('editMock', 'collection', collectionId) },

    {
      type: 'delete',
      label: 'Delete',
      isEnabled: permissionStore.can('deleteMock', 'collection', collectionId) }];


  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getMenuItems(mock) {
    let actions = this.getActions(mock);
    return _.map(actions, action => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["MenuItem"], {
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label)));


    });
  }

  render() {
    let mocks = this.getFilteredMocks();
    if (this.state.isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_11__["default"], null));

    }

    if (_.isEmpty(this.state.mocks)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container mocks empty' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_MocksEmpty__WEBPACK_IMPORTED_MODULE_5__["default"], {
            isMember: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').isMember,
            workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveBrowseWorkspaceStore').id,
            onSuccessCreate: this.fetchWorkspaceMocks })));



    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container mocks' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__["WorkspaceBrowserFilter"], {
            onFilterQueryChange: this.handleFilterQueryChange,
            onFilterQueryCancel: this.handleFilterQueryCancel,
            filterQuery: this.state.filterQuery }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'text',
              onClick: this.handleRefreshDebounced }, 'Refresh')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mocks__list' },

          _.isEmpty(mocks) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_12__["default"], null),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mocks__list__header' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mocks__list__header__name' }, 'NAME'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mocks__list__header__collection' }, 'COLLECTION'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mocks__list__header__version-tag' }, 'VERSION TAG'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mocks__list__header__environment' }, 'ENVIRONMENT'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mocks__list__header__mock-url' }, 'MOCK URL'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mocks__list__header__actions' })),


          _.map(mocks, mock => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'mocks__list__item',
                  key: mock.id },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mock__item__name' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mock-name' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                        title: mock.name,
                        onClick: this.handleMockNameClick.bind(this, mock.id) },

                      mock.name)),


                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mock-owner' },
                    _utils_util__WEBPACK_IMPORTED_MODULE_9__["default"].getUserNameForId(mock.createdBy.id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore')))),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                    className: 'mock__item__collection-name' },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                      title: _.get(mock.collection, 'name'),
                      onClick: this.handleCollectionClick.bind(this, _.get(mock.collection, 'id')) },

                    _.get(mock.collection, 'name'))),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mock__item__collection-version' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                      title: _.get(mock.collection, 'versionName'),
                      className: classnames__WEBPACK_IMPORTED_MODULE_18___default()({
                        'mock__item__collection-version-tag': true,
                        'mock__item__collection-version-tag--current':
                        _.isEqual(_.get(mock.collection, 'versionTag'), 'latest') }) },


                    _.get(mock.collection, 'versionName'))),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mock__item__environment-name' },
                  _.get(mock.environment, 'name') ?
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                      title: _.get(mock.environment, 'name'),
                      className: 'mock__item__environment-name--link',
                      onClick: this.handleEnvironmentClick.bind(this, _.get(mock.environment, 'id')) },

                    _.get(mock.environment, 'name')) :

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'mock__item__environment-name--empty' }, 'No environment')),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                    className: 'mock-id',
                    title: mock.url },

                  mock.url),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entities__item__action_wrapper mock__item__actions' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      className: 'mock___item__button-copy',
                      tooltip: 'Copy Mock URL',
                      type: 'icon',
                      onClick: this.handleAction.bind(this, mock, 'copy') },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_CopyIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null)),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["Dropdown"], {
                      className: 'entities_item__action__dropdown',
                      onSelect: this.handleAction.bind(this, mock) },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["DropdownButton"], {
                        dropdownStyle: 'nocaret',
                        type: 'custom' },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_16__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'entities_item__action__dropdown-btn' }))),


                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_10__["DropdownMenu"], {
                        'align-right': true },

                      this.getMenuItems(mock))))));





          }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5851:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MocksEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1222);



let
MocksEmpty = class MocksEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleCreateMock = this.handleCreateMock.bind(this);
    this.openLink = this.openLink.bind(this);
  }

  handleCreateMock() {
    if (this.props.isMember) {
      pm.mediator.trigger(
      'openCreateNewMockModal',
      {
        workspaceId: this.props.workspaceId,
        from: 'browse' },

      this.props.onSuccessCreate);

    } else
    {
      pm.mediator.trigger('joinWorkspace');
    }
  }

  openLink(url) {
    url && Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__["openExternalLink"])(url);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--mocks' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mocks-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'Looks like this workspace doesn\u2019t have any mocks'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Create a '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              className: 'learn-more-link',
              onClick: this.openLink.bind(this, _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__["MOCK_DOCS"]) }, 'mock server'),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' to simulate each endpoint and its corresponding environment in a Postman Collection, before sending the actual request.')),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'primary',
              onClick: this.handleCreateMock }, 'Create a mock in this workspace'))));






  }};

/***/ }),

/***/ 5852:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceHistoryBrowser", function() { return WorkspaceHistoryBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3946);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5841);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _components_empty_states_HistoryEmpty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5853);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _modules_controllers_SyncWorkspaceController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(779);
/* harmony import */ var _WorkspaceHistoryGroupItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5854);
/* harmony import */ var _components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1808);
/* harmony import */ var _components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5702);
/* harmony import */ var _components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4873);
var _class;













let WorkspaceHistoryBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class WorkspaceHistoryBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      filterQuery: '',
      histories: [],
      isLoading: false,
      archivedHistory: 0 };


    this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);
    this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);
    this.fetchData = this.fetchData.bind(this);
    this.handleRefreshDebounced = _.debounce(this.fetchData, 5000, {
      leading: true,
      trailing: false });

  }

  componentDidMount() {
    this.fetchData();
  }

  componentWillUnmount() {
    this.handleRefreshDebounced && this.handleRefreshDebounced.cancel();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.workspaceId !== nextProps.workspaceId) {
      this.fetchData(nextProps.workspaceId);
    }
  }

  fetchData() {
    this.setState({ histories: [], isLoading: true, archivedHistory: 0 });
    this.populateHistory();
    this.populateArchivedCount();
  }

  populateHistory() {
    this.setState({ isLoading: true });
    return _modules_controllers_SyncWorkspaceController__WEBPACK_IMPORTED_MODULE_7__["default"].getAllHistory({ workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveBrowseWorkspaceStore').id }).
    then(list => {
      this.setState({
        histories: list,
        isLoading: false });

    });
  }

  populateArchivedCount() {
    return _modules_controllers_SyncWorkspaceController__WEBPACK_IMPORTED_MODULE_7__["default"].fetchArchivedCounts({ id: this.props.workspaceId }).
    then(response => {
      if (response) {
        this.setState({ archivedHistory: response.history });
      }
    });
  }

  getGroupedFilteredHistories() {
    let histories = this.getFilteredHistory();
    return _postman_date_helper__WEBPACK_IMPORTED_MODULE_1___default.a.getDateGroups(histories, 'createdAt');
  }

  getFilteredHistory() {
    return _.filter(this.state.histories, history => _.includes(_.toLower(history.url), _.toLower(this.state.filterQuery)));
  }

  handleFilterQueryChange(filterQuery) {
    this.setState({ filterQuery });
  }

  handleFilterQueryCancel() {
    this.setState({ filterQuery: '' });
  }

  render() {
    let groupedHistories = this.getGroupedFilteredHistories(),
    archivedResources = {
      archivedHistoryCount: this.state.archivedHistory };


    if (this.state.isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], null));

    }

    if (_.isEmpty(this.state.histories)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container history empty' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_HistoryEmpty__WEBPACK_IMPORTED_MODULE_4__["default"], null)),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_11__["default"], {
            archivedResources: archivedResources,
            label: 'HISTORIES' })));



    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container history' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_2__["WorkspaceBrowserFilter"], {
            onFilterQueryChange: this.handleFilterQueryChange,
            onFilterQueryCancel: this.handleFilterQueryCancel,
            filterQuery: this.state.filterQuery }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
              type: 'text',
              onClick: this.handleRefreshDebounced }, 'Refresh')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history__list' },

          _.isEmpty(groupedHistories) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_10__["default"], null),


          _.map(groupedHistories, group => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceHistoryGroupItem__WEBPACK_IMPORTED_MODULE_8__["default"], {
                group: group,
                key: group.name }));


          })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_11__["default"], {
          archivedResources: archivedResources,
          label: 'HISTORIES' })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5853:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);

let

HistoryEmpty = class HistoryEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--history' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'No history requests'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' }, 'Requests send through the Postman app in a workspace are automatically saved in the workspace\'s History.')));




  }};

/***/ }),

/***/ 5854:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceHistoryGroupItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_history_HistoryListItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4884);
/* harmony import */ var _components_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1803);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;



let


WorkspaceHistoryGroupItem = pure_render_decorator__WEBPACK_IMPORTED_MODULE_2___default()(_class = class WorkspaceHistoryGroupItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { isOpen: true };

    this.handleToggleGroup = this.handleToggleGroup.bind(this);
  }

  getCollapseButtonClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'caret': true,
      'is-closed': !this.state.isOpen });

  }

  handleToggleGroup() {
    this.setState({ isOpen: !this.state.isOpen });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item-group' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'history-sidebar-list-item-group__meta',
            onClick: this.handleToggleGroup },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item-group__name' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: this.getCollapseButtonClasses() }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, this.props.group.name))),


        this.state.isOpen &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item-group__items' },

          _.map(this.props.group.items, item => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_history_HistoryListItem__WEBPACK_IMPORTED_MODULE_3__["default"], _extends({},
              item, {
                hideActions: true,
                key: item.id })));


          }))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5855:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceIntegrationsBrowser", function() { return WorkspaceIntegrationsBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _components_empty_states_IntegrationsEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5856);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
var _class;







let WorkspaceIntegrationsBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class WorkspaceIntegrationsBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { filterQuery: '' };

    this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);
    this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);
  }

  getFilteredIntegrations() {
    return _.filter(this.props.integrations, integration => _.includes(_.toLower(integration.name), _.toLower(this.state.filterQuery)));
  }

  handleFilterQueryChange(filterQuery) {
    this.setState({ filterQuery });
  }

  handleFilterQueryCancel() {
    this.setState({ filterQuery: '' });
  }

  render() {
    let integrations = this.getFilteredIntegrations();

    if (_.isEmpty(this.props.integrations)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container integrations empty' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_IntegrationsEmpty__WEBPACK_IMPORTED_MODULE_3__["default"], {
            isMember: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveBrowseWorkspaceStore').isMember,
            workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveBrowseWorkspaceStore').id })));



    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-item-browser__container integrations' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_1__["WorkspaceBrowserFilter"], {
          onFilterQueryChange: this.handleFilterQueryChange,
          onFilterQueryCancel: this.handleFilterQueryCancel,
          filterQuery: this.state.filterQuery }),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'integrations__list' },

          _.map(integrations, integration => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'integrations__list__item' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'integrations__item__label' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { type: 'text', className: 'integration-name' },
                    integration.name),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'integration-description' },
                    integration.description)),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'integration-count' },
                  integration.count)));



          }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5856:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return IntegrationsEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2078);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1222);




let
IntegrationsEmpty = class IntegrationsEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleAddIntegrations = this.handleAddIntegrations.bind(this);
    this.openLink = this.openLink.bind(this);
  }

  handleAddIntegrations() {
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["openIntegrationBrowse"])(this.props.workspaceId);
  }

  openLink(url) {
    url && Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__["openExternalLink"])(url);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--integrations' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'integrations-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'Integrations are coming soon to the Postman app'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Integrations allow you to share data or functionality between Postman and other tools that you might rely on for API development. Integrations can be created and configured from the web dashboard.')),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'primary',
              onClick: this.handleAddIntegrations }, 'View integrations in the web dashboard'))));






  }};

/***/ }),

/***/ 5857:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceActivityBrowser", function() { return WorkspaceActivityBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _components_workspace_activity_feed_WorkspaceActivityFeed__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5858);
/* harmony import */ var _components_library_LibraryEmptyListItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5863);
/* harmony import */ var _components_library_LibraryEmptyActivityFeed__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5859);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2690);
/* harmony import */ var _WorkspaceActivityFeedFilter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5864);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2083);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(748);
var _class;










/**
                                                                            *
                                                                            * @param {String} action Action for analytic event
                                                                            * @param {String} trigger Trigger for analytic event
                                                                            * @param {Number} members No. of members selected
                                                                            * @param {Number} entities No. of entities selected
                                                                            * @param {Boolean} isFilterApplied Flag to identify if filter is applied
                                                                            * @param {String} workspaceId Current workspace Id
                                                                            */
function addAnalyticsEvent(action, trigger, members, entities, isFilterApplied, workspaceId) {
  let label;

  if (!isFilterApplied) {
    label = `${trigger}`;
  } else
  if (members && entities) {
    label = `filter_${trigger}_users_models`;
  } else
  if (members) {
    label = `filter_${trigger}_users`;
  } else
  {
    label = `filter_${trigger}_models`;
  }

  _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
    category: 'workspace',
    action: action,
    label: label,
    value: 1 });

}


let WorkspaceActivityBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class WorkspaceActivityBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isFilterApplied: false,
      filterApplied: {
        members: {},
        entities: {} } };



    this.loadMoreActivityFeed = this.loadMoreActivityFeed.bind(this);
    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleRefresh = this.handleRefresh.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleClearAll = this.handleClearAll.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('WorkspaceActivityFeedStore');
    this.store.initiateInitialFetch();

    addAnalyticsEvent('activityfeed', 'view',
    _.size(this.state.filterApplied.members), _.size(this.state.filterApplied.entities), this.state.isFilterApplied, this.props.workspaceId);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.workspaceId !== nextProps.workspaceId) {
      this.store.initiateInitialFetch();
    }
  }

  componentWillUnmount() {
    this.store.reset();
    this.store = null;
  }

  loadMoreActivityFeed() {
    this.store.initiateLoadMore({
      users: _.keys(this.state.filterApplied.members),
      models: _.map(this.state.filterApplied.entities, 'value') });


    if (!this.store.areMoreFeedsAvailable) {
      addAnalyticsEvent('activityfeed_end', 'view',
      _.size(this.state.filterApplied.members), _.size(this.state.filterApplied.entities), this.state.isFilterApplied, this.props.workspaceId);
    }

    addAnalyticsEvent('activityfeed', 'view_more',
    _.size(this.state.filterApplied.members), _.size(this.state.filterApplied.entities), this.state.isFilterApplied, this.props.workspaceId);
  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_6__["default"].login();
  }

  handleRefresh() {
    this.store.refresh({
      users: _.keys(this.state.filterApplied.members),
      models: _.map(this.state.filterApplied.entities, 'value') });


    addAnalyticsEvent('activityfeed', 'refresh_view',
    _.size(this.state.filterApplied.members), _.size(this.state.filterApplied.entities), this.state.isFilterApplied, this.props.workspaceId);
  }

  handleSearch(filters) {
    this.setState({
      isFilterApplied: true,
      filterApplied: filters },
    function () {
      this.store.getBySearch({
        users: _.keys(filters.members),
        models: _.map(filters.entities, 'value') });


      addAnalyticsEvent('activityfeed', 'view',
      _.size(this.state.filterApplied.members), _.size(this.state.filterApplied.entities), this.state.isFilterApplied, this.props.workspaceId);
    });
  }

  handleClearAll() {
    this.setState({
      isFilterApplied: false,
      filterApplied: {
        members: {},
        entities: {} } },

    function () {
      this.store.refresh();
    });
  }


  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__["default"], null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-team-overview' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityFeedFilter__WEBPACK_IMPORTED_MODULE_7__["default"], {
            handleRefresh: this.handleRefresh,
            handleSearch: this.handleSearch,
            handleClearAll: this.handleClearAll,
            isLoading: this.store.isLoading,
            isFilterApplied: this.state.isFilterApplied,
            filtersApplied: this.state.filterApplied }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_workspace_activity_feed_WorkspaceActivityFeed__WEBPACK_IMPORTED_MODULE_2__["default"], {
            activityFeed: this.store,
            onLoadMore: this.loadMoreActivityFeed,
            isFilterApplied: this.state.isFilterApplied,
            isLoggedIn: this.props.isSignedIn,
            isLoading: this.store.isLoading,
            isLoadingMore: this.store.isLoadingMore,
            onSignIn: this.handleSignIn,
            areMoreFeedsAvailable: this.store.areMoreFeedsAvailable }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5858:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceActivityFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1808);
/* harmony import */ var _library_LibraryEmptyActivityFeed__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5859);
/* harmony import */ var _WorkspaceActivityItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5860);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3946);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _CollectionActivity__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5861);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1763);
var _class;











const EMPTY_STATE = {
  search: {
    title: 'No results found',
    description: 'Try adjusting your filters and try again.' },

  empty: {
    title: 'Looks like this workspace doesn’t have any activity',
    description: 'The activity feed keeps you updated with the happenings around this workspace.' +
    ' Start using this workspace to populate the feed.' } };let




WorkspaceActivityFeed = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class = class WorkspaceActivityFeed extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {

  constructor(props) {
    super(props);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollDebounced = _.debounce(this.handleScroll, 100);
    this.handleSignIn = this.handleSignIn.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.activityFeed &&
    this.props.activityFeed &&
    nextProps.activityFeed.id &&
    nextProps.activityFeed.id !== this.props.activityFeed.id) {
      this.refs.activity_feed && (this.refs.activity_feed.scrollTop = 0);
    }
  }

  handleSignIn() {
    this.props.onSignIn && this.props.onSignIn();
  }

  handleScroll() {
    let node = this.refs.activity_feed;
    if (node.scrollHeight - (node.scrollTop + node.offsetHeight) === 0) {
      !this.props.isLoadingMore && this.props.onLoadMore && this.props.onLoadMore();
    }
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_7___default()({ 'workspace-activity-feed-container': true }, this.props.className);
  }

  render() {
    let props = this.props,
    activities = _.get(props, 'activityFeed.feeds', []),
    isActivityFeedFetchError = _.get(props, 'activityFeed.error', false);

    if (!props.isLoggedIn) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-empty-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                className: 'workspace-activity-feed-empty-signin-link',
                onClick: this.handleSignIn }, 'Sign in'), ' to track changes to your collection.')));






    } else
    if (props.isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_1__["default"], null));

    } else
    if (_.isEmpty(props.activityFeed.feeds)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_library_LibraryEmptyActivityFeed__WEBPACK_IMPORTED_MODULE_2__["default"], {
          isSearch: props.isFilterApplied,
          title: props.isFilterApplied ? EMPTY_STATE.search.title : EMPTY_STATE.empty.title,
          description: props.isFilterApplied ? EMPTY_STATE.search.description : EMPTY_STATE.empty.description }));


    }

    let groupedActivities = _.isEmpty(activities) ? [] : _postman_date_helper__WEBPACK_IMPORTED_MODULE_4___default.a.getDateGroups(activities, 'updatedAt', 'MMMM D, YYYY'),
    activityId = '',
    activitySubCount = 1;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'workspace-activity-feed',
            ref: 'activity_feed',
            onScroll: this.handleScrollDebounced },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'workspace-activity-feed-date-group-container' },


            _.map(groupedActivities, subActivities => {
              let currentFeedUserId = '',
              showUserIcon = false;

              if (_.isEmpty(subActivities)) {
                return false;
              }

              return (
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                    className: 'workspace-activity-feed-date-group-wrapper',
                    key: subActivities.name },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-date-group' }, ' ', subActivities.name, ' '),

                  _.map(subActivities.items, activity => {
                    showUserIcon = activity.user && currentFeedUserId !== activity.user.id;
                    activity.user && (currentFeedUserId = activity.user.id);
                    activityId === activity.feed_id ?
                    (activityId = activity.feed_id) && (activity.feed_id = `${activity.feed_id}#${activitySubCount++}`) :
                    activityId = activity.feed_id;

                    return (
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        workspaceId: props.activityFeed.id,
                        userId: activity.user && activity.user.id,
                        markdown: activity.markdown,
                        updatedAt: activity.updatedAt,
                        key: activity.feed_id,
                        showUserIcon: showUserIcon }));


                  })));



            })),



          props.areMoreFeedsAvailable ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionActivity__WEBPACK_IMPORTED_MODULE_6__["LoadFeed"], {
            error: isActivityFeedFetchError,
            key: 'loading-more',
            loading: props.activityFeed.isLoadingMore }) :

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'workspace-activity-feed__end' }, 'The end! You\'ve seen all the activity for this workspace'))));







  }}) || _class;


WorkspaceActivityFeed.propTypes = {
  activityFeed: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object.isRequired,
  activityName: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  className: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  onLoadMore: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func.isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5859:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return LibraryEmptyActivityFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);



function LibraryEmptyActivityFeed(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-library-invite__wrapper empty-activity-feed' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: props.isSearch ? 'empty-activity-feed__search-image' : 'empty-activity-feed__image' }),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'empty-activity-feed__label' }, props.title),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'empty-activity-feed__description' }, props.description)));


}

LibraryEmptyActivityFeed.propTypes = {
  isSearch: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool.isRequired,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired };

/***/ }),

/***/ 5860:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5626);
/* harmony import */ var _base_Markdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1783);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1222);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(748);









function WorkspaceActivityItem(props) {
  const { showUserIcon, userId, markdown, updatedAt, workspaceId } = props;

  function handleClickAnalytic(target) {
    const link = target.getAttribute('href');

    link && Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__["openExternalLink"])(link);
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('workspace', 'activityfeed_action', 'redirect', 1, workspaceId);
  }

  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
          'workspace-activity-item-wrapper': true,
          'show-user': showUserIcon }) },


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_3__["Header"], null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_3__["ProfilePic"], { id: showUserIcon ? userId : '' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_3__["Heading"], null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Markdown__WEBPACK_IMPORTED_MODULE_4__["default"], {
                source: markdown,
                handleClick: handleClickAnalytic })),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_3__["Meta"], null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_3__["Time"], { timestamp: updatedAt })))))));






}

WorkspaceActivityItem.propTypes = {
  showUserIcon: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool.isRequired,
  userId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  markdown: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  updatedAt: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  workspaceId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired };


/* harmony default export */ __webpack_exports__["default"] = (Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(WorkspaceActivityItem));

/***/ }),

/***/ 5861:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Create", function() { return Create; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Update", function() { return Update; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Delete", function() { return Delete; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Share", function() { return Share; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Unshare", function() { return Unshare; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Subscribe", function() { return Subscribe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Unsubscribe", function() { return Unsubscribe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadFeed", function() { return LoadFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5626);
/* harmony import */ var _utils_ActivityFeedHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5862);
/* harmony import */ var _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2059);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1808);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



let

Create = class Create extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' Created '),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                activity.instance, {
                  meta: meta }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt }),

                this.props.enableRestore &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Restore"], {
                  createdAt: activity.createdAt,
                  id: activity.id,
                  isRestoring: this.props.isRestoring,
                  rollback_from: meta.rollback_from,
                  onRestore: this.props.onRestore })))))));








  }};let


Update = class Update extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta,
    trigger = activity.trigger,
    changesCount = _utils_ActivityFeedHelper__WEBPACK_IMPORTED_MODULE_2__["default"].getWhiteListedActivitiesCount(activity),
    pluralizedChangeText = _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_3__["default"].pluralize({
      count: changesCount,
      singular: 'change',
      plural: 'changes' });

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head-content' },

                  changesCount > 0 &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' ', changesCount, ' ', pluralizedChangeText, ' to '),


                  changesCount === 0 &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' ', trigger === 'restore' ? 'Restored' : 'Modified', ' '),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                  activity.instance, {
                    meta: meta })))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt }),

                this.props.enableRestore &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Restore"], {
                  createdAt: activity.createdAt,
                  id: activity.id,
                  isRestoring: this.props.isRestoring,
                  rollback_from: meta.rollback_from,
                  onRestore: this.props.onRestore })))),





          changesCount > 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Details"], activity))));



  }};let


Delete = class Delete extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Deleted'),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                activity.instance, {
                  meta: meta }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt }),

                this.props.enableRestore &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Restore"], {
                  createdAt: activity.createdAt,
                  id: activity.id,
                  isRestoring: this.props.isRestoring,
                  rollback_from: meta.rollback_from,
                  onRestore: this.props.onRestore })))))));








  }};let


Share = class Share extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Modified access to '),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                activity.instance, {
                  meta: meta }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt })))))));






  }};let


Unshare = class Unshare extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Modified access to '),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                activity.instance, {
                  meta: meta }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt })))))));






  }};let


Subscribe = class Subscribe extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Subscribed to'),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                activity.instance, {
                  meta: meta }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt })))))));






  }};let


Unsubscribe = class Unsubscribe extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Unsubscribed from'),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Collection"], _extends({},
                activity.instance, {
                  meta: meta }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["User"], activity.user),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_WorkspaceActivityItemComponents__WEBPACK_IMPORTED_MODULE_1__["Time"], { timestamp: activity.createdAt })))))));






  }};let


LoadFeed = class LoadFeed extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-item-wrapper workspace-activity-item-loadfeed' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-loadmore-container' },

          this.props.error ?
          'Something went wrong while fetching the activity feed' :
          this.props.loading ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], null) : '')));




  }};




/***/ }),

/***/ 5863:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return LibraryEmptyListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1808);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2690);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1222);






let

LibraryEmptyListItem = class LibraryEmptyListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  handleTeamLibraryDocs() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__["TEAM_LIBRARY_DOCS"]);
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEvent('onboarding', 'view_documentation_sharing', 'team_library');
  }

  render() {
    if (!this.props.signedIn) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'library-empty-list-item-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'library-empty-list-item__text' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'signed-out-text' }, 'The Team Library and its collaboration tools are a Postman Pro feature. Sign in and upgrade to collaborate on collections and environments with your entire team.')),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'learnmore-link',
              type: 'text',
              onClick: this.handleTeamLibraryDocs }, 'Learn more about the Team Library'),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'primary',
              size: 'huge',
              className: 'signout-out-signin-btn',
              onClick: () => {_modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_5__["default"].login();} }, 'Sign in to Postman')));





    }

    if (this.props.loading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'library-empty-list-item-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'library-empty-list-item' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_2__["default"], null))));



    }


    return this.props.renderEmptyStateComponent();
  }};

/***/ }),

/***/ 5864:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceActivityFeedFilter; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _components_share_SelectDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5782);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _components_workspace_activity_feed_config_WorkspaceActivityFeedConfig__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1645);
var _class;





let


WorkspaceActivityFeedFilter = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class WorkspaceActivityFeedFilter extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      filter: this.props.filtersApplied,
      isFilterApplied: this.props.isFilterApplied,
      isFilterSelected: false };


    this.handleUserSelect = this.handleUserSelect.bind(this);
    this.handleEntitySelect = this.handleEntitySelect.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleClearFilter = this.handleClearFilter.bind(this);
    this.handleRefresh = this.handleRefresh.bind(this);
  }

  handleUserSelect(users) {
    this.setState({
      filter: {
        members: users,
        entities: this.state.filter.entities },

      isFilterSelected: true });

  }

  handleEntitySelect(entities) {
    this.setState({
      filter: {
        members: this.state.filter.members,
        entities: entities },

      isFilterSelected: true });

  }

  handleSearch() {
    this.setState({
      isFilterApplied: true,
      isFilterSelected: false },
    function () {

      _.isFunction(this.props.handleSearch) && this.props.handleSearch(this.state.filter);
    });

  }

  handleClearFilter() {
    this.setState({
      filter: {
        members: {},
        entities: {} },

      isFilterSelected: false },
    function () {
      _.isFunction(this.props.handleClearAll) && this.props.handleClearAll();
    });
  }

  handleRefresh() {
    _.isFunction(this.props.handleRefresh) && this.props.handleRefresh();
  }

  render() {
    const appliedEntitiesLength = _.size(this.props.filtersApplied.entities),
    appliedMembersLength = _.size(this.props.filtersApplied.members),
    selectedEntitiesLength = _.size(this.state.filter.entities),
    selectedMembersLength = _.size(this.state.filter.members),
    entitiesToBeShown = Object(_components_workspace_activity_feed_config_WorkspaceActivityFeedConfig__WEBPACK_IMPORTED_MODULE_5__["getAllowedModelsForWorkspaceFeed"])(),
    workspaceMembers = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveBrowseWorkspaceStore').members.users,
    membersValue = _.map(_.cloneDeep(workspaceMembers), value => {
      value.name = value.name || value.username;

      return value;
    });

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-filter-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-filter' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-filter-types' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_share_SelectDropdown__WEBPACK_IMPORTED_MODULE_3__["default"], {
              className: 'workspace-members',
              selectedItems: this.state.filter.members,
              items: membersValue,
              isFilterApplied: appliedMembersLength && this.props.isFilterApplied,
              isSelected: selectedMembersLength && this.state.isFilterSelected,
              onSelect: this.handleUserSelect,
              dropDownPlaceholder: `Filter by User ${selectedMembersLength > 0 ? `(${selectedMembersLength})` : ''}`,
              searchPlaceholder: 'Search for user',
              searchFields: ['name', 'email'] }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_share_SelectDropdown__WEBPACK_IMPORTED_MODULE_3__["default"], {
              className: 'entities',
              selectedItems: this.state.filter.entities,
              items: entitiesToBeShown,
              isFilterApplied: appliedEntitiesLength && this.props.isFilterApplied,
              isSelected: selectedEntitiesLength && this.state.isFilterSelected,
              onSelect: this.handleEntitySelect,
              dropDownPlaceholder: `Filter by Entity ${selectedEntitiesLength > 0 ? `(${selectedEntitiesLength})` : ''}`,
              searchPlaceholder: 'Select for entity',
              searchFields: ['name'] })),



          (selectedMembersLength + selectedEntitiesLength > 0 || appliedMembersLength + appliedEntitiesLength > 0) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-filter-actions' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                className: 'workspace-activity-feed__search-button',
                type: 'primary',
                onClick: this.handleSearch,
                disabled: !this.state.isFilterSelected }, 'Apply'),



            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                className: 'workspace-activity-feed__clear-button',
                type: 'text',
                onClick: this.handleClearFilter }, 'Clear filters'))),






        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'workspace-activity-feed-refresh' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
              className: 'workspace-activity-feed__refresh',
              type: 'text',
              onClick: this.handleRefresh,
              disabled: this.props.isLoading }, 'Refresh'))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5865:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceOfflineView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2114);



let

WorkspaceOfflineView = class WorkspaceOfflineView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSwitchToBuildView = this.handleSwitchToBuildView.bind(this);
  }

  handleSwitchToBuildView() {
    _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_3__["default"].openBuildMode();
  }


  render() {
    let isLocalWorkspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('WorkspaceStore').find(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceSessionStore').workspace);
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'offline__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'Looks like you\'re offline'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Postman couldn\'t connect to the internet. '),

          isLocalWorkspace ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Switch to the Build view to resume your work.') :
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Switch to one of your personal workspaces.')),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },

          isLocalWorkspace &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'primary',
              onClick: this.handleSwitchToBuildView }, 'Switch to the Build view'))));







  }};

/***/ }),

/***/ 5866:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WorkspaceAPIBrowser", function() { return WorkspaceAPIBrowser; });
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1763);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1537);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_DeleteModal_DeleteModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3939);
/* harmony import */ var _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3938);
/* harmony import */ var _services_APIDevService_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1551);
/* harmony import */ var _js_constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5842);
/* harmony import */ var _js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2078);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(784);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1768);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1793);
/* harmony import */ var _js_components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2125);
/* harmony import */ var _js_components_base_Icons_ShareIcon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5844);
/* harmony import */ var _js_components_base_InlineEditor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1766);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1808);
/* harmony import */ var _WorkspaceAPIsEmpty_WorkspaceAPIsEmpty__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5867);
/* harmony import */ var _js_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5841);
/* harmony import */ var _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3930);
/* harmony import */ var _js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3929);
/* harmony import */ var _js_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(5702);
/* harmony import */ var _api_editor_common_RemoveFromWorkspaceModal_RemoveFromWorkspaceModal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3940);
/* harmony import */ var _js_constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2467);
var _class;

























const DEFAULT_MESSAGE = 'You do not have permissions to perform this action.',
MANAGE_ROLES_MESSAGE = 'You need to be signed-in to a team to perform this action';


let WorkspaceAPIBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_0__["observer"])(_class = class WorkspaceAPIBrowser extends react__WEBPACK_IMPORTED_MODULE_2__["Component"] {
  constructor(props) {
    super(props);this.




















    handleRefresh = () => {
      this.setState({
        isLoading: true });


      Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('APIListStore').refresh().then(() => {
        this.setState({
          isLoading: false });

      }).
      catch(() => {
        this.setState({
          isLoading: false });

      });
    };this.

    deleteAPI = () => {
      this.setState({
        isDeleting: true });

      _services_APIDevService_js__WEBPACK_IMPORTED_MODULE_6__["default"].deleteAPI(this.state.apiId).
      then(() => {
        pm.toasts.success(`You deleted ${this.state.apiName} from all workspaces.`, { title: 'API deleted' });
        this.toggleDeleteModal();
      }).
      catch(err => {
        this.handleError(err, 'There was an unexpected error deleting your API from your workspace. Please try again.');
      });
    };this.

    removeFromWorkspace = () => {
      this.setState({
        isRemovingFromWorkspace: true });

      _services_APIDevService_js__WEBPACK_IMPORTED_MODULE_6__["default"].removeFromWorkspace(this.state.apiId).
      then(() => {
        pm.toasts.success(`You removed ${this.state.apiName} from this workspace.`, { title: 'API removed' });
        this.toggleRemoveFromWorkspaceModal();
      }).
      catch(err => {
        this.handleError(err, 'There was an unexpected error removing this API from your workspace. Please try again.');
      });
    };this.

    handleError = (error, errMsg) => {
      this.setState({ isDeleting: false, isRemovingFromWorkspace: false, isLoading: false });
      let toastMessage = _.get(error, 'details.message') || _.get(error, 'message') || errMsg,
      toastTitle = _.get(error, 'error.title');

      pm.toasts.error(toastMessage, { noIcon: true, title: toastTitle });
    };this.













































    handleAPIActions = (apiId, apiName, action) => {
      switch (action) {
        case _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MANAGE_ROLES"]:
          Object(_js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_19__["manageRolesOnAPI"])(apiId);
          return;
        case _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"]:
          this.toggleDeleteModal(apiId, apiName);
          return;
        case _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"]:
          this.toggleRemoveFromWorkspaceModal(apiId, apiName);
          return;}

    };this.

    toggleRemoveFromWorkspaceModal = (apiId, apiName) => {
      this.setState(prevState => ({
        openRemoveFromWorkspaceModal: !prevState.openRemoveFromWorkspaceModal,
        isRemovingFromWorkspace: false,
        apiId: apiId,
        apiName: apiName }));

    };this.

    toggleDeleteModal = (apiId, apiName) => {
      this.setState(prevState => ({
        openDeleteModal: !prevState.openDeleteModal,
        isDeleting: false,
        apiId: apiId,
        apiName: apiName }));

    };this.state = { filterQuery: '', sortType: _js_constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_7__["LIBRARY_SORT_TYPE_NAME"], isLoading: false, openDeleteModal: false, isDeleting: false, apiId: '', apiName: '' };this.handleFilterQueryChange = this.handleFilterQueryChange.bind(this);this.handleFilterQueryCancel = this.handleFilterQueryCancel.bind(this);this.handleSortTypeChange = this.handleSortTypeChange.bind(this);this.handleAction = this.handleAction.bind(this);this.handleRefreshDebounced = _.debounce(this.handleRefresh, 5000, { leading: true, trailing: false });}getFilteredAPIs() {return _.chain(this.props.apis).filter(api => _.includes(_.toLower(api.name), _.toLower(this.state.filterQuery))).sortBy([this.getSortFunction(this.state.sortType)]).value();}handleFilterQueryChange(filterQuery) {this.setState({ filterQuery });}handleFilterQueryCancel() {this.setState({ filterQuery: '' });}handleSortTypeChange(sortType) {this.setState({ sortType });}getSortFunction(type) {switch (type) {case _js_constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_7__["LIBRARY_SORT_TYPE_NAME"]:return api => _.toLower(api.name);case _js_constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_7__["LIBRARY_SORT_TYPE_LAST_MODIFIED"]:return api => new moment__WEBPACK_IMPORTED_MODULE_1___default.a(api.updatedAt);case _js_constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_7__["LIBRARY_SORT_TYPE_DATE_CREATED"]:return api => new moment__WEBPACK_IMPORTED_MODULE_1___default.a(api.createdAt);case _js_constants_LibrarySortTypeConstants__WEBPACK_IMPORTED_MODULE_7__["LIBRARY_SORT_TYPE_OWNER"]:return api => _.toLower(_js_utils_util__WEBPACK_IMPORTED_MODULE_10__["default"].getUserNameForId(api.createdBy, Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore')));}}handleAction(api, action) {if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {pm.mediator.trigger('joinWorkspace');return;}this.handleAPIActions(api.id, api.name, action);}

  handleShare(api) {
    Object(_js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_20__["shareAPI"])(api.id);
  }

  getActions() {
    const currentUserStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore');

    return [
    {
      type: _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MANAGE_ROLES"],
      label: 'Manage Roles',
      isEnabled: Boolean(currentUserStore.team) },

    {
      type: _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"],
      label: 'Remove from workspace',
      isEnabled: true },

    {
      type: _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      isEnabled: true }];


  }

  getDisabledText(isDisabled, actionType) {
    if (!isDisabled) {
      return;
    }

    switch (actionType) {
      case _api_dev_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MANAGE_ROLES"]:
        return MANAGE_ROLES_MESSAGE;
      default:
        return DEFAULT_MESSAGE;}

  }

  getMenuItems() {
    return _.map(this.getActions(), action => {
      return (
        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_12__["MenuItem"], {
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled, action.type) },

          react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label)));


    });
  }

  // redirect to web view
  handleAPIClick(apiId) {
    Object(_js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_8__["openEntity"])('apis', apiId, Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveBrowseWorkspaceStore').id);
  }

  render() {
    let filteredAPIs = this.getFilteredAPIs();

    if (this.state.isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_16__["default"], null));

    }
    if (_.isEmpty(this.props.apis)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'workspace-item-browser__container collections empty' },
          react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_WorkspaceAPIsEmpty_WorkspaceAPIsEmpty__WEBPACK_IMPORTED_MODULE_17__["default"], {
            isMember: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveBrowseWorkspaceStore').isMember,
            workspaceId: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveBrowseWorkspaceStore').id })));



    }
    return (
      react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'workspace-item-browser__container collections' },
        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'workspace-head' },
          react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_workspaces_WorkspaceBrowserFilter__WEBPACK_IMPORTED_MODULE_18__["WorkspaceBrowserFilter"], {
            onFilterQueryChange: this.handleFilterQueryChange,
            onFilterQueryCancel: this.handleFilterQueryCancel,
            filterQuery: this.state.filterQuery,
            onSortTypeChange: this.handleSortTypeChange,
            sortType: this.state.sortType }),

          react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_11__["Button"], {
              type: 'text',
              onClick: this.handleRefreshDebounced }, 'Refresh')),




        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'collections__list' },

          _.isEmpty(filteredAPIs) && this.state.filterQuery &&
          react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_empty_states_NoResultFound__WEBPACK_IMPORTED_MODULE_21__["default"], null),


          _.map(filteredAPIs, api => {
            return (
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { key: api.id, className: 'collections__list__item' },
                react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'collections__item__header' },
                  react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'collections__item__label__wrapper' },
                    react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'collections__item__label' },
                      react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_11__["Button"], {
                          type: 'text',
                          className: 'collection-name',
                          onClick: this.handleAPIClick.bind(this, api.id) },

                        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('span', null, api.name))),


                    react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'collections__item__owner' },
                      _js_utils_util__WEBPACK_IMPORTED_MODULE_10__["default"].getUserNameForId(api.createdBy, Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore')))),


                  react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', { className: 'entities__item__action_wrapper' },
                    react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_11__["Button"], {
                        onClick: this.handleShare.bind(this, api),
                        type: 'secondary',
                        size: 'small' },

                      react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Icons_ShareIcon__WEBPACK_IMPORTED_MODULE_14__["default"], { className: 'share-icon' }),
                      react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('span', null, 'Share')),

                    react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_12__["Dropdown"], {
                        className: 'entities_item__action__dropdown',
                        onSelect: this.handleAction.bind(this, api) },

                      react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_12__["DropdownButton"], {
                          dropdownStyle: 'nocaret',
                          type: 'custom' },

                        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_11__["Button"], { tooltip: _js_constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_23__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
                          react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Icons_MoreIcon__WEBPACK_IMPORTED_MODULE_13__["default"], { className: 'entities_item__action__dropdown-btn' }))),


                      react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_12__["DropdownMenu"], {
                          'align-right': true },

                        this.getMenuItems(api))))),




                react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_js_components_base_InlineEditor__WEBPACK_IMPORTED_MODULE_15__["default"], {
                  isViewMore: true,
                  className: 'collections__item__description',
                  placeholder: 'Make things easier for your teammates with a complete request description.',
                  value: api.description })));



          })),


        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_common_DeleteModal_DeleteModal__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isOpen: this.state.openDeleteModal,
          onRequestClose: this.toggleDeleteModal,
          headerTitle: 'Delete API?',
          content: 'This will delete the API from all workspaces – no one on your team will be able to access it.\nThis won\'t affect the mock servers, documentation, environments, and test suites linked to this API.',
          btnContent: 'Delete API',
          onSubmit: this.deleteAPI,
          isLoading: this.state.isDeleting }),

        react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_api_editor_common_RemoveFromWorkspaceModal_RemoveFromWorkspaceModal__WEBPACK_IMPORTED_MODULE_22__["default"], {
          isOpen: this.state.openRemoveFromWorkspaceModal,
          onRequestClose: this.toggleRemoveFromWorkspaceModal,
          headerTitle: 'Remove API?',
          content: 'Are you sure you want to remove this API from this workspace? \nThe mock servers, documentation, environments, test suites and monitors linked to this API won’t be affected.',
          btnContent: 'Remove API',
          onSubmit: this.removeFromWorkspace,
          isLoading: this.state.isRemovingFromWorkspace })));



  }}) || _class;


WorkspaceAPIBrowser.propTypes = {
  apis: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.array.isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5867:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceAPIsEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
let

WorkspaceAPIsEmpty = class WorkspaceAPIsEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--collections' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'No APIs yet'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' }, 'APIs define related collections and environments under a consistent schema.')));




  }};

/***/ })

}]);