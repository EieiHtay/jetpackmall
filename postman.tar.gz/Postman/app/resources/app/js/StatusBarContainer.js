(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[18],{

/***/ 5894:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return StatusBarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5895);
/* harmony import */ var _components_status_bar_plugins__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5897);
/* harmony import */ var _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5896);
/* harmony import */ var _components_status_bar_base_Item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5911);
/* harmony import */ var _components_status_bar_base_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5912);
/* harmony import */ var _components_status_bar_base_Icon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5913);
/* harmony import */ var _components_status_bar_base_Pane__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5914);
/* harmony import */ var _components_status_bar_base_Drawer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5915);
/* harmony import */ var _constants_RequesterTabLayoutConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1764);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1789);
var _class;















let PluginEnvironment = {
  React: (react__WEBPACK_IMPORTED_MODULE_0___default()),
  PluginInterface: _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_4__["default"],
  StatusBarComponents: {
    Item: _components_status_bar_base_Item__WEBPACK_IMPORTED_MODULE_5__["default"],
    Text: _components_status_bar_base_Text__WEBPACK_IMPORTED_MODULE_6__["default"],
    Icon: _components_status_bar_base_Icon__WEBPACK_IMPORTED_MODULE_7__["default"],
    Pane: _components_status_bar_base_Pane__WEBPACK_IMPORTED_MODULE_8__["default"],
    Drawer: _components_status_bar_base_Drawer__WEBPACK_IMPORTED_MODULE_9__["default"] },

  constants: {
    layout: {
      REQUESTER_TAB_LAYOUT_1_COLUMN: _constants_RequesterTabLayoutConstants__WEBPACK_IMPORTED_MODULE_10__["REQUESTER_TAB_LAYOUT_1_COLUMN"],
      REQUESTER_TAB_LAYOUT_2_COLUMN: _constants_RequesterTabLayoutConstants__WEBPACK_IMPORTED_MODULE_10__["REQUESTER_TAB_LAYOUT_2_COLUMN"] } } };let





StatusBarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class StatusBarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      items: [],
      activeItem: null };


    this.addItem = this.addItem.bind(this);
    this.addItems = this.addItems.bind(this);
    this.toggleActive = this.toggleActive.bind(this);
    this.items = null;
  }

  componentDidMount() {
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].initialize();
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].loadPlugins(_components_status_bar_plugins__WEBPACK_IMPORTED_MODULE_3__["default"]);
  }

  UNSAFE_componentWillMount() {
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].on('loadedPlugins', this.addItems);
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].on('add', this.addItem);
  }

  componentWillUnmount() {
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].off('loadedPlugins', this.addItems);
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].off('add', this.addItem);
    this.items = null;
  }

  addItem(item) {
    this.items.push({
      item: item,
      component: item.getComponent(PluginEnvironment) });

    let items = _.concat(this.state.items, item);
    this.setState({ items });
  }

  addItems(items) {
    this.items = _.map(_components_status_bar_plugins__WEBPACK_IMPORTED_MODULE_3__["default"], item => {
      return {
        item: item,
        component: item.getComponent(PluginEnvironment) };

    });
    this.setState({ items });
  }

  toggleActive(item) {
    this.setState({ activeItem: this.state.activeItem === item ? null : item });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'statusBar' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'status-bar-container status-bar' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sb-section' },

            _.map(this.items, (item, index) => {
              return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(item.component, {
                key: index,
                isOpen: _.isEqual(this.state.activeItem, item.item.name),
                toggleActive: this.toggleActive.bind(this, item.item.name) });

            })))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5895:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(131);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5896);

let

StatusBar = class StatusBar extends events__WEBPACK_IMPORTED_MODULE_0___default.a {
  constructor() {
    super();
  }

  initialize() {
    _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_1__["default"].initialize();
  }

  register(property, handler, context) {
    this.properties[property] &&
    this.properties[property].handler(context, handler);
  }

  loadPlugins(plugins) {
    this.emit('loadedPlugins', plugins);
  }

  addItem(sbItem) {
    this.emit('add', sbItem);
    sbItem.initialize && sbItem.initialize();
  }};


/* harmony default export */ __webpack_exports__["default"] = (new StatusBar());

/***/ }),

/***/ 5896:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(751);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1875);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1545);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1222);
/* harmony import */ var _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1540);







let
PluginInterface = class PluginInterface {
  initialize() {
    this.properties = {
      layout: {
        value: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ConfigurationStore').get('editor.requestEditorLayoutName'),
        registerer: function (context, cb) {
          Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ConfigurationStore').get('editor.requestEditorLayoutName'), cb.bind(context));
        } },

      theme: {
        value: pm.settings.getSetting('postmanTheme') || 'light',
        registerer: function (context, cb) {
          pm.settings.on('setSetting:postmanTheme', cb, context);
        } },

      platform: {
        value: navigator.platform,
        registerer: _.noop },

      windows: {
        value: [],
        registerer: function (context, cb) {
          pm.appWindow.on('windowClosed', cb.bind(context, 'windowClosed'), context);
        } },

      modals: {
        value: null,
        registerer: function (context, cb) {
          pm.mediator.on('modalOpened', cb.bind(context, 'modalOpened'), context);
          pm.mediator.on('modalClosed', cb.bind(context, 'modalClosed'), context);
        } },

      xFlows: {
        value: null,
        registerer: function (context, cb) {
          pm.mediator.on('saveXFlowActivity', cb.bind(context), context);
        } } };


  }

  register(property, handler, context) {
    this.properties[property] &&
    this.properties[property].registerer(context, handler);
  }

  get(key) {
    return _.get(this, `properties[${key}].value`);
  }

  openWindow(windowType) {
    switch (windowType) {
      case 'requester':
        pm.mediator.trigger('newRequesterWindow');
        break;
      case 'runner':
        pm.mediator.trigger('newRunnerWindow');
        break;
      case 'console':
        pm.mediator.trigger('newConsoleWindow');
        break;
      default:
        break;}

  }

  toggleTwoPaneLayout() {
    pm.app.toggleLayout();
  }

  openURL(url) {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__["openExternalLink"])(url);
  }

  openModal(modalName, options) {
    switch (modalName) {
      case 'settings':
        pm.mediator.trigger('openSettingsModal', options.tab);
        break;
      case 'release-notes':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_3__["default"].open('customview://releaseNotes');
        break;
      case 'x-flow-activity-feed':
        pm.mediator.trigger('openXFlowActivityFeed');
        break;
      default:
        break;}

  }

  toggleSidebar() {
    pm.mediator.trigger('toggleSidebar');
  }

  toggleFindReplace() {
    const store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(_constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_5__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"]);
  }

  toggleConsole() {
    const store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(_constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_5__["REQUESTER_BOTTOM_PANE_CONSOLE"]);
  }};


/* harmony default export */ __webpack_exports__["default"] = (new PluginInterface());
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5897:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Help__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5898);
/* harmony import */ var _ShortcutsReference__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5900);
/* harmony import */ var _TwoPane__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5902);
/* harmony import */ var _ToggleSidebar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5905);
/* harmony import */ var _WorkspaceTypeSwitcher__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5907);
/* harmony import */ var _onboarding_src_features_Skills_Bootcamp_components_BootcampLauncher__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5908);
/* harmony import */ var _AgentSelection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5909);








/* harmony default export */ __webpack_exports__["default"] = ([
_Help__WEBPACK_IMPORTED_MODULE_0__["default"],
_ShortcutsReference__WEBPACK_IMPORTED_MODULE_1__["default"],
_TwoPane__WEBPACK_IMPORTED_MODULE_2__["default"],
_ToggleSidebar__WEBPACK_IMPORTED_MODULE_3__["default"],
_AgentSelection__WEBPACK_IMPORTED_MODULE_6__["default"],
_WorkspaceTypeSwitcher__WEBPACK_IMPORTED_MODULE_4__["default"],
_onboarding_src_features_Skills_Bootcamp_components_BootcampLauncher__WEBPACK_IMPORTED_MODULE_5__["default"]]);

/***/ }),

/***/ 5898:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_base_Icons_HelpIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5899);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1875);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Help',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {let
    Help = class Help extends React.Component {
      constructor(props) {
        super(props);
      }

      handleItemSelect(item) {
        switch (item) {
          case 'releases':
            PluginInterface.openModal('release-notes');
            break;
          case 'docs':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["DOCS_URL"]);
            break;
          case 'security':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["DOCS_SECURITY_URL"]);
            break;
          case 'support':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["SUPPORT_URL"]);
            break;
          case 'twitter':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["TWITTER_URL"]);
            break;
          case 'community':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["POSTMAN_COMMUNITY"]);
            break;
          default:
            break;}

      }

      getIcon() {
        return (
          React.createElement(_components_base_Icons_HelpIcon__WEBPACK_IMPORTED_MODULE_0__["default"], null));

      }

      render() {
        let { Item, Icon, Drawer } = StatusBarComponents;

        return (
          React.createElement(Item, _extends({
              className: 'plugin__help',
              tooltip: 'Help & Feedback' },
            this.props),

            React.createElement(Drawer, {
              className: 'plugin__help__drawer',
              button: () => {
                return (
                  React.createElement(Icon, {
                    className: 'plugin__help__icon',
                    icon: this.getIcon() }));


              },
              onSelect: this.handleItemSelect,
              items: [
              {
                key: 'releases',
                label: 'Release Notes' },

              {
                key: 'docs',
                label: 'Documentation' },

              {
                key: 'security',
                label: 'Security' },

              {
                key: 'support',
                label: 'Support' },

              {
                key: 'twitter',
                label: '@getpostman' },

              {
                key: 'community',
                label: 'Community' }] })));





      }};


    return Help;
  } });

/***/ }),

/***/ 5899:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HelpIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'help', d: 'M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm0-1A7 7 0 1 0 8 1a7 7 0 0 0 0 14zM6.715 5.054a.622.622 0 1 1-1.143-.5A2.581 2.581 0 0 1 7.94 3a2.586 2.586 0 0 1 2.581 2.59c0 .864-.583 1.588-1.642 2.19a.625.625 0 0 0-.316.543V9.79a.624.624 0 1 1-1.246 0V8.323c0-.675.362-1.298.947-1.63.71-.404 1.01-.778 1.01-1.104a1.335 1.335 0 1 0-2.56-.536zm.6 7.321a.624.624 0 1 0 1.249.002.624.624 0 0 0-1.248-.002z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#666', fillRule: 'nonzero', xlinkHref: '#help' }));



function HelpIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 5900:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _components_base_Icons_KeyboardShortcutIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5901);


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Shortcuts',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {
    return class ShortcutsReference extends React.Component {
      constructor(props) {
        super(props);

        this.state = { isModalOpen: false };
      }

      UNSAFE_componentWillMount() {
        PluginInterface.register('modals', this.handleModalState, this);
      }

      handleClick() {
        PluginInterface.openModal('settings', { tab: 'shortcuts' });
      }

      handleModalState(event, payload) {
        if (event === 'modalOpened' && payload.name === 'settings' && payload.activeTab === 'shortcuts') {
          this.setState({ isModalOpen: true });
        } else
        if (event === 'modalOpened' && payload.name === 'settings') {
          this.setState({ isModalOpen: false });
        } else
        if (event === 'modalClosed' && payload.name === 'settings') {
          this.setState({ isModalOpen: false });
        }
      }

      getIcon() {
        let style = this.state.isModalOpen ? 'secondary' : 'normal';

        return (
          React.createElement(_components_base_Icons_KeyboardShortcutIcon__WEBPACK_IMPORTED_MODULE_0__["default"], { style: style }));

      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌘?';
        } else
        {
          return 'Ctrl + ?';
        }
      }

      render() {
        let { Item, Icon } = StatusBarComponents;

        return (
          React.createElement(Item, {
              className: 'plugin__shortcuts',
              tooltip: `Keyboard Shortcuts (${this.getShortcut()})` },

            React.createElement(Icon, {
              onClick: this.handleClick,
              className: 'plugin__shortcuts__icon',
              icon: this.getIcon() })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5901:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return KeyboardShortcutIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '15', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'keyboard-shortcut', d: 'M7.1 7V2.687c0-.455-.414-.843-.934-.843-.519 0-.932.388-.932.843v.751c0 .989-.846 1.781-1.868 1.781-1.02 0-1.866-.792-1.866-1.781V.5a.5.5 0 0 1 1 0v2.938c0 .421.384.781.866.781.484 0 .868-.36.868-.781v-.751c0-1.023.875-1.843 1.932-1.843 1.059 0 1.934.82 1.934 1.843V7H15v9H0V7h7.1zM1 15h13V8H1v7zm1-6h1v1H2V9zm2 0h1v1H4V9zm2 0h1v1H6V9zm2 0h1v1H8V9zm2 0h1v1h-1V9zm2 0h1v1h-1V9zM2 11h1v1H2v-1zm1 2h1v1H3v-1zm1-2h1v1H4v-1zm2 0h1v1H6v-1zm2 0h1v1H8v-1zm2 0h1v1h-1v-1zm2 0h1v1h-1v-1zm-1 2h1v1h-1v-1zm-6 0h5v1H5v-1z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', xlinkHref: '#keyboard-shortcut' }));



function KeyboardShortcutIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: 'shortcuts' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5902:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _components_base_Icons_TwoPaneIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5903);
/* harmony import */ var _components_base_Icons_SinglePaneIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5904);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'TwoPane',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents,
    constants })
  {
    return class TwoPane extends React.Component {
      constructor(props) {
        super(props);

        this.state = { layout: PluginInterface.get('layout') };
      }

      UNSAFE_componentWillMount() {
        PluginInterface.register('layout', this.handleLayout, this);
      }

      handleLayout(payload) {
        this.setState({ layout: payload });
      }

      handleClick() {
        PluginInterface.toggleTwoPaneLayout();
      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌥⌘V';
        } else
        {
          return 'Ctrl + Alt + V';
        }
      }

      getIcon() {
        let activeTheme = PluginInterface.get('theme'),
        layout = this.state.layout,
        { REQUESTER_TAB_LAYOUT_1_COLUMN, REQUESTER_TAB_LAYOUT_2_COLUMN } = constants.layout;

        if (_.isEqual(layout, REQUESTER_TAB_LAYOUT_2_COLUMN)) {
          return (
            React.createElement(_components_base_Icons_SinglePaneIcon__WEBPACK_IMPORTED_MODULE_1__["default"], null));

        } else
        {
          return (
            React.createElement(_components_base_Icons_TwoPaneIcon__WEBPACK_IMPORTED_MODULE_0__["default"], null));

        }
      }

      render() {
        let { Item, Icon } = StatusBarComponents,
        { REQUESTER_TAB_LAYOUT_2_COLUMN } = constants.layout,
        isTwoPane = this.state.layout === REQUESTER_TAB_LAYOUT_2_COLUMN;

        return (
          React.createElement(Item, {
              className: `plugin__layout ${isTwoPane ? 'singlePane' : 'twoPane'}`,
              tooltip: `${isTwoPane ? 'Single pane view' : 'Two pane view'} (${this.getShortcut()})` },

            React.createElement(Icon, {
              onClick: this.handleClick,
              icon: this.getIcon() })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5903:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TwoPaneIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'two-pane', d: 'M7.5 1H1v14h6.521a.974.974 0 0 1-.021-.205V1zm1 0v13.795c0 .072-.007.14-.021.205H15V1H8.5zM15 0a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h14zM2.25 10V6h4v4h-4zm9.5 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', xlinkHref: '#two-pane' }));



function TwoPaneIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: 'layout' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5904:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SinglePaneIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'single-pane', d: 'M7.5 1H1v14h6.521a.974.974 0 0 1-.021-.205V1zm1 0v13.795c0 .072-.007.14-.021.205H15V1H8.5zM15 0a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h14zM2.25 10V6h4v4h-4zm9.5 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', transform: 'rotate(90 8 8)', xlinkHref: '#single-pane' }));



function SinglePaneIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: 'layout' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5905:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _components_base_Icons_SidebarShowIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5906);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ToggleSidebar',
  position: 'left',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {var _class;
    return Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class ToggleSidebar extends React.Component {
      constructor(props) {
        super(props);

        this.handleClick = this.handleClick.bind(this);
      }

      handleClick() {
        PluginInterface.toggleSidebar();
      }

      getIcon(isOpen) {
        let style = isOpen ? 'secondary' : 'normal';

        return (
          React.createElement(_components_base_Icons_SidebarShowIcon__WEBPACK_IMPORTED_MODULE_0__["default"], { style: style }));

      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌘\\';
        } else
        {
          return 'Ctrl + \\';
        }
      }

      render() {
        let { Item, Icon } = StatusBarComponents;
        let isOpen = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('RequesterSidebarStore').isOpen;

        return (
          React.createElement(Item, {
              className: 'plugin__sidebar-shortcut',
              tooltip: `${isOpen ? 'Hide' : 'Show'} Sidebar (${this.getShortcut()})` },

            React.createElement(Icon, {
              onClick: this.handleClick,
              className: 'plugin__sidebar__icon',
              icon: this.getIcon(isOpen) })));



      }}) || _class;

  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5906:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SidebarShowIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '14', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'sidebar-show', d: 'M7 2H1.433A.433.433 0 0 0 1 2.434v11.132c0 .24.194.434.433.434H7V2zm1 0v12h6.567c.24 0 .433-.194.433-.434V2.434A.433.433 0 0 0 14.567 2H8zM6 5v1H2V5h4zm0-1H2V3h4v1zm0 3v1H2V7h4zm0 2v1H2V9h4zm0 2v1H2v-1h4zM1.324 1h13.352C15.407 1 16 1.593 16 2.324v11.352c0 .731-.593 1.324-1.324 1.324H1.324A1.324 1.324 0 0 1 0 13.676V2.324C0 1.593.593 1 1.324 1z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', xlinkHref: '#sidebar-show' }));



function SidebarShowIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: 'sidebar' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5907:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(774);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(751);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(748);
/* harmony import */ var _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2114);
/* harmony import */ var _constants_AppUrlConstants_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1875);
/* harmony import */ var _WorkspaceTypeSwitcherIntro__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2098);
/* harmony import */ var _TypeSwitcher__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2097);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1222);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};











const labelMap = {
  [_constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BUILDER_VIEW"]]: 'Build',
  [_constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BROWSER_VIEW"]]: 'Browse' };


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'WorkspaceViewSwitcher',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {let
    WorkspaceTypeSwitcher = class WorkspaceTypeSwitcher extends React.Component {
      constructor(props) {
        super(props);

        this.state = { showTooltip: false };

        this.handleItemSelect = this.handleItemSelect.bind(this);
        this.handleHideTooptip = this.handleHideTooptip.bind(this);
        this.handleShowTooltip = this.handleShowTooltip.bind(this);
        this.handleLearnMore = this.handleLearnMore.bind(this);
      }

      UNSAFE_componentWillMount() {
        this.viewModeReaction = Object(mobx__WEBPACK_IMPORTED_MODULE_3__["reaction"])(() => Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').viewMode, viewMode => {
          if (viewMode === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BROWSER_VIEW"]) {
            this.handleShowTooltip();
          }
        });
      }

      componentWillUnmount() {
        this.viewModeReaction();
      }

      handleHideTooptip() {
        this.setState({ showTooltip: false });
        pm.settings.setSetting('showWorkspaceTypeSwitcherIntro', false);
      }

      handleShowTooltip() {
        this.setState({ showTooltip: _.isUndefined(pm.settings.getSetting('showWorkspaceTypeSwitcherIntro')) ? true : pm.settings.getSetting('showWorkspaceTypeSwitcherIntro') });
      }

      handleLearnMore() {
        Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_10__["openExternalLink"])(_constants_AppUrlConstants_js__WEBPACK_IMPORTED_MODULE_7__["BROWSING_A_WORKSPACE_DOCS"]);
      }

      handleItemSelect(item) {
        this.handleHideTooptip();

        if (item === Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').viewMode) {
          return;
        } else
        if (item === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BROWSER_VIEW"]) {
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('workspace', 'switch_view', 'browse');
          _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_6__["default"].openBrowseMode();
        } else
        if (item === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BUILDER_VIEW"]) {
          if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
            pm.mediator.trigger('joinWorkspace');
            return;
          }
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('workspace', 'switch_view', 'build');
          _services_WorkspaceViewModeService__WEBPACK_IMPORTED_MODULE_6__["default"].openBuildMode();
        }

      }

      getSwitchClasses(viewMode) {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default()({
          'plugin__workspace-view-switcher__switch': true,
          left: viewMode === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BUILDER_VIEW"],
          right: viewMode === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BROWSER_VIEW"] });

      }

      render() {
        let { Item, Text } = StatusBarComponents;
        if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('CurrentUserStore').isLoggedIn) {
          return false;
        }

        let viewMode = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').viewMode;
        return (
          React.createElement('div', null,
            React.createElement(Item, _extends({
                className: 'plugin__workspace-view-switcher',
                tooltip: 'Switch workspace view',
                ref: 'tooltip_button' },
              this.props),

              React.createElement(Text, {
                render: () => {
                  return (
                    React.createElement(_TypeSwitcher__WEBPACK_IMPORTED_MODULE_9__["default"], {
                      activeItem: viewMode,
                      onSelect: this.handleItemSelect,
                      items: [
                      {
                        key: _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BUILDER_VIEW"],
                        label: 'Build',
                        position: 'left' },

                      {
                        key: _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_0__["WORKSPACE_BROWSER_VIEW"],
                        label: 'Browse',
                        position: 'right' }] }));




                } })),


            React.createElement(_WorkspaceTypeSwitcherIntro__WEBPACK_IMPORTED_MODULE_8__["default"], {
              show: this.state.showTooltip,
              target: this.refs.tooltip_button,
              onHide: this.handleHideTooptip,
              onLearnMore: this.handleLearnMore })));




      }};


    return Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(WorkspaceTypeSwitcher);
  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5908:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LessonConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2598);
/* harmony import */ var _common_APIService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2561);
/* harmony import */ var _LessonController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2562);
/* harmony import */ var _common_dependencies__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2109);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1789);
/* harmony import */ var _js_components_base_Icons_BootcampIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2931);
/* harmony import */ var _js_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1883);













const defaultState = {
  dismissable: false,
  currentState: null,
  label: 'Bootcamp',
  pausedLessonId: null },

HIGHLIGHT_STATE = 'highlight',
SUCCESS_STATE = 'success';

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'learningCenter',
  position: 'right',

  getComponent: function ({
    React,
    StatusBarComponents })
  {
    return class LearningCenter extends React.Component {
      constructor(props) {
        super(props);
        this.state = defaultState;

        this.handleReset = this.handleReset.bind(this);
        this.handleContinue = this.handleContinue.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.handleHighlightLessonButton = this.handleHighlightLessonButton.bind(this);
        _common_dependencies__WEBPACK_IMPORTED_MODULE_4__["UIEventService"].subscribe(_LessonConstants__WEBPACK_IMPORTED_MODULE_1__["LESSON_PAUSED"], this.handleContinue);
        _common_dependencies__WEBPACK_IMPORTED_MODULE_4__["UIEventService"].subscribe('highlightLessonButton', this.handleHighlightLessonButton);
        _common_dependencies__WEBPACK_IMPORTED_MODULE_4__["UIEventService"].subscribe(_common_dependencies__WEBPACK_IMPORTED_MODULE_4__["OPEN_LESSON_PLAN"], this.openBootcampTab);
      }

      openBootcampTab() {
        _common_dependencies__WEBPACK_IMPORTED_MODULE_4__["EditorService"].open('customView://bootcamp', { preview: false });
      }

      continuePausedLesson() {
        Object(_common_APIService__WEBPACK_IMPORTED_MODULE_2__["fetchLesson"])(this.state.pausedLessonId, lesson => {
          if (_.isEmpty(lesson)) {
            return;
          }
          _LessonController__WEBPACK_IMPORTED_MODULE_3__["default"].continueLesson(lesson);
        });
        this.handleReset();
      }

      handleClick() {
        if (this.state.pausedLessonId) {
          this.continuePausedLesson();
          return;
        }
        let currentUser = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CurrentUserStore'),
        isLoggedIn = currentUser && currentUser.isLoggedIn;

        if (!isLoggedIn) {
          pm.mediator.trigger('showSignInModal', {
            title: 'Improve your skills in Postman',
            subtitle: 'Learn about different features inside Postman and improve your skills through an interactive tutorial. Please create an account to continue.',
            renderIcon: this.renderIcon,
            onAuthentication: this.openBootcampTab,
            origin: 'learning_center' });

          return;
        }

        this.openBootcampTab();
        this.handleReset();
      }

      renderIcon() {
        return React.createElement('div', { className: 'learning-center-empty-state-icon' });
      }

      handleReset(e) {
        e && e.stopPropagation();
        this.setState(defaultState);
      }

      handleContinue(pausedLessonId) {
        this.setState({
          dismissable: true,
          currentState: HIGHLIGHT_STATE,
          label: 'Continue learning',
          pausedLessonId });

      }

      handleHighlightLessonButton() {
        this.setState({
          currentState: HIGHLIGHT_STATE,
          label: 'Bootcamp' });

      }

      render() {
        let { Item, Text } = StatusBarComponents;

        return (
          React.createElement(Item, {
              className: 'plugin__learningCenter',
              tooltip: 'Learning Center' },

            React.createElement(Text, {
              render: () => {
                return (
                  React.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__["default"], { identifier: 'learningCenter' },
                    React.createElement('div', {
                        className: classnames__WEBPACK_IMPORTED_MODULE_0___default()('learning-center-button', this.state.currentState),
                        onClick: this.handleClick },

                      React.createElement(_js_components_base_Icons_BootcampIcon__WEBPACK_IMPORTED_MODULE_6__["default"], null),
                      React.createElement('span', { className:
                          classnames__WEBPACK_IMPORTED_MODULE_0___default()(
                          { 'dismissable': this.state.dismissable },
                          'learning-center-label') },


                        this.state.label),


                      this.state.dismissable &&
                      React.createElement(_js_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_7__["default"], { size: 'xs', onClick: this.handleReset }))));




              } })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5909:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _components_base_Icons_RunIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5790);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1789);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1769);
/* harmony import */ var _runtime_components_agent_AgentSelectionContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5910);
/* harmony import */ var _runtime_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2104);











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AgentSelection',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {var _class;
    return Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class AgentSelection extends React.Component {
      constructor(props) {
        super(props);

        this.state = {
          isOpen: false };


        this.handleOpen = this.handleOpen.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleClick = this.handleClick.bind(this);
      }

      handleOpen() {
        this.setState({ isOpen: true });
      }

      handleClose() {
        this.setState({ isOpen: false });
      }

      handleClick() {
        this.setState(({ isOpen }) => ({ isOpen: !isOpen }));
      }

      componentWillMount() {
        pm.mediator.on('showAgentSelectionPopover', this.handleOpen);
      }

      componentWillUnmount() {
        pm.mediator.off('showAgentSelectionPopover', this.handleOpen);
      }

      getIcon() {
        const { state: agentState } = pm.runtime.agent.stat,
        className = classnames__WEBPACK_IMPORTED_MODULE_1___default()('agent-selection-icon', { 'has-error': agentState === _runtime_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_7__["STATES"].DISCONNECTED });

        return (
          React.createElement(_components_base_Icons_RunIcon__WEBPACK_IMPORTED_MODULE_3__["default"], { className: className }));

      }

      render() {
        if (!(window.SDK_PLATFORM === 'browser')) {
          return null;
        }

        let { Item, Icon } = StatusBarComponents;

        return (
          React.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: 'runtime-agent' },
            React.createElement('div', { ref: ref => {this.containerRef = ref;} },
              React.createElement(Item, {
                  className: 'plugin__agent-selection-shortcut' },

                React.createElement(Icon, {
                  onClick: this.handleClick,
                  className: 'plugin__agent-selection__icon',
                  icon: this.getIcon() })),


              React.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_5__["Tooltip"], {
                  className: 'agent-selection__details',
                  show: this.state.isOpen,
                  target: this.containerRef,
                  placement: 'top',
                  immediate: true },

                React.createElement(_runtime_components_agent_AgentSelectionContainer__WEBPACK_IMPORTED_MODULE_6__["default"], { onClose: this.handleClose })))));




      }}) || _class;

  } });

/***/ }),

/***/ 5910:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AgentSelectionContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _base_atom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2468);
/* harmony import */ var _base_molecule__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2514);
/* harmony import */ var _js_components_base_Text__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2120);
/* harmony import */ var _js_components_base_Icons_ErrorIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2067);
/* harmony import */ var _js_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1883);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1222);
/* harmony import */ var _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2104);
/* harmony import */ var _js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1875);
var _class;











let


AgentSelectionContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class AgentSelectionContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleAgentSelect = this.handleAgentSelect.bind(this);
    this.renderSelectionDropdown = this.renderSelectionDropdown.bind(this);
    this.handleAgentOnboardingOpen = this.handleAgentOnboardingOpen.bind(this);
    this.handleLinkClick = this.handleLinkClick.bind(this);
  }

  getMessage(isXHR, hasError) {
    // Browser agent
    if (isXHR) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, 'Sending your requests through your browser comes with some',

          ' ',
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'details__link', onClick: this.handleLinkClick }, 'limitations'), '.'));



    }

    // Desktop agent with error
    if (hasError) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, 'Make sure the Agent is',

          ' ',
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'details__link', onClick: this.handleAgentOnboardingOpen }, 'installed'),
          ' ', 'and check your toolbar to see if it\'s running.'));



    }

    // Desktop agent
    return 'Sending your requests through the desktop agent running in your toolbar.';
  }

  handleLinkClick() {
    Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_10__["POSTMAN_AGENTS"]);
  }

  handleAgentOnboardingOpen() {
    this.props.onClose && this.props.onClose();
    _base_molecule__WEBPACK_IMPORTED_MODULE_4__["openAgentOnboardingModal"] && Object(_base_molecule__WEBPACK_IMPORTED_MODULE_4__["openAgentOnboardingModal"])();
  }

  handleAgentSelect(option) {
    pm.settings.setSetting(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_9__["SETTING_KEY"], option);
  }

  renderSelectionDropdown(isXHR, hasError) {
    const options = Object.values(_constants_AgentConstants__WEBPACK_IMPORTED_MODULE_9__["SETTING_VALUES"]),
    selection = isXHR ? _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_9__["SETTING_VALUES"].BROWSER.key : _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_9__["SETTING_VALUES"].DESKTOP.key;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_molecule__WEBPACK_IMPORTED_MODULE_4__["Dropdown"], {
          className: 'agent-selection-details__dropdown',
          onSelect: this.handleAgentSelect },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_molecule__WEBPACK_IMPORTED_MODULE_4__["DropdownButton"], {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(
            'selection-details__dropdown-button',
            { 'has-error': hasError }) },


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_atom__WEBPACK_IMPORTED_MODULE_3__["Button"], { size: 'small', fluid: true },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'selection-details__label' },
              selection),

            hasError && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_ErrorIcon__WEBPACK_IMPORTED_MODULE_6__["default"], null))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_molecule__WEBPACK_IMPORTED_MODULE_4__["DropdownMenu"], { fluid: true },
          options.map(option =>
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_molecule__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], { key: option.key, refKey: option.key },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'selection-details__label' }, option.label))))));





  }

  render() {
    const { type: agentType } = pm.runtime.agent.stat,
    isXHR = agentType === _constants_AgentConstants__WEBPACK_IMPORTED_MODULE_9__["TYPES"].XHR,
    hasError = !pm.runtime.agent.isReady;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'agent-selection__details' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'details__header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Text__WEBPACK_IMPORTED_MODULE_5__["default"], { type: 'label-primary-medium', value: 'Postman Agent' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_7__["default"], {
            className: 'header__close-icon',
            onClick: this.props.onClose })),



        this.renderSelectionDropdown(isXHR, hasError),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('details__help', { 'is-error': !isXHR && hasError }) },
          this.getMessage(isXHR, hasError))));



  }}) || _class;

/***/ }),

/***/ 5911:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Item; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5912);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5913);
/* harmony import */ var _Pane__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5914);
/* harmony import */ var _Drawer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5915);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1769);







let

Item = class Item extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { showTooltip: false };

    this.handleToggleTooltip = this.handleToggleTooltip.bind(this);
  }

  handleToggleTooltip(value = !this.state.showTooltip) {
    if (this.props.isOpen && value) {
      // Do not show the tooltip if the status bar / pane is open
      this.setState({ showTooltip: false });
      return;
    }

    this.setState({ showTooltip: value });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'sb__item': true,
      'is-active': this.props.isOpen },
    this.props.className);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          ref: 'item',
          className: this.getClasses() },


        react__WEBPACK_IMPORTED_MODULE_0___default.a.Children.map(this.props.children, child => {
          if (child.type === _Icon__WEBPACK_IMPORTED_MODULE_3__["default"]) {
            return react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, {
              onMouseEnter: this.handleToggleTooltip.bind(this, true),
              onMouseLeave: this.handleToggleTooltip.bind(this, false) });

          } else
          if (child.type === _Text__WEBPACK_IMPORTED_MODULE_2__["default"]) {
            return react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child);
          } else
          if (child.type === _Pane__WEBPACK_IMPORTED_MODULE_4__["default"]) {
            return react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, {
              isOpen: this.props.isOpen,
              onClose: this.props.toggleActive });

          } else
          if (child.type === _Drawer__WEBPACK_IMPORTED_MODULE_5__["default"]) {
            return react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, {
              isOpen: this.props.isOpen,
              onClose: this.props.toggleActive });

          } else
          {
            throw new Error('Invalid child type, must be Icon, Text, Drawer or Pane');
          }
        }),


        this.props.tooltip &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["Tooltip"], {
            show: this.state.showTooltip,
            target: this.refs.item,
            placement: 'top' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["TooltipBody"], null,
            this.props.tooltip))));





  }};

/***/ }),

/***/ 5912:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Text; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);

let

Text = class Text extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'sb__item__text': true }, this.props.className);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        this.props.render && this.props.render()));


  }};

/***/ }),

/***/ 5913:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Icon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);

let

Icon = class Icon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'sb__item__icon': true }, this.props.className);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: this.getClasses(),
          onClick: this.props.onClick,
          onMouseEnter: this.props.onMouseEnter,
          onMouseLeave: this.props.onMouseLeave },

        this.props.icon));


  }};

/***/ }),

/***/ 5914:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Pane; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1879);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1883);



let


Pane = class Pane extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { paneHeight: this.props.paneHeight || 200 };
    this.handleStart = this.handleStart.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.isOpen && nextProps.isOpen !== this.props.isOpen) {
      let documentHeight = _.get(document, 'body.offsetHeight', 800);
      if (documentHeight - this.state.paneHeight < 100) {
        this.setState({ paneHeight: documentHeight - 100 });
      }
    }
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'sb__item__pane': true,
      'is-hidden': !this.props.isOpen },
    this.props.className);
  }

  handleStart(event, data) {
    this.paneHeight = this.state.paneHeight;
    this.startClientY = data.y;
  }

  handleDrag(event, data) {
    let clientY = data.y,
    paneHeight = this.paneHeight + (this.startClientY - clientY),
    documentHeight = _.get(document, 'body.offsetHeight', 800);

    if (documentHeight - paneHeight < 100) {
      paneHeight = this.state.paneHeight;
    }

    if (paneHeight < 100) {
      paneHeight = 100;
    }

    this.setState({ paneHeight: paneHeight });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_2__["DraggableCore"], {
          axis: 'y',
          handle: '.plugin__pane-resize-wrapper',
          onStart: this.handleStart,
          onDrag: this.handleDrag },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: this.getClasses(),
            style: { 'height': this.state.paneHeight } },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'plugin__pane-resize-wrapper' }),
          this.props.children,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_3__["default"], {
            className: 'plugin__pane-close',
            onClick: this.props.onClose }))));




  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5915:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Drawer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1793);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};

let

Drawer = class Drawer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
  }

  handleSelect(item) {
    this.props.onSelect && this.props.onSelect(item);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({ 'sb__drawer': true }, this.props.className);
  }

  getItemProps(defaultArgs, props = {}) {
    return _extends({},
    defaultArgs,
    props, {
      className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(defaultArgs.className, props.className || '') });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["Dropdown"], { onSelect: this.handleSelect },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["DropdownButton"], null,
            this.props.button && this.props.button()),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["DropdownMenu"], { 'align-right': true },

            _.map(this.props.items, item => {
              return (
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                    key: item.key,
                    refKey: item.key },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, item.label)));


            })))));





  }};


Drawer.defaultProps = {
  itemRenderer: (item, getItemProps) => {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', getItemProps(),
        item.label));


  } };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ })

}]);