(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[17],{

/***/ 5868:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1879);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_collections_browser_CollectionBrowser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5869);
/* harmony import */ var _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2877);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1269);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _models_services_DocumenterService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4869);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(742);
/* harmony import */ var _modules_services_CollectionSidebarService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4854);
/* harmony import */ var _utils_CollectionActionsUtil__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4868);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1789);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(748);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4861);
var _class;
















const TABS = {
  DOCUMENTATION: 'Documentation',
  MONITORS: 'Monitors',
  MOCKS: 'Mocks',
  ACTIVITY: 'Activity' };let



CollectionBrowserContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class CollectionBrowserContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isOpen: false,
      browserWidth: _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_5__["default"].ui.REQUESTER_BROWSER_WIDTH,
      collectionId: null,
      activeTab: TABS.DOCUMENTATION,
      isResizing: false };


    this.handleOpen = this.handleOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
    this.handleDragStop = this.handleDragStop.bind(this);
    this.handleFolderSelect = this.handleFolderSelect.bind(this);
    this.handleViewToggle = this.handleViewToggle.bind(this);
    this.handleAction = this.handleAction.bind(this);
    this.handleCollectionNameUpdate = this.handleCollectionNameUpdate.bind(this);
    this.handleCollectionDescriptionUpdate = this.handleCollectionDescriptionUpdate.bind(this);
    this.handleTabChange = this.handleTabChange.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.setState({ browserWidth: pm.settings.getSetting('requesterBrowserWidth') || _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_5__["default"].ui.REQUESTER_BROWSER_WIDTH });
    pm.mediator.on('showCollectionBrowser', this.handleOpen);
    pm.mediator.on('hideCollectionBrowser', this.handleClose);
    pm.mediator.on('toggleSidebar', this.handleClose);
  }

  componentWillUnmount() {
    pm.mediator.off('showCollectionBrowser', this.handleOpen);
    pm.mediator.off('hideCollectionBrowser', this.handleClose);
    pm.mediator.off('toggleSidebar', this.handleClose);
  }

  handleAction(type, id, action, data) {
    if (type === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"]) {
      this.handleCollectionActions(id, action);
    } else
    if (type === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_FOLDER"]) {
      this.handleFolderActions(id, action, data);
    } else
    if (type === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_REQUEST"]) {
      this.handleRequestActions(id, action, data);
    }
  }

  handleCollectionActions(id, action) {
    let store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('EnvironmentStore');
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_RUN"]) {
      let environmentId = null,
      environment = store.find(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveEnvironmentStore').id);
      if (environment) {
        environmentId = environment.id;
      }
      pm.eventBus.channel('runner-events').publish(
      Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_9__["createEvent"])(
      'launch',
      'runner',
      {
        workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceSessionStore').workspace,
        collection: id,
        folder: null,
        environment: environmentId }));



    } else
    {
      Object(_utils_CollectionActionsUtil__WEBPACK_IMPORTED_MODULE_11__["default"])(id, action, {}, { origin: 'collection_browser' });
    }
  }

  handleFolderActions(id, action, data) {
    let store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('EnvironmentStore');
    let collection = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CollectionStore').find(this.state.collectionId);

    if (!collection) {
      return;
    }

    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_RUN"]) {
      let environmentId = null,
      environment = store.find(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveEnvironmentStore').id),
      collectionId = null;
      if (environment) {
        environmentId = environment.id;
      }
      let folder = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('FolderStore').find(id);
      if (folder) {
        collectionId = folder.collection;
      }
      pm.eventBus.channel('runner-events').publish(
      Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_9__["createEvent"])(
      'launch',
      'runner',
      {
        workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceSessionStore').workspace,
        collection: collectionId,
        folder: id,
        environment: environmentId }));



    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_EDIT"] || action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_VIEW_ONLY"]) {
      pm.mediator.trigger('showEditFolderModal', id, undefined, 'collection_browser');
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_ADD_REQUEST"]) {
      this.handleCreateRequest(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('FolderStore').find(id));
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_ADD_FOLDER"]) {
      pm.mediator.trigger('showAddFolderModal', _.get(collection, 'id'), id);
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DUPLICATE"]) {
      let duplicateFolderEvent = {
        name: 'duplicate',
        namespace: 'folder',
        data: { folder: { id } } };

      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(duplicateFolderEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in duplicating folder', response.error);
          return;
        }
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while duplicating folder', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteFolderModal', id);
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_RENAME"]) {
      let updateFolderEvent = {
        name: 'update',
        namespace: 'folder',
        data: { id, name: data } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(updateFolderEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in renaming folder', response.error);
          return;
        }
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while renaming folder', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DESCRIPTION_UPDATE"]) {
      let updateFolderEvent = {
        name: 'update',
        namespace: 'folder',
        data: { id, description: data } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(updateFolderEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in renaming folder', response.error);
          return;
        }

        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__["default"].addEventV2({
          category: 'documentation',
          action: 'edit_description',
          label: 'collection_browser',
          entityType: 'folder',
          entityId: `${_.get(response, 'response.data.id')}` });

      }).
      catch(err => {
        pm.logger.error('Error in pipeline while renaming folder', err);
      });
    }
  }

  handleRequestActions(id, action, data) {

    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_EDIT"]) {
      pm.mediator.trigger('editCollectionRequest', id, 'collection_browser');
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DUPLICATE"]) {
      let duplicateRequestEvent = {
        name: 'duplicate',
        namespace: 'request',
        data: { request: { id } } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(duplicateRequestEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in duplicating request', response.error);
          return;
        }
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while duplicating request', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteRequestModal', id);
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_OPEN_IN_BUILDER"]) {
      _modules_services_CollectionSidebarService__WEBPACK_IMPORTED_MODULE_10__["default"].openRequestInTab(id);
      this.handleClose();
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_RENAME"]) {
      let updateRequestEvent = {
        name: 'update',
        namespace: 'request',
        data: { id, name: data } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(updateRequestEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in renaming request', response.error);
          return;
        }
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while renaming request', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DESCRIPTION_UPDATE"]) {
      let updateRequestEvent = {
        name: 'update',
        namespace: 'request',
        data: { id, description: data } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(updateRequestEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in renaming request', response.error);
          return;
        }

        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__["default"].addEventV2({
          category: 'documentation',
          action: 'edit_description',
          label: 'collection_browser',
          entityType: 'request',
          entityId: `${_.get(response, 'response.data.id')}` });

      }).
      catch(err => {
        pm.logger.error('Error in pipeline while renaming request', err);
      });
    }
  }

  handleClose() {
    if (!this.state.isOpen) {
      return;
    }
    this.setState({
      isOpen: false,
      collectionId: null,
      activeTab: TABS.DOCUMENTATION });


    pm.settings.setSetting('requesterBrowserWidth', this.state.browserWidth);
    pm.mediator.trigger('collectionBrowserClosed');
  }

  handleOpen(id, collectionTab = TABS.DOCUMENTATION) {
    if (!id) {
      this.handleClose();
      return;
    }
    pm.mediator.trigger('collectionBrowserOpened', id);

    if (this.state.collectionId === id && this.state.activeTab === collectionTab) {
      return;
    }
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ResourceLimitMessagesStore').fetch();

    let scaledBrowserWidth = pm.settings.getSetting('requesterBrowserWidth'),
    collection = this.getCollection(id);

    this.setState({
      isOpen: true,
      collectionId: id,
      activeTab: collectionTab || TABS.DOCUMENTATION,
      collection,
      browserWidth: this._checkBrowserWidthBounds(scaledBrowserWidth),
      isCollectionDetails: this.getCollectionViewStatus(id) });

  }

  handleViewToggle() {
    this.setState({ isCollectionDetails: !this.state.selectedFolder });
  }

  handleTabChange(tab) {
    this.setState({ activeTab: tab });
  }

  handleFolderSelect(folder) {
    this.setState({
      selectedFolder: folder,
      isCollectionDetails: !folder });

  }

  getCollection(collectionId) {
    return Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CollectionStore').find(collectionId);
  }

  getCollectionViewStatus(collectionId) {
    let selectedFolder = this.state.selectedFolder,
    collection = this.getCollection(collectionId);
    if (selectedFolder && collection) {
      let folders = _.get(collection, 'folders', []),
      folder = _.find(folders, ['id', selectedFolder.id]);
      return !folder;
    }
    return true;
  }

  findAndSetContainerState(collectionId, isOpen) {
    if (isOpen) {
      this.setState({
        collection: this.getCollection(collectionId),
        isCollectionDetails: this.getCollectionViewStatus(collectionId) });

    }
  }

  _checkBrowserWidthBounds(width) {
    let windowWidth = window.innerWidth,
    sidebarWidth = pm.settings.getSetting('requesterSidebarWidth'),
    defaultWidth = _constants_AppSettingsDefaults__WEBPACK_IMPORTED_MODULE_5__["default"].ui.REQUESTER_BROWSER_WIDTH,
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore'),
    adjustedDefaultWidth = currentUser.isLoggedIn ? defaultWidth : defaultWidth + 50;

    if (width + sidebarWidth > windowWidth - 30) {
      return windowWidth - sidebarWidth - 30;
    }

    if (width < adjustedDefaultWidth) {
      return adjustedDefaultWidth;
    }

    return width;
  }

  handleDrag(event, data) {
    let scaledClientX = data.x,
    sidebarWidth = pm.settings.getSetting('requesterSidebarWidth'),
    browserWidth = scaledClientX - sidebarWidth;
    this.setState({
      browserWidth: this._checkBrowserWidthBounds(browserWidth),
      isResizing: true });

  }

  handleDragStop() {
    pm.settings.setSetting('requesterBrowserWidth', this.state.browserWidth);
    this.setState({ isResizing: false });
  }

  handleCollectionNameUpdate(name) {
    let updateCollectionEvent = {
      name: 'update',
      namespace: 'collection',
      data: { id: this.state.collectionId, name } };


    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(updateCollectionEvent).
    then(response => {
      if (!_.isEmpty(_.get(response, 'error'))) {
        pm.logger.error('Error in renaming collection', response.error);
        return;
      }
    }).
    catch(err => {
      pm.logger.error('Error in pipeline while renaming collection', err);
    });
  }

  handleCollectionDescriptionUpdate(description) {

    let updateCollectionEvent = {
      name: 'update',
      namespace: 'collection',
      data: { id: this.state.collectionId, description } };


    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_6__["default"])(updateCollectionEvent).
    then(response => {
      if (!_.isEmpty(_.get(response, 'error'))) {
        pm.logger.error('Error in updataing collection description', response.error);
        return;
      }

      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_13__["default"].addEventV2({
        category: 'documentation',
        action: 'edit_description',
        label: 'collection_browser',
        entityType: 'collection',
        entityId: `${Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').id}-${_.get(this.state, 'collectionId')}` });

    }).
    catch(err => {
      pm.logger.error('Error in pipeline while updataing collection description', err);
    });
  }

  handleCreateRequest(target) {
    let collection = null,
    folder = null;

    switch (target.type) {
      case 'collection':
        collection = target;
        break;
      case 'folder':
        folder = target;
        break;}


    let initialSelection = {
      target: {
        collection,
        folder } };



    pm.mediator.trigger('showAddToCollectionModal', {}, initialSelection);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'collection-browser-wrapper': true,
      'is-hidden': !this.state.isOpen });

  }

  render() {
    let collectionId = this.state.collectionId,
    collection = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CollectionStore').find(collectionId),
    classes = this.getClasses(),
    browserStyle = {
      width: this.state.browserWidth + 5 + 'px',
      WebkitUserSelect: this.state.isResizing ? 'none' : 'text' },

    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore'),
    isLoggedIn = currentUser && currentUser.isLoggedIn,
    isProUser = currentUser && currentUser.teamSyncEnabled;

    // Additonal 5px to avoid clicking outside browser on drag end
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'collectionBrowser', isVisible: this.state.isOpen },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: classes,
            style: browserStyle },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_browser_CollectionBrowser__WEBPACK_IMPORTED_MODULE_4__["default"], {
            activeTab: this.state.activeTab,
            browserWidth: this.state.browserWidth,
            className: 'collection-browser',
            collection: collection,
            isCollectionDetails: this.state.isCollectionDetails,
            isLoggedIn: isLoggedIn,
            isOpen: this.state.isOpen,
            isProUser: isProUser,
            selectedFolder: this.state.selectedFolder,
            onActionTriggered: this.handleAction,
            onAddRequest: this.handleCreateRequest,
            onClose: this.handleClose,
            onCollectionDescriptionUpdate: this.handleCollectionDescriptionUpdate,
            onCollectionDetailsNavigate: this.handleFolderSelect,
            onCollectionNameUpdate: this.handleCollectionNameUpdate,
            onFolderSelect: this.handleFolderSelect,
            onTabChange: this.handleTabChange,
            onViewToggle: this.handleViewToggle }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_1__["DraggableCore"], {
              offsetParent: document.body,
              onDrag: this.handleDrag,
              onStop: this.handleDragStop },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-left-sidebar-resize-handle requester-browser-resize-handle' })))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5869:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1791);
/* harmony import */ var _CollectionBrowserCollectionDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5870);
/* harmony import */ var _CollectionBrowserFolderDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5893);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4861);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1763);
var _class;










let


CollectionBrowser = Object(mobx_react__WEBPACK_IMPORTED_MODULE_9__["observer"])(_class = class CollectionBrowser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: 'Details',
      showFloatingEdit: false,
      isEditingDescription: false };


    this.handleTabChange = this.handleTabChange.bind(this);
    this.handleActionTrigger = this.handleActionTrigger.bind(this);
    this.handleFolderSelect = this.handleFolderSelect.bind(this);
    this.toggleCollectionView = this.toggleCollectionView.bind(this);
    this.handleTeamLabelClick = this.handleTeamLabelClick.bind(this);
    this.handleFloatingEditClick = this.handleFloatingEditClick.bind(this);
    this.handleEditDescriptionToggle = this.handleEditDescriptionToggle.bind(this);
    this.toggleFloatingEdit = this.toggleFloatingEdit.bind(this);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleCollectionDetailsToggle = this.handleCollectionDetailsToggle.bind(this);
  }

  getCollectionBrowserClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({
      'collection-browser-body': true,
      'is-hidden': this.state.activeTab === 'Activity' });

  }

  getCollectionDetailsWrapperClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({
      'collection-browser-collection-details-wrapper': true,
      'is-hidden': !this.props.isCollectionDetails });

  }

  getFolderDetailsWrapperClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({
      'collection-browser-folder-details-wrapper': true,
      'is-hidden': this.props.isCollectionDetails });

  }

  getFloatingEditClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({
      'collection-browser-floating-edit-btn': true,
      'is-hidden': !this.state.showFloatingEdit });

  }

  handleFolderSelect(folder) {
    this.setState({ isEditingDescription: false });
    this.props.onFolderSelect && this.props.onFolderSelect(folder);
  }

  toggleCollectionView() {
    this.setState({ isEditingDescription: false });
    this.props.onViewToggle && this.props.onViewToggle();
  }

  handleTabChange(tab) {
    this.setState({
      activeTab: tab,
      showFloatingEdit: false });

  }
  handleActionTrigger(entity, entityId, action, data) {
    this.props.onActionTriggered && this.props.onActionTriggered(entity, entityId, action, data);
  }

  handleTeamLabelClick() {
    this.props.onActionTriggered && this.props.onActionTriggered('collection', this.props.collection.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SHARE"]);
  }

  handleScroll() {
    let { collection } = this.props;

    if (this.state.isEditingDescription || collection && !collection.isEditable || !this.collectionBrowserNode) {
      return;
    }

    this.toggleFloatingEdit();
  }

  toggleFloatingEdit() {
    if (this.state.isEditingDescription) {
      return;
    }

    let descriptionWrapper;
    if (this.props.isCollectionDetails) {
      descriptionWrapper = this.collectionBrowserNode.querySelector('.collection-browser-details-description-wrapper');
    } else
    {
      descriptionWrapper = this.collectionBrowserNode.querySelector('.collection-browser-folder-description-wrapper');
    }

    let descriptionOffsetBottom = _.get(descriptionWrapper, 'offsetTop') + _.get(descriptionWrapper, 'offsetHeight'),
    scrollTop = _.get(this.collectionBrowserNode, 'scrollTop'),
    topOffset = 80;

    // If scrollTop > description height, hide the button
    if (scrollTop + topOffset > descriptionOffsetBottom) {
      if (this.state.showFloatingEdit) {
        this.setState({ showFloatingEdit: false });
      }
    } else
    if (scrollTop > 100 && !this.state.showFloatingEdit) {
      this.setState({ showFloatingEdit: true });
    } else
    if (scrollTop <= 100 && this.state.showFloatingEdit) {
      this.setState({ showFloatingEdit: false });
    }
  }

  handleFloatingEditClick() {
    this.collectionBrowserScrollTop = _.get(this.collectionBrowserNode, 'scrollTop');
    this.collectionBrowserScrollHeight = _.get(this.collectionBrowserNode, 'scrollHeight');
    this.collectionBrowserOffsetHeight = _.get(this.collectionBrowserNode, 'offsetHeight');

    this.setState({
      isEditingDescription: true,
      showFloatingEdit: false });

  }

  handleEditDescriptionToggle(isEditingDescription) {
    if (isEditingDescription) {
      let collectionBrowserScrollHeight = _.get(this.collectionBrowserNode, 'scrollHeight'),
      scrollHeightDiff = collectionBrowserScrollHeight - this.collectionBrowserScrollHeight;

      // If already at top, maintain the position
      if (!this.collectionBrowserScrollTop) {
        _.set(this.collectionBrowserNode, 'scrollTop', 0);
      }

      // If already at bottom, maintain the position
      else if (this.collectionBrowserScrollTop + this.collectionBrowserOffsetHeight === this.collectionBrowserScrollHeight) {
          _.set(this.collectionBrowserNode, 'scrollTop', collectionBrowserScrollHeight);
        } else

        {
          _.set(this.collectionBrowserNode, 'scrollTop', this.collectionBrowserScrollTop + scrollHeightDiff);
        }

      this.collectionBrowserScrollTop = null;
    }

    this.setState({ isEditingDescription }, this.toggleFloatingEdit);
  }

  handleCollectionDetailsToggle() {
    this.toggleCollectionView();
  }

  componentDidUpdate() {
    if (!this.collectionBrowserNode && this.collectionBrowser) {
      this.collectionBrowserNode = this.collectionBrowser && Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.collectionBrowser);
      this.collectionBrowserNode && this.collectionBrowserNode.addEventListener('scroll', this.handleScroll);
    }
  }

  componentWillUnmount() {
    this.collectionBrowserNode && this.collectionBrowserNode.removeEventListener('scroll', this.handleScroll);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.collection && this.props.collection && nextProps.collection.id !== this.props.collection.id ||
    nextProps.isOpen !== this.props.isOpen) {
      this.setState({
        showFloatingEdit: false,
        isEditingDescription: false });

    }
  }

  render() {

    let isOffline = !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('SyncStatusStore').isSocketConnected,
    collectionDetailsClasses = this.getCollectionDetailsWrapperClasses(),
    folderDetailsClasses = this.getFolderDetailsWrapperClasses(),
    collection = this.props.collection,
    canRestore;

    if (!collection || !collection.id) {
      return null;
    }

    canRestore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('PermissionStore').can('restore', 'collection', collection.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.props.className },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: this.getCollectionBrowserClasses(),
            ref: ref => {return this.collectionBrowser = ref;} },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserCollectionDetails__WEBPACK_IMPORTED_MODULE_4__["default"], {
            activeTab: this.props.activeTab,
            browserWidth: this.props.browserWidth,
            className: collectionDetailsClasses,
            collection: collection,
            isEditingDescription: _.isEmpty(this.props.selectedFolder) && this.state.isEditingDescription,
            isOpen: this.props.isOpen,
            isOffline: isOffline,
            onClose: this.props.onClose,
            onFolderSelect: this.handleFolderSelect,
            onActionTriggered: this.handleActionTrigger,
            onAddRequest: this.props.onAddRequest,
            onTeamLabelClick: this.handleTeamLabelClick,
            onCollectionNameUpdate: this.props.onCollectionNameUpdate,
            onCollectionDescriptionUpdate: this.props.onCollectionDescriptionUpdate,
            onEditCollectionDescriptionToggle: this.handleEditDescriptionToggle,
            onEditCollectionNameToggle: this.handleCollectionNameEditToggle,
            enableRestore: this.props.isProUser && canRestore,
            isLoggedIn: this.props.isLoggedIn,
            onTabChange: this.props.onTabChange }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserFolderDetails__WEBPACK_IMPORTED_MODULE_5__["default"], {
            browserWidth: this.props.browserWidth,
            className: folderDetailsClasses,
            collection: collection,
            isOpen: this.props.isOpen,
            onClose: this.props.onClose,
            folder: this.props.selectedFolder,
            onFolderSelect: this.handleFolderSelect,
            onAddRequest: this.props.onAddRequest,
            onFolderEditDescriptionToggle: this.handleEditDescriptionToggle,
            onActionTriggered: this.handleActionTrigger,
            onCollectionDetailsNavigate: this.props.onCollectionDetailsNavigate,
            isEditingDescription: !_.isEmpty(this.props.selectedFolder) && this.state.isEditingDescription }))));




  }}) || _class;


CollectionBrowser.defaultProps = { selectedFolder: {} };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5870:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserCollectionDetails; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3946);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1791);
/* harmony import */ var _components_base_InlineInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1881);
/* harmony import */ var _components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1883);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1763);
/* harmony import */ var _CollectionBrowserCollectionContents__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5871);
/* harmony import */ var _containers_collections_browser_CollectionBrowserMocksContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5876);
/* harmony import */ var _containers_collections_browser_CollectionBrowserMonitorListContainer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5882);
/* harmony import */ var _CollectionBrowserActivityFeed__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5887);
/* harmony import */ var _CollectionBrowserCollectionAction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5891);
/* harmony import */ var _components_collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3961);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(749);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(784);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1789);
/* harmony import */ var _modules_services_CollectionBrowserService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5892);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1808);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1768);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_19__);
var _class;




















const TABS = {
  DOCUMENTATION: 'Documentation',
  MONITORS: 'Monitors',
  MOCKS: 'Mocks',
  ACTIVITY: 'Activity' };let



CollectionBrowserCollectionDetails = Object(mobx_react__WEBPACK_IMPORTED_MODULE_6__["observer"])(_class = class CollectionBrowserCollectionDetails extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      api: null,
      showEditNameToggle: true };


    this.handleActionTrigger = this.handleActionTrigger.bind(this);
    this.handleFolderSelect = this.handleFolderSelect.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
    this.handleEditName = this.handleEditName.bind(this);
    this.handleLoadApiNameRetry = this.handleLoadApiNameRetry.bind(this);
    this.getApiName = this.getApiName.bind(this);
  }

  componentDidMount() {
    !this.props.isOffline && this.getApiName();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.collection.uid !== this.props.collection.uid || prevProps.isOffline !== this.props.isOffline) {
      !this.props.isOffline && this.getApiName();
    }
  }

  getApiName() {
    this.setState({
      api: null,
      isApiNameLoading: true,
      isApiNameLoadingFailed: false });

    return _modules_services_CollectionBrowserService__WEBPACK_IMPORTED_MODULE_16__["default"].fetchLinkedApiName(this.props.collection.uid).
    then(data => {
      this.setState({
        api: data.api,
        isApiNameLoading: false,
        isApiNameLoadingFailed: false });

    }).
    catch(() => {
      this.setState({
        isApiNameLoading: false,
        isApiNameLoadingFailed: true });

    });
  }

  handleActionTrigger(entity, entityId, action, data) {
    this.props.onActionTriggered && this.props.onActionTriggered(entity, entityId, action, data);
  }

  handleFolderSelect(folder) {
    this.props.onFolderSelect && this.props.onFolderSelect(folder);
  }

  handleLoadApiNameRetry() {
    !this.props.isOffline && this.getApiName();
  }

  getCollectionDetailHeaderClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-browser-details-header': true,
      'collection-browser-details-header--edit': !this.state.showEditNameToggle,
      'editable': Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_13__["getStore"])('PermissionStore').can('edit', 'collection', this.props.collection.id) });

  }

  getMetaClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'collection-browser-meta-info': true });
  }

  getMetaValueClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-browser-meta-value': true,
      'empty-value': !this.state.api,
      'is-loading': this.state.isApiNameLoading,
      'is-error': this.state.isApiNameLoadingFailed || this.props.isOffline });

  }

  getTabContentClass(tab) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'is-hidden': tab !== this.props.activeTab });
  }

  handleToggleEditName(isEditing) {
    const inlineInput = this.refs.inlineInput;
    if (isEditing && inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    } else
    {
      this.setState({ showEditNameToggle: true });
    }
  }

  handleEditName() {
    this.setState({ showEditNameToggle: false }, () => {
      this.refs.inlineInput && this.refs.inlineInput.startEditing();
    });
  }

  getUsername(owner, currentUser) {
    return _utils_util__WEBPACK_IMPORTED_MODULE_14__["default"].getUserNameForId(owner, currentUser);
  }

  renderRetryContent(retryFunction) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Failed to load data.'),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_18__["Button"], {
          type: 'text',
          onClick: retryFunction }, 'Retry'));




  }

  render() {
    let collection = this.props.collection,
    activeTab = this.props.activeTab || TABS.DOCUMENTATION,
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_13__["getStore"])('CurrentUserStore');

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.props.className },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-details-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getCollectionDetailHeaderClasses(), title: _.get(collection, 'name') },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_4__["default"], {
              className: 'collection-browser-details-header__name',
              placeholder: 'Collection Name',
              ref: 'inlineInput',
              value: _.get(collection, 'name'),
              onSubmit: this.props.onCollectionNameUpdate,
              onToggleEdit: this.handleToggleEditName,
              disableTrim: true }),


            this.state.showEditNameToggle && Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_13__["getStore"])('PermissionStore').can('edit', 'collection', this.props.collection.id) &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                className: 'collection-browser-details-header__edit-icon-wrapper',
                onClick: this.handleEditName },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_19__["Icon"], {
                name: 'icon-action-edit-stroke',
                className: 'collection-browser-details-header__edit-icon pm-icon pm-icon-normal' })),



            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'close' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-header-close-btn' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__["default"], {
                  className: 'collection-browser-header-close-icon',
                  onClick: this.props.onClose })))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-meta' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getMetaClasses() },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-meta__field collection-browser-meta--api-name' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'collection-browser-meta-label' }, 'API'),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                    className: this.getMetaValueClasses(),
                    title: _.get(this.state.api, 'name') },


                  this.state.isApiNameLoading && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_17__["default"], null) ||
                  this.props.isOffline && 'You seem to be offline.' ||
                  this.state.isApiNameLoadingFailed && this.renderRetryContent(this.handleLoadApiNameRetry) || (
                  this.state.api ? this.state.api.name : 'This collection is not linked to any API'))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_12__["default"], { forkInfo: _.get(collection, 'forkInfo') })))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserCollectionAction__WEBPACK_IMPORTED_MODULE_11__["default"], {
          collection: collection,
          isPRO: currentUser && currentUser.isLoggedIn && currentUser.teamSyncEnabled,
          onActionTriggered: this.handleActionTrigger }),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__["Tabs"], {
            activeRef: activeTab,
            className: 'collection-browser-tabs-wrapper',
            defaultActive: TABS.DOCUMENTATION,
            type: 'primary',
            onChange: this.props.onTabChange },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'documentationTab' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__["Tab"], { refKey: TABS.DOCUMENTATION }, 'Documentation')),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'monitorsTab' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__["Tab"], { refKey: TABS.MONITORS }, 'Monitors')),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'mocksTab' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__["Tab"], { refKey: TABS.MOCKS }, 'Mocks')),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'activityFeedTab' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_3__["Tab"], { refKey: TABS.ACTIVITY }, 'Changelog'))),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'collectionContent', isVisible: activeTab === TABS.DOCUMENTATION },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserCollectionContents__WEBPACK_IMPORTED_MODULE_7__["default"], {
            className: this.getTabContentClass(TABS.DOCUMENTATION),
            collection: collection,
            isOpen: this.props.isOpen,
            onActionTriggered: this.handleActionTrigger,
            onAddRequest: this.props.onAddRequest,
            onFolderSelect: this.handleFolderSelect,
            onToggleEdit: this.props.onEditCollectionDescriptionToggle,
            onUpdate: this.props.onCollectionDescriptionUpdate,
            browserWidth: this.props.browserWidth })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'monitor', isVisible: activeTab === TABS.MONITORS },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_collections_browser_CollectionBrowserMonitorListContainer__WEBPACK_IMPORTED_MODULE_9__["default"], {
            className: this.getTabContentClass(TABS.MONITORS),
            collection: this.props.collection,
            isHidden: activeTab !== TABS.MONITORS })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'mock', isVisible: activeTab === TABS.MOCKS },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_collections_browser_CollectionBrowserMocksContainer__WEBPACK_IMPORTED_MODULE_8__["default"], {
            className: this.getTabContentClass(TABS.MOCKS),
            collection: this.props.collection,
            isHidden: activeTab !== TABS.MOCKS })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'activityFeed', isVisible: activeTab === TABS.ACTIVITY },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserActivityFeed__WEBPACK_IMPORTED_MODULE_10__["default"], {
            className: this.getTabContentClass(TABS.ACTIVITY),
            collectionUid: this.props.collection.uid,
            enableRestore: this.props.enableRestore,
            key: this.props.collection.uid,
            isLoggedIn: this.props.isLoggedIn,
            isVisible: TABS.ACTIVITY === activeTab }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5871:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserCollectionContents; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CollectionBrowserFolderListItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5872);
/* harmony import */ var _CollectionBrowserRequestListItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5875);
/* harmony import */ var _base_InlineEditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1766);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1875);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(748);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(749);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1222);
/* harmony import */ var _modules_tracked_state_TrackedState__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1876);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__);
var _class;













let


CollectionBrowserCollectionContents = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class = class CollectionBrowserCollectionContents extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      editingDescription: false };


    this.trackedState = new _modules_tracked_state_TrackedState__WEBPACK_IMPORTED_MODULE_12__["TrackedState"]({
      collectionDescription: _.get(this.props, 'collection.description') });


    this.handleActionTrigger = this.handleActionTrigger.bind(this);
    this.handleFolderSelect = this.handleFolderSelect.bind(this);
    this.handleCollectionDescriptionChange = this.handleCollectionDescriptionChange.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleToggleEdit = this.handleToggleEdit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.resetDescriptionTrackedState = this.resetDescriptionTrackedState.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const inlineEditor = this.refs.inlineEditor;
    if (inlineEditor && nextProps.browserWidth !== this.props.browserWidth) {
      inlineEditor.refresh();
    }

    if (_.get(this.props, 'collection.id') !== _.get(nextProps, 'collection.id')) {
      //  reset tracked state description
      this.trackedState.reset({ collectionDescription: _.get(nextProps, 'collection.description') });
    }
  }

  handleFolderSelect(folder) {
    this.props.onFolderSelect && this.props.onFolderSelect(folder);
  }

  handleActionTrigger(entity, entityId, action, data) {
    this.props.onActionTriggered && this.props.onActionTriggered(entity, entityId, action, data);
  }

  handleDocumentationLearnmore() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_11__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__["DOCUMENTATION_LINK"]);
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('onboarding', 'view_documentation_intro_documentation', 'collection_browser');
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({ 'collection-browser-collection-contents': true }, this.props.className);
  }

  handleCollectionDescriptionChange(value) {
    this.trackedState.set({ collectionDescription: value });
  }

  handleToggleEdit(e) {
    this.setState(prevState => {
      return { editingDescription: !prevState.editingDescription };
    }, () => {
      this.props.onToggleEdit(e);
    });
  }

  handleCancel() {
    if (this.trackedState.isDirty()) {
      pm.mediator.trigger('showConfirmationModal', this.resetDescriptionTrackedState);
    } else
    {
      this.handleToggleEdit();
    }
  }

  resetDescriptionTrackedState() {
    // Reset Description
    this.trackedState.reset({ collectionDescription: _.get(this.props, 'collection.description', '') });
    this.handleToggleEdit();
  }

  handleSave(value) {
    //  reset tracked state description
    this.trackedState.reset({ collectionDescription: value });
    this.props.onUpdate(value);

    this.setState(prevState => {
      return { editingDescription: !prevState.editingDescription };
    });
  }

  render() {
    let ownFolders = _.get(this.props, 'collection.ownFolders', []),
    ownRequests = _.get(this.props, 'collection.ownRequests', []);
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'collection-browser-learn-more-header',
            onClick: this.handleDocumentationLearnmore },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { name: 'icon-action-publish-stroke',
            className: 'collection-browser-learn-more-header__icon pm-icon pm-icon-secondary' }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-learn-more-header__text' }, 'Learn how to document your requests')),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__["default"], { identifier: 'collectionDescription' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InlineEditor__WEBPACK_IMPORTED_MODULE_3__["default"], {
            isControlled: true,
            key: _.get(this.props, 'collection.id'),
            className: 'collection-browser-details-description-wrapper',
            editable: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('PermissionStore').can('edit', 'collection', this.props.collection.id),
            isEditing: this.state.editingDescription,
            placeholder: 'Make things easier for your teammates with a complete request description.',
            ref: 'inlineEditor',
            value: this.trackedState.get('collectionDescription'),
            onToggleEdit: this.handleToggleEdit,
            onChange: this.handleCollectionDescriptionChange,
            onUpdate: this.handleSave,
            onCancel: this.handleCancel })),



        _.isEmpty(ownFolders) && _.isEmpty(ownRequests) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-collection-contents' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__body--empty' }, 'This collection is empty.\xA0',


            Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('PermissionStore').can('addRequest', 'collection', this.props.collection.id) &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                  type: 'text',
                  className: 'learn-more-link',
                  onClick: () => this.props.onAddRequest(this.props.collection) }, 'Add requests'), 'to this collection and create folders to organize them'))),









        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-collection-contents-wrapper' },

          _.map(ownFolders && ownFolders, (folder, index) => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__["default"], { identifier: `folder/${index}`, key: folder.id },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserFolderListItem__WEBPACK_IMPORTED_MODULE_1__["default"], {
                  folder: folder,
                  key: folder.id,
                  onActionTriggered: this.handleActionTrigger,
                  onFolderSelect: this.handleFolderSelect })));



          }),


          _.map(ownRequests, (request, index) => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__["default"], { identifier: `request/${index}`, key: request.id },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserRequestListItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
                  request: request,
                  isOpen: this.props.isOpen,
                  onActionTriggered: this.handleActionTrigger,
                  browserWidth: this.props.browserWidth })));



          }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5872:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserFolderListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_pureRenderDecorator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4866);
/* harmony import */ var _components_base_InlineInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1881);
/* harmony import */ var _components_base_ContextMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4857);
/* harmony import */ var _CollectionBrowserFolderItemActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5873);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4861);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__);
var _dec, _class;










const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore');let












































CollectionBrowserFolderListItem = (_dec = Object(_components_base_ContextMenu__WEBPACK_IMPORTED_MODULE_3__["default"])([{ label: 'Rename', shortcut: 'rename', isVisible(props) {return permissionStore.can('edit', 'folder', props.folder.id);}, onClick(props, component) {component.toggleEditName();} }, { label: 'View Details', isVisible(props) {return !permissionStore.can('edit', 'folder', props.folder.id);}, onClick(props, component) {component.handleActionTrigger(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TARGET_FOLDER"], props.folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_VIEW_ONLY"]);} }, { label: 'Edit', isVisible(props) {return permissionStore.can('edit', 'folder', props.folder.id);}, onClick(props, component) {component.handleActionTrigger(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TARGET_FOLDER"], props.folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_EDIT"]);} }, { label: 'Duplicate', shortcut: 'duplicate', isVisible(props) {return permissionStore.can('duplicate', 'folder', props.folder.id);}, onClick(props, component) {component.handleActionTrigger(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TARGET_FOLDER"], props.folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DUPLICATE"]);} }, { label: 'Delete', shortcut: 'delete', isVisible(props) {return permissionStore.can('delete', 'folder', props.folder.id);}, onClick(props, component) {component.handleActionTrigger(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TARGET_FOLDER"], props.folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"]);} }], monitor => {return { isContextMenuOpen: monitor.isOpen };}), _dec(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_6__["observer"])(_class = class CollectionBrowserFolderListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { showRename: true };

    this.handleActionTrigger = this.handleActionTrigger.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
  }

  handleFolderSelect(folder) {
    if (this.props.isContextMenuOpen()) {
      return;
    }

    this.props.onFolderSelect && this.props.onFolderSelect(folder);
  }

  toggleEditName() {
    this.refs.inlineInput && this.refs.inlineInput.toggleEdit();
  }

  handleToggleEditName(isEditing) {
    const inlineInput = this.refs.inlineInput;
    if (inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    }
    this.setState({ showRename: !isEditing });
  }

  handleSubmit(value) {
    this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TARGET_FOLDER"], this.props.folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_RENAME"], value);
  }

  handleActionTrigger(entity, entityId, action) {
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_RENAME_TOGGLE"]) {
      this.toggleEditName();
    } else
    {
      this.props.onActionTriggered && this.props.onActionTriggered(entity, entityId, action);
    }
  }

  render() {

    let { folder } = this.props;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__folder' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'collection-browser-list-item__folder__head',
            onClick: this.handleFolderSelect.bind(this, folder) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__folder__head__icon-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-entity-folder-stroke', className: 'collection-browser-list-item__folder__head__icon icon_folder pm-icon pm-icon-normal' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__folder__head__meta' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_2__["default"], {
              className: 'collection-browser-list-item__folder__head__meta__name',
              placeholder: 'Folder Name',
              ref: 'inlineInput',
              value: folder.name,
              onSubmit: this.handleSubmit,
              onToggleEdit: this.handleToggleEditName })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserFolderItemActions__WEBPACK_IMPORTED_MODULE_4__["default"], {
            folder: folder,
            showRename: this.state.showRename,
            onActionTriggered: this.handleActionTrigger }))));




  }}) || _class) || _class);

/***/ }),

/***/ 5873:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserFolderItemActions; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4861);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5874);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__);
var _class;






let


CollectionBrowserFolderItemActions = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class CollectionBrowserFolderItemActions extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  handleActionTrigger(entityId, action, e) {
    this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_2__["ACTION_TARGET_FOLDER"], entityId, action);
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  render() {
    let { folder, showRename } = this.props;

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore'),
    canEditFolder = permissionStore.can('edit', 'folder', folder.id),
    canDuplicate = permissionStore.can('duplicate', 'folder', folder.id),
    canDeleteFolder = permissionStore.can('delete', 'folder', folder.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__folder__head__actions collection-browser-actions-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["ButtonGroup"], null,

          showRename &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'icon',
              onClick: this.handleActionTrigger.bind(this, folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_2__["ACTION_TYPE_RENAME_TOGGLE"]),
              disabled: !canEditFolder,
              tooltip: this.getTooltipText(!canEditFolder) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_RENAME_FOLDER_TOOLTIP"] },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'rename' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-rename-stroke', className: 'collection-browser-collection-rename-icon pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'icon',
              onClick: this.handleActionTrigger.bind(this, folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_2__["ACTION_TYPE_EDIT"]),
              disabled: !canEditFolder,
              tooltip: this.getTooltipText(!canEditFolder) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_EDIT_FOLDER_TOOLTIP"] },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'edit' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-edit-stroke', className: 'collection-browser-collection-edit-icon pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'icon',
              onClick: this.handleActionTrigger.bind(this, folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_2__["ACTION_TYPE_DUPLICATE"]),
              disabled: !canDuplicate,
              tooltip: this.getTooltipText(!canDuplicate) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DUPLICATE_FOLDER_TOOLTIP"] },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'copy' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-copy-stroke', className: 'collection-browser-collection-duplicate-icon pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'icon',
              onClick: this.handleActionTrigger.bind(this, folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_2__["ACTION_TYPE_DELETE"]),
              disabled: !canDeleteFolder,
              tooltip: this.getTooltipText(!canDeleteFolder) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DELETE_FOLDER_TOOLTIP"] },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'delete' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-delete-stroke', className: 'collection-browser-collection-delete-icon pm-icon pm-icon-normal' }))))));





  }}) || _class;

/***/ }),

/***/ 5874:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_RENAME_FOLDER_TOOLTIP", function() { return ACTION_TYPE_RENAME_FOLDER_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_EDIT_FOLDER_TOOLTIP", function() { return ACTION_TYPE_EDIT_FOLDER_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DUPLICATE_FOLDER_TOOLTIP", function() { return ACTION_TYPE_DUPLICATE_FOLDER_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE_FOLDER_TOOLTIP", function() { return ACTION_TYPE_DELETE_FOLDER_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_RENAME_REQUEST_TOOLTIP", function() { return ACTION_TYPE_RENAME_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_EDIT_REQUEST_TOOLTIP", function() { return ACTION_TYPE_EDIT_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DUPLICATE_REQUEST_TOOLTIP", function() { return ACTION_TYPE_DUPLICATE_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE_REQUEST_TOOLTIP", function() { return ACTION_TYPE_DELETE_REQUEST_TOOLTIP; });
const ACTION_TYPE_RENAME_FOLDER_TOOLTIP = 'Rename folder',
ACTION_TYPE_EDIT_FOLDER_TOOLTIP = 'Edit folder',
ACTION_TYPE_DUPLICATE_FOLDER_TOOLTIP = 'Duplicate folder',
ACTION_TYPE_DELETE_FOLDER_TOOLTIP = 'Delete folder',
ACTION_TYPE_RENAME_REQUEST_TOOLTIP = 'Rename request',
ACTION_TYPE_EDIT_REQUEST_TOOLTIP = 'Edit request',
ACTION_TYPE_DUPLICATE_REQUEST_TOOLTIP = 'Duplicate request',
ACTION_TYPE_DELETE_REQUEST_TOOLTIP = 'Delete request';

/***/ }),

/***/ 5875:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserRequestListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _components_base_InlineInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1881);
/* harmony import */ var _base_InlineEditor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1766);
/* harmony import */ var _components_base_ContextMenu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4857);
/* harmony import */ var _components_request_RequestIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4863);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4861);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(749);
/* harmony import */ var _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5874);
/* harmony import */ var _modules_tracked_state_TrackedState__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1876);
var _dec, _class;


















const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('PermissionStore');let





































CollectionBrowserRequestListItem = (_dec = Object(_components_base_ContextMenu__WEBPACK_IMPORTED_MODULE_5__["default"])([{ label: 'Rename', shortcut: 'rename', isVisible(props) {return permissionStore.can('edit', 'request', props.request.id);}, onClick(props, component) {component.toggleEditName();} }, { label: 'Edit', isVisible(props) {return permissionStore.can('edit', 'request', props.request.id);}, onClick(props, component) {component.handleActionTrigger(props.request.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_EDIT"]);} }, { label: 'Duplicate', shortcut: 'duplicate', isVisible(props) {return permissionStore.can('duplicate', 'request', props.request.id);}, onClick(props, component) {component.handleActionTrigger(props.request.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DUPLICATE"]);} }, { label: 'Delete', shortcut: 'delete', isVisible(props) {return permissionStore.can('delete', 'request', props.request.id);}, onClick(props, component) {component.handleActionTrigger(props.request.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DELETE"]);} }], monitor => {return { isContextMenuOpen: monitor.isOpen };}), _dec(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_9__["observer"])(_class = class CollectionBrowserRequestListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      showDescription: false,
      showRename: true,
      editingDescription: false };


    this.trackedState = new _modules_tracked_state_TrackedState__WEBPACK_IMPORTED_MODULE_13__["TrackedState"]({
      requestDescription: _.get(this.props, 'request.description') });


    this.handleToggleShowDescription = this.handleToggleShowDescription.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
    this.handleNameUpdate = this.handleNameUpdate.bind(this);
    this.handleRequestDescriptionUpdate = this.handleRequestDescriptionUpdate.bind(this);
    this.handleRequestDescriptionChange = this.handleRequestDescriptionChange.bind(this);
    this.handleToggleEdit = this.handleToggleEdit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.resetDescriptionTrackedState = this.resetDescriptionTrackedState.bind(this);
  }

  getDescriptionClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()('collection-browser-list-item__request__description', { 'is-open': this.state.showDescription });
  }

  handleToggleShowDescription() {
    if (this.props.isContextMenuOpen()) {
      return;
    }

    this.setState(prevState => {
      return { showDescription: !prevState.showDescription };
    });
  }

  toggleEditName() {
    this.refs.inlineInput && this.refs.inlineInput.toggleEdit();
  }

  handleToggleEditName(isEditing) {
    const inlineInput = this.refs.inlineInput;
    if (isEditing && inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    }
    this.setState({ showRename: !isEditing });
  }

  handleNameUpdate(value) {
    this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], this.props.request.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME"], value);
  }

  handleActionTrigger(entityId, action) {
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME_TOGGLE"]) {
      this.toggleEditName();
    } else
    {
      this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], entityId, action);
    }
  }

  handleActionClick(entityId, action, e) {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    this.handleActionTrigger(entityId, action);
  }

  handleRequestDescriptionUpdate(value) {
    //  reset tracked state description
    this.trackedState.reset({ requestDescription: value });

    this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], this.props.request.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DESCRIPTION_UPDATE"], value);

    this.setState(prevState => {
      return { editingDescription: !prevState.editingDescription };
    });

  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const inlineEditor = this.refs.inlineEditor;
    if (inlineEditor) {
      if (!nextProps.isOpen && this.props.isOpen) {
        inlineEditor.reset();
      } else
      if (nextProps.browserWidth !== this.props.browserWidth) {
        inlineEditor.refresh();
      }
    }
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  handleRequestDescriptionChange(value) {
    this.trackedState.set({ requestDescription: value });
  }

  handleToggleEdit() {
    this.setState(prevState => {
      return { editingDescription: !prevState.editingDescription };
    });
  }

  handleCancel() {
    if (this.trackedState.isDirty()) {
      pm.mediator.trigger('showConfirmationModal', this.resetDescriptionTrackedState);
    } else
    {
      this.handleToggleEdit();
    }
  }

  resetDescriptionTrackedState() {
    // Reset Description
    this.trackedState.reset({ requestDescription: _.get(this.props, 'request.description', '') });
    this.handleToggleEdit();
  }


  render() {

    let descriptionClasses = this.getDescriptionClasses();

    const { name, method, id } = this.props.request,
    permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('PermissionStore'),
    canEditRequest = permissionStore.can('edit', 'request', id),
    canDuplicateRequest = permissionStore.can('duplicate', 'request', id),
    canDeleteRequest = permissionStore.can('delete', 'request', id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__request-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { onClick: this.handleToggleShowDescription },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__request' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__request__label-wrapper' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_request_RequestIcon__WEBPACK_IMPORTED_MODULE_6__["default"], { method: method })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__request__meta' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_3__["default"], {
                className: 'collection-browser-list-item__request__name',
                placeholder: 'Request Name',
                ref: 'inlineInput',
                value: name,
                onSubmit: this.handleNameUpdate,
                onToggleEdit: this.handleToggleEditName })),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-list-item__request__actions collection-browser-actions-wrapper' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["ButtonGroup"], null,

                this.state.showRename &&

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'icon',
                    onClick: this.handleActionClick.bind(this, id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME_TOGGLE"]),
                    disabled: !canEditRequest,
                    tooltip: this.getTooltipText(!canEditRequest) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_RENAME_REQUEST_TOOLTIP"] },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'rename' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-rename-stroke', className: 'collection-browser-collection-rename-icon pm-icon pm-icon-normal' }))),




                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'icon',
                    onClick: this.handleActionClick.bind(this, id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_EDIT"]),
                    disabled: !canEditRequest,
                    tooltip: this.getTooltipText(!canEditRequest) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_EDIT_REQUEST_TOOLTIP"] },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'edit' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-edit-stroke', className: 'collection-browser-collection-edit-icon pm-icon pm-icon-normal' }))),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'icon',
                    onClick: this.handleActionClick.bind(this, id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DUPLICATE"]),
                    disabled: !canDuplicateRequest,
                    tooltip: this.getTooltipText(!canDuplicateRequest) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DUPLICATE_REQUEST_TOOLTIP"] },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'copy' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-copy-stroke', className: 'collection-browser-collection-duplicate-icon pm-icon pm-icon-normal' }))),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'icon',
                    onClick: this.handleActionClick.bind(this, id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DELETE"]),
                    disabled: !canDeleteRequest,
                    tooltip: this.getTooltipText(!canDeleteRequest) || _constants_CollectionBrowserActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DELETE_REQUEST_TOOLTIP"] },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'delete' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-delete-stroke', className: 'collection-browser-collection-delete-icon pm-icon pm-icon-normal' }))))))),






        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: descriptionClasses },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'requestDescription', isVisible: this.state.showDescription },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InlineEditor__WEBPACK_IMPORTED_MODULE_4__["default"], {
              isControlled: true,
              className: 'collection-browser-request-description-wrapper',
              editable: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('PermissionStore').can('edit', 'request', id),
              isEditing: this.state.editingDescription,
              fontSize: 11,
              placeholder: 'Make things easier for your teammates with a complete request description.',
              ref: 'inlineEditor',
              value: this.trackedState.get('requestDescription'),
              viewLessText: '(less)',
              viewMoreText: '(more)',
              onUpdate: this.handleRequestDescriptionUpdate,
              onToggleEdit: this.handleToggleEdit,
              onChange: this.handleRequestDescriptionChange,
              onCancel: this.handleCancel })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-expandable-view-list-item_request__openinbuilder' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                className: 'collection-expandable-view-list-item_request__openinbuilder_link',
                onClick: this.handleActionTrigger.bind(this, id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_OPEN_IN_BUILDER"]) }, 'Open in builder')))));







  }}) || _class) || _class);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5876:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMocksContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_collections_browser_mocks_CollectionBrowserMockHeader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5877);
/* harmony import */ var _components_collections_browser_mocks_CollectionBrowserMockList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5878);
/* harmony import */ var _constants_LimitServiceConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5881);
/* harmony import */ var _constants_InfobarConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1258);
/* harmony import */ var _modules_controllers_MockController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1251);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1789);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1763);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2690);
/* harmony import */ var _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4870);
/* harmony import */ var _services_UIEventService_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1755);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;











let


CollectionBrowserMocksContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_9__["observer"])(_class = class CollectionBrowserMocksContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      mocks: [],
      refreshing: false };

    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleRefreshMocks = this.handleRefreshMocks.bind(this);
    this.handleAddMock = this.handleAddMock.bind(this);
    this.handleEditMock = this.handleEditMock.bind(this);
    this.handleCloseWarning = this.handleCloseWarning.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    // Someone has sidebar open and switches collection
    if (_.get(this.props, 'collection.uid') !== _.get(nextProps, 'collection.uid')) {
      this.detachModelListeners();

      this.initializeModel(nextProps.collection);
    }
  }

  componentDidMount() {
    // Required as the lesson Design an API directly opens mocks tab
    this.initializeModel(this.props.collection);
  }

  componentWillUnmount() {
    this.detachModelListeners();
  }

  fetchMocks(collectionUId) {
    this.setState({ refreshing: true });
    _modules_controllers_MockController__WEBPACK_IMPORTED_MODULE_5__["default"].getAll({
      collection: collectionUId,
      workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id,
      populate: true }).
    then(list => {
      this.setState({
        mocks: list,
        refreshing: false });


      // Event being fired for the lesson step to progress
      _services_UIEventService_js__WEBPACK_IMPORTED_MODULE_12__["default"].publish('mocksLoaded');
    }).catch(() => {
      this.setState({ refreshing: false });
    });
  }

  initializeModel(collection) {
    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore').isLoggedIn || _.isEmpty(collection)) {
      return;
    }
    this.fetchMocks(collection.uid);
  }

  detachModelListeners() {
    this.setState({
      mocks: [],
      refreshing: false });

  }

  handleCloseWarning() {
    let mockLimitMessage = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ResourceLimitMessagesStore').find(_constants_LimitServiceConstants__WEBPACK_IMPORTED_MODULE_3__["MOCK_CALLS"]);
    mockLimitMessage && mockLimitMessage.dismissMessage();
  }

  handleDelete(mockId) {

    let mock = _.find(this.state.mocks, ['id', mockId]);
    mock && pm.mediator.trigger('showDeleteMockModal', mock, this.fetchMocks.bind(this, this.props.collection.uid), { origin: 'collection_browser' });
  }

  handleEditMock(data = {}) {
    _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_11__["default"].edit(
    {
      collectionId: this.props.collection.id,
      opts: { from: data.from },
      mock: _extends({}, data.mock) },

    this.fetchMocks.bind(this, this.props.collection.uid));

  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_10__["default"].login();
  }

  handleRefreshMocks() {
    !this.state.refreshing && this.fetchMocks(this.props.collection.uid);
  }

  handleAddMock(data = {}) {
    _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_11__["default"].create(
    {
      collectionId: this.props.collection.id,
      opts: { from: data.from } },

    this.fetchMocks.bind(this, this.props.collection.uid));

  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_8___default()({ 'collection-browser-mocks': true }, this.props.className);
  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore'),
    message = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ResourceLimitMessagesStore').find(_constants_LimitServiceConstants__WEBPACK_IMPORTED_MODULE_3__["MOCK_CALLS"]) || {};

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_browser_mocks_CollectionBrowserMockHeader__WEBPACK_IMPORTED_MODULE_1__["default"], {
            isLoggedIn: currentUser.isLoggedIn,
            isRefreshing: this.state.refreshing,
            message: message,
            mocks: this.state.mocks,
            onAddMock: this.handleAddMock,
            onMessageClose: this.handleCloseWarning,
            onRefresh: this.handleRefreshMocks,
            collection: this.props.collection })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'list' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_browser_mocks_CollectionBrowserMockList__WEBPACK_IMPORTED_MODULE_2__["default"], {
            isLoading: this.state.refreshing,
            mocks: this.state.mocks,
            onAddMock: this.handleAddMock,
            onEdit: this.handleEditMock,
            onDelete: this.handleDelete,
            onSignIn: this.handleSignIn,
            collection: this.props.collection }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5877:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMockHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _messaging_Alert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2689);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1222);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1768);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;









let


CollectionBrowserMockHeader = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class CollectionBrowserMockHeader extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleMockLearn = this.handleMockLearn.bind(this);
    this.handleAddMock = this.handleAddMock.bind(this);
  }

  handleMockLearn() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__["MOCK_DOCS"]);
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEvent('onboarding', 'view_documentation_intro_mock', 'collection_browser');
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-browser-learn-more-header__actions-container': true,
      'collection-browser-learn-more-header__refresh-container': true,
      'is-disabled': this.props.isRefreshing });

  }

  handleAddMock() {
    this.props.onAddMock({ from: 'collection_browser' });
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getAddMockClass(isDisabled) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-browser-add-entity': isDisabled,
      'collection-browser-learn-more-header__text': true });

  }


  render() {
    let alertMessage = _.get(this.props, 'message.message');

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore'),
    collectionId = this.props.collection && this.props.collection.id,
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id;

    const canAddMock = collectionId && permissionStore.can('addMock', 'collection', collectionId) &&
    permissionStore.can('addMock', 'workspace', workspaceId);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-learn-more-header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], {
            name: 'icon-action-publish-stroke',
            className: 'collection-browser-learn-more-header__icon pm-icon pm-icon-secondary' }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'collection-browser-learn-more-header__text',
              onClick: this.handleMockLearn }, 'Learn how to mock your requests'),




          this.props.isLoggedIn &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: this.getRefreshTextClass(),
              onClick: this.props.onRefresh },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-action-refresh-stroke', className: 'collection-browser-learn-more-header__refresh-icon pm-icon pm-icon-normal' }))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' }),

        alertMessage &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_messaging_Alert__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({},
        this.props.message, {
          message: alertMessage,
          onDismiss: this.props.onMessageClose })),



        !_.isEmpty(this.props.mocks) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'addMock' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-learn-more-header' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_9__["Button"], {
                className: 'collection-browser-add-mock',
                onClick: this.handleAddMock,
                tooltip: this.getTooltipText(!canAddMock),
                disabled: !canAddMock },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getAddMockClass(!canAddMock) },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], {
                  name: 'icon-action-add-stroke',
                  className: 'collection-browser-add-entity-header__icon pm-icon pm-icon-secondary' }), 'Add mock'))))));









  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5878:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMockList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CollectionBrowserMockItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5879);
/* harmony import */ var _CollectionBrowserMockEmptyListItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5880);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



let
CollectionBrowserMockList = class CollectionBrowserMockList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-lists' },

        this.props.isLoading &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-empty-item' }, 'Fetching more mocks'),




        !this.props.isLoading && _.isEmpty(this.props.mocks) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserMockEmptyListItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
          onAddMock: this.props.onAddMock,
          onSignIn: this.props.onSignIn,
          collection: this.props.collection }),



        _.map(this.props.mocks, mock => {
          return (
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: mock.id, key: mock.id },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserMockItem__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({
                onAddMock: this.props.onAddMock,
                onSignIn: this.props.onSignIn,
                onDelete: this.props.onDelete,
                onEdit: this.props.onEdit,
                collectionId: this.props.collection.id,
                isLoading: this.props.isLoading },
              mock))));



        })));



  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5879:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMockItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1735);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(784);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1789);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_uid_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(768);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(748);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2078);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_11__);
var _class;










let


CollectionBrowserMockItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class CollectionBrowserMockItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleCopyUrl = this.handleCopyUrl.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleMockClick = this.handleMockClick.bind(this);
  }

  getMockUrl() {
    return _.get(this, 'props.url', _.get(this, 'props.id', ''));
  }

  handleCopyUrl() {
    _utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_1__["default"].copy(this.getMockUrl());
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
      category: 'mock',
      action: 'copy',
      label: 'collection_browser',
      entityId: _.get(this.props, 'id') });

    pm.toasts.success('Mock URL copied');
  }

  handleDelete() {
    this.props.onDelete && this.props.onDelete(this.props.id);
  }

  handleEdit() {
    this.props.onEdit && this.props.onEdit({ mock: {
        mockId: this.props.id,
        name: this.props.name,
        isPrivate: !this.props.published,
        mockUrl: this.props.url,
        versionId: this.props.collection && this.props.collection.versionTag,
        environmentId: this.props.environment && Object(_utils_uid_helper__WEBPACK_IMPORTED_MODULE_8__["decomposeUID"])(this.props.environment.id).modelId },
      from: 'collection_browser' });
  }

  getTooltipText(isDisabled, action) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    } else
    {
      return `${action} Mock`;
    }
  }

  handleMockClick() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
      category: 'mock',
      action: 'view_in_web',
      label: 'collection_browser',
      entityId: this.props.id });


    // Redirects the user to mock call logs view
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_10__["openMockCallLogs"])(this.props.id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').id);
  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore');

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('PermissionStore'),
    canDeleteMock = permissionStore.can('deleteMock', 'collection', _.get(this.props, 'collectionId')),
    canEditMock = permissionStore.can('editMock', 'collection', _.get(this.props, 'collectionId'));

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-list-item__container', 'data-mock-id': this.props.id },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'openCallLogs' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-list-item__container__content-wrapper', onClick: this.handleMockClick },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-list-item__icon-container' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_11__["Icon"], { name: 'icon-entity-mock-stroke', className: 'collection-browser-mock-list-item__icon pm-icon pm-icon-normal' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-list-item__details' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'collection-browser-mock-list-item__details-name' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { title: this.props.name }, this.props.name)),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'collection-browser-mock-list-item__details-link' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { title: this.getMockUrl() }, this.getMockUrl()))))),





        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-list-item-version' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              title: _.get(this.props.collection, 'versionName'),
              className: classnames__WEBPACK_IMPORTED_MODULE_7___default()({
                'collection-browser-mock-list-item-version-tag': true,
                'collection-browser-mock-list-item-version-tag--current':
                _.isEqual(_.get(this.props.collection, 'versionTag'), 'latest') }) },


            _.get(this.props.collection, 'versionName'))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-mock-list-item__actions' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              className: 'collection-browser-mock-list-item__button-copy',
              tooltip: 'Copy Mock URL',
              type: 'icon',
              onClick: this.handleCopyUrl },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'copy' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_11__["Icon"], { name: 'icon-action-copy-stroke', className: 'collection-browser-mock-list-item__actions-copy-icon pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              tooltip: this.getTooltipText(!canEditMock, 'Edit'),
              type: 'icon',
              onClick: this.handleEdit,
              disabled: !canEditMock },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'edit' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_11__["Icon"], { name: 'icon-action-edit-stroke', className: 'pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              className: 'collection-browser-mock-list-item__button-delete',
              tooltip: this.getTooltipText(!canDeleteMock, 'Delete'),
              type: 'icon',
              onClick: this.handleDelete,
              disabled: !canDeleteMock },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'delete' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_11__["Icon"], { name: 'icon-action-delete-stroke', className: 'collection-browser-mock-list-item__actions-delete-icon pm-icon pm-icon-normal' }))))));





  }}) || _class;


CollectionBrowserMockItem.defaultProps = { onDelete: _.noop };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5880:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMockEmptyListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2559);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__);
var _class;




let


CollectionBrowserMockEmptyListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class CollectionBrowserMockEmptyListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleAddMock = this.handleAddMock.bind(this);
    this.handleShowMeHow = this.handleShowMeHow.bind(this);
  }

  handleAddMock() {
    this.props.onAddMock({ from: 'browser_empty_state' });
  }

  handleShowMeHow() {
    Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_4__["runTaggedLesson"])('mocking', {
      signInModalOptions: {
        type: 'mock',
        origin: 'collection_browser_mock_show_me_how' } });


  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  render() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('PermissionStore'),
    canAddMock = permissionStore.can('addMock', 'collection', this.props.collection.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-empty-block' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--mock' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'mock-empty__illustration' })),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'This collection is not being mocked'),



            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' }, 'A mock lets you simulate endpoints and their corresponding responses in a Collection without actually spinning up a back end.'),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                  type: 'secondary',
                  onClick: this.handleAddMock,
                  disabled: !canAddMock,
                  tooltip: this.getTooltipText(!canAddMock) }, 'Create a mock server')),




            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__separator-block' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'separator' }),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'separator-text' }, 'OR'),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'separator' })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__learn' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                    type: 'secondary',
                    onClick: this.handleShowMeHow },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
                    name: 'icon-descriptive-step-stroke',
                    className: 'entity-empty__learn__mouse-click-icon pm-icon pm-icon-secondary' }), 'Show me how')))))));









  }}) || _class;

/***/ }),

/***/ 5881:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MOCK_CALLS", function() { return MOCK_CALLS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MONITOR_RUNS", function() { return MONITOR_RUNS; });
const MOCK_CALLS = 'mock_usage';
const MONITOR_RUNS = 'monitor_request_runs';

/***/ }),

/***/ 5882:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMonitorListContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_collections_browser_monitors_CollectionBrowserMonitorHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5883);
/* harmony import */ var _components_collections_browser_monitors_CollectionBrowserMonitorList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5884);
/* harmony import */ var _constants_InfobarConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1258);
/* harmony import */ var _constants_LimitServiceConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5881);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2078);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(748);
/* harmony import */ var _modules_controllers_MonitorController__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1249);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2690);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1763);
/* harmony import */ var _new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4839);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1789);
var _class;













let


CollectionBrowserMonitorListContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_11__["observer"])(_class = class CollectionBrowserMonitorListContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      monitors: [],
      refreshing: false };

    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleRefreshMonitors = this.handleRefreshMonitors.bind(this);
    this.handleAddMonitor = this.handleAddMonitor.bind(this);
    this.handleCloseWarning = this.handleCloseWarning.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.isHidden && !nextProps.isHidden) {
      this.detachModelListeners();
      this.initializeModel(nextProps.collection);
    }
  }

  componentDidMount() {
    this.initializeModel(this.props.collection);
  }

  componentWillUnmount() {
    this.detachModelListeners();
  }

  fetchMonitors(collectionUId) {
    this.setState({ refreshing: true });
    _modules_controllers_MonitorController__WEBPACK_IMPORTED_MODULE_8__["default"].getAll({
      collection: collectionUId,
      workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveWorkspaceStore').id }).
    then(list => {
      this.setState({
        monitors: list,
        refreshing: false });

    }).catch(() => {
      this.setState({ refreshing: false });
    });
  }

  detachModelListeners() {
    this.setState({
      monitors: [],
      refreshing: false });

  }

  initializeModel(collection) {
    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').isLoggedIn || _.isEmpty(collection)) {
      return;
    }

    this.fetchMonitors(collection.uid);
  }

  handleCloseWarning() {
    let monitorLimitMessage = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ResourceLimitMessagesStore').find(_constants_LimitServiceConstants__WEBPACK_IMPORTED_MODULE_5__["MONITOR_RUNS"]);
    monitorLimitMessage && monitorLimitMessage.dismissMessage();
  }

  handleDelete(monitorId) {
    let monitor = _.find(this.state.monitors, ['id', monitorId]);
    monitor && pm.mediator.trigger('showDeleteMonitorModal', monitor, this.fetchMonitors.bind(this, this.props.collection.uid), { origin: 'collection_browser' });
  }

  handleEdit(monitorId) {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('monitor', 'initiate_edit');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["editEntity"])('monitors', monitorId, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveWorkspaceStore').id);
  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_10__["default"].login();
  }

  handleRefreshMonitors() {
    !this.state.refreshing && this.fetchMonitors(this.props.collection.uid);
  }

  handleAddMonitor(data = {}) {
    _new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_12__["default"].create(
    'openCreateNewMonitorModal',
    {
      collectionId: this.props.collection.id,
      opts: { from: data.from } },

    this.fetchMonitors.bind(this, this.props.collection.uid),
    { from: 'collection_browser' });

  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'collection-browser-monitor': true }, this.props.className);
  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore'),
    message = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ResourceLimitMessagesStore').find(_constants_LimitServiceConstants__WEBPACK_IMPORTED_MODULE_5__["MONITOR_RUNS"]) || {};

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_13__["default"], { identifier: 'header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_browser_monitors_CollectionBrowserMonitorHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
            isLoggedIn: currentUser && currentUser.isLoggedIn,
            isRefreshing: this.state.refreshing,
            message: message,
            monitors: this.state.monitors,
            onAddMonitor: this.handleAddMonitor,
            onMessageClose: this.handleCloseWarning,
            onRefresh: this.handleRefreshMonitors,
            collection: this.props.collection })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_13__["default"], { identifier: 'list' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_browser_monitors_CollectionBrowserMonitorList__WEBPACK_IMPORTED_MODULE_3__["default"], {
            isLoading: this.state.refreshing,
            monitors: this.state.monitors,
            onAddMonitor: this.handleAddMonitor,
            onDelete: this.handleDelete,
            onEdit: this.handleEdit,
            onSignIn: this.handleSignIn,
            collection: this.props.collection }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5883:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMonitorHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _messaging_Alert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2689);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1222);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1768);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;









let


CollectionBrowserMonitorHeader = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class CollectionBrowserMonitorHeader extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleMonitorLearn = this.handleMonitorLearn.bind(this);
    this.handleAddMonitor = this.handleAddMonitor.bind(this);
  }

  handleMonitorLearn() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__["MONITORING_DOCS"]);
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEvent('onboarding', 'view_documentation_intro_monitors', 'collection_browser');
  }

  handleAddMonitor() {
    this.props.onAddMonitor({ from: 'collection_browser' });
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-browser-learn-more-header__actions-container': true,
      'collection-browser-learn-more-header__refresh-container': true,
      'is-disabled': this.props.isRefreshing });

  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getAddMonitorClass(isDisabled) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-browser-add-entity': isDisabled,
      'collection-browser-learn-more-header__text': true });

  }


  render() {
    let alertMessage = _.get(this.props, 'message.message');

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore'),
    collectionId = this.props.collection.id,
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id;

    const canAddMonitor = collectionId && permissionStore.can('addMonitor', 'collection', collectionId) &&
    permissionStore.can('addMonitor', 'workspace', workspaceId);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-learn-more-header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], {
            name: 'icon-action-publish-stroke',
            className: 'collection-browser-learn-more-header__icon pm-icon pm-icon-secondary' }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'collection-browser-learn-more-header__text',
              onClick: this.handleMonitorLearn }, 'Learn how to monitor your requests'),




          this.props.isLoggedIn &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: this.getRefreshTextClass(),
              onClick: this.props.onRefresh },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-action-refresh-stroke', className: 'collection-browser-learn-more-header__refresh-icon pm-icon pm-icon-normal' }))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' }),

        alertMessage &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_messaging_Alert__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({},
        this.props.message, {
          message: alertMessage,
          onDismiss: this.props.onMessageClose })),



        !_.isEmpty(this.props.monitors) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'addMonitor' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-learn-more-header' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_9__["Button"], {
                className: 'collection-browser-add-monitor',
                onClick: this.handleAddMonitor,
                tooltip: this.getTooltipText(!canAddMonitor),
                disabled: !canAddMonitor },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getAddMonitorClass(!canAddMonitor) },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], {
                  name: 'icon-action-add-stroke',
                  className: 'collection-browser-add-entity-header__icon pm-icon pm-icon-secondary' }), 'Add monitor'))))));









  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5884:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMonitorList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CollectionBrowserMonitorListItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5885);
/* harmony import */ var _CollectionBrowserMonitorEmptyItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5886);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1789);




let
CollectionBrowserMonitorList = class CollectionBrowserMonitorList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list' },

        this.props.isLoading &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-empty-item' }, 'Fetching more monitors'),




        !this.props.isLoading && _.isEmpty(this.props.monitors) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserMonitorEmptyItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
          onAddMonitor: this.props.onAddMonitor,
          onSignIn: this.props.onSignIn,
          collection: this.props.collection }),



        _.map(this.props.monitors, monitor => {
          return (
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], {
                identifier: monitor.id,
                key: monitor.id },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserMonitorListItem__WEBPACK_IMPORTED_MODULE_1__["default"], {
                monitor: monitor,
                onDelete: this.props.onDelete,
                onEdit: this.props.onEdit,
                id: monitor.id,
                collection: this.props.collection })));



        })));



  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5885:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMonitorListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2078);
/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(784);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1789);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__);
var _class;







let

CollectionBrowserMonitorListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class CollectionBrowserMonitorListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.getUsername = this.getUsername.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleOpenMonitor = this.handleOpenMonitor.bind(this);
  }

  getUsername(id, currentUser) {
    return _utils_util__WEBPACK_IMPORTED_MODULE_3__["default"].getUserNameForId(id, currentUser);
  }

  handleEdit() {
    _.invoke(this, 'props.onEdit', this.props.monitor.id);
  }

  handleDelete() {
    _.invoke(this, 'props.onDelete', this.props.monitor.id);
  }

  handleOpenMonitor() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('monitor', 'view_run_details', 'collection_browser');
    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__["openEntity"])('monitors', this.props.monitor.id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').id);
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    } else
    {
      return 'Delete Monitor';
    }
  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore');

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('PermissionStore'),
    canDeleteMonitor = permissionStore.can('deleteMonitor', 'collection', this.props.collection.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list-item', 'data-monitor-id': this.props.id },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'collection-browser-monitor-list-item__content-wrapper',
            onClick: this.handleOpenMonitor },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list-item__icon-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-descriptive-observe-stroke', className: 'collection-browser-monitor-list-item__icon pm-icon pm-icon-normal' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list-item__content' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list-item__name' }, this.props.monitor.name),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list-item__creator' }, this.getUsername(this.props.monitor.createdBy, currentUser)))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-monitor-list-item__actions' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'collection-browser-monitor-dropdown-menu-item__button--edit',
              tooltip: 'Edit Monitor',
              type: 'icon',
              onClick: this.handleEdit },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'edit' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-edit-stroke', className: 'collection-browser-monitor-dropdown-menu-item__icon--edit pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'collection-browser-monitor-dropdown-menu-item__button--delete',
              tooltip: this.getTooltipText(!canDeleteMonitor),
              type: 'icon',
              onClick: this.handleDelete,
              disabled: !canDeleteMonitor },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'delete' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-delete-stroke', className: 'collection-browser-monitor-dropdown-menu-item__icon--delete pm-icon pm-icon-normal' }))))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5886:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserMonitorEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2559);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__);
var _class;




let

CollectionBrowserMonitorEmptyItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class CollectionBrowserMonitorEmptyItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleAddMonitor = this.handleAddMonitor.bind(this);
    this.handleShowMeHow = this.handleShowMeHow.bind(this);
  }

  handleAddMonitor() {
    this.props.onAddMonitor({ from: 'browser_empty_state' });
  }

  handleShowMeHow() {
    Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_4__["runTaggedLesson"])('monitoring', {
      signInModalOptions: {
        type: 'monitor',
        origin: 'collection_browser_monitor_show_me_how' } });


  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getEmptyState() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('PermissionStore'),
    canAddMock = permissionStore.can('addMonitor', 'collection', this.props.collection.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--monitor' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'monitor-empty__illustration' })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'This collection is not being monitored'),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' }, 'A monitor lets you run a collection periodically to check for its performance and response.'),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                type: 'secondary',
                onClick: this.handleAddMonitor,
                disabled: !canAddMock,
                tooltip: this.getTooltipText(!canAddMock) }, 'Create a monitor')),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__separator-block' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'separator' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'separator-text' }, 'OR'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'separator' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__learn' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                  type: 'secondary',
                  onClick: this.handleShowMeHow },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
                  name: 'icon-descriptive-step-stroke',
                  className: 'entity-empty__learn__mouse-click-icon pm-icon pm-icon-secondary' }), 'Show me how'))))));








  }

  getContents() {
    return this.getEmptyState();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-empty-block' },
        this.getContents()));


  }}) || _class;

/***/ }),

/***/ 5887:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserActivityFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3946);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _activity_feed_ActivityFeed__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5888);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2690);
/* harmony import */ var _activity_feed_AddVersionTagModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5890);
/* harmony import */ var _stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1640);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(742);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);









let

CollectionBrowserActivityFeed = class CollectionBrowserActivityFeed extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      collectionRestoreTarget: null,
      openVersionTagModal: false,
      isRemovingTag: false,
      isRestored: false };


    this.handleLoadNew = this.handleLoadNew.bind(this);
    this.handleLoadMore = this.handleLoadMore.bind(this);
    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleRestore = this.handleRestore.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
    this.handleAddVersionTag = this.handleAddVersionTag.bind(this);
    this.handleRemoveVersionTag = this.handleRemoveVersionTag.bind(this);
    this.handleVersionTagModalClose = this.handleVersionTagModalClose.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.store = new _stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_5__["default"]();
    this.props.isLoggedIn && this.initializeFeeds();
    this.subscribeToCollectionRestore();
  }

  componentWillUnmount() {
    this.unsubscribe && typeof this.unsubscribe === 'function' && this.unsubscribe();
  }

  initializeFeeds() {
    let collectionUid = this.props.collectionUid;
    this.store.initialize(collectionUid);

    // Add analytics event to show that user is viewing collection changelog
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'collection',
      action: 'view_changelog',
      label: 'collection_changelog',
      entityId: this.props.collectionUid });

  }

  handleLoadNew() {
    return this.store.loadNew().
    then(isNewFeedLoaded => {
      return Promise.resolve(isNewFeedLoaded);
    });
  }

  handleLoadMore() {
    this.store.loadMore();
  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_3__["default"].login();
  }

  handleAddVersionTag(revisionId) {
    // Add analytics event to track initial version tag create
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'collection',
      action: 'initiate_version_tag_create',
      label: 'collection_changelog',
      entityId: this.props.collectionUid });


    this.setState({
      openVersionTagModal: !this.state.openVersionTagModal,
      revisionId: revisionId });

  }

  handleRemoveVersionTag(revisionId, tagId) {
    this.setState({ isRemovingTag: !this.state.isRemovingTag });

    let criteria = {
      collectionUid: this.props.collectionUid,
      tagId: tagId,
      revisionId: revisionId };


    this.store.removeVersionTag(criteria).
    then(() => {
      this.setState({ isRemovingTag: !this.state.isRemovingTag });

      // Add analytics event to track version tag delete
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
        category: 'collection',
        action: 'version_tag_delete',
        label: 'collection_changelog',
        entityId: this.props.collectionUid });

    }).
    catch(() => {
      this.setState({ isRemovingTag: !this.state.isRemovingTag });
    });
  }

  handleVersionTagModalClose() {
    this.setState({ openVersionTagModal: !this.state.openVersionTagModal });
  }

  handleRestore(maxId, createdAt) {
    let restoreTarget = {
      collectionUid: this.props.collectionUid,
      maxId: maxId };


    this.restoreDate = _postman_date_helper__WEBPACK_IMPORTED_MODULE_1___default.a.getFormattedDateAndTime(createdAt);

    this.setState({ isRestored: false });

    this.setState({ collectionRestoreTarget: restoreTarget }, () => {
      pm.syncManager.restoreCollection(restoreTarget, error => {
        if (error) {
          // when socket connection is not available
          this.setState({ isRestored: true, collectionRestoreTarget: null });
        }

        // Add analytics event to show that collection has been restored
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
          category: 'collection',
          action: 'restore_collection',
          label: 'collection_changelog',
          entityId: this.props.collectionUid });

      });
    });
  }

  subscribeToCollectionRestore() {
    this.unsubscribe = pm.eventBus.channel('sync-manager-internal').subscribe(event => {
      if (!event) {
        return;
      }

      const eventNamespace = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_7__["getEventNamespace"])(event),
      eventName = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_7__["getEventName"])(event),
      eventData = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_7__["getEventData"])(event) || {};

      if (eventName === 'collectionRestored' && eventNamespace === 'command') {
        this.setState({ isRestored: true, collectionRestoreTarget: null });

        if (!eventData.error) {
          pm.toasts.success(`Your collection has been successfully restored to ${this.restoreDate || 'a previous state'}.`, { noIcon: true, title: 'Collection restored' });
        } else
        {
          pm.toasts.error('We couldn\'t restore collection to a previous state. Please try again later.', { noIcon: true, title: 'Unable to restore collection' });
        }
      }
    });
  }

  /**
     * @param {Boolean} - options.initialRetry - retry initializing change-logs
     * @param {Boolean} - options.loadMoreRetry - retry loading more change-logs
     */
  handleRetry(options) {
    if (options.initialRetry) {
      this.initializeFeeds();
    } else
    if (options.loadMoreRetry) {
      this.handleLoadMore();
    }
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_8___default()({ 'collection-browser-activity-feed-lists': true }, this.props.className);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_activity_feed_ActivityFeed__WEBPACK_IMPORTED_MODULE_2__["default"], {
          activityFeed: this.store,
          collectionRestoreTarget: this.state.collectionRestoreTarget,
          enableRestore: this.props.enableRestore,
          isLoggedIn: this.props.isLoggedIn,
          isRemovingTag: this.state.isRemovingTag,
          isRestored: this.state.isRestored,
          isVisible: this.props.isVisible,
          onLoadNew: this.handleLoadNew,
          onLoadMore: this.handleLoadMore,
          onSignIn: this.handleSignIn,
          onRestore: this.handleRestore,
          onRetry: this.handleRetry,
          onAddVersionTag: this.handleAddVersionTag,
          onRemoveVersionTag: this.handleRemoveVersionTag }),


        this.state.openVersionTagModal &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_activity_feed_AddVersionTagModal__WEBPACK_IMPORTED_MODULE_4__["default"], {
          activityFeed: this.store,
          revisionId: this.state.revisionId,
          collectionUid: this.props.collectionUid,
          isOpen: this.state.openVersionTagModal,
          onRequestClose: this.handleVersionTagModalClose })));




  }};

/***/ }),

/***/ 5888:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ActivityFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Activity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5889);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3946);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1875);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1222);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1768);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1763);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__);
var _class;









let


ActivityFeed = Object(mobx_react__WEBPACK_IMPORTED_MODULE_9__["observer"])(_class = class ActivityFeed extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {

  constructor(props) {
    super(props);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollDebounced = _.debounce(this.handleScroll, 100);
    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleRefreshFeed = this.handleRefreshFeed.bind(this);
    this.handleChangeLogLearn = this.handleChangeLogLearn.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.activityFeed &&
    this.props.activityFeed &&
    nextProps.activityFeed.collectionUid &&
    nextProps.activityFeed.collectionUid !== this.props.activityFeed.collectionUid) {
      this.refs.activity_feed && (this.refs.activity_feed.scrollTop = 0);
    }

    if (nextProps.isRestored && nextProps.isRestored !== this.props.isRestored) {
      this.handleRefreshFeed();
    }
  }

  handleChangeLogLearn() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__["ACTIVITY_FEED_AND_RESTORING_COLLECTION"]);
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_8___default()({
      'changelog-learn-more-header__refresh-container': true,
      'is-loading-new': this.props.activityFeed.isLoadingNew });

  }

  handleSignIn() {
    this.props.onSignIn && this.props.onSignIn();
  }

  handleScroll() {
    let node = this.refs.activity_feed;
    if (node.scrollHeight - (node.scrollTop + node.offsetHeight) <= 5) {
      _.isEmpty(this.props.activityFeed.error) && this.props.onLoadMore && this.props.onLoadMore();
    }
  }

  handleRefreshFeed() {
    this.props.onLoadNew && this.props.onLoadNew().
    then(isNewFeedLoaded => {
      if (isNewFeedLoaded) {
        this.refs.activity_feed.scrollTop = 0;
      }
    });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_8___default()({ 'activity-feed-container': true }, this.props.className);
  }

  render() {
    let props = this.props,
    activities = _.get(props, 'activityFeed.feeds', []),
    meta = _.get(props, 'activityFeed.meta', {}),
    error = _.get(props, 'activityFeed.error', {}),
    initialError = error && error.type === 'initial',
    loadMoreError = error && error.type === 'loadMore';

    if (!props.isLoggedIn) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-feed-empty-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                className: 'activity-feed-empty-signin-link',
                onClick: this.handleSignIn }, 'Sign in'), ' to track changes to your collection.')));






    }

    // Don't show subscribe / Unsubscribe event in collection activity feed
    let filteredActivities = _.filter(activities, activity => {
      return !(meta.model === 'collection' && _.includes(['subscribe', 'unsubscribe'], activity.action));
    }),
    groupedActivities = _.isEmpty(filteredActivities) ? [] : _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default.a.getDateGroups(filteredActivities, 'createdAt', 'MMMM D, YYYY'),
    latestActivity = _.maxBy(filteredActivities, 'id');
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'changelog-learn-more-header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], {
            name: 'icon-action-publish-stroke',
            className: 'changelog-learn-more-header__icon pm-icon pm-icon-secondary' }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'changelog-learn-more-header__text',
              onClick: this.handleChangeLogLearn }, 'Learn more about the changelog'),




          this.props.isLoggedIn &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_7__["Button"], {
              className: this.getRefreshTextClass(),
              onClick: this.handleRefreshFeed,
              disabled: props.activityFeed.isLoading || initialError,
              tooltip: 'Fetch newer feeds' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-action-refresh-stroke', className: 'changelog-learn-more-header__refresh-icon pm-icon pm-icon-normal' }))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'activity-feed',
            ref: 'activity_feed',
            onScroll: this.handleScrollDebounced },


          (props.activityFeed.isLoading || initialError) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Activity__WEBPACK_IMPORTED_MODULE_1__["LoadFeed"], {
            error: error,
            key: 'loading',
            isLoading: props.activityFeed.isLoading,
            onRetry: this.props.onRetry }),



          _.map(groupedActivities, subActivities => {
            if (_.isEmpty(subActivities)) {
              return false;
            }

            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'activity-feed-date-group-wrapper',
                  key: subActivities.name },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-feed-date-group' }, ' ', subActivities.name, ' '),

                _.map(subActivities.items, activity => {
                  return (
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Activity__WEBPACK_IMPORTED_MODULE_1__["Activity"], {
                      activity: activity,
                      enableRestore: !!(this.props.enableRestore && latestActivity && latestActivity.id !== activity.id),
                      isRestoring: _.get(this.props, 'collectionRestoreTarget.maxId') === activity.id,
                      isRemovingTag: this.props.isRemovingTag,
                      isVisible: this.props.isVisible,
                      key: activity.id,
                      meta: meta,
                      onAddVersionTag: this.props.onAddVersionTag,
                      onRemoveVersionTag: this.props.onRemoveVersionTag,
                      onRestore: this.props.onRestore }));


                })));



          }),


          !props.activityFeed.isLoading && _.isEmpty(groupedActivities) && !error &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: props.className },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-feed-loading-container ' }, 'No activities yet'))),






        (props.activityFeed.isLoadingMore || loadMoreError) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Activity__WEBPACK_IMPORTED_MODULE_1__["LoadFeed"], {
          error: error,
          key: 'loading-more',
          isLoading: props.activityFeed.isLoadingMore,
          onRetry: this.props.onRetry })));




  }}) || _class;


ActivityFeed.propTypes = {
  activityFeed: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.object.isRequired,
  activityName: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
  className: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
  onLoadMore: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func.isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5889:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Activity", function() { return Activity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadFeed", function() { return LoadFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4007);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2060);
/* harmony import */ var _utils_ActivityFeedHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5862);
/* harmony import */ var _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2059);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1808);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1768);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;









const COLLECTION_ACTIVITY_MODEL = 'collection';let


Activity = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class Activity extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  findCurrentLabel(activity) {
    return _.find(activity.tags, ['system', true]);
  }

  render() {
    let activity = this.props.activity,
    meta = this.props.meta,
    destination = null,
    trigger = activity.trigger,
    changesCount = _utils_ActivityFeedHelper__WEBPACK_IMPORTED_MODULE_5__["default"].getWhiteListedActivitiesCount(activity),
    pluralizedChangeText = _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_6__["default"].pluralize({
      count: changesCount,
      singular: 'change',
      plural: 'changes' }),

    headingText,
    activityDetails = null,
    currentLabel = this.findCurrentLabel(activity);

    if (activity.to && activity.to.model === 'folder') {
      destination =
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' to the folder '),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'activity-item-model' }, ' ', activity.to.instance.name, ' '));


    }

    switch (`${activity.model}:${activity.action}`) {
      case 'collection:create':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' created this collection');
        break;
      case 'collection:update':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-head-content' },
            changesCount > 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' made ', changesCount, ' ', pluralizedChangeText, ' to '),
            changesCount === 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' ', trigger === 'restore' ? 'restored' : 'modified', ' ')), 'this collection');



        activityDetails = changesCount > 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Details"], _extends({ isVisible: this.props.isVisible }, activity));
        break;
      case 'collection:destroy':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' deleted this collection');
        break;
      case 'folder:create':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' created the folder ');
        break;
      case 'folder:update':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-head-content' },
            changesCount > 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' made ', changesCount, ' ', pluralizedChangeText, ' to '),
            changesCount === 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' modified ')), 'the folder');



        activityDetails = !_.isEmpty(activity.input) && !_.isEmpty(activity.rollback) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Details"], _extends({ isVisible: this.props.isVisible }, activity));
        break;
      case 'folder:destroy':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' deleted the folder ');
        break;
      case 'request:create':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' added the request ');
        break;
      case 'request:update':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-head-content' },
            changesCount > 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' made ', changesCount, ' ', pluralizedChangeText, ' to '),
            changesCount === 0 && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' modified ')), 'the request');



        activityDetails = !_.isEmpty(activity.input) && !_.isEmpty(activity.rollback) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Details"], _extends({ isVisible: this.props.isVisible }, activity));
        break;
      case 'request:destroy':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' deleted the request ');
        break;
      case 'request:transfer':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' moved the request ');
        break;
      case 'response:create':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' created the example ');
        break;
      case 'response:update':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' modified the example ');
        break;
      case 'response:destroy':
        headingText = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' deleted the example ');
        break;
      default:null;}


    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-feed-connect-line' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Header"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["ProfilePic"], activity.user),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-head' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Meta"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Time"], { timestamp: activity.createdAt }),


                !_.isEmpty(activity.tags) &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'version-label-wrapper' },

                  !_.head(activity.tags).system &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                      className: 'activity-item-tagged_version__label is-tag',
                      title: _.head(activity.tags).apiVersion.name },

                    _.head(activity.tags).apiVersion.name),



                  currentLabel &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'activity-item-tagged_version__label' },
                    'CURRENT'))),






              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Heading"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["User"], activity.user),
                headingText,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'activity-item-model' }, ' ', activity.model !== COLLECTION_ACTIVITY_MODEL && activity.instance.name, ' '),
                destination))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item-details-wrapper' },
            activityDetails,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-item__action' },

              !_.isEmpty(activity.tags) && !_.head(activity.tags).system ?
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["RemoveTag"], {
                tagId: _.head(activity.tags).id,
                revisionId: activity.id,
                onRemoveVersionTag: this.props.onRemoveVersionTag,
                isRemovingTag: this.props.isRemovingTag }) :


              // Purpose of conditional rendering of <TagVersion> component is to
              // disallow free users to create version tag on non-latest revision of
              // a collection. This flag `activity.allowedActions.versionTagCreate`
              // is sent by server. Added a safe check to ensure this doesn't break
              // the app.

              _.get(activity, 'allowedActions.versionTagCreate') &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["TagVersion"], {
                revisionId: activity.id,
                onAddVersionTag: this.props.onAddVersionTag }),




              this.props.enableRestore &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_2__["Restore"], {
                createdAt: activity.createdAt,
                id: activity.id,
                isRestoring: this.props.isRestoring,
                rollback_from: meta.rollback_from,
                onRestore: this.props.onRestore }),



              this.props.enableRestore && this.props.isRestoring &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__["default"], { className: 'activity-item-restore-loader' }))))));






  }}) || _class;let


LoadFeed = class LoadFeed extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'activity-feed-loader': true,
      'initial-fetch-error-banner': this.props.error.type === 'initial',
      'load-more-error-banner': this.props.error.type === 'loadMore' });

  }

  handleClick(options) {
    this.props.onRetry && this.props.onRetry(options);
  }

  renderInitialErrorBanner() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-feed-initial-fetch-error-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'initial-fetch-error-title' }, 'Couldn\'t load changelogs'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'initial-fetch-error-subtitle' }, 'There was an unexpected error. Please try again.'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
            className: 'activity-feed-retry__btn',
            onClick: this.handleClick.bind(this, { initialRetry: true }),
            disabled: this.props.isLoading },


          this.props.isLoading && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__["default"], null) || 'Try again')));




  }

  renderLoadMoreErrorBanner() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'activity-feed-load-more-error-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'load-more-error-info' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'load-more-error-icon' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 'sm' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'load-more-error-subtitle' }, 'Something went wrong while retrieving more changelogs. Try again.')),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
            className: 'activity-feed-retry__btn',
            onClick: this.handleClick.bind(this, { loadMoreRetry: true }),
            disabled: this.props.isLoading }, 'Retry')));





  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },

        this.props.error && this.props.error.type === 'initial' && this.renderInitialErrorBanner() ||
        this.props.error && this.props.error.type === 'loadMore' && this.renderLoadMoreErrorBanner() ||
        this.props.isLoading && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__["default"], null)));



  }};



/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5890:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AddVersionTagModal; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1222);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1808);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1768);
/* harmony import */ var _base_Modals__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2085);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1793);
/* harmony import */ var _api_dev_components_api_editor_common_ErrorHandler_ErrorHandler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3960);
/* harmony import */ var _modules_services_ActivityFeedService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1641);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(748);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1875);
/* harmony import */ var _api_dev_services_APIDevService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1551);
var _class;













const CONTEXT_LIST = [
{ model: 'collection', type: 'documentation', name: 'Documentation' },
{ model: 'collection', type: 'testsuite', name: 'Test Suite' },
{ model: 'collection', type: 'integrationtest', name: 'Integration Test' },
{ model: 'collection', type: 'contracttest', name: 'Contract Test' }];let



AddVersionTagModal = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class AddVersionTagModal extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      items: null,
      selectedAPI: null,
      selectedAPIVersion: null,
      selectedAPIContext: '',
      isAPIVersionSelectEnable: false,
      isRequiredWarning: true,
      isModalLoading: false,
      isLoading: false,
      isOnlyOneAPI: false,
      modalOpenError: null };


    this.handleClose = this.handleClose.bind(this);
    this.handleAPISelect = this.handleAPISelect.bind(this);
    this.handleAPIVersionSelect = this.handleAPIVersionSelect.bind(this);
    this.handleAPIContextSelect = this.handleAPIContextSelect.bind(this);
    this.handleAddVersionTag = this.handleAddVersionTag.bind(this);
    this.handleActivityFeedTagsLearn = this.handleActivityFeedTagsLearn.bind(this);
  }

  componentDidMount() {
    let criteria = _.assign({}, {
      collectionUid: this.props.collectionUid });

    this.store = this.props.activityFeed;
    this.initialFetch(criteria);
  }

  getCustomStyles() {
    return {
      margin: 'auto',
      height: '384px',
      width: '350px' };

  }

  handleActivityFeedTagsLearn() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_11__["ACTIVITY_FEED_VERSION_TAGS"]);
  }

  handleClose() {
    this.props.onRequestClose && this.props.onRequestClose();
  }

  initialFetch(criteria) {
    this.setState({
      isModalLoading: true });


    _modules_services_ActivityFeedService__WEBPACK_IMPORTED_MODULE_9__["default"].fetchPossibleAPIVersions(criteria).
    then(entities => {
      this.setState({
        isModalLoading: false,
        items: entities },
      () => {
        this.state.items.length === 1 &&
        this.setState({
          selectedAPI: _.head(this.state.items),
          isAPIVersionSelectEnable: true,
          isOnlyOneAPI: true });

      });
    }).
    catch(error => {
      this.setState({
        isModalLoading: false,
        modalOpenError: error });

      pm.logger.warn(error);
    });
  }

  handleAPISelect(id) {
    this.setState({ isAPIVersionSelectEnable: true });
    let item = _.find(this.state.items, ['id', id]);

    !_.isUndefined(item) ?
    this.setState({ selectedAPI: item }) :
    this.setState({ selectedAPI: _.head(this.state.items) });
  }

  handleAPIVersionSelect(id) {
    let item = _.find(this.state.selectedAPI.versions, ['id', id]);

    this.setState({
      selectedAPIVersion: item,

      // if API and API context are selected, enable `Add version tag` button by setting `isRequiredWarning` state to `false`
      isRequiredWarning: this.state.selectedAPI && this.state.selectedAPIContext ? false : true });

  }

  handleAPIContextSelect(contextType) {
    let context = _.find(CONTEXT_LIST, ['type', contextType]);

    this.setState({
      selectedAPIContext: context,

      // if API and API version are selected, enable `Add version tag` button by setting `isRequiredWarning` state to `false`
      isRequiredWarning: this.state.selectedAPI && this.state.selectedAPIVersion ? false : true });

  }

  handleAddVersionTag() {
    // Bail out if API or API version or API context is not selected
    if (!this.state.selectedAPI || !this.state.selectedAPIVersion || !this.state.selectedAPIContext) {
      return;
    } else
    {
      this.setState({ isLoading: true });
      let criteria = {
        collectionUid: this.props.collectionUid,
        revisionId: this.props.revisionId,
        apiVersionId: this.state.selectedAPIVersion.id,
        relationType: this.state.selectedAPIContext.type };


      this.store.addVersionTag(criteria).
      then(() => {
        this.setState({ isLoading: false });

        // Add analytics event to track initial version tag create
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_10__["default"].addEventV2({
          category: 'collection',
          action: 'successful_version_tag_create',
          label: 'collection_changelog',
          entityId: this.props.collectionUid });


        this.handleClose();
      }).
      catch(() => {
        this.setState({ isLoading: false });
      });
    }
  }

  getModalContentClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'is-modal-loading': this.state.isModalLoading });

  }

  getDropdownHeadLabelClasses(showPlaceholderText) {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'dropdown-head-label': true,
      'placeholder-text': showPlaceholderText });

  }

  renderModalContent() {
    if (this.state.isModalLoading) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], null);
    }

    if (this.state.modalOpenError) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'version-tag-modal-error' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_dev_components_api_editor_common_ErrorHandler_ErrorHandler__WEBPACK_IMPORTED_MODULE_8__["default"], {
          title: 'Something went wrong',
          description: 'There was a problem adding a version tag to this collection. Please try again after some time.' }));


    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'version-tag__modal-content-heading' }, 'Link this collection revision to a specific API version.',

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
              className: 'btn btn-text version-tag__learn-btn-text',
              onClick: this.handleActivityFeedTagsLearn }, 'Learn More')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'version-tag__modal-content-dropdown' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-select__dropdown' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-label' }, 'Select API'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], { onSelect: this.handleAPISelect },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { type: 'secondary', size: 'small' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                    className: 'dropdown-head',
                    disabled: this.state.isOnlyOneAPI },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: this.getDropdownHeadLabelClasses(!this.state.selectedAPI) },
                    this.state.selectedAPI && this.state.selectedAPI.name || 'Select an API'))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
                  className: 'dropdown-menu',
                  fluid: true },


                !_.isEmpty(this.state.items) ?
                this.state.items.map(menuItem => {
                  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { key: menuItem.id, refKey: menuItem.id }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, menuItem.name));
                }) :
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { disabled: true }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'There are no APIs in this workspace'))))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-version-select__dropdown' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-label' }, 'Select version'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], {
                onSelect: this.handleAPIVersionSelect },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { type: 'secondary', size: 'small' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                    className: 'dropdown-head',
                    disabled: !this.state.isAPIVersionSelectEnable },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: this.getDropdownHeadLabelClasses(!this.state.selectedAPIVersion) },
                    this.state.selectedAPIVersion && this.state.selectedAPIVersion.name || 'Select a version'))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
                  className: 'dropdown-menu-list',
                  fluid: true },


                this.state.selectedAPI &&
                !_.isEmpty(this.state.selectedAPI.versions) ?
                this.state.selectedAPI.versions.map(menuItem => {
                  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { key: menuItem.id, refKey: menuItem.id }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, menuItem.name));
                }) :
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { disabled: true }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'There are no API versions to tag this collection.'))))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-relation-select__dropdown' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-label' }, 'Add to API as'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], {
                onSelect: this.handleAPIContextSelect },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { type: 'secondary', size: 'small' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                    className: 'dropdown-head',
                    disabled: !this.state.isAPIVersionSelectEnable },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: this.getDropdownHeadLabelClasses(!this.state.selectedAPIContext) },
                    this.state.selectedAPIContext.name || 'Add this to your API as'))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
                  className: 'dropdown-menu-list',
                  fluid: true },


                CONTEXT_LIST.map(menuItem => {
                  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { key: menuItem.type, refKey: menuItem.type }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, menuItem.name));
                }))))),





        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'version-tag__modal-content-action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
              type: 'secondary',
              onClick: this.props.onRequestClose,
              className: 'modal-cancel-btn' }, 'Cancel'),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
              type: 'primary',
              onClick: this.handleAddVersionTag,
              className: 'modal-version-tag-btn',
              disabled: this.state.isRequiredWarning || this.state.isLoading,
              tooltip: 'To add a version tag, select an API version and what you want to add the collection as.' },


            this.state.isLoading ?
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], null) :
            'Add Version Tag'))));




  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Modals__WEBPACK_IMPORTED_MODULE_6__["Modal"], {
          className: 'version-tag-modal',
          isOpen: this.props.isOpen,
          onRequestClose: this.props.onRequestClose,
          customStyles: this.getCustomStyles() },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Modals__WEBPACK_IMPORTED_MODULE_6__["ModalHeader"], null, ' Add a version tag '),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Modals__WEBPACK_IMPORTED_MODULE_6__["ModalContent"], { className: this.getModalContentClasses() },
          this.renderModalContent())));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5891:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserCollectionAction; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _models_services_DocumenterService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4869);
/* harmony import */ var _modules_services_APIService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1220);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(748);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4861);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1789);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2467);
var _class;












let


CollectionBrowserCollectionAction = Object(mobx_react__WEBPACK_IMPORTED_MODULE_10__["observer"])(_class = class CollectionBrowserCollectionAction extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { dropdownOpen: false };
    this.handleToggle = this.handleToggle.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleViewDocumentation = this.handleViewDocumentation.bind(this);
  }

  handleActionTrigger(entity, entityId, action) {
    this.props.onActionTriggered && this.props.onActionTriggered(entity, entityId, action);
  }

  handleViewDocumentation() {
    _models_services_DocumenterService__WEBPACK_IMPORTED_MODULE_4__["default"].getDocumentationURL(_.get(this.props, 'collection.id'), (e, documentUrl) => {
      if (e) {
        return;
      }
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('documentation', 'view', 'collection_browser');

      if (_.has(this.props, 'collection.id') && !_.isEmpty(this.props.collection.id)) {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEventV2({
          category: 'documentation',
          action: 'view_private',
          label: 'collection_browser',
          entityType: 'collection',
          entityId: `${Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore').id}-${_.get(this.props, 'collection.id')}` });

      }

      Object(_modules_services_APIService__WEBPACK_IMPORTED_MODULE_5__["openAuthenticatedRoute"])(documentUrl);
    });
  }

  handleSelect(action) {
    this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TARGET_COLLECTION"], this.props.collection.id, action);
  }

  handleToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  getActions() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore'),
    collectionId = this.props.collection.id,
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id,
    canEditCollection = permissionStore.can('edit', 'collection', collectionId),
    isShared = _.get(this.props.collection, 'isShared', false),
    isForked = _.get(this.props.collection, 'isForked', false),
    isOnline = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected;

    return [
    {
      type: canEditCollection ? _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_EDIT"] : _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_VIEW_ONLY"],
      label: canEditCollection ? 'Edit' : 'View Details',
      shortcut: 'edit',
      isEnabled: true,
      xpathLabel: 'edit',
      icon: canEditCollection ?
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-edit-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_EDIT"]) }) :
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-view-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_VIEW_ONLY"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_FORK"],
      label: 'Create a fork',
      isEnabled: true,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-fork-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_FORK"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_PULL_REQUEST"],
      label: 'Create Pull Request',
      isEnabled: isForked,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-pull-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_PULL_REQUEST"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_MERGE"],
      label: 'Merge changes',
      isEnabled: isForked,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-merge-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_MERGE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_MANAGE_ROLES"],
      label: 'Manage Roles',
      isEnabled: !!currentUser.team, // Enable it if the user belongs to a team
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-state-locked-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_MANAGE_ROLES"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_REQUEST"],
      label: 'Add Request',
      isEnabled: permissionStore.can('addRequest', 'collection', collectionId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-entity-request-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_REQUEST"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_FOLDER"],
      label: 'Add Folder',
      isEnabled: permissionStore.can('addFolder', 'collection', collectionId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-newFolder-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_FOLDER"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DUPLICATE"],
      label: 'Duplicate',
      shortcut: 'duplicate',
      isEnabled: permissionStore.can('addCollection', 'workspace', workspaceId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-copy-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DUPLICATE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DOWNLOAD"],
      label: 'Export',
      isEnabled: true,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-download-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DOWNLOAD"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_MONITOR"],
      label: 'Monitor Collection',
      isEnabled: permissionStore.can('addMonitor', 'collection', collectionId) && permissionStore.can('addMonitor', 'workspace', workspaceId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-descriptive-observe-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_MONITOR"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_MOCK"],
      label: 'Mock Collection',
      isEnabled: permissionStore.can('addMock', 'collection', collectionId) && permissionStore.can('addMock', 'workspace', workspaceId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-entity-mock-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_ADD_MOCK"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_PUBLISH_DOCS"],
      label: 'Publish Docs',
      isEnabled: permissionStore.can('publish', 'collection', collectionId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-publish-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_PUBLISH_DOCS"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_REMOVE_FROM_WORKSPACE"],
      label: 'Remove from workspace',
      isEnabled: permissionStore.can('removeCollection', 'workspace', workspaceId) && isOnline,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-close-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_REMOVE_FROM_WORKSPACE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      shortcut: 'delete',
      isEnabled: permissionStore.can('delete', 'collection', collectionId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-delete-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DELETE"]) }) }];


  }

  getMenuItemIconClasses(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({ 'dropdown-menu-item-icon': true }, { 'pm-icon': true }, { 'pm-icon-normal': true }, 'collection-browser-collection-' + label + '-icon');
  }

  getActionIconClassNames(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({ ['collection-browser-collection-' + label + '-icon']: true });
  }

  getMenuItemClasses(isPro) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({ 'dropdown-menu-item--pro-disabled': isPro });
  }

  getDisabledText(isDisabled, actionType) {
    if (isDisabled) {
      let defaultMessage = 'You do not have permissions to perform this action.',
      manageRolesMessage = 'You need to be signed-in to a team to perform this action',
      permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
      workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id;

      switch (actionType) {
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_MANAGE_ROLES"]:
          return manageRolesMessage;
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_MERGE"]:
          return 'This collection is not a fork';
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_PULL_REQUEST"]:
          return 'This collection is not a fork';
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_REMOVE_FROM_WORKSPACE"]:
          if (permissionStore.can('removeCollection', 'workspace', workspaceId)) {
            return 'Get online to perform this action';
          } else
          {
            return defaultMessage;
          }
        default:
          return defaultMessage;}

    }
  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map(action => {
      const modifierLabel = action.modifier && action.modifier(this.props.isPRO);

      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
            className: this.getMenuItemClasses(modifierLabel),
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled, action.type) },

          action.icon,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label),

          modifierLabel &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-modifier' }, modifierLabel)));



    }).value();
  }

  render() {

    let collection = this.props.collection;

    if (!collection || !collection.id) {
      return null;
    }

    let permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore'),
    gatekeeperStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('GateKeeperStore'),
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id,
    canShare = permissionStore.can('share', 'collection', collection.id),
    canRunCollection = permissionStore.can('addCollectionrun', 'workspace', workspaceId),
    shareButtonTooltip = canShare ? null : 'You do not have permissions to perform this action.',
    runButtonTooltip = canRunCollection ? null : 'You do not have permissions to perform this action.',
    isLoggedIn = currentUser && currentUser.isLoggedIn,
    isSyncEnabled = gatekeeperStore.isSyncEnabled,
    menuItems = this.getMenuItems();

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-actions-wrapper' },

          !collection.subscribed &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'share' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                className: 'collection-browser-collection-action-share-button',
                size: 'small',
                type: 'primary',
                disabled: !canShare,
                tooltip: shareButtonTooltip,
                onClick: this.handleActionTrigger.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TARGET_COLLECTION"], collection.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_SHARE"]) }, 'Share')),





          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'run' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                className: 'collection-browser-collection-action-run-button',
                size: 'small',
                type: 'primary',
                disabled: !canRunCollection,
                tooltip: runButtonTooltip,
                onClick: this.handleActionTrigger.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TARGET_COLLECTION"], collection.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_RUN"]) }, 'Run')),





          isLoggedIn && isSyncEnabled &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'viewInWeb' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                className: 'collection-browser-collection-action-view-documentation-button',
                size: 'small',
                type: 'secondary',
                onClick: this.handleViewDocumentation }, 'View in web')),





          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
              onSelect: this.handleSelect,
              onToggle: this.handleToggle,
              className: 'collection-browser-actions-dropdown' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], {
                dropdownStyle: 'nocaret',
                type: 'custom' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"], className: 'collection-browser-collection-dropdown-actions-button-wrapper' }, ' ',
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-options-stroke', className: 'collection-browser-collection-dropdown-actions-button pm-icon pm-icon-normal' }))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
                'align-right': true },

              menuItems)))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5892:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(776);


let CollectionBrowserService = {
  fetchLinkedApiName(uid) {
    if (!uid) {
      pm.logger.warn('CollectionBrowserService~fetchLinkedApiName: Collection Uid is a mandatory parameter');
      return Promise.reject();
    }

    let url = `/collections/${uid}/api`;

    return _RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__["default"].request(url, {
      method: 'get' }).

    then(({ body }) => {
      return Promise.resolve(body.data);
    }).
    catch(error => {
      pm.logger.warn('CollectionBrowserService~fetchLinkedApiName: Failed to fetch api linked to the collection', error);
      return Promise.reject(error);
    });
  } };


/* harmony default export */ __webpack_exports__["default"] = (CollectionBrowserService);

/***/ }),

/***/ 5893:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserFolderDetails; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base_InlineEditor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1766);
/* harmony import */ var _CollectionBrowserRequestListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5875);
/* harmony import */ var _CollectionBrowserFolderListItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5872);
/* harmony import */ var _components_base_Breadcrumb__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2469);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var _components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1883);
/* harmony import */ var _modules_tracked_state_TrackedState__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1876);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4861);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2467);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__);
var _class;














let


CollectionBrowserFolderDetails = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class = class CollectionBrowserFolderDetails extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { dropdownOpen: false, editingDescription: false };

    this.trackedState = new _modules_tracked_state_TrackedState__WEBPACK_IMPORTED_MODULE_11__["TrackedState"]({
      folderDescription: _.get(this.props, 'folder.description', '') });



    this.toggleCollectionView = this.toggleCollectionView.bind(this);
    this.handleActionTrigger = this.handleActionTrigger.bind(this);
    this.handleFolderSelect = this.handleFolderSelect.bind(this);
    this.handleFolderDescriptionUpdate = this.handleFolderDescriptionUpdate.bind(this);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);

    this.handleFolderDescriptionChange = this.handleFolderDescriptionChange.bind(this);
    this.handleToggleEdit = this.handleToggleEdit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.resetDescriptionTrackedState = this.resetDescriptionTrackedState.bind(this);
  }

  toggleCollectionView() {
    this.props.onCollectionDetailsNavigate && this.props.onCollectionDetailsNavigate();
  }

  handleActionTrigger(entity, entityId, action, data) {
    this.props.onActionTriggered && this.props.onActionTriggered(entity, entityId, action, data);
  }

  getCollectionHeaderClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'collection-browser-folder-details-header': true,
      'collection-browser-folder-details-header--padded-below': _.isEmpty(_.get(this.props.folder, 'description')) && !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore').can('edit', 'collection', this.props.collection.id) });

  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const inlineEditor = this.refs.inlineEditor,
    breadcrumb = this.refs.breadcrumb;

    //  reset tracked state description
    this.trackedState.reset({ folderDescription: _.get(nextProps, 'folder.description', '') });

    if (inlineEditor) {
      if (nextProps.isEditingDescription && !this.props.isEditingDescription) {
        inlineEditor.startEditing();
        inlineEditor.focus();
      } else
      if (!nextProps.isEditingDescription && this.props.isEditingDescription) {
        inlineEditor.reset();
      }
    }

    if (breadcrumb) {
      if (nextProps.browserWidth !== this.props.browserWidth) {
        inlineEditor.refresh();

        if (nextProps.browserWidth < this.props.browserWidth) {
          breadcrumb.collapse(nextProps.browserWidth);
        } else
        if (nextProps.browserWidth > this.props.browserWidth) {
          breadcrumb.expand(nextProps.browserWidth);
        }
      }
    }
  }

  handleFolderDescriptionUpdate(value) {
    //  reset tracked state description
    this.trackedState.reset({ folderDescription: value });

    this.setState(prevState => {
      return {
        editingDescription: !prevState.editingDescription };

    }, () => {
      this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TARGET_FOLDER"], this.props.folder.id,
      _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DESCRIPTION_UPDATE"], value);
    });
  }

  handleFolderSelect(folder) {
    this.props.onFolderSelect && this.props.onFolderSelect(folder);
  }

  handleSelect(action) {
    this.props.onActionTriggered && this.props.onActionTriggered(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TARGET_FOLDER"], this.props.folder.id, action);
  }

  handleToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  getActions() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore'),
    folderId = this.props.folder.id,
    canEditFolder = permissionStore.can('edit', 'folder', folderId);

    return [
    {
      type: canEditFolder ? _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_EDIT"] : _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_VIEW_ONLY"],
      label: canEditFolder ? 'Edit' : 'View Details',
      shortcut: 'edit',
      isEnabled: true,
      icon: canEditFolder ?
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-action-edit-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_EDIT"]) }) :
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-action-view-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_VIEW_ONLY"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_ADD_REQUEST"],
      label: 'Add Request',
      isEnabled: permissionStore.can('addRequest', 'folder', folderId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-entity-request-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_ADD_REQUEST"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_ADD_FOLDER"],
      label: 'Add Folder',
      isEnabled: permissionStore.can('addFolder', 'folder', folderId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-action-newFolder-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_ADD_FOLDER"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DUPLICATE"],
      label: 'Duplicate',
      shortcut: 'duplicate',
      isEnabled: permissionStore.can('duplicate', 'folder', folderId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-action-copy-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DUPLICATE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      shortcut: 'delete',
      isEnabled: permissionStore.can('delete', 'folder', folderId),
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-action-delete-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DELETE"]) }) }];


  }

  getMenuItemIconClasses(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({ 'dropdown-menu-item-icon': true }, 'pm-icon', 'pm-icon-normal', `collection-browser-collection-${label}-icon`);
  }

  getActionIconClassNames(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({ [`collection-browser-collection-${label}-icon`]: true });
  }

  getMenuItemClasses(isPro) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({ 'dropdown-menu-item--pro-disabled': isPro });
  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map(action => {
      const modifierLabel = action.modifier && action.modifier(this.props.isPRO);

      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
            className: this.getMenuItemClasses(modifierLabel),
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled) },

          action.icon,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label),

          modifierLabel &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-modifier' }, modifierLabel)));



    }).value();
  }


  handleFolderDescriptionChange(value) {
    this.trackedState.set({ folderDescription: value });
  }


  handleToggleEdit(e) {
    this.setState(prevState => {
      return { editingDescription: !prevState.editingDescription };
    }, () => {
      this.props.onFolderEditDescriptionToggle(e);
    });
  }

  handleCancel() {
    if (this.trackedState.isDirty()) {
      pm.mediator.trigger('showConfirmationModal', this.resetDescriptionTrackedState);
    } else
    {
      this.handleToggleEdit();
    }
  }

  resetDescriptionTrackedState() {
    // Reset Description
    this.trackedState.reset({ folderDescription: _.get(this.props, 'folder.description', '') });
    this.handleToggleEdit();
  }

  handleSave(value) {
    //  reset tracked state description
    this.trackedState.reset({ folderDescription: value });
    this.props.onUpdate(value);

    this.setState(prevState => {
      return { editingDescription: !prevState.editingDescription };
    });
  }

  render() {
    let { collection, folder } = this.props;

    if (!folder || !folder.id) {
      return null;
    }

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore'),
    canEditFolder = permissionStore.can('edit', 'folder', folder.id),
    canAddRequestToFolder = permissionStore.can('addRequest', 'folder', folder.id);

    let ownFolders = _.get(folder, 'ownFolders', []),
    ownRequests = _.get(folder, 'ownRequests', []),
    folderPath = folder.path,
    menuItems = this.getMenuItems();

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.props.className },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-details-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getCollectionHeaderClasses() },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Breadcrumb__WEBPACK_IMPORTED_MODULE_7__["default"], {
              items: folderPath,
              containerWidth: this.props.browserWidth,
              offsetRight: 100,
              onItemClick: entity => {
                if (entity.type === 'collection') {
                  this.toggleCollectionView();
                } else
                {
                  this.props.onFolderSelect && this.props.onFolderSelect(entity);
                }
              },
              ref: 'breadcrumb' }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-header-close-btn' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_10__["default"], {
                className: 'collection-browser-header-close-icon',
                onClick: this.props.onClose }))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InlineEditor__WEBPACK_IMPORTED_MODULE_4__["default"], {
            isControlled: true,
            className: 'collection-browser-folder-description-wrapper',
            editable: canEditFolder,
            placeholder: 'Make things easier for your teammates with a complete request description.',
            ref: 'inlineEditor',
            value: this.trackedState.get('folderDescription'),
            isEditing: this.state.editingDescription,
            onEdit: this.props.onEditFolderDescription,
            onUpdate: this.handleFolderDescriptionUpdate,
            onToggleEdit: this.handleToggleEdit,
            onChange: this.handleFolderDescriptionChange,
            onCancel: this.handleCancel })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-actions-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                type: 'primary',
                size: 'small',
                className: 'collection-browser-collection-action-run-button',
                onClick: this.handleActionTrigger.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TARGET_FOLDER"], folder.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_RUN"]) }, 'Run'),



            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
                onSelect: this.handleSelect,
                onToggle: this.handleToggle,
                className: 'collection-browser-actions-dropdown-folder' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], {
                  dropdownStyle: 'nocaret',
                  type: 'custom' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_13__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"], className: 'collection-browser-collection-dropdown-actions-button-wrapper' }, ' ',
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_14__["Icon"], { name: 'icon-action-options-stroke', className: 'pm-icon pm-icon-normal collection-browser-collection-dropdown-actions-button' }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
                  'align-left': true },

                menuItems))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' })),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-folder-list-wrapper' },

          _.isEmpty(ownRequests) && _.isEmpty(ownFolders) ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-browser-empty-folder' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__body--empty' }, 'This folder is empty.\xA0',

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    type: 'text',
                    onClick: () => this.props.onAddRequest(this.props.folder),
                    disabled: !canAddRequestToFolder,
                    tooltip: this.getDisabledText(!canAddRequestToFolder) }, 'Add requests'), 'to this folder and create subfolders to organize them'))) :








          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,

            _.map(ownFolders, folder => {
              return (
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserFolderListItem__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  folder: folder,
                  key: folder.id,
                  onActionTriggered: this.handleActionTrigger,
                  onFolderSelect: this.handleFolderSelect }));


            }),


            _.map(ownRequests, request => {
              return (
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionBrowserRequestListItem__WEBPACK_IMPORTED_MODULE_5__["default"], {
                  request: request,
                  browserWidth: this.props.browserWidth,
                  isOpen: this.props.isOpen,
                  key: request.id,
                  onActionTriggered: this.handleActionTrigger,
                  browserWidth: this.props.browserWidth }));


            }))),





        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider' })));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ })

}]);