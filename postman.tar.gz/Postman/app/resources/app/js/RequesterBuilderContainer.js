(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[15],{

/***/ 5819:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterBuilderContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1794);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1879);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _runtime_components_variables_environment_EnvironmentSelectorContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5820);
/* harmony import */ var _runtime_components_variables_environment_EnvironmentPreviewContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5822);
/* harmony import */ var _runtime_components_variables_environment_EnvironmentMenuContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5826);
/* harmony import */ var _components_tabs_TabTitles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5828);
/* harmony import */ var _components_tabs_TabContents__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5835);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1789);
/* harmony import */ var _services_TabShortcutsService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4838);
/* harmony import */ var _modules_view_manager_ActiveViewManager__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1796);
/* harmony import */ var _common_constants_views__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1797);
/* harmony import */ var _common_constants_views__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_common_constants_views__WEBPACK_IMPORTED_MODULE_14__);
var _class;














let



RequesterBuilderContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default()(_class = pure_render_decorator__WEBPACK_IMPORTED_MODULE_3___default()(_class = class RequesterBuilderContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      selectorWidth: pm.settings.getSetting('selectorWidth') || 210,
      tabScrollDirection: 'none' };


    this.focus = this.focus.bind(this);
    this.handleStartDrag = this.handleStartDrag.bind(this);
    this.handleStopDrag = this.handleStopDrag.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.attachModelListeners();
  }

  componentDidMount() {
    _modules_view_manager_ActiveViewManager__WEBPACK_IMPORTED_MODULE_13__["default"].updateActiveView(_common_constants_views__WEBPACK_IMPORTED_MODULE_14__["WORKSPACE_BUILDER"]);
  }

  componentWillUnmount() {
    this.detachModelListeners();
  }

  attachModelListeners() {
    pm.mediator.on('focusBuilder', this.focus);
  }

  detachModelListeners() {
    pm.mediator.off('focusBuilder', this.focus);
  }

  getKeymapHandlers() {
    return Object(_services_TabShortcutsService__WEBPACK_IMPORTED_MODULE_12__["getTabShortcuts"])();
  }

  focus() {
    _.invoke(this, 'refs.builder.focus');
  }

  handleStartDrag(event, data) {
    this.selectorWidth = this.state.selectorWidth;
    this.startClientX = data.x;
  }

  handleStopDrag() {
    pm.settings.setSetting('selectorWidth', this.state.selectorWidth);
  }

  handleDrag(event, data) {
    event.preventDefault();
    let clientX = data.x,
    selectorWidth = this.selectorWidth + (this.startClientX - clientX);

    if (selectorWidth > 450) {
      selectorWidth = 450;
    } else
    if (selectorWidth < 210) {
      selectorWidth = 210;
    }

    this.setState({ selectorWidth: selectorWidth });
  }


  render() {

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_4__["default"], { keyMap: pm.shortcuts.getShortcuts(), handlers: this.getKeymapHandlers() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-builder' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-builder-header' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_tabs_TabTitles__WEBPACK_IMPORTED_MODULE_9__["default"], {
              tabScrollDirection: this.state.tabScrollDirection }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_5__["DraggableCore"], {
                axis: 'x',
                onStart: this.handleStartDrag,
                onDrag: this.handleDrag,
                onStop: this.handleStopDrag },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-resize-handle-wrapper' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-resize-handle' }))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-container' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'environmentSelector' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_variables_environment_EnvironmentSelectorContainer__WEBPACK_IMPORTED_MODULE_6__["default"], { selectorWidth: this.state.selectorWidth })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'environmentPreview' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_variables_environment_EnvironmentPreviewContainer__WEBPACK_IMPORTED_MODULE_7__["default"], null)),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'environmentMenu' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_variables_environment_EnvironmentMenuContainer__WEBPACK_IMPORTED_MODULE_8__["default"], null)))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_tabs_TabContents__WEBPACK_IMPORTED_MODULE_10__["default"], { ref: 'builder' }))));



  }}) || _class) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5820:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSelectorContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _EnvironmentSelector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5821);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1269);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(742);
var _class;






const defaultEnvironment = {
  id: null,
  name: 'No Environment' };let



EnvironmentSelectorContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class EnvironmentSelectorContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleEnvironmentSelect = this.handleEnvironmentSelect.bind(this);
  }

  getSelectorEnvironmentList(environmentsList) {
    const environments = _.chain(environmentsList).
    filter(environment => !environment.team).
    sortBy(environment => environment.name.toLowerCase()).
    value();

    environments.unshift(defaultEnvironment);

    return environments;
  }

  /**
     * Selecting an env from the dropdown will call this. this will update Environment Store
     */
  handleEnvironmentSelect(environment) {
    const activeWorkspaceSessionId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceSessionStore').id;

    // DispatchUserAction to update the particular environment id
    Object(_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_4__["default"])(Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_5__["createEvent"])(
    'setActiveEnvironment',
    'workspacesession',
    {
      workspaceSession: { id: activeWorkspaceSessionId },
      activeEnvironment: environment }));


  }

  render() {
    const selectorEnvironmentList = this.getSelectorEnvironmentList(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').environments),
    selectedEnvironment = _.find(selectorEnvironmentList, environment => environment.id === Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveEnvironmentStore').id) || defaultEnvironment;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentSelector__WEBPACK_IMPORTED_MODULE_2__["default"], {
        environmentsList: selectorEnvironmentList,
        ref: 'selector',
        selectedEnvironment: selectedEnvironment,
        selectorWidth: this.props.selectorWidth,
        onSelect: this.handleEnvironmentSelect }));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5821:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSelector; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _js_components_base_InputSelectV2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2543);
/* harmony import */ var _js_components_base_SearchHighlighter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2506);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1789);
/* harmony import */ var _EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4754);





let

EnvironmentSelector = class EnvironmentSelector extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleEnvironmentSelect = this.handleEnvironmentSelect.bind(this);
  }

  getOption(item, search, option = {}) {
    const { name, id } = item,
    shouldHighlight = search && !option.firstRender;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: id },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'item-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'item-label' },

            shouldHighlight ?
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_SearchHighlighter__WEBPACK_IMPORTED_MODULE_3__["default"], {
              source: name,
              query: search }) :


            name),




          // Adding this check to prevent showing meta icons for `No Environment` option
          id !== null && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_5__["default"], { environmentId: item.id }))));




  }

  getSelectWrapperClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'environment-selector-wrapper': true });
  }

  handleEnvironmentSelect(environment) {
    pm.mediator.trigger('focusBuilder');
    this.props.onSelect && this.props.onSelect(environment.id);
  }

  filterEnvironments(environmentList, query, options = {}) {
    if (!query || options.firstRender) {
      return environmentList;
    }

    return _.filter(
    environmentList,
    environment => environment.id &&
    _.includes(environment.name.toLowerCase(), query.toLowerCase()));

  }

  render() {
    const { environmentsList, selectedEnvironment, selectorWidth } = this.props;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-selector-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getSelectWrapperClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_InputSelectV2__WEBPACK_IMPORTED_MODULE_2__["InputSelectV2"], {
            style: { width: selectorWidth },
            selectedItem: selectedEnvironment,
            getInputValue: environmentObj => environmentObj.name || '',
            optionRenderer: this.getOption,
            getFilteredList: this.filterEnvironments.bind(this, environmentsList),
            ref: 'inputSelect',
            onSelect: this.handleEnvironmentSelect,
            menuClassName: 'environment-selector-menu' }))));




  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5822:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentPreviewContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _EnvironmentPreview__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5823);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1768);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1793);
/* harmony import */ var _js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1269);
/* harmony import */ var _js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(764);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(742);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(748);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;











let


EnvironmentPreviewContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class EnvironmentPreviewContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      // This state is being maintained to pass it to the XPath.
      // The actual visibility of the container is controlled by the visibility of the dropdown.
      isOpen: false };


    this.handlePreviewClose = this.handlePreviewClose.bind(this);
    this.handlePreviewToggle = this.handlePreviewToggle.bind(this);
  }

  getIconClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'environment-preview-button': true,
      'is-open': this.state.isOpen });

  }

  getEnabled(varsList) {
    if (varsList.values) {
      // Environment
      const visibleValues = _.filter(varsList.values, value => _.get(value, 'enabled', true));

      return _extends({},
      varsList, {
        values: visibleValues });

    }

    return _.filter(varsList, value => _.get(value, 'enabled', true));
  }

  getMenu() {
    const environment = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveEnvironmentStore'),
    globals = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveGlobalsStore');

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], { 'align-right': true },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'previewList', isVisible: this.state.isOpen },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentPreview__WEBPACK_IMPORTED_MODULE_4__["default"], {
            selectedEnvironmentStore: environment,
            globalsStore: globals,
            onClose: this.handlePreviewClose,
            onHover: this.handleHover,
            onEnvironmentSessionUpdate: this.handleEnvironmentSessionUpdate,
            onGlobalsSessionUpdate: this.handleGlobalsSessionUpdate,
            hoveredKey: this.state.hoveredKey }))));




  }

  handlePreviewClose() {
    this.state.isOpen && this.setState({ isOpen: false });
    const dropdownRef = _.get(this.refs, 'dropdownRef.__wrappedInstance');

    dropdownRef && dropdownRef.toggleDropdown && dropdownRef.closeDropdown();
  }

  handlePreviewToggle(dropdownState) {
    this.setState({ isOpen: dropdownState });
  }

  handleEnvironmentSessionUpdate(zippedVariables) {
    const envSessionVariables = Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_9__["unzipVariables"])(zippedVariables).sessionVariables,
    envSessionUpdateEvent = Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_10__["createEvent"])('update', 'variablesession', {
      id: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveEnvironmentStore').session.id,
      model: 'environment',
      values: envSessionVariables });


    Object(_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_8__["default"])(envSessionUpdateEvent).
    then(() => {
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEvent('session', 'user_edit', 'environment');
    }).
    catch(err => {
      pm.logger.error('Error while updating session', err);
    });
  }

  handleGlobalsSessionUpdate(zippedVariables) {
    const globalsSessionVariables = Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_9__["unzipVariables"])(zippedVariables).sessionVariables,
    globalsSessionUpdateEvent = Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_10__["createEvent"])('update', 'variablesession', {
      id: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveGlobalsStore').session.id,
      model: 'globals',
      values: globalsSessionVariables });


    Object(_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_8__["default"])(globalsSessionUpdateEvent).
    then(() => {
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEvent('session', 'user_edit', 'globals');
    }).
    catch(err => {
      pm.logger.error('Error while updating session', err);
    });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], {
            className: 'environment-preview-dropdown',
            ref: 'dropdownRef',
            onToggle: this.handlePreviewToggle },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { dropdownStyle: 'nocaret' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                type: 'icon',
                className: this.getIconClasses(),
                tooltip: 'Environment quick look' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_3__["Icon"], { name: 'icon-action-view-stroke', className: 'environment-preview-icon pm-icon pm-icon-normal' }))),


          this.getMenu())));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5823:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentPreview; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _EnvironmentPreviewList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5824);
/* harmony import */ var _js_constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2110);
/* harmony import */ var _js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(764);
/* harmony import */ var _js_variables_VariableAlertWrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5501);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1789);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
var _class;






let


EnvironmentPreview = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class EnvironmentPreview extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleClose = this.handleClose.bind(this);
    this.handleGlobalEdit = this.handleGlobalEdit.bind(this);
    this.handleEnvironmentEdit = this.handleEnvironmentEdit.bind(this);
    this.handleEnvironmentAdd = this.handleEnvironmentAdd.bind(this);
  }

  handleClose() {
    this.props.onClose && this.props.onClose();
  }

  handleGlobalEdit() {
    this.handleClose();
    pm.mediator.trigger('showManageEnvironmentModal', _js_constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_3__["MANAGE_ENVIRONMENT_VIEW_GLOBALS"]);
  }

  handleEnvironmentEdit() {
    this.handleClose();
    pm.mediator.trigger('showManageEnvironmentModal', _.get(this.props.selectedEnvironmentStore, 'id'));
  }

  handleEnvironmentAdd() {
    this.handleClose();
    pm.mediator.trigger('showManageEnvironmentModal', _js_constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_3__["MANAGE_ENVIRONMENT_VIEW_ADD_ENV"]);
  }

  render() {
    const environmentValues = Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_4__["sanitizeZippedValues"])(this.props.selectedEnvironmentStore.enabledValues),
    globalValues = Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_4__["sanitizeZippedValues"])(this.props.globalsStore.enabledValues),
    envId = _.get(this.props.selectedEnvironmentStore, 'id'),
    canEditEnvironment = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore').can('edit', 'environment', envId);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'environment' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentPreviewList__WEBPACK_IMPORTED_MODULE_2__["default"], {
              title: _.get(this.props.selectedEnvironmentStore, 'name', 'Environment'),
              items: environmentValues,
              envId: envId,
              keyHeading: 'VARIABLE',
              valueHeading: 'INITIAL VALUE',
              sessionHeading: 'CURRENT VALUE',
              onHover: this.props.onHover,
              onEdit: this.handleEnvironmentEdit,
              onAdd: this.handleEnvironmentAdd,
              onUpdate: this.props.onEnvironmentSessionUpdate,
              emptyMessage: 'No active Environment',
              overriddenKeys: [],
              canEditEnvironment: canEditEnvironment })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-divider' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'globals' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentPreviewList__WEBPACK_IMPORTED_MODULE_2__["default"], {
              title: 'Globals',
              items: globalValues,
              keyHeading: 'VARIABLE',
              valueHeading: 'INITIAL VALUE',
              sessionHeading: 'CURRENT VALUE',
              onHover: this.props.onHover,
              onEdit: this.handleGlobalEdit,
              onUpdate: this.props.onGlobalsSessionUpdate,
              emptyMessage: 'No Globals available',
              overriddenKeys: _.map(environmentValues, 'key'),
              envId: 'globals' })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_variables_VariableAlertWrapper__WEBPACK_IMPORTED_MODULE_5__["default"], { onMessageLinkClick: this.handleClose }))));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5824:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentPreviewList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2451);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1875);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1789);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1222);
/* harmony import */ var _EnvironmentPreviewListItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5825);
/* harmony import */ var _EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4754);
/* harmony import */ var _js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1794);
var _class;












const MIN_ROW_HEIGHT = 32,
LIST_HEIGHT = 200,
LIST_WIDTH = 720,
OVERSCAN_COUNT = 5;

/**
                     * @to-do: Move this helper function to InlineInput component
                     *
                     * @param {Object} editStateFromInput - state of InlineInput
                     *
                     * @returns {String|undefined}
                     */
function getInputValueFromInputEditState(editStateFromInput) {
  if (!(editStateFromInput && editStateFromInput.inlineInput)) {
    return;
  }

  return editStateFromInput.inlineInput.value;
}let



EnvironmentPreviewList = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class EnvironmentPreviewList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.getItemSize = this.getItemSize.bind(this);
    this.observeSizeChange = this.observeSizeChange.bind(this);
    this.unobserveSizeChange = this.unobserveSizeChange.bind(this);
    this.setSession = this.setSession.bind(this);
    this.setEditCache = this.setEditCache.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.saveCachedValue = this.saveCachedValue.bind(this);

    // Height for list items currently mounted
    this.heightSet = {};

    // Last fetched session values from db without truncation
    this.session = {};

    this.resizeObserver = new ResizeObserver(entries => {
      for (const entry of entries) {// eslint-disable-line no-unused-vars
        if (!(entry && entry.target && entry.target.dataset)) {
          return;
        }

        const { index } = entry.target.dataset;

        this.heightSet[index] = entry.target.offsetHeight;
      }

      this.listRef.resetAfterIndex(0);
    });

    /**
         * Cache for item currently in edit mode
         *
         * @type {Object}
         * @property {Number} index - index of the list item in edit mode
         * @property {Object} listItem - cache of EnvironmentPreviewListItem state
         * @property {Object} inlineInput - cache of inlineInput state
         */
    this.editCache = null;
  }

  // If any item is in edit mode and not in view,
  // this will update the value in DB when Preview is closed
  componentWillUnmount() {
    this.saveCachedValue();
  }

  getItemSize(index) {
    return this.heightSet[index] || MIN_ROW_HEIGHT;
  }

  getListItem(data) {
    if (!data) {
      return null;
    }

    const { index } = data,
    item = data.data && data.data[index],
    isEditing = this.editCache && this.editCache.index === index; // Check if the current list item is in edit mode

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview__virtualized-item', style: data.style },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: index, key: `variable-${index}` },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentPreviewListItem__WEBPACK_IMPORTED_MODULE_8__["default"], {
            item: item,
            onSubmit: this.handleVariableSubmit.bind(this, index),
            index: index,
            title: this.props.title,
            observeSizeChange: this.observeSizeChange,
            unobserveSizeChange: this.unobserveSizeChange,
            overriddenKeys: this.props.overriddenKeys,
            onUpdate: this.props.onUpdate,
            envId: this.props.envId,
            items: this.props.items,
            setSession: this.setSession,
            setEditCache: this.setEditCache,
            editCache: isEditing && this.editCache }))));




  }

  getKeyMapHandlers() {
    return {
      quit: pm.shortcuts.handle('quit', this.setEditCache.bind(this, null)), // Discard changes
      select: pm.shortcuts.handle('select', this.saveCachedValue) // Save changes
    };
  }

  setEditCache(value) {
    this.editCache = value;
  }

  setSession(session) {
    this.session = session;
  }

  saveCachedValue() {
    if (!this.editCache) {
      return;
    }

    const indexToUpdate = this.editCache.index,
    valueToUpdate = getInputValueFromInputEditState(this.editCache.inlineInput);

    // Index can be 0, and value can be an empty string
    // both of which are falsy values, hence checking for `isNil` (null/undefined)
    if (_.isNil(indexToUpdate) || _.isNil(valueToUpdate)) {
      return;
    }

    this.handleVariableSubmit(indexToUpdate, valueToUpdate);

    // Clear the editCache after updating the value in DB
    this.setEditCache(null);
  }

  handleClickOutside(e) {
    const targetClassName = e && e.target && e.target.className,
    isFromInput = targetClassName === 'input input-box inline-input';

    if (!isFromInput && this.editCache) {
      this.saveCachedValue();

      // Stop the propagation to children elements, as this click is supposed to save the item
      // currently in edit mode. Also `handleVariableSubmit` will trigger a re-render.
      e && e.stopPropagation();
    }
  }

  handleVariableSubmit(variableIndex, newValue) {
    const zippedVariable = this.props.items[variableIndex],
    { sessionIndex } = zippedVariable,
    updatedItems = _.clone(this.session.values),
    updatedItem = sessionIndex !== -1 && updatedItems[sessionIndex],
    indexInCompleteList = updatedItem && _.findIndex(updatedItems, item => item === updatedItem);


    // If session values does not exist, copy it from the variable value
    // Otherwise just update the session value
    if (sessionIndex === -1) {
      updatedItems.push({
        key: zippedVariable.key,
        value: newValue,
        enabled: true });

    } else {
      updatedItems[indexInCompleteList].sessionValue = newValue;
    }

    this.props.onUpdate(updatedItems);
  }

  handleGlobalDocs() {
    Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__["GLOBAL_VARIABLE_DOCS"]);
  }

  handleEnvironmentDocs() {
    Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__["ENVIRONMENT_DOCS"]);
  }

  observeSizeChange(node) {
    this.resizeObserver && this.resizeObserver.observe(node);
  }

  unobserveSizeChange(node) {
    this.resizeObserver && this.resizeObserver.unobserve(node);
  }

  render() {
    const { items } = this.props,
    noEnvSelected = !this.props.envId,
    isGlobals = this.props.title === 'Globals',
    metaActionTooltip = !noEnvSelected && !isGlobals && !this.props.canEditEnvironment ?
    'Your role on this environment is restricted to modifying the current value of variables.' :
    null;

    let { title } = this.props;

    if (noEnvSelected) {
      title = 'Environment';
    }

    const lister = data =>
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_1__["Observer"], null,
      this.getListItem.bind(this, data));



    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_10__["default"], {
          keyMap: pm.shortcuts.getShortcuts(),
          handlers: this.getKeyMapHandlers() },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-selected' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-header__meta' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-header__meta__title__wrapper' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'environment-header__meta__title' }, title),

                !noEnvSelected && !isGlobals &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_9__["default"], { environmentId: this.props.envId })),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                  className: 'environment-header__meta__actions--edit',
                  type: 'text',
                  onClick: !noEnvSelected ? this.props.onEdit : this.props.onAdd,
                  disabled: !noEnvSelected && !isGlobals && !this.props.canEditEnvironment,
                  tooltip: metaActionTooltip,
                  tooltipPlacement: 'left' },

                !noEnvSelected ? 'Edit' : 'Add'))),




          !isGlobals && items.length === 0 &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item--no-environment' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item--no-environment-header' }, !noEnvSelected ? 'No Environment variables' : this.props.emptyMessage),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item--no-environment-text' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, 'An environment is a set of variables that allow you to switch the context of your requests.'),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                  className: 'learn-more',
                  type: 'text',
                  onClick: this.handleEnvironmentDocs }, 'Learn more about environments'))),








          isGlobals && !noEnvSelected && items.length === 0 &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item--empty-globals' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item--empty-globals-header' }, 'No global variables'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item--empty-globals-text' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, 'Global variables are a set of variables that are always available in a workspace. '),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                  className: 'learn-more-link',
                  type: 'text',
                  onClick: this.handleGlobalDocs }, 'Learn more about globals'))),








          !noEnvSelected && items.length !== 0 &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {

              // Using `onClickCapture` instead of `onClick` to prevent propagation in cases of some item
              // already being in edit mode, and using the click to just save the item
              onClickCapture: this.handleClickOutside,
              className: 'environment-preview-list' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-header' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'environment-preview-list-header__key' }, this.props.keyHeading),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'environment-preview-list-header__value' }, this.props.valueHeading),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'environment-preview-list-header__session-value' }, this.props.sessionHeading)),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-divider' }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_window__WEBPACK_IMPORTED_MODULE_2__["VariableSizeList"], {
                height: LIST_HEIGHT,
                itemCount: items.length,
                itemSize: this.getItemSize,
                width: LIST_WIDTH,
                ref: ref => {this.listRef = ref;},
                overscanCount: OVERSCAN_COUNT,
                itemData: items,
                className: 'environment-preview-virtualized-list' },

              lister)))));








  }}) || _class) || _class;


EnvironmentPreviewList.defaultProps = { items: [] };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5825:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentPreviewListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1881);
/* harmony import */ var _js_components_base_Icons_EditIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1874);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(764);
/* harmony import */ var _js_modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1714);
/* harmony import */ var _js_constants_VariablesConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2884);
/* harmony import */ var _js_components_base_WarningButton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2512);











const truncateOptions = { length: _js_constants_VariablesConstants__WEBPACK_IMPORTED_MODULE_8__["VARIABLE_VALUE_MAX_LENGTH"], separator: ' ' },
DELETED_VALUE_PLACEHOLDER = '[Deleted]';let

EnvironmentPreviewListItem = class EnvironmentPreviewListItem extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);

    this.state = {
      isHovered: false,
      sessionValue: null, // Sanitized value without any truncation
      isEditing: false // For display the entire value without truncation
    };

    this.getClasses = this.getClasses.bind(this);
    this.handleEditVariable = this.handleEditVariable.bind(this);
    this.handleVariableToggle = this.handleVariableToggle.bind(this);
    this.handleMouseEnter = this.handleMouseEnter.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
  }

  componentDidMount() {
    this.selfNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    // Starts observing element
    this.props.observeSizeChange && this.props.observeSizeChange(this.selfNode);

    // If the list item was in edit state, restore its state
    if (this.props.editCache && this.inlineInput) {
      // eslint-disable-next-line react/no-did-mount-set-state
      this.setState(this.props.editCache.listItem, () => {
        this.inlineInput.setEditState(this.props.editCache.inlineInput);
      });
    }
  }

  componentWillUnmount() {
    this.props.unobserveSizeChange && this.props.unobserveSizeChange(this.selfNode, this.props.index);

    // If the list item is in its edit state, cache the internal state
    if (this.state.isEditing && this.inlineInput) {
      this.props.setEditCache({
        inlineInput: this.inlineInput.getEditState(),
        index: this.props.index,
        listItem: this.state });

    }
  }

  getClasses(item) {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'environment-preview-list-item': true,
      'globals-preview-list-item': this.props.title === 'Globals',
      'is-hovered': this.state.isHovered,
      'is-overridden': _.includes(this.props.overriddenKeys, item.key),
      'is-session-value-deleted': this.props.item.isSessionValueDeleted });

  }

  handleMouseEnter() {
    this.setState({ isHovered: true });
  }

  handleMouseLeave() {
    this.setState({ isHovered: false });
  }

  handleVariableToggle(isEditing) {
    const { inlineInput } = this;

    if (isEditing && inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    } else {
      this.setState({ isEditing: false });
      this.props.setEditCache(null);
    }
  }

  handleEditVariable() {
    const { index } = this.props,
    activeEnvironmentId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveEnvironmentStore').id,
    activeWorkspaceId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').id,
    activeGlobalsId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveGlobalsStore').id;

    let model,
    modelId;

    if (this.props.envId === 'globals') {
      model = 'globals';
      modelId = activeGlobalsId;
    } else {
      model = 'environment';
      modelId = activeEnvironmentId;
    }

    const sessionId = Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])(model, modelId, activeWorkspaceId);

    Object(_js_modules_services_VariableSessionService__WEBPACK_IMPORTED_MODULE_7__["getSessionFor"])(sessionId).
    then(session => {
      if (!session) {
        return;
      }

      const items = Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["sanitizeZippedValues"])(Object(_js_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["zipVariables"])(this.props.items, session.values));

      this.setState({ sessionValue: items[index].sessionValue, isEditing: true }, () => {
        const input = this.inlineInput;

        input && input.startEditing();
        this.props.setSession(session);
      });
    }).
    catch(err => {
      pm.logger.warn('Failed to get session in environment preview', err);
      pm.toasts.error('Something went wrong. Please check DevTools.');
    });
  }

  render() {
    const { isSessionValueDeleted } = this.props.item,
    itemSessionValue = this.props.item.sessionValue;

    let value;

    if (this.state.isEditing) {
      value = this.state.sessionValue;
    } else {
      value = isSessionValueDeleted ? DELETED_VALUE_PLACEHOLDER : _.truncate(itemSessionValue, truncateOptions);
    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          onMouseEnter: this.handleMouseEnter,
          onMouseLeave: this.handleMouseLeave,
          className: this.getClasses(this.props.item),
          'data-index': this.props.index },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'environment-preview-list-item__key' }, this.props.item.key),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'environment-preview-list-item__value' }, this.props.item.value),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-preview-list-item__session-value' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_3__["default"], {
            className: 'collection-browser-details-header__name',
            placeholder: isSessionValueDeleted ? DELETED_VALUE_PLACEHOLDER : itemSessionValue,
            value: value,
            onSubmit: this.props.onSubmit,
            onToggleEdit: this.handleVariableToggle,
            ref: ref => {this.inlineInput = ref;},
            allowEmpty: true }),



          isSessionValueDeleted &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_WarningButton__WEBPACK_IMPORTED_MODULE_9__["default"], {
            tooltip: 'This variable does not exist in the active session. However, its presence in the environment will not be affected.',
            tooltipPlacement: 'bottom',
            showTooltipOnHover: true }),




          !this.state.isEditing &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
              className: 'environment-preview-list-item__session-value__edit-icon-wrapper',
              onClick: this.handleEditVariable },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_EditIcon__WEBPACK_IMPORTED_MODULE_4__["default"], {
              className: 'environment-preview-list-item__session-value__edit-icon',
              size: 'xs' })))));








  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5826:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentMenuContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _EnvironmentMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5827);
var _class;


let


EnvironmentMenuContainer = pure_render_decorator__WEBPACK_IMPORTED_MODULE_1___default()(_class = class EnvironmentMenuContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { isOpen: false };
    this.handleManageEnvironment = this.handleManageEnvironment.bind(this);
    this.handleShareEnvironment = this.handleShareEnvironment.bind(this);
  }

  getIconClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'environment-preview-button': true,
      'is-open': this.state.isOpen });

  }

  handleManageEnvironment() {
    pm.mediator.trigger('showManageEnvironmentModal', 'Manage');
  }

  handleShareEnvironment() {
    pm.mediator.trigger('showManageEnvironmentModal', 'Templates');
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'environment-menu-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentMenu__WEBPACK_IMPORTED_MODULE_3__["default"], {
          onManageEnvironments: this.handleManageEnvironment,
          onShareEnvironments: this.handleShareEnvironment })));



  }}) || _class;

/***/ }),

/***/ 5827:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
var _class;



let


EnvironmentMenu = pure_render_decorator__WEBPACK_IMPORTED_MODULE_1___default()(_class = class EnvironmentMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleEnvironmentManage = this.handleEnvironmentManage.bind(this);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'environment-menu': true,
      'is-open': this.props.isOpen });

  }

  handleEnvironmentManage() {
    this.props.onManageEnvironments && this.props.onManageEnvironments();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
            className: 'environment-menu-button',
            tooltip: 'Manage Environments',
            onClick: this.handleEnvironmentManage },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_3__["Icon"], { name: 'icon-descriptive-manage-stroke', className: 'environment-menu-icon pm-icon pm-icon-normal' }))));



  }}) || _class;

/***/ }),

/***/ 5828:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabTitles; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _TabTitle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5829);
/* harmony import */ var _NewTabAction__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5831);
/* harmony import */ var _TabActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5832);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1545);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1789);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__);
var _class;








let


TabTitles = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class TabTitles extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleReorder = this.handleReorder.bind(this);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollLeft = this.handleScrollLeft.bind(this);
    this.handleScrollRight = this.handleScrollRight.bind(this);
    this.attachResizeObserver = this.attachResizeObserver.bind(this);
    this.removeResizeObserver = this.removeResizeObserver.bind(this);
    this.checkNavButtonVisibility = this.checkNavButtonVisibility.bind(this);
    this.debouncedCheckNavButtonVisibility = _.debounce(this.checkNavButtonVisibility.bind(this), 100);
    this.showNavigationButtons = false;

    this.resizeObserver = new ResizeObserver(this.debouncedCheckNavButtonVisibility);
  }


  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'requester-tabs': true,
      [`is-scrolling-${this.props.tabScrollDirection}`]: true });

  }

  handleReorder(sourceId, destinationId, position) {
    if (!destinationId || !position) {
      return;
    }

    let destination = { [position]: destinationId };

    _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].moveEditor(sourceId, destination);
  }

  handleScroll(e) {
    let node = this.refs.tabs;
    e.deltaY && (node.scrollLeft += e.deltaY);
  }

  // Handle case when 'Scroll Left' button is clicked
  handleScrollLeft(e) {
    let node = this.refs.tabs;
    if (node.scrollLeft > 0) {
      node.scrollLeft -= node.clientWidth;
    }
  }

  // Handle case when 'Scroll Right' button is clicked
  handleScrollRight(e) {
    let node = this.refs.tabs;
    if (node.scrollWidth > node.scrollLeft + node.clientWidth) {
      node.scrollLeft += node.clientWidth;
    }
  }

  // Attach resize observer that observes for changes in tabs titles wrapper
  attachResizeObserver(e) {
    let tabsWrapper = this.refs.tabsWrapper;

    this.resizeObserver.observe(tabsWrapper);
  }

  removeResizeObserver(e) {
    this.resizeObserver.disconnect();
  }

  // Checks if there is need to show the scroll buttons in the tab titles wrapper and triggers a
  // re-render if there is need to change the state of the scroll buttons (i.e. hide->show, show->hide)
  checkNavButtonVisibility() {
    let tabsNode = this.refs.tabs,
    shouldShowNavButtons;

    // If no tabs are open we do not show the scroll buttons. This is a specific case where our check
    // that scrollWidth > clientWidth fails even though no tabs are open. Here, the clientWidth is 0 as
    // expected. But the scrollWidth is greater than 0 because it also takes into account the width of pseudo-elements
    // ::before and ::after (Link to documentation - https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollWidth).
    // Thus, our condition fails and the buttons are shown. So we handle this case separately.
    if (tabsNode.children.length === 0) {
      shouldShowNavButtons = false;
    }

    // If the navigation buttons are already shown, the width of the buttons decreases the width of the wrapper itself.
    // So we also have to account for those when checking the condition.
    else if (this.showNavigationButtons) {
        this.scrollLeftButtonWidth = this.scrollLeftButtonWidth || this.refs.scrollLeft.clientWidth;
        this.scrollRightButtonWidth = this.scrollRightButtonWidth || this.refs.scrollRight.clientWidth;

        shouldShowNavButtons = tabsNode.scrollWidth > tabsNode.clientWidth + this.scrollLeftButtonWidth + this.scrollRightButtonWidth;
      }

      // Default case where we just check if the scrollWidth is greater than the clientWidths
      else {
          shouldShowNavButtons = tabsNode.scrollWidth > tabsNode.clientWidth;
        }

    // show/hide navigation buttons only if previously hidden/visible respectively
    if (this.showNavigationButtons === !shouldShowNavButtons) {
      // toggle navigation buttons visibility
      this.showNavigationButtons = shouldShowNavButtons;
      this.forceUpdate();
    }
  }

  componentDidMount() {
    this.attachResizeObserver();
  }

  componentDidUpdate() {
    this.checkNavButtonVisibility();
  }

  componentWillUnmount() {
    this.removeResizeObserver();
  }

  render() {
    let TabUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('TabUIStore'),
    activeTab = TabUIStore.activeTab;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tabs-wrapper', onWheel: this.handleScroll, ref: 'tabsWrapper' },

        this.showNavigationButtons &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-nav-btn-wrapper', ref: 'scrollLeft', onClick: this.handleScrollLeft },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-direction-back', className: 'requester-tab-nav-previous-icon pm-icon pm-icon-normal', size: 'large' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses(), ref: 'tabs' },

          _.map(TabUIStore.tabHeaders, (tab, index) => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: `${tab.id}/tab`, key: tab.id },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TabTitle__WEBPACK_IMPORTED_MODULE_4__["default"], {
                  tab: tab,
                  onReorder: this.handleReorder,
                  isLastVisibleTab: index === _.size(TabUIStore.tabHeaders) - 1,
                  isActive: activeTab === tab.id })));



          })),



        this.showNavigationButtons &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-nav-btn-wrapper', ref: 'scrollRight', onClick: this.handleScrollRight },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-direction-forward', className: 'requester-tab-nav-next-icon pm-icon pm-icon-normal', size: 'large' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-actions' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'addNewTab' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NewTabAction__WEBPACK_IMPORTED_MODULE_5__["default"], null)),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tabs-options-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'tabActions' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TabActions__WEBPACK_IMPORTED_MODULE_6__["default"], null))))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5829:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CONFLICT_STATES_MAP", function() { return CONFLICT_STATES_MAP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CONFLICT", function() { return CONFLICT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabTitle; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2136);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1883);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1545);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1769);
/* harmony import */ var _base_Icons_TabIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5830);
var _dec, _dec2, _class;










const CONFLICT_STATES_MAP = {
  updated: 'CONFLICT',
  deleted: 'DELETED' },

CONFLICT = 'CONFLICT';

const EDITOR_NAME_LENGTH = 24;

const getMiddleX = component => {
  const elementRect = Object(react_dom__WEBPACK_IMPORTED_MODULE_3__["findDOMNode"])(component).getBoundingClientRect();
  return elementRect.left + elementRect.width / 2;
};


const tabSource = {
  canDrag(props, monitor) {
    return !props.only;
  },

  beginDrag(props) {
    return { id: props.tab.id };
  },

  endDrag(props, monitor) {
    const dragId = monitor.getItem().id;
    const { dropId, position } = monitor.getDropResult() || {};

    if (dragId === dropId) {
      return;
    }

    props.onReorder(dragId, dropId, position);
  } };


const tabTarget = {
  hover(props, monitor, component) {
    const dragId = monitor.getItem().id;
    const dropId = props.tab.id;
    if (dragId === dropId) {
      return;
    }

    if (!props.isLastVisibleTab) {
      component.getDecoratedComponentInstance().scheduleHoverUpdate();
      return;
    }

    if (monitor.getClientOffset().x > getMiddleX(component)) {
      component.getDecoratedComponentInstance().scheduleHoverUpdate('after');
    } else
    {
      component.getDecoratedComponentInstance().scheduleHoverUpdate();
    }

  },
  drop(props, monitor, component) {
    if (!props.isLastVisibleTab) {
      return {
        dropId: props.tab.id,
        position: 'before' };

    }
    return {
      dropId: props.tab.id,
      position: monitor.getClientOffset().x > getMiddleX(component) ? 'after' : 'before' };

  } };let


















TabTitle = (_dec = Object(react_dnd__WEBPACK_IMPORTED_MODULE_2__["DropTarget"])('requester-tab', tabTarget, (connect, monitor) => {return { connectDropTarget: connect.dropTarget(), isDragOver: monitor.isOver({ shallow: true }), canDrop: monitor.canDrop() };}), _dec2 = Object(react_dnd__WEBPACK_IMPORTED_MODULE_2__["DragSource"])('requester-tab', tabSource, (connect, monitor) => {return { connectDragSource: connect.dragSource(), connectDragPreview: connect.dragPreview(), isDragging: monitor.isDragging() };}), _dec(_class = _dec2(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class TabTitle extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleCloseTab = this.handleCloseTab.bind(this);
    this.handleDoubleClick = this.handleDoubleClick.bind(this);
    this.handleFocus = this.handleFocus.bind(this);
    this.setDropHoverLeft = this.setDropHoverLeft.bind(this);
    this.setDropHoverRight = this.setDropHoverRight.bind(this);
    this.scheduleHoverUpdate = this.scheduleHoverUpdate.bind(this);
    this.handleMouseUp = this.handleMouseUp.bind(this);

    this.showConflictTooltip = this.showConflictTooltip.bind(this);
    this.hideConflictTooltip = this.hideConflictTooltip.bind(this);

    this.state = { showConflictMessage: false };
  }

  getClasses() {
    let tabStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('TabUIStore'),
    tabId = this.props.tab.id,
    isActive = tabStore.activeTab === tabId,
    isPreview = tabStore.previewTab === tabId;

    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'requester-tab': true,
      'is-active': isActive,
      'is-preview': isPreview,
      'is-dragged': this.props.isDragging,
      'is-hover-left': this.state.dropHoverLeft,
      'is-hover-right': this.state.dropHoverRight,
      'is-drop-hovered': this.props.canDrop && this.props.isDragOver });

  }

  componentDidMount() {
    this.scrollActiveTabInView();
  }

  componentDidUpdate(prevProps) {
    // Scroll active tab into view if not in view and not previously active
    if (this.props.isActive && (!prevProps.isActive || this.props.tab.resourceId !== prevProps.tab.resourceId)) {
      this.scrollActiveTabInView();
    }
  }

  scrollActiveTabInView() {
    this.refs.tabTitle && this.refs.tabTitle.scrollIntoViewIfNeeded(true);
  }

  showConflictTooltip() {
    !this.state.showConflictMessage && this.setState({ showConflictMessage: true });
  }

  hideConflictTooltip() {
    this.state.showConflictMessage && this.setState({ showConflictMessage: false });
  }

  getCloseButtonClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'requester-tab__close': true,
      'is-dirty': this.props.tab.isDirty });

  }

  handleDoubleClick() {
    this.props.tab.isPreview &&
    _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].promoteEditor({ id: this.props.tab.id });
  }

  handleCloseTab(event) {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].close({ id: this.props.tab.id });
    event.stopPropagation();
  }

  handleFocus() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].focus({ id: this.props.tab.id });
  }

  scheduleHoverUpdate(type) {
    let func = this.setDropHoverLeft;
    if (type === 'after') {
      func = this.setDropHoverRight;
    }
    if (!this.requestedFrame) {
      this.requestedFrame = requestAnimationFrame(() => {
        try {
          func && func();
        }
        catch (e) {
        } finally
        {
          this.requestedFrame = null;
        }
      });
    }
  }

  setDropHoverLeft() {
    !this.state.dropHoverLeft &&
    this.setState({
      dropHoverLeft: true,
      dropHoverRight: false });

  }

  setDropHoverRight() {
    !this.state.dropHoverRight &&
    this.setState({
      dropHoverLeft: false,
      dropHoverRight: true });

  }

  handleMouseUp(e) {
    // middle click
    if (e.nativeEvent.which === 2) {
      _services_EditorService__WEBPACK_IMPORTED_MODULE_7__["default"].close({ id: this.props.tab.id });
      return;
    }
  }


  render() {
    const {
      connectDragSource,
      connectDropTarget,
      connectDragPreview } =
    this.props;

    let tab = this.props.tab,
    editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('EditorStore').find(tab.id),
    tabUiStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('TabUIStore'),
    iconIdentifier,
    Icon,
    showIcons,
    tabName;

    if (!editor) {
      return null;
    }

    // if setting for showIcons is switched to true,
    // then find the icon
    showIcons = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ConfigurationStore') && Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ConfigurationStore').get('editor.showIcons');
    iconIdentifier = showIcons && editor.model && editor.model.getIcon();
    Icon = _base_Icons_TabIcon__WEBPACK_IMPORTED_MODULE_9__["default"],
    tabName = tab.name;

    return connectDropTarget(connectDragPreview(connectDragSource(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
        className: this.getClasses(),
        'data-tab-id': tab.id,
        onClick: this.handleFocus,
        onDoubleClick: this.handleDoubleClick,
        onMouseUp: this.handleMouseUp,
        onMouseEnter: this.showConflictTooltip,
        onMouseLeave: this.hideConflictTooltip },

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-title-wrapper', ref: 'tabTitle' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-title__text-wrapper' },
          tab.isConflicted &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab__conflict-message-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                className: 'requester-tab__conflict-message',
                ref: 'conflictMessage' },


              `[${_.toUpper(CONFLICT_STATES_MAP[tab.conflictState.type]) || CONFLICT}] `),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_8__["Tooltip"], {
                show: this.state.showConflictMessage,
                target: this.refs.conflictMessage,
                placement: 'bottom-right' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_8__["TooltipHeader"], null,
                _.truncate(tab.name, { length: EDITOR_NAME_LENGTH })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_8__["TooltipBody"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, ' ', _.toUpper(CONFLICT_STATES_MAP[tab.conflictState.type]) || CONFLICT, ' '),
                tab.conflictState.message))),





          showIcons &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab__icon' },

            iconIdentifier && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Icon, { iconIdentifier: iconIdentifier })),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab__name', title: tabName },

            tabName)),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: this.getCloseButtonClasses(),
            onClick: this.handleCloseTab },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_6__["default"], {
            className: 'requester-tab__close-icon',
            size: 'xs' })))))));





  }}) || _class) || _class) || _class);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5830:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _request_RequestIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4863);
/* harmony import */ var _BootcampIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2931);
/* harmony import */ var _ResponseIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5660);
/* harmony import */ var _constants_iconIdentifiers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2909);
/* harmony import */ var _constants_iconIdentifiers__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_constants_iconIdentifiers__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__);







const REQUEST_ICON = 'RequestIcon',
iconMap = {
  [_constants_iconIdentifiers__WEBPACK_IMPORTED_MODULE_4__["BOOTCAMP_ICON"]]: _BootcampIcon__WEBPACK_IMPORTED_MODULE_2__["default"],
  [_constants_iconIdentifiers__WEBPACK_IMPORTED_MODULE_4__["RELEASE_NOTES_ICON"]]: () => react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-release-notes' }),
  [_constants_iconIdentifiers__WEBPACK_IMPORTED_MODULE_4__["RESPONSE_ICON"]]: _ResponseIcon__WEBPACK_IMPORTED_MODULE_3__["default"] };let


TabIcon = class TabIcon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  isRequest(iconIdentifier) {
    return iconIdentifier && iconIdentifier.startsWith(REQUEST_ICON);
  }

  // We append the request method to the end of the identifier to uniquely identify the icon
  // for the request. This is done because we do not have unique icon components for each request method.
  // Instead we use the method name as text input to a generic icon component which then gives us the icon
  // This is a hack implemented for now. This can be removed when we have unique identifiers for each
  // icon in the app.
  getRequestIcon(iconIdentifier) {
    if (!iconIdentifier || !this.isRequest(iconIdentifier)) {
      return null;
    }

    let method = iconIdentifier.split('-')[1];
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_request_RequestIcon__WEBPACK_IMPORTED_MODULE_1__["default"], { method: method });
  }

  render() {
    let iconIdentifier = this.props.iconIdentifier;

    if (!iconIdentifier) {
      return null;
    }

    // Special handling for the case when the identifier represents a request icon
    if (this.isRequest(iconIdentifier)) {
      return this.getRequestIcon(iconIdentifier);
    }

    let Icon = iconMap[iconIdentifier];
    return Icon ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Icon, null) : null;
  }};

/***/ }),

/***/ 5831:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NewTab; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1545);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_2__);


let

NewTab = class NewTab extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    _services_EditorService__WEBPACK_IMPORTED_MODULE_1__["default"].openDefault();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-create', onClick: this.handleClick },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
          name: 'icon-action-add-stroke',
          className: 'requester-tab-create-icon pm-icon pm-icon-normal' })));



  }};

/***/ }),

/***/ 5832:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterTabOptions; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4285);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(748);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1545);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(749);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2467);
/* harmony import */ var _TabTitle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5829);
/* harmony import */ var _RecentlyClosedTabs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5833);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_12__);
var _class;













const DISABLED_ACTIONS_TEXT = 'Open a new tab to perform this action';let


RequesterTabOptions = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class RequesterTabOptions extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
    this.closeDropdown = this.closeDropdown.bind(this);
    this.getRecentlyClosedTabs = this.getRecentlyClosedTabs.bind(this);
  }

  handleClick() {
    this.props.onClick && this.props.onClick();
  }

  handleSelect(item, editorId) {
    switch (item) {
      case 'duplicate':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].duplicate();
        break;
      case 'close-active':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].closeCurrent();
        break;
      case 'force-close-active':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].closeCurrent({ force: true });
        break;
      case 'close-other':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].closeAllButCurrent();
        break;
      case 'close-all':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].closeAll();
        break;
      case 'force-close-all':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].requestForceCloseAll();
        break;
      case 'undo-close':
        if (!editorId) {
          return;
        }

        _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].undoClose(editorId);
        break;}

  }

  getRecentlyClosedTabs() {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RecentlyClosedTabs__WEBPACK_IMPORTED_MODULE_11__["default"], { onSelect: this.handleSelect });
  }

  closeDropdown() {
    _.invoke(this.refs, 'dropdown.__wrappedComponent.toggleDropdown', null, false);
  }

  render() {

    let subMenuForRecentlyClosed = this.getRecentlyClosedTabs(),
    visibleEditors = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('ActiveWorkspaceSessionStore').visibleEditors,
    areMenuActionsDisabled = _.isEmpty(visibleEditors);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
          ref: 'dropdown',
          className: 'tab-actions-dropdown',
          onSelect: this.handleSelect,
          onToggle: this.props.onToggle },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], {
            dropdownStyle: 'nocaret',
            type: 'custom' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"], className: 'requester-tab-options', onClick: this.handleClick }, ' ',
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_12__["Icon"], { name: 'icon-action-options-stroke', className: 'requester-tab-options-icon pm-icon pm-icon-normal' }))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], { 'align-right': true },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'undo-close', hasSubMenu: true },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'undoClosed' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Recently Closed')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["SubMenuItem"], { onSelect: this.handleSelect },

              subMenuForRecentlyClosed)),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
              refKey: 'duplicate',
              disabled: areMenuActionsDisabled,
              disabledText: DISABLED_ACTIONS_TEXT },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'duplicate' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Duplicate Current Tab'))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider divider--space' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
              refKey: 'close-active',
              disabled: areMenuActionsDisabled,
              disabledText: DISABLED_ACTIONS_TEXT },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'closeCurrentTab' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Close Current Tab'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__["getShortcutByName"])('closeCurrentTab')))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
              refKey: 'force-close-active',
              disabled: areMenuActionsDisabled,
              disabledText: DISABLED_ACTIONS_TEXT },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'forceCloseCurrentTab' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Force Close Current Tab'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__["getShortcutByName"])('forceCloseCurrentTab')))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
              refKey: 'close-other',
              disabled: areMenuActionsDisabled,
              disabledText: DISABLED_ACTIONS_TEXT },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'closeOtherTabs' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Close All but Current Tab'))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
              refKey: 'close-all',
              disabled: areMenuActionsDisabled,
              disabledText: DISABLED_ACTIONS_TEXT },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'closeAllTabs' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Close All Tabs'))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
              refKey: 'force-close-all',
              disabled: areMenuActionsDisabled,
              disabledText: DISABLED_ACTIONS_TEXT },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'forceCloseAllTabs' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-options__label' }, 'Force Close All Tabs'))))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5833:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RecentlyClosedTabs; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1793);
/* harmony import */ var _services_ActiveWorkspaceSessionService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5834);
/* harmony import */ var _base_Icons_TabIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5830);
var _class;






const FALLBACK_TITLE = 'Untitled';let


RecentlyClosedTabs = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class RecentlyClosedTabs extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getEmptyStateForRecentlyClosed() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], { disabled: true },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab__name' }, 'None')));





  }

  componentDidMount() {
    // This function performs the migration flow for the fix for APPSDK-539.  We added a new
    // key 'closedEditorMeta' in the workspace session in the DB to maintain a cache of the closed tabs
    // in the workspace. When a user updates their app, initially this key won't be present for them.
    // So, this migration flow is needed which will populate the cache the first time. This won't
    // have any effect once the cache has been populated.
    _services_ActiveWorkspaceSessionService__WEBPACK_IMPORTED_MODULE_4__["default"].createClosedEditorsCache(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceSessionStore'));
  }

  render() {
    let ActiveWorkspaceSessionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceSessionStore'),
    closedEditors = ActiveWorkspaceSessionStore.closedEditors || [],
    closedEditorsMeta = ActiveWorkspaceSessionStore.closedEditorsMeta || {};

    if (_.isEmpty(closedEditors)) {
      return this.getEmptyStateForRecentlyClosed();
    }

    return _.chain(closedEditors).
    map(id => {
      if (!id) {
        return;
      }

      let configStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ConfigurationStore'),
      showIcons = configStore && configStore.get('editor.showIcons'),
      Icon,
      iconIdentifier,
      name;

      if (!closedEditorsMeta[id]) {
        Icon = null;
        name = FALLBACK_TITLE;
      } else
      {
        Icon = showIcons && _base_Icons_TabIcon__WEBPACK_IMPORTED_MODULE_5__["default"],
        iconIdentifier = closedEditorsMeta[id].icon,
        name = closedEditorsMeta[id].name;
      }

      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], { refKey: id, key: id, onSelect: this.props.onSelect },

          Icon &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab__icon' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Icon, { iconIdentifier: iconIdentifier })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { title: name },

            name)));



    }).
    compact().
    value();
  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5834:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(751);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1269);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(742);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};





// Set of workspace ids for which the closedEditorsCached has already been populated.
const cachedWorkspacesSet = new Set(),
EDITOR_LOADING_TIMEOUT = 5000;

var ActiveWorkspaceSessionService = {

  /**
                                       * This function performs the migration flow for the fix for APPSDK-539. We added a new
                                       * key 'closedEditorMeta' in the workspace session in the DB to maintain a cache of the closed tabs
                                       * in the workspace. When a user updates their app, initially this key won't be present for them.
                                       * So, this migration flow is needed which will populate the cache the first time. This won't
                                       * have any effect once the cache has been populated.
                                       *
                                       * @param {Object} workspaceSession
                                       */
  createClosedEditorsCache(workspaceSession) {
    if (!workspaceSession || cachedWorkspacesSet.has(workspaceSession.id)) {
      return;
    }

    // Add the workspace id to the list of cached workspace ids
    cachedWorkspacesSet.add(workspaceSession.id);

    // If the workspace already has the cache, we bail out
    if (workspaceSession.closedEditorsMeta) {
      return;
    }

    // Analytics event to help us know how many times the migration flow for creating the closed editors
    // cache is fired. Over time if this gets lower, we can get rid of the migration flow.
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEventV2({
      category: 'workspace_session',
      action: 'migrated_recently_closed_tabs_list' });


    pm.logger.info('ActiveWorkspaceSessionService~createClosedEditorsCache: Closed editors cache not present. Creating for workspace session.');

    let closedEditorIds = workspaceSession.closedEditors || [],
    editorsData = workspaceSession.editorsData || {},
    closedEditorsMeta = {},
    closedEditors = _.map(closedEditorIds, editorId => {
      return _extends({
        id: editorId },
      editorsData[editorId]);

    });


    if (!closedEditors) {
      return Promise.reject(new Error('Closed editors not present in workspace session'));
    }

    let pendingPromises = _.map(closedEditors, editorId => {
      return new Promise((resolve, reject) => {
        // We create an object representing the closed editor with the model loaded
        let editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('EditorStore').createItemStoreFromDefinition(editorId),
        disposer,
        timeoutId;

        // We set a timeout for the case when the reaction does not fire within the specified time
        // We dispose the reaction and then resolve the promise without any meta data for the editor id
        timeoutId = setTimeout(() => {
          disposer && disposer();
          resolve({ id: editorId });
        }, EDITOR_LOADING_TIMEOUT);

        // For each editor, we set up a reaction that fires when the model has been loaded into the tab
        disposer = Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => editor.lifecycle, lifecycle => {
          if (lifecycle === 'idle') {
            clearTimeout(timeoutId);
            disposer && disposer();

            resolve({
              id: editor.id,
              name: editor.model && editor.model.name,
              icon: editor.model && editor.model.getIcon(),
              timestamp: Date.now() });

          }
        });
      });
    });

    Promise.all(pendingPromises).
    then(closedEditorsData => {
      closedEditorsData.forEach(editorData => {
        closedEditorsMeta[editorData.id] = {
          name: editorData.name,
          icon: editorData.icon,
          timestamp: editorData.timestamp };

      });

      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_2__["createEvent"])('update', 'workspacesession', { id: workspaceSession.id, closedEditorsMeta }));
    }).
    catch(err => {
      // Analytics event to help us know how many times the migration flow for creating the closed editors
      // failed.
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEventV2({
        category: 'workspace_session',
        action: 'migration_failed_recently_closed_tabs_list' });


      pm.logger.warn('ActiveWorkspaceSessionService~createClosedEditorsCache: Error while creating cache', err);
    });
  } };


/* harmony default export */ __webpack_exports__["default"] = (ActiveWorkspaceSessionService);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5835:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabContents; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _TabContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5836);
/* harmony import */ var _TabContentEmptyShell__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5837);
var _class;



let


TabContents = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class TabContents extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

  constructor() {
    super(...arguments);
    this.focus = this.focus.bind(this);
  }

  componentDidMount() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('WorkspaceLifecycleStore').isSwitching) {
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('WorkspaceLifecycleStore').resetLifecycle(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceSessionStore').workspace);
    }
  }

  componentDidUpdate() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('WorkspaceLifecycleStore').isSwitching) {
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('WorkspaceLifecycleStore').resetLifecycle(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceSessionStore').workspace);
    }
  }

  focus() {
    let activeTabId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('TabUIStore').activeTab,
    tab = this.refs[activeTabId];

    tab && tab.focus();
  }

  getTabs() {
    let tabs = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('TabUIStore').tabContents,
    activeTab = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('TabUIStore').activeTab,
    EditorStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('EditorStore');

    if (!EditorStore) {
      return;
    }

    return _.chain(tabs).
    map(tab => {
      let editor = EditorStore.find(tab);

      if (!editor) {
        return;
      }

      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TabContent__WEBPACK_IMPORTED_MODULE_3__["default"], { key: tab, tabId: tab, isActive: activeTab === tab, ref: tab }));

    }).
    compact().
    value();
  }

  render() {
    let tabs = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('TabUIStore').tabContents;

    if (!tabs) {
      return null;
    }

    let tabsToBeRendered = this.getTabs();

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-tab-contents' },
        _.isEmpty(tabsToBeRendered) ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TabContentEmptyShell__WEBPACK_IMPORTED_MODULE_4__["default"], null) : tabsToBeRendered));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 5836:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabContent; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2083);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1545);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1789);
var _class;








let


TabContent = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class TabContent extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

  constructor() {
    super(...arguments);

    this.focus = this.focus.bind(this);
    this.closeTab = this.closeTab.bind(this);
    this.handleScrollToTop = this.handleScrollToTop.bind(this);
    this.handleScrollToBottom = this.handleScrollToBottom.bind(this);
  }

  componentDidMount() {
    pm.mediator.on('handleScrollToTopShortcut', this.handleScrollToTop);
    pm.mediator.on('handleScrollToBottomShortcut', this.handleScrollToBottom);
  }

  componentWillUnmount() {
    pm.mediator.off('handleScrollToTopShortcut', this.handleScrollToTop);
    pm.mediator.off('handleScrollToBottomShortcut', this.handleScrollToBottom);
  }

  handleScrollToTop() {
    if (!this.props.isActive) {
      return;
    }

    this.refs.container && (this.refs.container.scrollTop = 0);
  }

  handleScrollToBottom() {
    if (!this.props.isActive) {
      return;
    }

    this.refs.container && (this.refs.container.scrollTop = this.refs.container.scrollHeight);
  }

  closeTab() {
    let tabId = this.props.tabId;

    return _services_EditorService__WEBPACK_IMPORTED_MODULE_6__["default"].close({ id: tabId });
  }

  getTabContainerClasses({ isActive }) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'requester-tab-content-container': true,
      'is-hidden': !isActive });

  }

  focus() {
    let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.refs.container);
    $node && $node.focus();
  }

  render() {
    let tabId = this.props.tabId,
    editorStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('EditorStore').find(tabId),
    editorModel = editorStore && editorStore.model;

    if (!editorModel) {
      return null;
    }

    let EditorView = editorModel.getView();

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: tabId, isVisible: this.props.isActive },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getTabContainerClasses({ isActive: this.props.isActive }) },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { 'data-tabid': tabId, className: 'requester-tab-content', ref: 'container', tabIndex: '-1' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_5__["default"], { onClose: this.closeTab },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(EditorView, {
                id: tabId,
                editor: editorModel }))))));






  }}) || _class;

/***/ }),

/***/ 5837:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabContentEmptyShell; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1545);
/* harmony import */ var _base_Icons_OpenIcon_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5838);
/* harmony import */ var _onboarding_src_features_Recommendations_components_RecommendationViewer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2107);
var _class;





let


TabContentEmptyShell = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class TabContentEmptyShell extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  handleOpenLaunchpad() {
    return _services_EditorService__WEBPACK_IMPORTED_MODULE_3__["default"].open('customview://launchpad', { preview: false });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'tab-content-shell-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'tab-content-shell' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'tab-content-shell-thumbnail' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '200', height: '200', viewBox: '0 0 160 160', xmlns: 'http://www.w3.org/2000/svg' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'tabContentEmptyShell', d: 'M44.3876 8.36374C58.5563 1.32009 74.4955 -1.36374 90.1896 0.651652C111.232 3.3539 130.34 14.304 143.31 31.0934C156.279 47.8829 162.049 69.1365 159.349 90.1796C157.336 105.874 150.714 120.619 140.32 132.549C129.927 144.48 116.229 153.06 100.958 157.206C85.6882 161.351 69.5316 160.875 54.5319 155.838C39.5323 150.801 26.3632 141.428 16.6901 128.907C7.01705 116.385 1.27449 101.276 0.188639 85.49C-0.89721 69.7044 2.72243 53.9513 10.5898 40.2229C18.4572 26.4945 30.2189 15.4074 44.3876 8.36374ZM112.621 31.2721C114.229 30.4997 115.99 30.0978 117.774 30.096C120.505 30.0873 123.157 31.0164 125.286 32.728L114.686 43.32C114.592 43.4129 114.519 43.5232 114.468 43.6447C114.418 43.7662 114.392 43.8965 114.392 44.028C114.392 44.1595 114.418 44.2898 114.468 44.4113C114.519 44.5328 114.592 44.6431 114.686 44.736L122.798 52.848C121.179 53.5975 119.413 53.9744 117.629 53.951C115.845 53.9275 114.09 53.5043 112.491 52.7125C110.893 51.9208 109.492 50.7805 108.393 49.3759C107.293 47.9712 106.523 46.3378 106.138 44.5959C105.754 42.8541 105.765 41.0482 106.17 39.3111C106.576 37.5741 107.366 35.9501 108.483 34.5588C109.599 33.1676 111.013 32.0444 112.621 31.2721ZM57.985 85.1992C57.9208 85.17 57.8687 85.1194 57.8377 85.056C57.8035 84.9914 57.7943 84.9165 57.8121 84.8456C57.8298 84.7747 57.8731 84.7129 57.9337 84.672L65.6057 77L70.9897 82.456L58.1897 85.216C58.1216 85.2343 58.0492 85.2284 57.985 85.1992ZM106.862 52.368H106.686C106.479 52.3664 106.273 52.3852 106.07 52.424H105.998C105.775 52.4721 105.555 52.5363 105.342 52.616L105.174 52.696C105.013 52.7632 104.857 52.8435 104.71 52.936L104.534 53.048C104.34 53.1817 104.158 53.3315 103.99 53.496L74.5256 82.968L78.1736 86.616L109.374 59.232C109.55 59.0774 109.711 58.9059 109.854 58.72L109.99 58.544C110.096 58.3878 110.192 58.2248 110.278 58.056C110.326 57.96 110.366 57.864 110.406 57.768C110.459 57.6404 110.505 57.5095 110.542 57.376C110.542 57.3149 110.564 57.2538 110.587 57.1927C110.6 57.1578 110.613 57.1229 110.622 57.088C110.661 56.8899 110.688 56.6895 110.702 56.488V55.792C110.702 55.6481 110.702 55.6 110.662 55.504C110.514 54.749 110.145 54.0549 109.603 53.5095C109.06 52.9641 108.368 52.5919 107.614 52.44H107.462C107.264 52.4019 107.063 52.3779 106.862 52.368ZM73.0297 81.6L66.9817 75.584C95.2056 47.448 100.902 46.4 106.126 50.4C104.788 50.5321 103.535 51.1162 102.574 52.056L73.0297 81.6ZM111.037 60.384L110.677 60.736L79.4775 88.112L84.7815 93.408C97.9335 80.968 109.605 69.12 111.037 60.384ZM33.309 124.664C33.2632 124.627 33.2299 124.577 33.2137 124.52C33.1929 124.466 33.1878 124.407 33.1991 124.351C33.2105 124.294 33.2377 124.242 33.2777 124.2L39.4457 118.04L47.0697 125.664L33.4697 124.728C33.4109 124.724 33.3548 124.702 33.309 124.664ZM40.8696 116.624L48.9096 124.664C49.0051 124.766 49.1327 124.832 49.2711 124.851C49.4095 124.87 49.5503 124.841 49.6696 124.768C49.7942 124.706 49.8935 124.603 49.9504 124.476C50.0073 124.349 50.0184 124.206 49.9816 124.072L48.6296 118.296C48.5421 117.922 48.5818 117.529 48.7427 117.18C48.9035 116.83 49.1762 116.545 49.5176 116.368C63.6136 109.304 74.9816 102.032 83.3255 94.768L77.7255 89.168L65.7256 91.752L40.8696 116.624ZM72.9975 84.4641L76.0055 87.4721L69.0695 88.9761C69.0248 88.99 68.9766 88.9872 68.9338 88.968C68.8911 88.9489 68.8569 88.9147 68.8375 88.8721C68.8076 88.8362 68.7912 88.7909 68.7912 88.7441C68.7912 88.6973 68.8076 88.652 68.8375 88.6161L72.9975 84.4641ZM116.805 44L126.741 34.104C128.729 36.3914 129.778 39.3461 129.677 42.3749C129.576 45.4036 128.333 48.282 126.197 50.432C125.707 50.9336 125.171 51.3888 124.597 51.792L116.805 44ZM126.824 40.2129C126.913 40.3105 126.98 40.4262 127.022 40.5521C127.416 41.3514 127.571 42.2475 127.469 43.133C127.367 44.0184 127.012 44.8556 126.446 45.5441C126.358 45.648 126.249 45.7319 126.126 45.7899C126.003 45.8478 125.869 45.8786 125.734 45.8801C125.558 45.8796 125.385 45.8291 125.237 45.7345C125.089 45.6399 124.97 45.5051 124.896 45.3457C124.821 45.1864 124.793 45.0092 124.816 44.8347C124.838 44.6602 124.909 44.4956 125.022 44.3601C125.363 43.9453 125.577 43.4407 125.638 42.9069C125.699 42.3732 125.605 41.8332 125.366 41.3521C125.292 41.2417 125.244 41.1169 125.223 40.9862C125.202 40.8554 125.209 40.7217 125.244 40.594C125.279 40.4663 125.341 40.3476 125.426 40.2458C125.511 40.1441 125.616 40.0616 125.736 40.004C125.855 39.9464 125.985 39.915 126.117 39.9119C126.25 39.9088 126.381 39.934 126.503 39.9859C126.625 40.0378 126.734 40.1152 126.824 40.2129Z' })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fillRule: 'evenodd', xlinkHref: '#tabContentEmptyShell' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'tab-content-shell-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'tab-content-shell-content' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                  type: 'secondary',
                  onClick: this.handleOpenLaunchpad },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_OpenIcon_js__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'launchpad-open-icon' }), 'Open Launchpad'))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_onboarding_src_features_Recommendations_components_RecommendationViewer__WEBPACK_IMPORTED_MODULE_5__["default"], {
            target: 'tabs/response/empty' }))));




  }}) || _class;

/***/ }),

/***/ 5838:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return OpenIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'open', d: 'M1.143 0h13.714C15.488 0 16 .512 16 1.143v13.714c0 .631-.512 1.143-1.143 1.143H1.143A1.143 1.143 0 0 1 0 14.857V1.143C0 .512.512 0 1.143 0zm11.862 8.677a.684.684 0 0 0 .694-.679V3.421a1.15 1.15 0 0 0-1.15-1.135H7.981a.684.684 0 0 0-.693.678c0 .373.321.678.693.678h3.332L7.29 7.677a.708.708 0 0 0 0 1.017.704.704 0 0 0 1.014 0l4.026-4.052V8a.68.68 0 0 0 .676.678z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#282828', fillRule: 'evenodd', xlinkHref: '#open' }));



function OpenIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ })

}]);