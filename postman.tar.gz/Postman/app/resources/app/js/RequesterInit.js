(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ 4796:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Requester; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _RequesterHeaderContainer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4797);
/* harmony import */ var _RequesterInfobarContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4840);
/* harmony import */ var react_notification_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4556);
/* harmony import */ var react_notification_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_notification_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1794);
/* harmony import */ var _components_base_Panes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1878);
/* harmony import */ var _containers_variables_VariablesProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4841);
/* harmony import */ var _constants_AppNotificationStyles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4725);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2136);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _postman_react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2516);
/* harmony import */ var _postman_react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_postman_react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _RequesterContentContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4842);
/* harmony import */ var _RequesterBottomPaneContainer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4894);
/* harmony import */ var _RequesterBottomPaneHeader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4907);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4416);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_messaging_Popover__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4908);
/* harmony import */ var _components_base_XPaths_XPathProvider__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4730);
/* harmony import */ var _onboarding_onAppReadyHooks_requester__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4910);
/* harmony import */ var _common_constants_views__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1797);
/* harmony import */ var _common_constants_views__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_common_constants_views__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _constants_Panes__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1880);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2083);
/* harmony import */ var _collaboration_containers_comments_inline_InlineComment__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4916);
var _dec, _class;





















const RequesterModalContainer = react_loadable__WEBPACK_IMPORTED_MODULE_13___default()({
  loader: () => Promise.all(/* import() | RequesterModalContainer */[__webpack_require__.e(9), __webpack_require__.e(14)]).then(__webpack_require__.bind(null, 5485)),
  loading: () => null });let



Requester = (_dec = Object(react_dnd__WEBPACK_IMPORTED_MODULE_8__["DragDropContext"])(_postman_react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_9___default.a), _dec(_class = class Requester extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  componentDidMount() {
    pm.toasts.setNotificationComponent(this.refs.notificationSystem);
    Object(_onboarding_onAppReadyHooks_requester__WEBPACK_IMPORTED_MODULE_16__["initializeOnboarding"])();
  }

  getKeyMapHandlers() {
    return {
      import: pm.shortcuts.handle('import'),

      requestUrl: pm.shortcuts.handle('requestUrl'),
      saveCurrentRequest: pm.shortcuts.handle('saveCurrentRequest'),
      saveCurrentRequestAs: pm.shortcuts.handle('saveCurrentRequestAs'),
      sendCurrentRequest: pm.shortcuts.handle('sendCurrentRequest'),
      sendAndDownloadCurrentRequest: pm.shortcuts.handle('sendAndDownloadCurrentRequest'),
      scrollToRequest: pm.shortcuts.handle('scrollToRequest'),
      scrollToResponse: pm.shortcuts.handle('scrollToResponse'),

      focusSidebar: pm.shortcuts.handle('focusSidebar'),
      focusBuilder: pm.shortcuts.handle('focusBuilder'),
      toggleSidebar: pm.shortcuts.handle('toggleSidebar'),
      switchPane: pm.shortcuts.handle('switchPane'),

      manageEnvironments: pm.shortcuts.handle('manageEnvironments'),
      settings: pm.shortcuts.handle('settings'),
      shortcutCheats: pm.shortcuts.handle('shortcutCheats'),

      openCreateNewModal: pm.shortcuts.handle('openCreateNewModal'),
      newRequesterWindow: pm.shortcuts.handle('newRequesterWindow'),
      newRunnerWindow: pm.shortcuts.handle('newRunnerWindow'),
      newConsoleWindow: pm.shortcuts.handle('newConsoleWindow'),
      toggleFindReplace: pm.shortcuts.handle('toggleFindReplace'),

      increaseUIZoom: pm.shortcuts.handle('increaseUIZoom'),
      decreaseUIZoom: pm.shortcuts.handle('decreaseUIZoom'),
      resetUIZoom: pm.shortcuts.handle('resetUIZoom'),
      toggleLayout: pm.shortcuts.handle('toggleLayout'),
      toggleWorkspaceView: pm.shortcuts.handle('toggleWorkspaceView') };

  }

  /**
     * Returns the criteria to activate a shortcut. The criteria used is the active view at the
     * time of handling the shortcut.
     *
     * In general components don't need to provide this since the shortcuts only work
     * when the component is in focus. On changing the active view (for eg from build view to browse view),
     * the components also loses focus and so the shortcuts becomes deactivated.
     *
     * This is a special case component which is mounted at a higher level and have attached shortcuts
     * which are actually meant for its children. So even if the active view changes, this component can
     * still have focus and the shortcuts would not be deactivated.
     * This is where the prop `allowedViews` can help by restricting the shortcut to a
     * single/multiple views only.
     */
  getShortcutsActivationCriteria() {
    return {
      requestUrl: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      saveCurrentRequest: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      saveCurrentRequestAs: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      sendCurrentRequest: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      sendAndDownloadCurrentRequest: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      scrollToRequest: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      scrollToResponse: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],

      focusSidebar: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      focusBuilder: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      toggleSidebar: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      switchPane: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],

      manageEnvironments: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"]],
      shortcutCheats: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"], _common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BROWSER"]],

      toggleFindReplace: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"], _common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BROWSER"]],
      toggleWorkspaceView: [_common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BUILDER"], _common_constants_views__WEBPACK_IMPORTED_MODULE_17__["WORKSPACE_BROWSER"]] };

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPathProvider__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: 'requester' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_4__["default"], {
            keyMap: pm.shortcuts.getShortcuts(),
            handlers: this.getKeyMapHandlers(),
            allowedViews: this.getShortcutsActivationCriteria() },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_variables_VariablesProvider__WEBPACK_IMPORTED_MODULE_6__["default"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app-requester' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { id: 'dropdown-root', style: { width: 0, height: 0 } }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { id: 'auto-suggest-root', style: { width: 0, height: 0 } }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { id: 'right-overlay-root' }),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["PaneGroup"], { defaultLayout: _constants_Panes__WEBPACK_IMPORTED_MODULE_18__["PANE_LAYOUT_VERTICAL"], attachZoomHandler: true },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["Pane"], { height: { resizableByDefault: false, default: 50 } },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["PaneContent"], null,
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterHeaderContainer__WEBPACK_IMPORTED_MODULE_1__["default"], null))),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["Pane"], {
                    className: 'requester-contents-pane',
                    height: { collapsed: 1, collapseThreshold: 20 } },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["PaneContent"], null,
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterInfobarContainer__WEBPACK_IMPORTED_MODULE_2__["default"], null),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterContentContainer__WEBPACK_IMPORTED_MODULE_10__["default"], null))),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["Pane"], {
                    height: { collapsedByDefault: true, default: 300, min: 150 } },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["PaneHeader"], {
                    height: 32,
                    className: 'requester-bottom-pane-header-container',
                    defaultLayout: 'horizontal',
                    horizontalComponent: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterBottomPaneHeader__WEBPACK_IMPORTED_MODULE_12__["default"], null) }),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_5__["PaneContent"], { className: 'requester-bottom-pane-content' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterBottomPaneContainer__WEBPACK_IMPORTED_MODULE_11__["default"], null)))),




              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_notification_system__WEBPACK_IMPORTED_MODULE_3___default.a, {
                allowHTML: true,
                ref: 'notificationSystem',
                style: _constants_AppNotificationStyles__WEBPACK_IMPORTED_MODULE_7__["default"] }),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(RequesterModalContainer, null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_messaging_Popover__WEBPACK_IMPORTED_MODULE_14__["default"], null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_19__["default"], { silent: true },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collaboration_containers_comments_inline_InlineComment__WEBPACK_IMPORTED_MODULE_20__["default"], null)))))));






  }}) || _class);

/***/ }),

/***/ 4797:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterHeaderContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(612);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _utils_default_workspace__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1234);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1793);
/* harmony import */ var _components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1794);
/* harmony import */ var _controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4285);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(748);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2083);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1545);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(615);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1756);
/* harmony import */ var _modules_services_SignInModalService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2111);
/* harmony import */ var _constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2110);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1875);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _sync_SyncStatusContainer__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4798);
/* harmony import */ var _proxy_ProxyStatusContainer__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4800);
/* harmony import */ var _RequesterHeaderSettingsContainer__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4802);
/* harmony import */ var _RequesterHeaderUsersInfoContainer__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4803);
/* harmony import */ var _RequesterHeaderTeamInfoContainer__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4805);
/* harmony import */ var _containers_notifications_NotificationFeedContainer__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4808);
/* harmony import */ var _containers_capture_CaptureSettingsFeed__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4815);
/* harmony import */ var _containers_workspaces_WorkspaceSwitcherContainer__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4732);
/* harmony import */ var _collaboration_containers_presence_PresenceContainer__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(4834);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1763);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1789);
/* harmony import */ var _services_UIEventService__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(1755);
/* harmony import */ var _services_TabShortcutsService__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(4838);
/* harmony import */ var _new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(4839);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(1222);
var _class;
































let


RequesterHeaderContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_26__["observer"])(_class = class RequesterHeaderContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleNewRunnerWindow = this.handleNewRunnerWindow.bind(this);
    this.handleImportClick = this.handleImportClick.bind(this);
    this.handleNewRequesterWindow = this.handleNewRequesterWindow.bind(this);
    this.handleOpenWindow = this.handleOpenWindow.bind(this);
    this.handleOpenWindowButtonToggle = this.handleOpenWindowButtonToggle.bind(this);
    this.handleInviteButton = this.handleInviteButton.bind(this);
  }

  UNSAFE_componentWillMount() {
    pm.appWindow.trigger('registerInternalEvent', 'openRunner', this.handleNewRunnerWindow, this);
  }

  getKeymapHandlers() {
    return Object(_services_TabShortcutsService__WEBPACK_IMPORTED_MODULE_29__["getTabShortcuts"])();
  }

  handleOpenWindowButtonToggle(isOpen) {
    // Send event if the dropdown is opened.
    isOpen && _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('topbar', 'click_open_new');
  }


  handleNewRequesterWindow() {
    pm.mediator.trigger('newRequesterWindow');
  }

  handleNewRunnerWindow() {
    pm.mediator.trigger('newRunnerWindow');
  }

  handleImportClick() {
    pm.mediator.trigger('openImportModal');
  }

  async handleInviteButton(source) {
    let currentUserStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('CurrentUserStore');

    if (!currentUserStore.isLoggedIn) {
      return Object(_modules_services_SignInModalService__WEBPACK_IMPORTED_MODULE_12__["showContextualSignInModal"])('invite',
      () => this.handleInviteButton(source),
      { from: 'requester_header' });

    }

    let ActiveWorkspaceStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('ActiveWorkspaceStore'),
    workspaceId = ActiveWorkspaceStore.id,
    isTeamUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('CurrentUserStore').teamSyncEnabled;

    if (!ActiveWorkspaceStore.isMember) {
      pm.mediator.trigger('joinWorkspace');
      return;
    }

    let userDefaultWorkspaceId = await Object(_utils_default_workspace__WEBPACK_IMPORTED_MODULE_3__["defaultUserWorkspaceId"])();

    if (isTeamUser && userDefaultWorkspaceId !== workspaceId) {
      pm.mediator.trigger('openShareWorkspaceModal', workspaceId);
      return;
    }

    _services_UIEventService__WEBPACK_IMPORTED_MODULE_28__["default"].publish(_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_11__["OPEN_INVITE_MODAL"], { source });
  }

  handleCreateNewButton() {
    let workspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('ActiveWorkspaceSessionStore').workspace,
    isJoinedWorkspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('WorkspaceStore').find(workspace);
    if (_.isEmpty(isJoinedWorkspace)) {
      pm.mediator.trigger('joinWorkspace');
      return;
    }
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('onboarding', 'view_create_new_modal');
    pm.mediator.trigger('openCreateNewXModal');
  }

  handleOpenWindow(window) {
    switch (window) {
      case 'tab':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_9__["default"].openDefault();
        break;
      case 'requester':
        this.handleNewRequesterWindow();
        break;
      case 'runner':
        this.handleNewRunnerWindow();
        break;}

  }

  getApiButtonDisabledText(isLoggedIn, isOnline) {
    if (!isLoggedIn) return 'Sign in to create an API';
    if (!isOnline) return 'Get online to create an API';

    return '';
  }

  render() {
    let isLoggedIn = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('CurrentUserStore').isLoggedIn,
    isOnline = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('SyncStatusStore').isSocketConnected,
    isApiButtonDisabled = !(isLoggedIn && isOnline),
    activeWorkspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('ActiveWorkspaceStore'),
    workspacePresenceModel = { workspace: activeWorkspace.id },
    showWorkspacePresence = isOnline && activeWorkspace.type === 'team' &&
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('FeatureFlagsStore').isEnabled('presence:enabled') && !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_25__["getStore"])('PresenceStore').error;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'header' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_5__["default"], { keyMap: pm.shortcuts.getShortcuts(), handlers: this.getKeymapHandlers() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__section-left' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'create-new-button' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'createNew' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      type: 'primary',
                      tooltip: 'Create new',
                      onClick: this.handleCreateNewButton },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'plus-icon-wrapper' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], {
                        name: 'icon-action-add-stroke',
                        className: 'plus-icon',
                        size: 'large',
                        color: 'color-content-constant' })), 'New'))),






              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'import' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'header',
                    size: 'small',
                    onClick: this.handleImportClick,
                    className: 'import-collection-button',
                    tooltip: 'Import Collections, cURL, RAML, WADL and OpenAPI files' }, 'Import')),




              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'runner' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'header',
                    size: 'small',
                    onClick: this.handleNewRunnerWindow,
                    className: 'launch-runner-button',
                    tooltip: 'Run collections' }, 'Runner')),




              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'openNew' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["Dropdown"], {
                    className: 'window-new-button-dropdown',
                    onSelect: this.handleOpenWindow,
                    onToggle: this.handleOpenWindowButtonToggle },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["DropdownButton"], { type: 'secondary', size: 'small', dropdownStyle: 'nocaret' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                        className: 'window-new-button',
                        tooltip: 'Open New' },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], { name: 'icon-action-newWindow-stroke', size: 'large', className: 'window-new-button-icon pm-icon-header' }),
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], { name: 'icon-direction-down', size: 'large', className: 'down-solid-icon pm-icon-header' }))),


                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["DropdownMenu"], { 'align-left': true },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItemHeader"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Open new')),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], { refKey: 'tab' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'tab' },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'window-new-button__label' }, 'Tab'),
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'window-new-button__shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_6__["getShortcutByName"])('openNewTab')))),


                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], { refKey: 'requester' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'window' },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'window-new-button__label' }, 'Postman Window'),
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'window-new-button__shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_6__["getShortcutByName"])('newRequesterWindow')))),


                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], { refKey: 'runner' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'runner' },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'window-new-button__label' }, 'Runner Window'),
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'window-new-button__shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_6__["getShortcutByName"])('newRunnerWindow')))))))),






            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__section-center' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_workspaces_WorkspaceSwitcherContainer__WEBPACK_IMPORTED_MODULE_23__["default"], null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'invite' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'header',
                    className: 'btn btn-small workspace-invite-btn',
                    onClick: this.handleInviteButton.bind(this, 'header') },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], { name: 'icon-action-invite-stroke', size: 'small', className: 'pm-icon pm-icon-normal' }), '\xA0\xA0Invite')),



              showWorkspacePresence &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__["default"], { silent: true },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collaboration_containers_presence_PresenceContainer__WEBPACK_IMPORTED_MODULE_24__["default"], {
                  primaryModel: 'workspace',
                  models: workspacePresenceModel,
                  model: 'workspace',
                  modelId: activeWorkspace.id }))),




            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__section-right' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterHeaderTeamInfoContainer__WEBPACK_IMPORTED_MODULE_20__["default"], { onInviteButtonClick: this.handleInviteButton }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterHeaderUsersInfoContainer__WEBPACK_IMPORTED_MODULE_19__["default"], null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                  className: 'heart-button',
                  type: 'icon',
                  onClick: () => {Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_31__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_14__["LIKE_URL"]);} },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_27__["default"], { identifier: 'heart' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], {
                    name: 'icon-descriptive-like-stroke',
                    className: 'heart-button-icon pm-icon-header',
                    size: 'large',
                    color: 'color-header-content' }))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_notifications_NotificationFeedContainer__WEBPACK_IMPORTED_MODULE_21__["default"], null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterHeaderSettingsContainer__WEBPACK_IMPORTED_MODULE_18__["default"], null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_capture_CaptureSettingsFeed__WEBPACK_IMPORTED_MODULE_22__["default"], null),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sync_SyncStatusContainer__WEBPACK_IMPORTED_MODULE_16__["default"], null))))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4798:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SyncStatusContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_sync_SyncStatus__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4799);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2690);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1222);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1875);
var _class;





let


SyncStatusContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class SyncStatusContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      status: 'off',
      showTooltip: false,
      timeTillReconnect: null };


    this.handleClick = this.handleClick.bind(this);
    this.handleForceConnect = this.handleForceConnect.bind(this);
    this.handleTooltipClose = this.handleTooltipClose.bind(this);
    this.handleEnableSync = this.handleEnableSync.bind(this);
    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleModelChange = this.handleModelChange.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.attachModelListeners();
    this.handleModelChange();
  }

  componentWillUnmount() {
    this.detachModelListeners();
  }

  attachModelListeners() {
    pm.syncManager.on('change:timeTillReconnect', this.handleModelChange);
  }

  detachModelListeners() {
    pm.syncManager.off('change:timeTillReconnect', this.handleModelChange);
  }

  handleModelChange() {
    let timeTillReconnect = pm.syncManager.get('timeTillReconnect');

    this.setState({ timeTillReconnect: timeTillReconnect });
  }

  _setState(state) {
    this.setState(state);
  }

  getNewState(status) {
    switch (status) {
      case 'syncing':
        return 'syncing';
      case 'off':
        return 'off';
      case 'insync':
      case 'idle':
      case 'connected':
        return 'insync';
      case 'connecting':
        return 'connecting';
      case 'offline':
        return 'offline';
      default:
        pm.logger.error('Unrecognised sync status', status);
        return status;}

  }

  handleTooltipClose() {
    this.setState({ showTooltip: false });
  }

  handleClick() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').currentSyncStatus === 'insync') {
      pm.syncManager.syncIconClick();
    }
  }

  handleForceConnect() {
    pm.syncManager.forceConnect();
  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_2__["default"].login();
    this.handleTooltipClose();
  }

  handleEnableSync() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__["ENABLE_SYNC_DOCS_URL"]);
  }

  render() {
    let currentSyncStatus = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').currentSyncStatus,
    isSyncDisabled = !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('GateKeeperStore').isSyncEnabled,
    isLoggedIn = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore').isLoggedIn;

    // if sync is disabled from the gatekeeper store then set sync status as off
    // off means the red/maroon sync indicator to come up
    if (isLoggedIn && isSyncDisabled) {
      currentSyncStatus = 'off';
    }

    let syncStatus = this.getNewState(currentSyncStatus);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_sync_SyncStatus__WEBPACK_IMPORTED_MODULE_1__["default"], {
        showTooltip: this.state.showTooltip,
        status: syncStatus,
        timeTillReconnect: this.state.timeTillReconnect,
        onEnableSync: this.handleEnableSync,
        onForceConnect: this.handleForceConnect,
        onIconClick: this.handleClick,
        onSignin: this.handleSignIn,
        onTooltipToogle: this.handleTooltipToggle }));


  }}) || _class;

/***/ }),

/***/ 4799:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SyncStatus; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1769);
/* harmony import */ var _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2059);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1875);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(749);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1222);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__);
var _class;











const SYNC_STATUS_META = {
  off: {
    label: 'SYNC OFF',
    classes: 'sync-off' },

  insync: {
    label: 'IN SYNC',
    classes: 'in-sync' },

  syncing: {
    label: 'SYNCING',
    classes: 'syncing' },

  pending: {
    label: 'PENDING',
    classes: 'syncing' },

  connecting: {
    label: 'CONNECTING',
    classes: 'connecting' },

  offline: {
    label: 'OFFLINE',
    classes: 'offline' } };


const tooltipShowTimeout = 100,
tooltipDismissTimeout = 100;let


SyncStatus = Object(mobx_react__WEBPACK_IMPORTED_MODULE_7__["observer"])(_class = class SyncStatus extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);

    this.state = {
      showTooltip: false };


    this.showToolTip = this.showToolTip.bind(this);
    this.hideToolTip = this.hideToolTip.bind(this);
  }

  getButtonClasses() {
    let meta = SYNC_STATUS_META[this.props.status];
    return classnames__WEBPACK_IMPORTED_MODULE_5___default()({ 'sync-button': true }, meta.classes);
  }

  handleClick() {
    this.props.onIconClick && this.props.onIconClick();
  }

  handleOpenExternalLink() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_9__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__["SYNC_DOCS"]);
  }

  showToolTip() {
    this.dismissTooltipTimeout && clearTimeout(this.dismissTooltipTimeout);

    this.dismissTooltipTimeout = setTimeout(() => {
      this.setState({ showTooltip: true });
    }, tooltipShowTimeout);
  }

  hideToolTip() {
    this.dismissTooltipTimeout && clearTimeout(this.dismissTooltipTimeout);

    this.dismissTooltipTimeout = setTimeout(() => {
      this.setState({ showTooltip: false });
    }, tooltipDismissTimeout);
  }

  getOfflineMessage() {
    const currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('CurrentUserStore');
    const activeWorkspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('ActiveWorkspaceStore');

    if (!currentUser || !currentUser.isLoggedIn) {
      return 'Syncing makes any changes to your Postman data available across devices linked to your account. Enable sync to never worry about losing your data.';
    }

    return activeWorkspace.type === 'personal' ?
    'Data in this workspace might not be up to date.' :
    'Any changes made while offline might not sync properly with other members of this workspace.';
  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('CurrentUserStore'),
    meta = SYNC_STATUS_META[this.props.status],
    isLoggedIn = currentUser && currentUser.isLoggedIn,
    headerContent = isLoggedIn ? 'Syncing is disabled' : 'Sign in to sync';

    if (this.props.status === 'off') {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { type: 'icon', iconType: 'circle',
              className: this.getButtonClasses(),
              onClick: this.props.onTooltipToogle,
              ref: 'syncstatus_icon',
              tooltip: 'Sync your API requests across devices' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-state-syncing-stroke', className: 'pm-icon-sync pm-icon pm-icon-normal' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_3__["Tooltip"], {
                show: this.props.showTooltip,
                target: this.refs.syncstatus_icon,
                placement: 'bottom',
                className: 'sync-status-tooltip',
                immediate: true },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_3__["TooltipBody"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-wrapper' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-header' },
                    headerContent),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-description' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' Syncing makes any changes to your Postman data available across devices linked to your account. Enable sync to never worry about losing your data.'),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                        className: 'learn-more',
                        type: 'text',
                        onClick: this.handleOpenExternalLink }, 'Learn more about syncing')),





                  isLoggedIn &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      type: 'primary',
                      size: 'small',
                      onClick: this.props.onEnableSync,
                      className: 'sync-status-tooltip-button' }, 'Enable syncing'),





                  !isLoggedIn &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      type: 'primary',
                      size: 'small',
                      onClick: this.props.onSignin,
                      className: 'sync-status-tooltip-button' }, 'Sign in to sync your Postman data')))))));










    }

    if (this.props.status === 'offline') {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'sync-status',
            ref: ref => this.syncIconRef = ref,
            onMouseEnter: this.showToolTip,
            onMouseLeave: this.hideToolTip },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'icon',
              iconType: 'circle',
              className: this.getButtonClasses(),
              onClick: this.hideToolTip },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-state-notSynced-stroke', className: 'pm-icon-sync pm-icon pm-icon-normal' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_3__["Tooltip"], {
              immediate: true,
              show: this.state.showTooltip,
              target: this.syncIconRef,
              placement: 'bottom-left',
              className: 'sync-status-tooltip',
              onMouseEnter: this.showToolTip,
              onMouseLeave: this.hideToolTip },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_3__["TooltipBody"], null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-wrapper' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('h4', { className: 'sync-status-tooltip-header' },
                  isLoggedIn ?
                  'You are offline' :
                  'Sign in to sync your Postman data'),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-description' },
                  this.getOfflineMessage()),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                    type: 'primary',
                    size: 'small',
                    onClick: isLoggedIn ? this.props.onForceConnect : this.props.onSignin,
                    className: 'sync-status-tooltip-button' },

                  isLoggedIn ?
                  'Connect Now' :
                  'Sign In'))))));







    }

    if (this.props.status === 'connecting') {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { type: 'icon', iconType: 'circle',
              className: this.getButtonClasses(),
              onClick: this.props.onTooltipToogle,
              ref: 'syncstatus_icon',
              tooltip: 'Sync your API requests across devices' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-state-syncing-stroke', className: 'pm-icon-sync pm-icon pm-icon-normal' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_3__["Tooltip"], {
                show: this.props.showTooltip,
                target: this.refs.syncstatus_icon,
                placement: 'bottom',
                className: 'sync-status-tooltip',
                immediate: true },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_3__["TooltipBody"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-wrapper' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className:
                      this.props.timeTillReconnect !== null ?
                      'sync-status-tooltip-header' :
                      'sync-status-tooltip-header sync-status-tooltip-header--no-description' }, 'Connecting...'),



                  this.props.timeTillReconnect &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status-tooltip-description' }, 'Reconnecting in [',
                    this.props.timeTillReconnect, '] ', _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_4__["default"].pluralize({
                      count: this.props.timeTillReconnect,
                      singular: 'second',
                      plural: 'seconds' }), '...'),




                  this.props.timeTillReconnect &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                      type: 'primary',
                      size: 'small',
                      onClick: this.props.onForceConnect,
                      className: 'sync-status-tooltip-button' }, 'Retry Now')))))));








    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'sync-status' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { type: 'icon', iconType: 'circle',
            className: this.getButtonClasses(),
            onClick: this.handleClick,
            tooltip: 'Sync your API requests across devices' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_10__["Icon"], { name: 'icon-state-syncing-stroke', className: 'pm-icon-sync pm-icon pm-icon-normal' }))));



  }}) || _class;


SyncStatus.defaultProps = { status: 'off' };

SyncStatus.propTypes = { status: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['off', 'insync', 'syncing', 'connecting', 'offline', 'pending']) };

/***/ }),

/***/ 4800:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxyStatusContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Tooltips__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1769);
/* harmony import */ var _components_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2511);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Icons_ProxyIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4801);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1789);






let

ProxyStatusContainer = class ProxyStatusContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      status: false,
      showTooltip: false,
      proxyStatus: false };

    this.openProxySettingsModal = this.openProxySettingsModal.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.attachModelListeners();
    this.setState({ proxyStatus: pm.tcpReader.status });
  }

  componentWillUnmount() {
    this.detachModelListeners();
  }

  attachModelListeners() {
    pm.mediator.on('proxyStatusChanged', this.handleModelChange, this);
  }

  detachModelListeners() {
    pm.mediator.on('proxyStatusChanged', this.handleModelChange, this);
  }

  openProxySettingsModal(value) {
    pm.mediator.trigger('openProxySettingsModal');
  }

  handleModelChange() {
    this.setState({ proxyStatus: pm.tcpReader.status });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_5___default()('interceptor-button', { 'is-active': this.state.proxyStatus === 'connected' });
  }

  render() {

    let status = this.state.status;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: 'proxy' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
            type: 'icon',
            className: this.getClasses(),
            onClick: this.openProxySettingsModal,
            tooltip: 'Capture API requests with Postman' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_ProxyIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'proxy-button-icon' }))));



  }};

/***/ }),

/***/ 4801:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxyIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '17', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'proxy', d: 'M10.18 6.456L8.809 8.462l5.464 4.86c-2.988 3.373-8.173 3.681-11.528.674C-.629 11.008-.938 5.822 2.07 2.468l5.505 4.896 1.795-1.7a1.446 1.446 0 1 1 .81.793zm.314-4.49a.36.36 0 0 0 .192-.095c1.427-.309 2.853.578 3.162 2.004.038.25.058.54.058.79 0 .059 0 .078-.077.078l-.926-.116c0-.212-.019-.405-.077-.636-.289-.906-1.214-1.388-2.101-1.099-.02-.135-.077-.25-.135-.385-.058-.135-.116-.309-.173-.444v-.019c0-.02.019-.077.077-.077zM14.06.985c.771.597 1.31 1.426 1.6 2.332.135.501.154 1.041.135 1.542 0 .02-.02.078-.02.135l-.982-.115v-.424a3.457 3.457 0 0 0-1.292-2.68.296.296 0 0 1-.116-.077c-.173-.096-.308-.212-.482-.29a3.285 3.285 0 0 0-2.621-.25l-.135.02-.328-.945c.25-.058.482-.154.733-.174a4.533 4.533 0 0 1 3.354.79c.019.059.058.097.077.116.02 0 .058 0 .077.02z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#FFF', fillRule: 'nonzero', xlinkHref: '#proxy' }));



function ProxyIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 4802:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterHeaderSettingsContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
/* harmony import */ var _services_ReleaseNotesService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1633);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1875);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1789);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1222);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__);












const noIndicatorStatus = ['idle', 'checking', 'updateNotAvailable', 'downloading'],
indicatorStatus = ['updateAvailable', 'error', 'downloaded'],
allowedAutoUpdateStatus = noIndicatorStatus.concat(indicatorStatus),
updateStatusAnalyticsMap = {
  updateAvailable: 'update_available',
  downloaded: 'update_downloaded',
  error: 'error' };let


RequesterHeaderSettingsContainer = class RequesterHeaderSettingsContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { showSettingsIndicator: false };
    pm.updateNotifier.on('change:status', this.handleUpdateAvailability.bind(this));
  }

  handleUpdateAvailability() {
    const status = pm.updateNotifier.get('status'),
    showSettingsIndicator = _.includes(indicatorStatus, status);

    if (!_.includes(allowedAutoUpdateStatus, status)) {
      return;
    }

    if (showSettingsIndicator) {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEvent('app', 'view_settings_badge', updateStatusAnalyticsMap[status]);
    }

    return this.setState({
      showSettingsIndicator,
      updateStatus: status });

  }

  handleDropdownSelect(ref) {
    switch (ref) {
      case 'settings':{
          pm.mediator.trigger('openSettingsModal');
          break;
        }
      case 'releaseNotes':{
          _services_ReleaseNotesService__WEBPACK_IMPORTED_MODULE_5__["default"].openReleaseNotes();
          break;
        }
      case 'documentation':{
          Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__["DOCS_URL"]);
          break;
        }
      case 'security':{
          Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__["DOCS_SECURITY_URL"]);
          break;
        }
      case 'support':{
          Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__["SUPPORT_URL"]);
          break;
        }
      case 'twitter':{
          Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_8__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_6__["TWITTER_URL"]);
          break;
        }
      case 'update-available':{
          pm.mediator.trigger('showUpdateModal', { origin: 'settings_indicator' });
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEvent('app', 'view_update_available_modal', 'settings_indicator');
          break;
        }
      case 'update-downloaded':{
          pm.updateNotifier.applyUpdate();
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEvent('app', 'app_restart', 'settings_dropdown');
          break;
        }
      case 'update-failed':{
          pm.mediator.trigger('showUpdateModal');
          break;
        }}

  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'settings-button-icon': true,
      'pm-icon-header': true,
      'indicator': this.state.showSettingsIndicator,
      'error': this.state.updateStatus === 'error' });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'settings' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            className: 'settings-dropdown',
            onSelect: this.handleDropdownSelect },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], { dropdownStyle: 'nocaret' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                className: 'settings-button',
                tooltip: 'Settings',
                type: 'icon' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], {
                name: 'icon-descriptive-setting-stroke',
                size: 'large', color: 'color-header-content',
                className: this.getClasses() }))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], { 'align-right': true },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'settings' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'setting' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Settings'))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'divider divider--space' }),

            this.state.updateStatus === 'updateAvailable' &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'update-available' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Update available, view changes')),


            this.state.updateStatus === 'downloaded' &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'update-downloaded' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Update downloaded, restart now')),


            this.state.updateStatus === 'error' &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'update-failed' }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Update failed, view details')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'releaseNotes' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'releaseNotes' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Release Notes'))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'documentation' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'documentation' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Documentation'))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'security' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'security' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Security'))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'support' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'support' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Support'))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: 'twitter' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'twitter' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, '@getpostman')))))));






  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4803:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterHeaderUsersInfoContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2070);
/* harmony import */ var _components_base_UserCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4804);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1793);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2078);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1763);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(742);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1269);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2690);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1789);
/* harmony import */ var _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(769);
var _class;













let

RequesterHeaderUsersInfoContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class = class RequesterHeaderUsersInfoContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleLoginClick = this.handleLoginClick.bind(this);
    this.handleDropdownSelect = this.handleDropdownSelect.bind(this);
  }

  handleLoginClick() {
    _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_13__["default"].get().
    then(user => {
      // if user is signed out, initiate login flow
      if (!user || user.id === '0') {
        return _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_11__["default"].login();
      }

      // if user is not signed in, initiate add user flow
      // maybe the component/UI thinks user is signed out but user is signed in in the DB
      return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_10__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_9__["createEvent"])('add', 'users'));
    }).
    catch(e => {
      pm.logger.warn('RequesterHeaderUsersInfoContainer~handleLoginClick: Could not handle login. Error while fetching current user', e);
    });
  }

  handleLogoutClick() {
    pm.mediator.trigger('showUserSignoutModal');
  }

  handleDropdownSelect(ref) {
    if (_.startsWith(ref, 'switch_')) {
      let id = ref.split('_')[1];

      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_10__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_9__["createEvent"])('switch', 'users', { id }));
    }

    switch (ref) {
      case 'signin':{
          this.handleLoginClick();
          break;
        }
      case 'manage-profile':{
          Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openUserProfile"])();
          break;
        }
      case 'manage-account':{
          Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openAccountSettings"])();
          break;
        }
      case 'manage-trash':{
          Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openTrash"])();
          break;
        }
      case 'manage-notifications':{
          Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openNotificationPreferences"])();
          break;
        }
      case 'manage-sessions':{
          Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openUserSessions"])();
          break;
        }
      case 'logout':{
          this.handleLogoutClick();
          break;
        }
      case 'addNewAccount':{
          Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_10__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_9__["createEvent"])('add', 'users'));
          break;
        }}

  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore'),
    usersStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('UsersStore'),
    users = usersStore.values;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info' },

        !(currentUser && currentUser.isLoggedIn) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'signIn' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'show-sign-in-screen',
              size: 'small',
              type: 'header',
              onClick: this.handleLoginClick }, 'Sign In')),






        currentUser && currentUser.isLoggedIn &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'userInfo' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["Dropdown"], {
              'align-right': true,
              className: 'user-info-dropdown',
              onSelect: this.handleDropdownSelect },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["DropdownButton"], { dropdownStyle: 'nocaret' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: 'requester-header__user-info__button',
                  type: 'icon',
                  tooltip: 'Manage accounts' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info__button-wrapper' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Avatar__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    size: 'medium',
                    userId: currentUser.id,
                    customPic: currentUser.profile_pic_url })))),




            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["DropdownMenu"], { 'align-right': true },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'username',
                  className: 'is-disabled' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_UserCard__WEBPACK_IMPORTED_MODULE_3__["default"], {
                  showSignout: true,
                  email: currentUser.email || currentUser.username_email,
                  id: currentUser.id,
                  profile_pic_url: currentUser.profile_pic_url,
                  name: currentUser.name,
                  onLogout: this.handleLogoutClick })),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'manage-profile' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'profile' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info__menu-item' }, 'Profile'))),




              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'manage-trash' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'trash' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info__menu-item' }, 'Trash'))),




              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'manage-account' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'accountSettings' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info__menu-item' }, 'Account Settings'))),





              currentUser.teamSyncEnabled &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'manage-notifications' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'notificationPreferences' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info__menu-item' }, 'Notification Preferences'))),





              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'manage-sessions' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_12__["default"], { identifier: 'activeSessions' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__user-info__menu-item' }, 'Active Sessions'))),





              _.map(users && users, user => {
                if (user && user.id !== currentUser.id) {
                  return (
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                        key: user.id,
                        refKey: 'switch_' + user.id },

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_UserCard__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        className: 'requester-header__user-info__card',
                        email: user.email || user.username_email,
                        id: user.id,
                        name: user.name,
                        profile_pic_url: user.profile_pic_url })));



                }
                return null;
              }),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                  refKey: 'addNewAccount' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_UserCard__WEBPACK_IMPORTED_MODULE_3__["default"], {
                  isAddAccount: true,
                  className: 'requester-header__user-info__card' })))))));








  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4804:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return UserCard; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2070);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1789);



let
UserCard = class UserCard extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'user-card': true }, this.props.className);
  }

  render() {
    let decodedName = decodeURIComponent(this.props.name);
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'user-card__left' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Avatar__WEBPACK_IMPORTED_MODULE_2__["default"], {
            className: 'user-card__left-avatar',
            type: this.props.isAddAccount ? 'adduser' : 'user',
            userId: this.props.id,
            customPic: this.props.profile_pic_url })),



        this.props.isAddAccount &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'addNewAccount' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'user-card__right' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'user-card__right-add-account' }, 'Add a new account'))),






        !this.props.isAddAccount &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'user-card__right' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'user-card__right-name' },
            decodedName),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'user-card__right-email' },
            this.props.email),


          this.props.showSignout &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'signOut' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                className: 'user-card__right-signout',
                onClick: this.props.onLogout }, 'Sign Out')))));









  }};

/***/ }),

/***/ 4805:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterHeaderTeamInfoContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _components_messaging_Alert__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2689);
/* harmony import */ var _constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1756);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1222);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2078);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1875);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1793);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(749);
/* harmony import */ var _components_team_usage_TeamUsage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4806);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(748);
/* harmony import */ var _services_UIEventService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1755);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1789);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__);
var _class;

















const ENTERPRISE_UPDATE_TEMP_LINK = '#dashboardEnterprise';let


RequesterHeaderTeamInfoContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class RequesterHeaderTeamInfoContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { imageNotFound: false };
    this.handleDropdownSelect = this.handleDropdownSelect.bind(this);
    this.handleImageError = this.handleImageError.bind(this);
    this.handleUpgrade = this.handleUpgrade.bind(this);
    this.handleFetchDebounced = _.debounce(this.fetchResources.bind(this), 3000, { leading: true });
    this.handleDropdownOpen = this.handleDropdownOpen.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.unsubscribeHandler = _services_UIEventService__WEBPACK_IMPORTED_MODULE_13__["default"].subscribe(_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_4__["SHOW_USAGE"], this.handleDropdownOpen);
    pm.mediator.on('appOnline', this.handleFetchDebounced);
  }

  componentWillUnmount() {
    this.unsubscribeHandler && this.unsubscribeHandler();
    pm.mediator.off('appOnline', this.handleFetchDebounced);
  }

  handleDropdownOpen() {
    let toggleDropdown = _.get(this.refs, 'dropdownRef.__wrappedInstance.toggleDropdown');
    toggleDropdown && toggleDropdown(null, true);
  }

  handleInviteButton() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEvent('app', 'upgrade_dropdown_invite', 'header');
    this.props.onInviteButtonClick && this.props.onInviteButtonClick('upgrade_dropdown');
  }


  handleUpgrade() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('CurrentUserStore'),
    quantity;

    if (currentUser.team) {
      quantity = _.get(currentUser, 'organizations[0].team_users').length;
    }

    quantity = quantity || 1;

    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["upgradeToPro"])({ quantity });

    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEvent('onboarding', 'upgrade_pro_click', 'header');
  }

  fetchResources() {
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ResourceLimitOperationsStore').fetch();
  }

  handleDropdownSelect(item) {
    switch (item) {
      case 'sign-in':
        pm.mediator.trigger('openLoginModal');
        break;
      case 'enable-sync':
        // open docs for sync disabled
        Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_7__["ENABLE_SYNC_DOCS_URL"]);
        break;
      case 'view-team':
        Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openTeam"])();
        break;
      case 'billing':
        Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openTeamBilling"])();
        break;
      case 'resource-usage':
        Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openPostmanUsages"])();
        break;
      case 'audit-logs':
        Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openAuditLogs"])();
        break;
      case 'team-settings':
        Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openTeamSettings"])();
        break;
      case 'invite':
        this.handleInviteButton();
        break;}

  }

  handleImageError() {
    this.setState({ imageNotFound: true });
  }

  handleProDocsClick() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_7__["POSTMAN_PRO_DOCS"]);
  }

  handleUpgradePlan(link) {
    if (ENTERPRISE_UPDATE_TEMP_LINK === link) {
      Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openEnterprise"])();
    }
  }

  getUpgradeClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'team-info-dropdown-upgrade': true,
      'usage-warning': this.getUpgradeButtonType() === 'primary' });

  }

  getUpgradeButtonType() {
    let ResourceLimitOperationsStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ResourceLimitOperationsStore');

    return ResourceLimitOperationsStore.isResourceWarningThresholdReached ||
    ResourceLimitOperationsStore.isLimitReached ? 'primary' : 'header';
  }

  getWarningMessage() {
    // Ideally should come from God server [WEB-1044]
    let resourceLimitOperationsStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ResourceLimitOperationsStore');

    if (resourceLimitOperationsStore.isLimitReached) {
      return 'You have reached the monthly usage limits of your plan.';
    } else
    if (resourceLimitOperationsStore.isResourceWarningThresholdReached) {
      return 'You are about to reach the monthly usage limits of your plan.';
    }
    return '';
  }

  getMenu() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('CurrentUserStore'),
    ENTERPRISE_UPDATE_TEMP_LINK = '#dashboardEnterprise',
    teamSyncEnabled = currentUser.teamSyncEnabled,
    isSyncEnabled = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('GateKeeperStore').isSyncEnabled,
    warningMessage = this.getWarningMessage(),
    isProUser = !(currentUser.isFreeUser || currentUser.isFreeTeamUser),
    resourceLimitOperationsStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ResourceLimitOperationsStore');

    if (!isSyncEnabled) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownMenu"], { 'align-right': true, className: 'dropdown-sync-disabled-menu' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { disabled: true, refKey: 'enable-sync' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item__title' }, 'Enable Sync to view your team'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item__subtitle' }, 'Collaborate on your API collections with your teammates'),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                type: 'primary',
                size: 'large',
                onClick: this.handleDropdownSelect.bind(this, 'enable-sync') }, 'Enable Sync'))));






    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownMenu"], { 'align-right': true },

        teamSyncEnabled ?
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { disabled: true, refKey: 'teamname', className: 'dropdown-team-user-header-menu-item' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'team-info-dropdown__team-image',
              onClick: this.handleDropdownSelect.bind(this, 'view-team') },


            this.state.imageNotFound ?
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], { name: 'icon-descriptive-team-stroke', size: 'large', className: 'pm-icon pm-icon-normal' }) :
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('img', { src: currentUser.team.logo_url, onError: this.handleImageError })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-info-dropdown__team-details' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-info-dropdown__team-details-meta' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'team-info-dropdown__team-details__name',
                  title: currentUser.team.name,
                  onClick: this.handleDropdownSelect.bind(this, 'view-team') },

                currentUser.team.name),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-info-dropdown__team-details__domain', title: `${currentUser.team.domain}.postman.co` },
                `${currentUser.team.domain}.postman.co`)),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'manage' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                  type: 'secondary',
                  size: 'small',
                  onClick: this.handleDropdownSelect.bind(this, 'view-team') }, 'Manage Team')))) :




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { className: 'dropdown-free-user-header-menu-item' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item__title' }, 'Invite users and start sharing for free.'),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
              type: 'primary',
              size: 'small',
              onClick: this.handleDropdownSelect.bind(this, 'invite') }, 'Invite')),






        warningMessage &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_messaging_Alert__WEBPACK_IMPORTED_MODULE_3__["default"], {
          message: warningMessage,
          type: 'warn',
          isDismissable: false }),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_team_usage_TeamUsage__WEBPACK_IMPORTED_MODULE_11__["default"], { ResourceLimitOperationsStore: resourceLimitOperationsStore }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { refKey: 'billing' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'billing' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Billing'))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { refKey: 'resource-usage' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'resourceUsage' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Resource Usage'))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { refKey: 'audit-logs' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'auditLogs' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Audit Logs'))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], { refKey: 'team-settings' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'teamSettings' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Team Settings')))));




  }

  render(props) {
    let CurrentUserStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('CurrentUserStore'),
    resourceLimitOperationsStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ResourceLimitOperationsStore');

    if (!CurrentUserStore.isLoggedIn) {
      return null;
    }

    if (CurrentUserStore.isFreeUser || CurrentUserStore.isFreeTeamUser) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'teamInfo' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getUpgradeClasses() },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["Dropdown"], {
                className: 'team-info-dropdown',
                ref: 'dropdownRef',
                onSelect: this.handleDropdownSelect,
                onToggle: this.handleFetchDebounced,
                disableCloseOnPageScroll: true },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownButton"], { dropdownStyle: 'split', className: 'upgrade-dropdown', type: this.getUpgradeButtonType() },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                    className: 'team-button requester-header__team-info__button',
                    type: this.getUpgradeButtonType(),
                    onClick: this.handleUpgrade }, 'Upgrade')),




              this.getMenu()))));




    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'teamInfo' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-header__team-info' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["Dropdown"], {
              className: 'team-info-dropdown',
              ref: 'dropdownRef',
              onSelect: this.handleDropdownSelect,
              onToggle: this.handleFetchDebounced,
              disableCloseOnPageScroll: true },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownButton"], { dropdownStyle: 'nocaret' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                  className: 'team-button requester-header__team-info__button',
                  size: 'small',
                  type: 'header' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_15__["Icon"], { name: 'icon-descriptive-team-stroke', size: 'large', className: 'team-icon pm-icon-header' }), 'Team')),



            this.getMenu()))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4806:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TeamUsage; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _TeamUsageItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4807);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1808);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1768);
var _class;




let


TeamUsage = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class TeamUsage extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleRetry = this.handleRetry.bind(this);
  }

  getWrapperClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'team-usage-loading-wrapper': true,
      'is-loading': this.props.ResourceLimitOperationsStore.isLoading });

  }

  handleRetry() {
    this.props.ResourceLimitOperationsStore.fetch();
  }

  getOperationsUsage(members) {
    return _.map(members, operation => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TeamUsageItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
          key: operation.name,
          id: operation.name,
          title: operation.operationName,
          tooltip: operation.description,
          usage: operation.usage,
          overage: operation.overage,
          usageLimit: operation.limit,
          warningThreshold: operation.warningThreshold }));


    });
  }

  render() {
    let resourceLimitOperationsStore = this.props.ResourceLimitOperationsStore;

    if (resourceLimitOperationsStore.isError) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-error' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-error-title' }, 'Something went wrong!'),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-error-meta' }, 'Something went wrong while fetching your team\'s usage data.'),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-error-btn' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                type: 'primary',
                tooltip: 'Retry',
                onClick: this.handleRetry }, 'Retry'))));






    }
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getWrapperClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-container' },
          this.getOperationsUsage(this.props.ResourceLimitOperationsStore.values)),


        resourceLimitOperationsStore.isLoading && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'team-usage-loading' })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4807:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TeamUsageItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _base_InfoButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2496);
/* harmony import */ var _base_ProgressBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2504);
/* harmony import */ var _base_Markdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1783);
/* harmony import */ var _base_InfoButtonV3__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3944);
/* harmony import */ var _modules_services_APIService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1220);
var _class;







let


TeamUsageItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class TeamUsageItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.openDetailedUsagePage = this.openDetailedUsagePage.bind(this);
  }

  getUsagePercentage() {
    if (this.props.usageLimit) {
      return Math.ceil(this.props.usage / this.props.usageLimit * 100);
    }
    return 0;
  }

  getProgressColorClass() {
    let usagePercentage = this.getUsagePercentage();

    if (usagePercentage >= 100) {
      return 'error';
    } else if (usagePercentage > this.props.warningThreshold * 100) {
      return 'warning';
    }
    return 'success';
  }

  openDetailedUsagePage(target) {
    const link = target.getAttribute('href');
    link && Object(_modules_services_APIService__WEBPACK_IMPORTED_MODULE_6__["openAuthenticatedRoute"])(link);
  }

  /**
     * Renders info button with the markdown tooltip
     */
  renderInfoButton() {
    let { tooltip } = this.props,
    markdownTooltip =
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Markdown__WEBPACK_IMPORTED_MODULE_4__["default"], {
      className: 'info__button-markdown_tooltip',
      source: tooltip,
      handleClick: this.openDetailedUsagePage });



    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InfoButtonV3__WEBPACK_IMPORTED_MODULE_5__["default"], {
        tooltip: markdownTooltip,
        tooltipPlacement: 'bottom' }));


  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-item', ref: this.props.ref },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-item-header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-item-title-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'team-usage-item-title' },
              this.props.title),



            /**
                                  * @todo - Remove the condition and use 'this.renderInfoButton()'
                                  * once all the items has markdown description to render info icon
                                  * with markdown description
                                  */
            this.props.id === 'adp_api_usage' ?
            this.renderInfoButton() :
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InfoButton__WEBPACK_IMPORTED_MODULE_2__["default"], { tooltip: this.props.tooltip, tooltipPlacement: 'bottom' })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'team-usage-item-meta' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: this.getProgressColorClass() },
              this.props.usage, this.props.overage > 0 ? ` + ${this.props.overage}` : null), '/',

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, this.props.usageLimit))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ProgressBar__WEBPACK_IMPORTED_MODULE_3__["default"], { type: 'determinate', progress: this.getUsagePercentage(), className: this.getProgressColorClass() })));


  }}) || _class;

/***/ }),

/***/ 4808:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationFeedContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_notifications_NotificationFeed__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4809);
/* harmony import */ var _components_notifications_NotificationIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4814);
/* harmony import */ var _components_notifications_NotificationPanelHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4810);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1793);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _constants_SettingsTypeConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2876);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1763);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1789);
var _class;










let


NotificationFeedContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_7___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_10__["observer"])(_class = class NotificationFeedContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { isPanelOpen: false };

    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.togglePanel = this.togglePanel.bind(this);
    this.markAllAsRead = this.markAllAsRead.bind(this);
    this.loadMore = this.loadMore.bind(this);
  }

  handleClickOutside() {
    this.closePanel();
  }

  togglePanel() {
    this.state.isPanelOpen ? this.closePanel() : this.openPanel();
  }

  closePanel() {
    this.state.isPanelOpen && this.setState({ isPanelOpen: false }, () => {
      this.markAllAsRead();
    });
  }

  openPanel() {
    !this.state.isPanelOpen && this.setState({ isPanelOpen: true });
  }

  loadMore() {
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('TextMessageStore').loadMoreNotifications();
  }

  markAllAsRead() {
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('TextMessageStore').markNotificationsRead();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'notification' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_notifications_NotificationIcon__WEBPACK_IMPORTED_MODULE_2__["default"], {
            isPanelOpen: this.state.isPanelOpen,
            unreadCount: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('TextMessageStore').unreadCount,
            onToggle: this.togglePanel })),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_notifications_NotificationFeed__WEBPACK_IMPORTED_MODULE_1__["default"], {
          isPanelOpen: this.state.isPanelOpen,
          onToggle: this.togglePanel,
          onLoadMore: this.loadMore })));



  }}) || _class) || _class;

/***/ }),

/***/ 4809:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _NotificationPanelHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4810);
/* harmony import */ var _NotificationPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4811);



let

NotificationFeed = class NotificationFeed extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'notification-feed': true,
      'is-hidden': !this.props.isPanelOpen });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NotificationPanelHeader__WEBPACK_IMPORTED_MODULE_2__["default"], null),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NotificationPanel__WEBPACK_IMPORTED_MODULE_3__["default"],
        this.props)));



  }};

/***/ }),

/***/ 4810:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationPanelHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
let

NotificationPanelHeader = class NotificationPanelHeader extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-header' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'notification-panel-header__title' }, 'NOTIFICATIONS')));


  }};

/***/ }),

/***/ 4811:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationPanel; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1808);
/* harmony import */ var _NotificationItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4812);
/* harmony import */ var _NotificationEmptyItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4813);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1768);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2690);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1763);
var _class;







let

NotificationPanel = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class = class NotificationPanel extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {

  constructor(props) {
    super(props);
    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('TextMessageStore');
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollDebounced = _.debounce(this.handleScroll, 300);
  }

  handleScroll() {
    let node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    if (!this.store.endOfFeed && node.scrollTop + node.offsetHeight === node.scrollHeight) {
      this.props.onLoadMore && this.props.onLoadMore();
    }
  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_6__["default"].login();
  }

  render() {
    let notifications = _.filter(this.store.notifications, notification => {
      return _.get(notification, ['message', 'text']);
    });

    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').isLoggedIn) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-error-item' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-error-item__text' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                    className: 'signin-btn',
                    type: 'text',
                    size: 'small',
                    onClick: this.handleSignIn }, 'Sign In'),



                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, ' to view your notifications.'))))));





    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel', onScroll: this.handleScrollDebounced },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list' },

          _.isEmpty(notifications) ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NotificationEmptyItem__WEBPACK_IMPORTED_MODULE_4__["default"], null) :
          _.map(notifications, notification => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NotificationItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
                onAction: this.props.onAction,
                key: notification.id,
                notification: notification }));


          }),


          !_.isEmpty(notifications) && this.store.loading &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_2__["default"], { className: 'notification-panel-loader' }),


          this.store.endOfFeed && !_.isEmpty(notifications) &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-end' }, 'No more notifications'))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4812:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1783);
/* harmony import */ var _base_Avatar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2070);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3946);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1222);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);








/**
                                                                         * sends the analytic event for any clicks within a particular notification
                                                                         */
function sendAnalyticEvent() {
  _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEvent('notification', 'click', null, 1);
}let

NotificationItem = class NotificationItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleNotificationClick = this.handleNotificationClick.bind(this);
    this.handleNotificationMarkdownClick = this.handleNotificationMarkdownClick.bind(this);
    this.handleNotificationSummaryClick = this.handleNotificationSummaryClick.bind(this);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'notification-panel-list-item': true,
      'is-unread': this.props.notification.isUnread });

  }

  handleNotificationClick() {
    sendAnalyticEvent();
  }

  handleNotificationSummaryClick() {
    sendAnalyticEvent();
  }

  handleNotificationMarkdownClick(target) {
    const link = target.getAttribute('href');

    sendAnalyticEvent();
    link && Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__["openExternalLink"])(link);
  }

  render() {
    let formattedTime = _postman_date_helper__WEBPACK_IMPORTED_MODULE_4___default.a.getFormattedDateAndTime(this.props.notification.createdAt),
    message = _.get(this.props, 'notification.message.text'),
    messageSummary = _.get(this.props, 'notification.message.summary', '');

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses(), onClick: this.handleNotificationClick },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-item__body' },

          _.get(this.props.notification, 'variables.actor_id') &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-item__icon' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Avatar__WEBPACK_IMPORTED_MODULE_3__["default"], {
              type: 'user',
              userId: parseInt(_.get(this.props.notification, 'variables.actor_id')) })),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-item__content' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-item__content__text-markdown' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                source: message,
                handleClick: this.handleNotificationMarkdownClick })),



            messageSummary &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-item__content__text-message-summary', onClick: this.handleNotificationSummaryClick },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, messageSummary)),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-item__content__meta' },
              formattedTime)))));





  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4813:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function NotificationEmptyItem() {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-error-item' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'notification-panel-list-error-item__text' }, 'No new notifications')));




}

/***/ }),

/***/ 4814:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NotificationIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(748);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__);




let

NotificationIcon = class NotificationIcon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'notifications-button-icon': true,
      'pm-icon-header': true,
      'notifications-button-icon--unread': this.props.unreadCount !== 0 });

  }

  handleClick() {
    if (this.props.unreadCount !== 0) {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEvent('notification', 'view', null, this.props.unreadCount);
    }
    this.props.onToggle();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          type: 'icon',
          className: 'notifications-button',
          active: this.props.isPanelOpen,
          onClick: this.handleClick,
          tooltip: 'Notifications' },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-descriptive-notification-stroke', size: 'large', color: 'color-header-content', className: this.getClasses() })));


  }};

/***/ }),

/***/ 4815:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CaptureSettingsContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_capture_CaptureContainer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4816);
/* harmony import */ var _components_capture_CaptureIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4833);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1789);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1763);
var _class;






let



CaptureSettingsContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_3___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_7__["observer"])(_class = class CaptureSettingsContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      status: false,
      showTooltip: false,
      proxyStatus: false };


    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.togglePanel = this.togglePanel.bind(this);
    this.openProxySettingsModal = this.openProxySettingsModal.bind(this);
    this.CapturePanelUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CapturePanelUIStore');
  }

  handleClickOutside(e) {
    if (e.target.closest('.proxy-target-selector-menu') || e.target.closest('.interceptor-target-selector-menu')) {
      return;
    }

    // Avoids closing the capture panel if the click from the bootcamp interceptor lessons which are tooltips
    if (!e.target.closest('.tooltip')) {
      this.closePanel();
    }
  }

  togglePanel() {
    this.CapturePanelUIStore.isPanelOpen ? this.closePanel() : this.openPanel();
  }

  closePanel() {
    this.CapturePanelUIStore.isPanelOpen && this.CapturePanelUIStore.toggleCapturePanel(false);
  }

  openPanel() {
    !this.CapturePanelUIStore.isPanelOpen && this.CapturePanelUIStore.toggleCapturePanel(true);
  }

  UNSAFE_componentWillMount() {
    this.attachModelListeners();
    this.setState({ proxyStatus: pm.tcpReader.status });
  }

  componentWillUnmount() {
    this.detachModelListeners();
  }

  attachModelListeners() {
    pm.mediator.on('proxyStatusChanged', this.handleModelChange, this);
  }

  detachModelListeners() {
    pm.mediator.on('proxyStatusChanged', this.handleModelChange, this);
  }

  openProxySettingsModal(value) {
    pm.mediator.trigger('openProxySettingsModal');
  }

  handleModelChange() {
    this.setState({ proxyStatus: pm.tcpReader.status });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_4___default()('interceptor-button', { 'is-active': this.state.proxyStatus === 'connected' });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'capture-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__["default"], { identifier: 'proxy' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_capture_CaptureIcon__WEBPACK_IMPORTED_MODULE_2__["default"], {
            isPanelOpen: this.CapturePanelUIStore.isPanelOpen,
            onToggle: this.togglePanel })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__["default"], { identifier: 'CaptureSettingsFeed', isVisible: this.CapturePanelUIStore.isPanelOpen },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_capture_CaptureContainer__WEBPACK_IMPORTED_MODULE_1__["default"], {
            isPanelOpen: this.CapturePanelUIStore.isPanelOpen,
            onToggle: this.togglePanel }))));




  }}) || _class) || _class;

/***/ }),

/***/ 4816:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CaptureFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _CapturePanelHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4817);
/* harmony import */ var _CapturePanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4818);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1789);




let

CaptureFeed = class CaptureFeed extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'capture-feed': true,
      'is-hidden': !this.props.isPanelOpen });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: 'CaptureContainer' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CapturePanelHeader__WEBPACK_IMPORTED_MODULE_2__["default"], null),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CapturePanel__WEBPACK_IMPORTED_MODULE_3__["default"],
          this.props))));




  }};

/***/ }),

/***/ 4817:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CapturePanelHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
let

CapturePanelHeader = class CapturePanelHeader extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'capture-panel-header' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'capture-panel-header__title' }, 'Capture requests and cookies')));


  }};

/***/ }),

/***/ 4818:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CapturePanel; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2511);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1768);
/* harmony import */ var _status_bar_TypeSwitcher__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2097);
/* harmony import */ var _base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1794);
/* harmony import */ var _proxy_ProxySettingsTabs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4819);
/* harmony import */ var _proxy_ProxySettingsTabContents__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4820);
/* harmony import */ var _proxy_ProxySettingsTabContent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4821);
/* harmony import */ var _proxy_ProxySettingsConnection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4822);
/* harmony import */ var _proxy_ProxySettingsFilters__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4823);
/* harmony import */ var _interceptor_InterceptorSettingsTab__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4824);
/* harmony import */ var _proxy_InterceptorSettingsFilters__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4831);
/* harmony import */ var _interceptor_InterceptorConnectionIndicator__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4825);
/* harmony import */ var _interceptor_InterceptorSettingsConnection__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4832);
/* harmony import */ var _interceptor_InterceptorBridgeInstallation__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4828);
/* harmony import */ var _interceptor_InterceptorSnapWarning__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4830);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1875);
/* harmony import */ var vm__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(476);
/* harmony import */ var vm__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(vm__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(748);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(1789);
/* harmony import */ var _interceptor_InterceptorConnection__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4829);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;
























const STATUS_CONNECTING = 'connecting';
const STATUS_CONNECTED = 'connected';
const STATUS_DISCONNECTING = 'disconnecting';
const STATUS_DISCONNECTED = 'disconnected';
const DEFAULT_PORT = 5555;
const SHOW_FILTERS = 'Show additional filters';
const HIDE_FILTERS = 'Hide additional filters';let


CapturePanel = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class CapturePanel extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: 'Connection',
      connection: {
        port: DEFAULT_PORT,
        selectedTarget: {
          id: 'history',
          name: 'History' },

        filterItems: [],
        status: STATUS_DISCONNECTED },

      interceptorConnection: {
        selectedTarget: {
          id: 'history',
          name: 'History' },

        filterItems: [],
        status: STATUS_DISCONNECTED },


      isOpenfilterOptions: false,
      showFiltersStatus: SHOW_FILTERS,
      showInterceptorFiltersStatus: SHOW_FILTERS,
      isOpenInterceptorFilterOptions: false,
      filters: {
        url: '',
        url_disabled: '',
        methods: '' },

      activeItem: 'proxy' };


    this.handleTabSelect = this.handleTabSelect.bind(this);

    this.handleFilterChange = this.handleFilterChange.bind(this);
    this.handleFilterSave = this.handleFilterSave.bind(this);

    this.handleTargetSelect = this.handleTargetSelect.bind(this);
    this.handleInterceptorTargetSelect = this.handleInterceptorTargetSelect.bind(this);
    this.handleConnect = this.handleConnect.bind(this);
    this.handlePortChange = this.handlePortChange.bind(this);
    this.getFilterItems = this.getFilterItems.bind(this);
    this.handleProxyConnectionAttemptSuccess = this.handleProxyConnectionAttemptSuccess.bind(
    this);

    this.handleProxyConnectionAttemptFailed = this.handleProxyConnectionAttemptFailed.bind(
    this);

    this.handleProxyDisConnectionAttemptSuccess = this.handleProxyDisConnectionAttemptSuccess.bind(
    this);

    this.handleProxyDisConnectionAttemptFailed = this.handleProxyDisConnectionAttemptFailed.bind(
    this);

    this.handleShowFilters = this.handleShowFilters.bind(this);
    this.handleShowInterceptorFilters = this.handleShowInterceptorFilters.bind(this);
    this.handleActiveItem = this.handleActiveItem.bind(this);
    this.handleRequestCapture = this.handleRequestCapture.bind(this);
    this.handleFilterChangeInterceptor = this.handleFilterChangeInterceptor.bind(this);
    this.delayedSubmit = _.debounce(this.handleFilterSave, 500);
    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('InterceptorSettingsStore');
    this.CapturePanelUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('CapturePanelUIStore');
  }

  UNSAFE_componentWillMount() {
    this.model = pm.tcpReader;
    this.interceptorManager = pm.interceptorManager;
    this.setInitialValues();
    this.attachListeners();
  }

  componentWillUnmount() {
    this.detachListeners();
    this.model = null;
  }

  attachListeners() {
    pm.mediator.on(
    'proxyStartSuccess',
    this.handleProxyConnectionAttemptSuccess,
    this);

    pm.mediator.on(
    'proxyStartFailure',
    this.handleProxyConnectionAttemptFailed,
    this);

    pm.mediator.on(
    'proxyStopSuccess',
    this.handleProxyDisConnectionAttemptSuccess,
    this);

    pm.mediator.on(
    'proxyStopFailure',
    this.handleProxyDisConnectionAttemptFailed,
    this);

  }

  detachListeners() {
    pm.mediator.off(
    'proxyStartSuccess',
    this.handleProxyConnectionAttemptSuccess);

    pm.mediator.off(
    'proxyStartFailure',
    this.handleProxyConnectionAttemptFailed);

    pm.mediator.off(
    'proxyStopSuccess',
    this.handleProxyDisConnectionAttemptSuccess);

    pm.mediator.off(
    'proxyStopFailure',
    this.handleProxyDisConnectionAttemptFailed);

  }

  getCustomStyles() {
    return {
      marginTop: '15vh',
      height: '70vh' };

  }

  getKeyMapHandlers() {
    if (this.state.activeTab === 'Filters') {
      return { submit: pm.shortcuts.handle('submit', this.handleFilterSave) };
    }
    return { submit: pm.shortcuts.handle('submit', this.handleConnect) };
  }

  handleTabSelect(id) {
    if (id === this.CapturePanelUIStore.activeTab) {
      return;
    }
    this.CapturePanelUIStore.setActiveTab(id);
  }

  setInitialValues() {
    this.setState(prevState => {
      return {
        filters: this.model.filters,
        connection: _extends({},
        this.state.connection, {
          selectedTarget: {
            id: this.model.target_id },

          filterItems: this.getFilterItems(
          Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceStore').collections),

          status:
          this.model.status === 'connected' ?
          STATUS_CONNECTED :
          prevState.connection.status,
          port: pm.settings.getSetting('proxyPort') || DEFAULT_PORT }),

        interceptorConnection: _extends({},
        this.state.interceptorConnection, {
          selectedTarget: {
            id: this.store.requestCaptureTarget() === 'history' ? 'history' : this.store.requestCaptureTarget() } }) };



    });
  }

  /** Filter API's **/

  handleFilterSave() {
    let model = this.model;
    model.filters = this.state.filters;
    model.save();
  }

  handleFilterChange(key, value) {
    this.setState({
      filters: _extends({},
      this.state.filters, {
        [key]: value }) });


    this.delayedSubmit();
  }

  handleFilterChangeInterceptor(key, value) {
    this.setState({
      interceptorFilters: _extends({},
      this.state.interceptorFilters, {
        [key]: value }) });


  }

  /** Connections API's **/

  handleTargetSelect(value) {
    this.setState({
      connection: _extends({},
      this.state.connection, {
        selectedTarget: { id: value.id, name: value.name } }) });


    let model = this.model,
    target = value;

    _.assign(model, {
      target_type: target.id === 'history' ? 'history' : 'collection',
      target_id: target.id === 'history' ? 'history' : target.id });

    model.save();
  }

  handleInterceptorTargetSelect(value) {
    this.setState({
      interceptorConnection: _extends({},
      this.state.interceptorConnection, {
        selectedTarget: { id: value.id, name: value.name } }) });


    if (value.id === 'history') {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
        category: 'interceptor',
        action: 'update_capture_target',
        label: 'history' });

    } else
    if (value.id === 'collection') {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
        category: 'interceptor',
        action: 'update_capture_target',
        label: 'collection' });

    }
    pm.interceptorBridge.requestCapture.updateTarget(value);
  }

  handleConnect() {
    let model = this.model,
    target = this.state.connection.selectedTarget;

    if (target === null) {
      pm.toasts.error('Select a target to proceed');
      return;
    }

    _.assign(model, {
      target_type: target.id === 'history' ? 'history' : 'collection',
      target_id: target.id === 'history' ? 'history' : target.id,
      port: this.state.connection.port });

    model.save();

    if (this.state.connection.status === STATUS_CONNECTED) {
      model.disconnect();
      this.setState({
        connection: _extends({},
        this.state.connection, {
          status: STATUS_DISCONNECTING }) });


      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
        category: 'proxy',
        action: 'stop_proxy',
        label: 'toggle' });

    } else if (this.state.connection.status === STATUS_DISCONNECTED) {
      model.connect();
      this.setState({
        connection: _extends({},
        this.state.connection, {
          status: STATUS_CONNECTING }) });


      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
        category: 'proxy',
        action: 'start_proxy',
        label: 'toggle' });

    }
  }

  handlePortChange(value) {
    this.setState({
      connection: _extends({},
      this.state.connection, {
        port: value }) });



    pm.settings.setSetting('proxyPort', value);
  }

  getFilterItems(collections) {
    let historyObjArray = [
    {
      id: 'history',
      name: 'History' }];


    let filterItems = _.chain(collections).
    filter(collection =>
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('PermissionStore').can('edit', 'collection', collection.id)).

    map(collection => {
      let collectionItem = {
        type: 'collection',
        id: collection.id,
        name: 'Collection: ' + collection.name };

      return collectionItem;
    }).
    value();

    return historyObjArray.concat(filterItems);
  }

  handleProxyConnectionAttemptSuccess() {
    this.setState({
      connection: _extends({},
      this.state.connection, {
        status: STATUS_CONNECTED }) });


    pm.toasts.success('Proxy Connected');
  }

  handleProxyConnectionAttemptFailed() {
    pm.toasts.error('Proxy Connection failed');
    this.setState({
      connection: _extends({},
      this.state.connection, {
        status: STATUS_DISCONNECTED }) });


    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
      category: 'proxy',
      action: 'attempt_failed',
      label: 'connection' });

  }

  handleShowFilters() {
    if (this.state.isOpenfilterOptions) {
      this.setState({
        showFiltersStatus: SHOW_FILTERS });

    } else
    {
      this.setState({
        showFiltersStatus: HIDE_FILTERS });

    }
    this.setState(prevState => ({
      isOpenfilterOptions: !prevState.isOpenfilterOptions }));

  }

  handleShowInterceptorFilters() {
    if (this.state.isOpenInterceptorFilterOptions) {
      this.setState({
        showInterceptorFiltersStatus: SHOW_FILTERS });

    } else
    {
      this.setState({
        showInterceptorFiltersStatus: HIDE_FILTERS });

    }
    this.setState(prevState => ({
      isOpenInterceptorFilterOptions: !prevState.isOpenInterceptorFilterOptions }));

  }

  handleProxyDisConnectionAttemptSuccess() {
    pm.toasts.success('Proxy Disconnected');
    this.setState({
      connection: _extends({},
      this.state.connection, {
        status: STATUS_DISCONNECTED }) });


  }

  handleProxyDisConnectionAttemptFailed() {
    pm.toasts.error('Proxy Disconnection failed');
    this.setState({
      connection: _extends({},
      this.state.connection, {
        status: STATUS_CONNECTED }) });


  }

  getSwitcherClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_4___default()({
      'plugin__workspace-view-switcher__wrapper': true,
      'plugin__workspace-view-switcher': true,
      'capture_request_source_switcher': true });

  }

  handleActiveItem() {
    if (this.state.activeItem === 'proxy') {
      this.setState({
        activeItem: 'interceptor' });

    } else {
      this.setState({
        activeItem: 'proxy' });

    }
  }

  handleRequestCapture(newState) {
    if (newState) {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
        category: 'interceptor',
        action: 'enable_request_capture' });

      pm.interceptorBridge.requestCapture.enable();

    } else
    {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_21__["default"].addEventV2({
        category: 'interceptor',
        action: 'disable_request_capture' });

      pm.interceptorBridge.requestCapture.disable();
    }
  }

  handleLearnMore() {
    pm.app.openExternalLink(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_19__["CAPTURE_HTTP_REQUESTS_DOCS_URL"]);
  }

  render() {
    let status = this.state.connection.status;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_22__["default"], { identifier: 'CapturePanel' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'modal proxy-modal' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-panel-list' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_7__["default"], {
                keyMap: pm.shortcuts.getShortcuts(),
                handlers: this.getKeyMapHandlers() },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'settings-container modal proxy-modal' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_ProxySettingsTabs__WEBPACK_IMPORTED_MODULE_8__["default"], {
                  activeTab: this.CapturePanelUIStore.activeTab,
                  onSelect: this.handleTabSelect }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_ProxySettingsTabContents__WEBPACK_IMPORTED_MODULE_9__["default"], { activeKey: this.CapturePanelUIStore.activeTab },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_ProxySettingsTabContent__WEBPACK_IMPORTED_MODULE_10__["default"], { key: 'Connection' },
                    this.state.activeItem === 'interceptor' ?
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'capture_requests_learn_more' }, 'Capture requests from your browser with the Interceptor.',

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                          className: 'external-link',
                          onClick: this.handleLearnMore }, '\xA0Learn more about capturing requests.')) :




                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'capture_requests_learn_more' }, 'Capture requests from any device or browser with Postman\'s built-in proxy.',

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                          className: 'external-link',
                          onClick: this.handleLearnMore }, '\xA0Learn more about capturing requests.')),





                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'capture-requests-source-label' }, 'Source'),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getSwitcherClasses() },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_status_bar_TypeSwitcher__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        activeItem: this.state.activeItem,
                        onSelect: this.handleActiveItem,
                        items: [
                        {
                          key: 'proxy',
                          label: 'Proxy',
                          position: 'right' },

                        {
                          key: 'interceptor',
                          label: 'Interceptor',
                          position: 'left' }] })),




                    this.state.activeItem === 'interceptor' ?
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-requests-label' }, 'Capture Requests'),


                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-requests-menu' },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-requests-menu__left' },
                          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-requests-toggle-label' },
                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_3__["default"], {
                              isActive: this.store.captureRequestEnabled,
                              onClick: this.handleRequestCapture,
                              activeLabel: 'ON',
                              inactiveLabel: 'OFF' }))),



                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-requests-menu__right' },
                          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_interceptor_InterceptorConnection__WEBPACK_IMPORTED_MODULE_23__["default"], null),
                          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_interceptor_InterceptorConnectionIndicator__WEBPACK_IMPORTED_MODULE_15__["default"], null))),


                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_interceptor_InterceptorSettingsConnection__WEBPACK_IMPORTED_MODULE_16__["default"], _extends({},
                        this.state.interceptorConnection, {
                          filterItems: this.getFilterItems(
                          Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceStore').collections),

                          onTargetSelect: this.handleInterceptorTargetSelect }))),


                      this.store.connectionStatus ?
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                            className: 'btn btn-text proxy-show-filters-btn',
                            onClick: this.handleShowInterceptorFilters },

                          this.state.showInterceptorFiltersStatus),

                        this.state.isOpenInterceptorFilterOptions ?
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_InterceptorSettingsFilters__WEBPACK_IMPORTED_MODULE_14__["default"], null) :
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null)) :

                      pm.env.SNAP ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_interceptor_InterceptorSnapWarning__WEBPACK_IMPORTED_MODULE_18__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_interceptor_InterceptorBridgeInstallation__WEBPACK_IMPORTED_MODULE_17__["default"], null)) :


                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-capture-requests-label' }, 'Capture Requests'),


                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        activeLabel: 'ON',
                        inactiveLabel: 'OFF',
                        isActive: _.isEqual(status, STATUS_CONNECTED),
                        onClick: this.handleConnect }),

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_ProxySettingsConnection__WEBPACK_IMPORTED_MODULE_11__["default"], _extends({},
                      this.state.connection, {
                        filterItems: this.getFilterItems(
                        Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceStore').collections),

                        onPortChange: this.handlePortChange,
                        onTargetSelect: this.handleTargetSelect })),

                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                          className: 'btn btn-text proxy-show-filters-btn',
                          onClick: this.handleShowFilters },

                        this.state.showFiltersStatus),

                      this.state.isOpenfilterOptions ?
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-save-filters' },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_ProxySettingsFilters__WEBPACK_IMPORTED_MODULE_12__["default"], {
                          filters: this.state.filters,
                          onFilterChange: this.handleFilterChange })) :


                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null))),




                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_proxy_ProxySettingsTabContent__WEBPACK_IMPORTED_MODULE_10__["default"], { key: 'Cookies' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_22__["default"], { identifier: 'InterceptorCookies' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_interceptor_InterceptorSettingsTab__WEBPACK_IMPORTED_MODULE_13__["default"], null))))))))));









  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4819:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxySettingsTabs; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Tabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1791);

let

ProxySettingsTabs = class ProxySettingsTabs extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleSelect = this.handleSelect.bind(this);
  }

  handleSelect(id) {
    this.props.onSelect && this.props.onSelect(id);
  }

  render() {

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'capture-modal-title modal proxy-modal' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tabs"], {
            type: 'primary',
            defaultActive: 'Connection',
            activeRef: this.props.activeTab,
            onChange: this.handleSelect,
            className: 'tabs tabs-primary capture-settings-tabs' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'Connection' }, 'Requests'),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_1__["Tab"], { refKey: 'Cookies' }, 'Cookies', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'interceptor-capture-cookies-beta-label' }, 'BETA')))));



  }};

/***/ }),

/***/ 4820:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxySettingsTabContents; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
let

ProxySettingsTabContents = class ProxySettingsTabContents extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {

    let children = react__WEBPACK_IMPORTED_MODULE_0___default.a.Children.map(this.props.children, child => {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, { active: this.props.activeKey === child.key });
    });
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-contents' },
        children));


  }};

/***/ }),

/***/ 4821:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxySettingsTabContent; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);

let

ProxySettingsTabContent = class ProxySettingsTabContent extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()(
    'proxy-settings-content',
    { 'is-hidden': !this.props.active },
    this.props.className);

  }

  render() {

    let classes = this.getClasses();

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: classes },
        this.props.children));


  }};

/***/ }),

/***/ 4822:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxySettingsConnection; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1882);
/* harmony import */ var _base_InputSelectV2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2543);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1789);
/* harmony import */ var _base_SearchHighlighter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2506);




let

ProxySettingsConnection = class ProxySettingsConnection extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.selectedTarget = this.selectedTarget.bind(this);
  }

  getFilteredList(list, query, options = {}) {

    if (!query || options.firstRender) {
      return list;
    }

    return _.filter(list, item => {
      return item.id && _.includes(item.name.toLowerCase(), query.toLowerCase());
    });
  }

  selectedTarget() {
    var filterItems = this.props.filterItems,
    selectedTarget = this.props.selectedTarget,
    modifiedSelectedTarget = _.find(filterItems, item => {return item.id === selectedTarget.id;});

    // handle renaming and deletion of selected item.

    if (modifiedSelectedTarget) {
      return modifiedSelectedTarget;
    } else
    {

      return {
        id: 'history',
        name: 'History' };

    }
  }

  getOption(item, search, option = {}) {
    const name = item.name,
    id = item.id;
    if (search && !option.firstRender) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'input-select-item',
              key: id },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_SearchHighlighter__WEBPACK_IMPORTED_MODULE_4__["default"], {
              source: name,
              query: search }))));




    }
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'input-select-item', key: id }, name));
  }

  render() {
    var { filterItems } = this.props;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-connection-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-connection-group' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-label' }, ' Port '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
              inputStyle: 'box',
              type: 'text',
              value: this.props.port,
              className: 'proxy-settings-connection-input',
              onChange: this.props.onPortChange,
              disabled: this.props.status !== 'disconnected' }))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-connection-group' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-label' }, 'Save Requests to'),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InputSelectV2__WEBPACK_IMPORTED_MODULE_2__["InputSelectV2"], {
              style: { width: '100%' },
              onSelect: this.props.onTargetSelect,
              getFilteredList: this.getFilteredList.bind(this, filterItems),
              optionRenderer: this.getOption,
              selectedItem: this.selectedTarget(),
              ref: 'inputSelect',
              menuClassName: 'proxy-target-selector-menu',
              getInputValue: listObj => {
                return listObj.name || '';
              } })))));





  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4823:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxySettingsFilters; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1882);

let

ProxySettingsFilters = class ProxySettingsFilters extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {

    let filters = this.props.filters;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-group' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-label' }, ' URL Contains '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-input' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
              inputStyle: 'box',
              type: 'text',
              value: filters.url,
              onChange: this.props.onFilterChange.bind(this, 'url') }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-input-help' }, 'Regular expressions are supported'))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-group' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-label' }, ' URL Does not contain '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-input' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
              inputStyle: 'box',
              type: 'text',
              value: filters.url_disabled,
              onChange: this.props.onFilterChange.bind(this, 'url_disabled') }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-input-help' }, 'Regular expressions are supported. For example, to exclude multiple strings use google|dropbox|github'))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-group' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-label' }, ' Methods '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-input' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
              inputStyle: 'box',
              type: 'text',
              value: filters.methods,
              onChange: this.props.onFilterChange.bind(this, 'methods') }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'proxy-settings-filters-input-help' }, 'Separate using commas. Example PUT,GET,POST')))));






  }};

/***/ }),

/***/ 4824:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InterceptorSettingsTab; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1882);
/* harmony import */ var _base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2511);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _base_InfoButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2496);
/* harmony import */ var _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4087);
/* harmony import */ var _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1875);
/* harmony import */ var _InterceptorConnectionIndicator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4825);
/* harmony import */ var _InterceptorSettingsDomainListContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4826);
/* harmony import */ var _InterceptorBridgeInstallation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4828);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(748);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1222);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1789);
/* harmony import */ var _onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2559);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1883);
/* harmony import */ var _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1612);
/* harmony import */ var _InterceptorConnection__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4829);
/* harmony import */ var _InterceptorSnapWarning__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4830);
var _class;


















let


InterceptorSettingsTab = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class InterceptorSettingsTab extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

  constructor(props) {

    super(props);

    this.state = {
      domain: '',
      text: '' };


    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('InterceptorSettingsStore');
    this.interceptorUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('InterceptorInstallationUIStore');
    this.handleChange = this.handleChange.bind(this);
    this.handleAddDomain = this.handleAddDomain.bind(this);
    this.handleEnableCookieSync = this.handleEnableCookieSync.bind(this);
    this.getKeyMapHandlers = this.getKeyMapHandlers.bind(this);
    this.handleShowMeHow = this.handleShowMeHow.bind(this);
    this.handleClose = this.handleClose.bind(this);

    _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_17__["default"].get('capturingCookiesThroughInterceptor').
    then(data => {
      if (data) {
        this.interceptorUIStore.updateBannerState(false);
      }
    }).
    catch(e => {
      pm.logger.warn('Couldn\'t get capturingCookiesThroughInterceptor variable', e);
    });

    _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_17__["default"].get('actionOnInterceptorLesson').
    then(data => {
      if (data) {
        this.interceptorUIStore.updateBannerState(false);
      }
    }).
    catch(e => {
      pm.logger.warn('Couldn\'t get actionOnInterceptorLesson variable', e);
    });

  }

  handleAddDomain() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2({
      category: 'interceptor',
      action: 'add_cookie_domain' });

    pm.interceptorBridge.cookieSync.addDomain(this.state.domain);

    this.setState({
      text: '',
      domain: '' });


    if (this.interceptorUIStore.showBanner) {
      _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_17__["default"].set('capturingCookiesThroughInterceptor', true);
    }

  }

  handleChange(value) {
    this.setState({
      domain: value,
      text: value });

  }

  handleEnableCookieSync() {
    if (!this.store.cookieSyncEnabled) {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2({
        category: 'interceptor',
        action: 'enable_cookie_sync' });

      pm.interceptorBridge.cookieSync.enable();
    } else
    {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2({
        category: 'interceptor',
        action: 'disable_cookie_sync' });

      pm.interceptorBridge.cookieSync.disable();
    }
  }

  getKeyMapHandlers() {
    return {
      submit: pm.shortcuts.handle('submit', this.handleAddDomain) };

  }

  handleLearnMore() {
    Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_13__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["CAPTURE_HTTP_REQUESTS_DOCS_URL"]);
  }

  handleClose() {
    _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_17__["default"].set('actionOnInterceptorLesson', true);
    this.interceptorUIStore.updateBannerState(false);
  }

  handleShowMeHow() {
    _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_17__["default"].set('actionOnInterceptorLesson', true);
    this.interceptorUIStore.updateBannerState(false);

    if (this.store.connectionStatus) {
      Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_15__["runTaggedLesson"])('interceptor-cookies-lesson', {
        signInModalOptions: {
          type: 'interceptorCookies',
          origin: 'from_manage_cookies' } });


    } else
    {
      if (this.store.interceptorInstalledStatus) {
        Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_15__["runTaggedLesson"])('interceptor-not-connected-cookies-lesson', {
          signInModalOptions: {
            type: 'interceptorCookies',
            origin: 'from_manage_cookies' } });


      } else
      {
        Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_15__["runTaggedLesson"])('interceptor-not-installed-cookies-lesson', {
          signInModalOptions: {
            type: 'interceptorCookies',
            origin: 'from_manage_cookies' } });


      }
    }
  }


  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-wrapper' },
        this.interceptorUIStore.showBanner &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bootcamp-lesson-banner' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'interceptor-bootcamp-lesson-banner-description' }, 'Learn how to capture cookies with interceptor'),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                className: 'interceptor-bootcamp-lesson-banner-button',
                type: 'text',
                onClick: this.handleShowMeHow }, 'Start Lesson'),



            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_16__["default"], {
              className: 'interceptor-bootcamp-lesson-banner--dismiss',
              size: 'xs',
              onClick: this.handleClose }))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_capture_cookies_learn_more' }, 'Capture cookies from any domain to use in Postman requests with the Interceptor.',

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
              className: 'external-link',
              onClick: this.handleLearnMore }, '\xA0Learn more about capturing cookies.')),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-cookies-label' }, 'Capture Cookies'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-cookies-menu' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-cookies-menu__left' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-cookies-menu-toggle' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'CaptureCookies' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_3__["default"], {
                  isActive: this.store.cookieSyncEnabled,
                  onClick: this.handleEnableCookieSync,
                  activeLabel: 'ON',
                  inactiveLabel: 'OFF' })))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-cookies-menu__right' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InterceptorConnection__WEBPACK_IMPORTED_MODULE_18__["default"], null),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'InterceptorConnection' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InterceptorConnectionIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], null)))),



        this.store.connectionStatus ?
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-cookies-label' }, 'Domains',

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InfoButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
              tooltip: 'Domains can be root domains (domain.com) or subdomains (sub.domain.com). Adding a domain will automatically sync all cookies for its subdomains as well.',
              tooltipPlacement: 'right' })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-add-domain' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-domain-input' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'DomainInput' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_2__["Input"], {
                  inputStyle: 'box',
                  type: 'text',
                  value: this.state.text,
                  disabled: !this.store.connectionStatus,
                  onSubmit: this.handleAddDomain,
                  placeholder: 'Enter a domain to capture cookies',
                  onChange: value => {this.handleChange(value);} }))),



            this.store.connectionStatus ?
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'AddDomain' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], { className: 'btn-secondary btn-small btn-fluid', type: 'secondary', onClick: this.handleAddDomain }, ' Add Domain ')) :


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], { className: 'btn-secondary btn-small btn-fluid is-disabled', type: 'secondary', onClick: this.handleAddDomain }, ' Add Domain ')),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InterceptorSettingsDomainListContainer__WEBPACK_IMPORTED_MODULE_10__["default"], null)) :

        pm.env.SNAP ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InterceptorSnapWarning__WEBPACK_IMPORTED_MODULE_19__["default"], null) :
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_14__["default"], { identifier: 'InterceptorInstallation' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InterceptorBridgeInstallation__WEBPACK_IMPORTED_MODULE_11__["default"], null))));





  }}) || _class;

/***/ }),

/***/ 4825:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
var _class;

let


InterceptorConnectionIndicator = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class InterceptorConnectionIndicator extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('InterceptorSettingsStore');
  }

  render() {
    let connectionDot;

    if (this.store.connectionStatus) {
      connectionDot = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'interceptor-bridge-connected-dot' });

    } else
    {
      connectionDot = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'interceptor-bridge-disconnected-dot' });
    }
    return connectionDot;
  }}) || _class;


/* harmony default export */ __webpack_exports__["default"] = (InterceptorConnectionIndicator);

/***/ }),

/***/ 4826:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4087);
/* harmony import */ var _models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_models_InterceptorBridge__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _InterceptorSettingsDomainListItems__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4827);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
var _class;



let


InterceptorSettingsDomainListContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class InterceptorSettingsDomainListContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

  constructor(props) {
    super(props);
  }

  render() {

    let store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('InterceptorSettingsStore');

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InterceptorSettingsDomainListItems__WEBPACK_IMPORTED_MODULE_2__["default"], null)));


  }}) || _class;


/* harmony default export */ __webpack_exports__["default"] = (InterceptorSettingsDomainListContainer);

/***/ }),

/***/ 4827:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1883);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(748);
var _class, _class2;



let


DomainListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class DomainListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
    constructor(props) {
        super(props);
    }

    render() {
        let store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('InterceptorSettingsStore');
        if (store && store.domainList instanceof Array) {
            let rows = store.domainList.map((domain, index) => {
                return (
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-domain-list-item', key: index },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-domain-list-item-label' },
                            domain),

                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-domain-list-item-value' },
                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_1__["default"], { className: 'intereceptor-remove-domain-btn', size: 'xs', onClick: () => {
                                    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEventV2({
                                        category: 'interceptor',
                                        action: 'remove_cookie_domain' });

                                    pm.interceptorBridge.cookieSync.removeDomain(store.domainList[index]);
                                } }))));




            });
            return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, rows);
        }
        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null);
    }}) || _class;let




InterceptorSettingsDomainListItems = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class2 = class InterceptorSettingsDomainListItems extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

    constructor(props) {
        super(props);
    }

    render() {

        return (
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-domain-list-wrapper' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-domain-list' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(DomainListItem, null))));



    }}) || _class2;


/* harmony default export */ __webpack_exports__["default"] = (InterceptorSettingsDomainListItems);

/***/ }),

/***/ 4828:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InterceptorBridgeInstallation; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _base_ProgressBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2504);
/* harmony import */ var _base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2060);
/* harmony import */ var _models_InterceptorInstaller__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4312);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1222);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1875);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(748);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1789);
/* harmony import */ var _constants_SettingsTypeConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2876);
var _class;












const CHROME_WEB_STORE = 'https://chrome.google.com/webstore/detail/' + window.INTERCEPTOR_ID;

const BridgeNotYetInstalled = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-label' }, 'Capture requests with Interceptor'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_info' }, 'The Interceptor Bridge connects the Postman app with the browser extension.'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'BridgeInstall' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: 'primary',
            size: 'large',
            onClick: installInterceptorBridge }, 'Install Interceptor Bridge'))));





};

const BridgeDownloadInProgress = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-label' }, 'Capture requests with Interceptor'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_info' }, 'The Interceptor Bridge connects the Postman app with the browser extension.'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_progress_info' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ProgressBar__WEBPACK_IMPORTED_MODULE_3__["default"], null),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_status_message' }, 'DOWNLOADING BRIDGE...'))));



};

const BridgeInstallationInProgress = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-label' }, 'Capture requests with Interceptor'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_info' }, 'The Interceptor Bridge connects the Postman app with the browser extension.'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_progress_info' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ProgressBar__WEBPACK_IMPORTED_MODULE_3__["default"], null),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_status_message' }, 'INSTALLING BRIDGE...'))));



};

const Done = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-label' }, 'Installation complete! Connecting to Interceptor...'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_info' }, 'Install the browser extension from the\xA0',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
            className: 'external-link',
            onClick: () => Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(CHROME_WEB_STORE) }, 'Chrome Web Store.'))));






};

const ErrorInDownload = props => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-label' }, 'DOWNLOAD FAILED',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'bridge-installation-error-icon' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null))),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_error_info' }, 'Something went wrong while downloading Interceptor Bridge. Read our\xA0',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
            className: 'external-link',
            onClick: () => Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["INTERCEPTOR_TROUBLESHOOTING_DOC"]) }, 'troubleshooting doc'), '\xA0for more information.'),





      props.errorCode && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-code-label' }, ' ERROR CODE: ', props.errorCode),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          type: 'primary',
          size: 'large',
          onClick: installInterceptorBridge }, 'Retry Download')));





};

const ErrorInInstallation = props => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-label' }, 'COULDN\'T INSTALL',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'bridge-installation-error-icon' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null))),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_error_info' }, 'Postman doesn\'t have the required permissions to install Node.js and other dependencies. Read our\xA0',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
            className: 'external-link',
            onClick: () => Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["INTERCEPTOR_TROUBLESHOOTING_DOC"]) }, 'troubleshooting doc'), '\xA0for more information.'),





      props.errorCode && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-code-label' }, 'ERROR CODE: ', props.errorCode),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          type: 'primary',
          size: 'large',
          onClick: () => pm.interceptorInstaller.installInterceptorBridge() }, 'Retry Installation')));





};

const NodeInstallationError = props => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-label' }, 'COULDN\'T INSTALL',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'bridge-installation-error-icon' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null))),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_error_info' }, 'Postman doesn\'t have the required permissions to install Node.js and other dependencies. Read our\xA0',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
            className: 'external-link',
            onClick: () => Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["INTERCEPTOR_TROUBLESHOOTING_DOC"]) }, 'troubleshooting doc'), '\xA0for more information.'),





      props.errorCode && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-code-label' }, 'ERROR CODE: ', props.errorCode),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          type: 'primary',
          size: 'large',
          onClick: () => pm.interceptorInstaller.installNode() }, 'Retry Installation')));





};

const MacOsNodeNotYetInstalled = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-label' }, 'Capture requests with Interceptor'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_info' }, 'The Interceptor Bridge connects the Postman app with the browser extension.'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: 'NodeInstall' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: 'primary',
            size: 'large',
            onClick: () => pm.interceptorInstaller.installNode() }, 'Install Interceptor Bridge'))));





};

const NodeDownloadInProgress = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-label' }, 'Capture requests with Interceptor'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_info' }, 'The Interceptor Bridge connects the Postman app with the browser extension.'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_progress_info' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ProgressBar__WEBPACK_IMPORTED_MODULE_3__["default"], null),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_status_message' }, 'DOWNLOADING NODE.JS...'))));



};

const NodeDownloaded = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-label' }, 'NODE.JS REQUIRED TO COMPLETE INSTALLATION'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_error_info' }, 'Complete the Node.js installation from the pop-up. The Bridge installation will resume automatically once you\'re done.')));



};


const NodeError = props => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-label' }, 'NODE.JS DOWNLOAD FAILED',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'bridge-installation-error-icon' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null))),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_error_info' }, 'Something went wrong while downloading the Node.js package. Read our\xA0',

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
            className: 'external-link',
            onClick: () => Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["INTERCEPTOR_TROUBLESHOOTING_DOC"]) }, 'troubleshooting doc'), '\xA0for more information.'),





      props.errorCode && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-code-label' }, 'ERROR CODE:  ', props.errorCode),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          type: 'primary',
          size: 'large',
          onClick: () => pm.interceptorInstaller.installNode() }, 'Retry Download')));





};

const NodeNotInstalled = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-bridge-installation-error-label' }, 'NODE.JS REQUIRED TO COMPLETE INSTALLATION'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_bridge_installation_error_info' }, 'Complete the Node.js installation from the pop-up. The Bridge installation will resume automatically once you\'re done.'),


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          type: 'primary',
          size: 'large',
          onClick: () => pm.interceptorInstaller.installInterceptorBridge() }, 'Retry Node.js Installation')));




};

const INSTALLATION_STATES = props => ({
  BRIDGE_NOT_YET_INSTALLED: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(BridgeNotYetInstalled, null),
  DONE: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Done, null),
  ERR_DOWNLOAD: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ErrorInDownload, { errorCode: props }),
  ERR_INSTALLATION: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ErrorInInstallation, { errorCode: props }),
  MACOS_NODE_NOT_YET_INSTALLED: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(MacOsNodeNotYetInstalled, null),
  NODE_DOWNLOAD_IN_PROGRESS: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(NodeDownloadInProgress, null),
  NODE_DOWNLOADED: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(NodeDownloaded, null),
  NODE_ERROR: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(NodeError, { errorCode: props }),
  NODE_INSTALLATION_ERROR: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(NodeInstallationError, { errorCode: props }),
  NODE_NOT_INSTALLED: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(NodeNotInstalled, null),
  BRIDGE_INSTALLATION_IN_PROGRESS: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(BridgeInstallationInProgress, null),
  BRIDGE_DOWNLOAD_IN_PROGRESS: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(BridgeDownloadInProgress, null) });



/**
                                                                                        * Calls api to install interceptor bridge
                                                                                        */
function installInterceptorBridge() {
  _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
    category: 'interceptor',
    action: 'initiate_installation' });

  pm.interceptorInstaller.installInterceptorBridge();
}


/**
   * decides which installation state to display
   */
function InstallationStates({ state, data }) {
  // sending error codes as props to enum
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null, INSTALLATION_STATES(data)[state]);
}let


InterceptorBridgeInstallation = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class InterceptorBridgeInstallation extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {

    super(props);

    this.interceptorStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('InterceptorSettingsStore');
    this.interceptorUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('InterceptorInstallationUIStore');
    this.settingsModalUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SettingsModalUIStore');
    this.capturePanelUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CapturePanelUIStore');

    this.state = {
      ERR_CODE: '' };


    this.installInterceptorBridge = this.installInterceptorBridge.bind(this);

    // events for intermediate states of Interceptor Bridge installation
    pm.appWindow.trigger('registerInternalEvent', 'interceptorBridgeInstallationStatusUpdate', function (data) {
      if (data.status === 'downloadStarted') {
        this.interceptorUIStore.updateInstallationStates('BRIDGE_DOWNLOAD_IN_PROGRESS');
      } else
      if (data.status === 'installationStarted') {
        this.interceptorUIStore.updateInstallationStates('BRIDGE_INSTALLATION_IN_PROGRESS');
      } else
      if (data.status === 'installationFinished') {
        this.interceptorUIStore.updateInstallationStates('DONE');
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
          category: 'interceptor',
          action: 'complete_installation' });


        // from the app checking bridge installation for every 3 secs
        // and the extension is checking for the same every 5 secs
        setTimeout(() => {
          this.interceptorStore.updateInterceptorBridgeInstallationStatus(true);
        }, 8000);
      } else
      if (data.status === 'error') {
        if (data.type === 'installation') {
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
            category: 'interceptor',
            action: 'error_installation',
            label: 'bridge' });

        } else
        if (data.type === 'download') {
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
            category: 'interceptor',
            action: 'error_download',
            label: 'bridge' });

        }
        if (data.subType) {
          this.setState({
            ERR_CODE: data.subType });

        } else
        {
          this.setState({
            ERR_CODE: '' });

        }
        this.interceptorUIStore.updateErrorState(data.type, 'bridge', data.errorMessage);
      }
    }, this);

    // events for intermediate states of downloading node....
    pm.appWindow.trigger('registerInternalEvent', 'nodeInstallationStatusUpdate', function (data) {
      if (data.status === 'downloadStarted') {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
          category: 'interceptor',
          action: 'download_started',
          label: 'node' });

        this.interceptorUIStore.updateNodeInstallationStatus('NODE_DOWNLOAD_IN_PROGRESS');
      } else
      if (data.status === 'downloadFinished') {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
          category: 'interceptor',
          action: 'download_finished',
          label: 'node' });

        this.interceptorUIStore.updateNodeInstallationStatus('NODE_DOWNLOADED');
      } else
      if (data.status === 'installationFinished') {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
          category: 'interceptor',
          action: 'installation_finished',
          label: 'node' });

        this.installInterceptorBridge();
      } else
      if (data.status === 'installationNotFinished') {
        this.interceptorUIStore.updateNodeInstallationStatus('NODE_NOT_INSTALLED');
      } else
      if (data.status === 'error') {
        // check for the node error types.
        if (data.type === 'installation') {
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
            category: 'interceptor',
            action: 'error_installation',
            label: 'node' });

          this.interceptorUIStore.updateErrorState('installation', 'node', data.errorMessage);
        } else
        if (data.type === 'download') {
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
            category: 'interceptor',
            action: 'error_download',
            label: 'node' });

          this.interceptorUIStore.updateErrorState('nodeDownload', 'node', data.errorMessage);
        }
        if (data.subType) {
          this.setState({
            ERR_CODE: data.subType });

        } else
        {
          this.setState({
            ERR_CODE: '' });

        }
      }
    }, this);

  }

  // Calls api to install interceptor bridge
  installInterceptorBridge() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_9__["default"].addEventV2({
      category: 'interceptor',
      action: 'initiate_installation' });

    pm.interceptorInstaller.installInterceptorBridge();
  }

  // Function to show external links
  handleLearnMore() {
    Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["INTERCEPTOR_DOCS_URL"]);
  }

  // Function which takes user to learning center
  openLearningCenter() {
    Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["UPDATE_INTERCEPTOR_DOCS_URL"]);
  }

  openSettingsModal() {
    this.capturePanelUIStore.toggleCapturePanel(false);
    this.settingsModalUIStore.toggleSettingsModal(true);
    this.settingsModalUIStore.setActiveTab(_constants_SettingsTypeConstants__WEBPACK_IMPORTED_MODULE_11__["SETTINGS_UPDATE"]);
  }

  render() {
    return (
      this.interceptorStore.minVersionSatisfied ?
      this.interceptorStore.interceptorInstalledStatus ?
      !this.interceptorStore.connectionStatus &&
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-connection-error-label' }, 'No connection to Interceptor'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor_connection_error_info' }, 'Make sure your browser is open and you\'ve installed the',

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
              className: 'external-link',
              onClick: this.handleLearnMore }, '\xA0Interceptor extension.'))) :





      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(InstallationStates, { state: this.interceptorUIStore.installationStatus, data: this.state.ERR_CODE }) :
      this.interceptorStore.minExtensionVersionSatisfied ?
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app_min_version_error' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app_min_version_error_label' }, 'POSTMAN APP UPDATE REQUIRED',

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'app_min_version_error_label__icon' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app_min_version_error_info' }, 'To continue using the Interceptor extension, go to settings and update your Postman desktop app to v',
          this.interceptorStore.minAppVersion, ' or greater.'),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: 'primary',
            size: 'large',
            onClick: () => this.openSettingsModal() }, 'Open Settings')) :



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app_min_version_error' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app_min_version_error_label' }, 'INTERCEPTOR UPDATE REQUIRED',

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'app_min_version_error_label__icon' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'app_min_version_error_info' }, 'This version of Interceptor isn\u2019t compatible with the current version of the Postman app. Update Interceptor to v',
          this.interceptorStore.minExtensionVersion, ' or greater. Visit the\xA0',

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
              className: 'external-link',
              onClick: () => this.openLearningCenter() }, 'Learning center'), '\xA0for instructions on how to update.')));






  }}) || _class;

/***/ }),

/***/ 4829:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _base_Icons_LockedIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4721);
/* harmony import */ var _base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2060);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1769);
/* harmony import */ var _base_PasswordInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2500);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(748);
var _class;









const SECURE_CONNECTION = {
  title: 'Connection is secure',
  description: 'The information sent between the Postman app and the browser extension is encrypted with a custom key.' },


KEY_MISMATCH = {
  title: 'Encryption keys don\'t match',
  description: 'Check the encryption in the browser extension and ensure it matches the one entered here.' },


KEY_VALIDATION_FAIL_TEXT = 'The encryption key must be at least 10 characters long, and contain one digit and one letter',

KEY_RECOMMENDATION_HELPER_TEXT = 'Alphanumeric, minimum 10 characters',

INTERCEPTOR_CONNECTED = 'INTERCEPTOR CONNECTED',

INTERCEPTOR_DISCONNECTED = 'INTERCEPTOR DISCONNECTED',

WAITING_STATE = {
  title: 'Almost done...',
  description: 'Now, enter the same encryption key into the Interceptor and you\'ll be all set.' },


DEFAULT_CONNECTION = {
  title: 'Add an additional layer of security',
  description: 'We already encrypt communication with the Interceptor. You can make that communication even more secure by adding a custom encryption key.' };let



InterceptorConnection = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class InterceptorConnection extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);
    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('InterceptorSettingsStore');
    this.state = {
      isTooltipVisible: false,
      tooltipPlacement: 'bottom',
      keyValidationFail: false,
      key: this.store.customEncryptionKey,
      waitingState: false };

    this.openTooltip = this.openTooltip.bind(this);
    this.handleTooltipClose = this.handleTooltipClose.bind(this);
    this.saveKey = this.saveKey.bind(this);
  }

  openTooltip() {
    this.setState({
      isTooltipVisible: true,
      key: this.store.customEncryptionKey,
      keyValidationFail: false });

  }

  saveKey() {
    if (this.state.key.length < 10 || !/\d/.test(this.state.key) || !/[a-zA-Z]/.test(this.state.key)) {
      this.setState({
        keyValidationFail: true });

    } else
    {
      pm.interceptorBridge.setKey(this.state.key);
      this.setState({
        keyValidationFail: false,
        waitingState: true });

      this.store.updateCustomEncryptionKey(this.state.key);
      if (!this.store.customKeyInitialized) {
        this.store.updateCustomKeyInitializedFlag(true);
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEventV2({
          category: 'interceptor',
          action: 'encryption_key_updated',
          label: 'initial' });

      } else
      {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEventV2({
          category: 'interceptor',
          action: 'encryption_key_updated',
          label: 'repeated' });

      }
    }
  }


  handleChange(value) {
    this.setState({
      key: value,
      keyValidationFail: false });

  }

  handleTooltipClose() {
    this.state.isTooltipVisible && this.setState({
      isTooltipVisible: false,
      waitingState: false });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-capture-requests-menu--interceptor-connected-label' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { ref: 'toolTipTarget' },
          this.store.connectionStatus ? this.store.minExtensionVersionForCustomEncryptionSatisfied || this.store.customKeyInitialized || this.store.keyMismatch ?
          this.state.waitingState ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
              type: 'icon tertiary',
              active: this.state.isTooltipVisible,
              className: 'encryption-key-mismatch-btn',
              onClick: this.openTooltip,
              tooltip: 'Secure connection' },

            this.store.keyMismatch ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_LockedIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_LockedIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'interceptor-secure-lock-icon' })) :
          this.store.keyMismatch ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
              type: 'icon tertiary',
              active: this.state.isTooltipVisible,
              className: 'encryption-key-mismatch-btn',
              onClick: this.openTooltip,
              tooltip: 'Secure connection' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'interceptor-encryption-key-warning' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_WarningIcon__WEBPACK_IMPORTED_MODULE_5__["default"], { className: 'interceptor-encryption-key-warning' }))) :
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
              type: 'icon tertiary',
              active: this.state.isTooltipVisible,
              className: 'encryption-key-mismatch-btn',
              onClick: this.openTooltip,
              tooltip: 'Secure connection' },

            this.store.customKeyInitialized ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_LockedIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'interceptor-secure-lock-icon' }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_LockedIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null)) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["Tooltip"], {
              show: this.state.isTooltipVisible,
              placement: this.state.tooltipPlacement,
              target: this.refs.toolTipTarget,
              onClose: this.handleTooltipClose,
              className: 'interceptor-encryption-key-tooltip-wrapper',
              closeOnClickOutside: true,
              immediate: true },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["TooltipBody"], null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-encryption-key-tooltip' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-secure-connection-label' },
                  this.store.customKeyInitialized ?
                  this.state.waitingState ? this.store.keyMismatch ? WAITING_STATE.title : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'key-match' }, SECURE_CONNECTION.title) : this.store.keyMismatch ?
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'key-mismatch' }, KEY_MISMATCH.title) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'key-match' }, SECURE_CONNECTION.title) : this.store.keyMismatch ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'key-mismatch' }, KEY_MISMATCH.title) : DEFAULT_CONNECTION.title),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-tooltip__text' },
                  this.store.customKeyInitialized ? this.state.waitingState ?
                  this.store.keyMismatch ? WAITING_STATE.description : SECURE_CONNECTION.description :
                  this.store.keyMismatch ? KEY_MISMATCH.description : SECURE_CONNECTION.description : this.store.keyMismatch ? KEY_MISMATCH.description : DEFAULT_CONNECTION.description),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-encryption-key-label' }, 'Encryption Key'),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_PasswordInput__WEBPACK_IMPORTED_MODULE_7__["default"], {
                  className: 'interceptor-encryption-key-input',
                  disabled: false,
                  inputStyle: 'box',
                  error: this.state.keyValidationFail,
                  placeholder: 'Password',
                  value: this.state.key,
                  onChange: value => {this.handleChange(value);} }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-encryption-key-input-help' },
                  this.state.keyValidationFail ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'interceptor-key-validation-fail' }, KEY_VALIDATION_FAIL_TEXT) : KEY_RECOMMENDATION_HELPER_TEXT),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-encryption-key-save-btn' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                      type: 'primary',
                      size: 'small',
                      fluid: true,
                      onClick: this.saveKey,
                      disabled: this.state.waitingState || !this.state.key }, 'Save key')))))),








        this.store.connectionStatus ? INTERCEPTOR_CONNECTED : INTERCEPTOR_DISCONNECTED));

  }}) || _class;


/* harmony default export */ __webpack_exports__["default"] = (InterceptorConnection);

/***/ }),

/***/ 4830:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1222);



let

InterceptorSnapWarning = class InterceptorSnapWarning extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

  constructor(props) {
    super(props);
    this.openNativeAppDownloadURL.bind(this);
  }

  openNativeAppDownloadURL() {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_2__["NATIVE_APPS_URL"]);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-snap-warning' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-snap-label' }, 'Interceptor does not work with Snap'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-snap-info' }, 'If you have installed Postman via Snap, you may have problems connecting to the Interceptor extension. In such cases, we recommend that you download Postman directly by clicking the button below.'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            type: 'primary',
            size: 'large',
            onClick: this.openNativeAppDownloadURL }, 'Download Postman App')));





  }};


/* harmony default export */ __webpack_exports__["default"] = (InterceptorSnapWarning);

/***/ }),

/***/ 4831:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InterceptorSettingsFilters; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1882);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
var _class;





let


InterceptorSettingsFilters = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class InterceptorSettingsFilters extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('InterceptorSettingsStore');

    this.handleURLChange = this.handleURLChange.bind(this);
    this.handleMethodChange = this.handleMethodChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.delayedSubmit = lodash__WEBPACK_IMPORTED_MODULE_1___default.a.debounce(this.handleSubmit, 500);
  }

  handleURLChange(value) {
    this.store.updateRequestCaptureFilters({ url: value, methods: this.store.requestCaptureFilters.methods });
    this.delayedSubmit();
  }

  handleMethodChange(value) {
    this.store.updateRequestCaptureFilters({ url: this.store.requestCaptureFilters.url, methods: value });
    this.delayedSubmit();
  }

  handleSubmit() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'interceptor',
      action: 'update_capture_filter' });

    pm.interceptorBridge.requestCapture.updateFilters(this.store.getRequestCaptureFilters());
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-group filter-url' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-label' }, ' URL Contains  '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-input' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_2__["Input"], {
              inputStyle: 'box',
              type: 'text',
              value: this.store.requestCaptureFilters.url,
              onChange: value => this.handleURLChange(value) }),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-input-help' }, 'Regular expressions are supported'))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-group filter-methods' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-label' }, ' Methods '),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-input' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_2__["Input"], {
              inputStyle: 'box',
              type: 'text',
              value: this.store.requestCaptureFilters.methods,
              onChange: value => this.handleMethodChange(value) }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-filters-input-help' }, 'Separate using commas. Example PUT, GET, POST')))));






  }}) || _class;

/***/ }),

/***/ 4832:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InterceptorSettingsConnection; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_InputSelectV2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2543);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1789);
/* harmony import */ var _base_SearchHighlighter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2506);



let

InterceptorSettingsConnection = class InterceptorSettingsConnection extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.selectedTarget = this.selectedTarget.bind(this);
  }

  getFilteredList(list, query, options = {}) {

    if (!query || options.firstRender) {
      return list;
    }

    return _.filter(list, item => {
      return item.id && _.includes(item.name.toLowerCase(), query.toLowerCase());
    });
  }

  selectedTarget() {
    var filterItems = this.props.filterItems,
    selectedTarget = this.props.selectedTarget,
    modifiedSelectedTarget = _.find(filterItems, item => {return item.id === selectedTarget.id;});

    // handle renaming and deletion of selected item.

    if (modifiedSelectedTarget) {
      return modifiedSelectedTarget;
    } else
    {
      return {
        id: 'history',
        name: 'History' };

    }
  }

  getOption(item, search, option = {}) {
    const name = item.name,
    id = item.id;
    if (search && !option.firstRender) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'input-select-item',
              key: id },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_SearchHighlighter__WEBPACK_IMPORTED_MODULE_3__["default"], {
              source: name,
              query: search }))));




    }
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'input-select-item', key: id }, name));
  }

  render() {
    var { filterItems } = this.props;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-connection-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-settings-connection-group' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'interceptor-target-label' }, 'Save Requests to'),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InputSelectV2__WEBPACK_IMPORTED_MODULE_1__["InputSelectV2"], {
              style: { width: '100%' },
              onSelect: this.props.onTargetSelect,
              getFilteredList: this.getFilteredList.bind(this, filterItems),
              optionRenderer: this.getOption,
              selectedItem: this.selectedTarget(),
              ref: 'inputSelect',
              menuClassName: 'interceptor-target-selector-menu',
              getInputValue: listObj => {
                return listObj.name || '';
              } })))));





  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4833:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CaptureIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_2__);


let

CaptureIcon = class CaptureIcon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          type: 'icon',
          active: this.props.isPanelOpen,
          onClick: this.props.onToggle,
          tooltip: 'Capture requests and cookies with Postman' },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
          name: 'icon-action-capture-stroke',
          className: 'proxy-button-icon pm-icon-header',
          size: 'large',
          color: 'color-header-content' })));



  }};

/***/ }),

/***/ 4834:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PresenceContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_presence_PresenceUser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4835);
/* harmony import */ var _components_presence_PresenceDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4836);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(748);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
var _class;





let


PresenceContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class PresenceContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isDropdownOpen: false };


    this.presenceRef = null;
    this.toggleUserDropdown = this.toggleUserDropdown.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
    this.handlePresenceFocus = this.handlePresenceFocus.bind(this);
    this.handlePresenceBlur = this.handlePresenceBlur.bind(this);
    this.handleMouseEnterOnMoreUser = this.handleMouseEnterOnMoreUser.bind(this);
    this.getMoreUsersClasses = this.getMoreUsersClasses.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.presenceStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PresenceStore');
    this.syncStatusStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore');

    this.presenceStore.initialPresenceFetchAndReport({
      primaryModel: this.props.primaryModel,
      models: this.props.models,
      model: this.props.model,
      modelId: this.props.modelId,
      isFocused: true });


    window.addEventListener('focus', this.handlePresenceFocus);
    window.addEventListener('blur', this.handlePresenceBlur);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.primaryModel !== this.props.primaryModel || !_.isEqual(nextProps.models, this.props.models) ||
    nextProps.model !== this.props.model || nextProps.modelId !== this.props.modelId) {
      this.presenceStore.clearPolling();

      this.presenceStore.updatePresenceFetchAndReport({
        prevPrimaryModel: this.props.primaryModel,
        prevModels: this.props.models,
        primaryModel: nextProps.primaryModel,
        models: nextProps.models,
        model: nextProps.model,
        modelId: nextProps.modelId,
        isFocused: true });

    }
  }

  componentWillUnmount() {
    this.presenceStore.clearPolling();

    // This is to handle a case when presence is unmounted it should report presence as focused false
    // on current workspace so that presence is wiped out for that particular workspace
    // Check on socketConnect so that we do not send focus false call when socket is disconnected as
    // the component will unmount and the report call will error out and when the socket connects, the presence
    // will not come back.
    !this.presenceStore.error && this.syncStatusStore.isSocketConnected && this.presenceStore.remoteReport({
      primaryModel: this.props.primaryModel,
      models: this.props.models,
      isFocused: false });


    window.removeEventListener('focus', this.handlePresenceFocus);
    window.removeEventListener('blur', this.handlePresenceBlur);
  }

  handlePresenceFocus() {
    this.presenceStore.remoteReport({
      primaryModel: this.props.primaryModel,
      models: this.props.models,
      isFocused: true });

  }

  handlePresenceBlur() {
    this.presenceStore.clearPolling();

    this.presenceStore.remoteReport({
      primaryModel: this.props.primaryModel,
      models: this.props.models,
      isFocused: false });

  }

  toggleUserDropdown() {
    this.setState(prevState => {
      return {
        isDropdownOpen: !prevState.isDropdownOpen };

    }, () => {
      this.state.isDropdownOpen &&
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
        category: 'workspace',
        action: 'presence',
        label: 'click_all',
        value: 1,
        entityId: this.props.modelId });

    });
  }

  handleOutsideClick(e) {
    if (!this.presenceRef.contains(e.target)) {
      this.setState({ isDropdownOpen: false });
    }
  }

  handleMouseEnterOnMoreUser() {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
      category: 'workspace',
      action: 'presence',
      label: 'hover_all',
      value: 1,
      entityId: this.props.modelId });

  }

  getMoreUsersClasses(usersLength) {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()('presence-indicator__more-users', {
      'opened': this.state.isDropdownOpen,
      'large': usersLength > 99 });

  }

  render() {
    const presenceUsers = this.presenceStore.presenceWorkspaceUsers,
    presenceUsersValues = _.orderBy(presenceUsers, ['active']);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: 'presence-indicator',
          ref: ref => this.presenceRef = ref },

        presenceUsersValues.length > 3 &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: this.getMoreUsersClasses(presenceUsersValues.length),
            onClick: this.toggleUserDropdown,
            onMouseEnter: this.handleMouseEnterOnMoreUser },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'presence-indicator__more-users-text' }, '+',
            presenceUsersValues.length - 3)),




        _.map(presenceUsersValues.slice(0, 3).reverse(), user => {
          return (
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_presence_PresenceUser__WEBPACK_IMPORTED_MODULE_1__["default"], {
              key: user.id,
              userId: user.id,
              name: user.name || user.username,
              active: user.active,
              entityId: this.props.modelId }));


        }),


        this.state.isDropdownOpen &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_presence_PresenceDropdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
          users: presenceUsersValues,
          onClickOutside: this.handleOutsideClick })));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4835:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PresenceUser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2070);
/* harmony import */ var _js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1769);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(748);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);




let

PresenceUser = class PresenceUser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isNameTooltipVisible: false };


    this.userTooltip = null;
    this.handleShowTooltip = this.handleShowTooltip.bind(this);
    this.handleCloseTooltip = this.handleCloseTooltip.bind(this);
    this.getAvatarClasses = this.getAvatarClasses.bind(this);
    this.getTooltipTextClasses = this.getTooltipTextClasses.bind(this);
    this.handleUserClick = this.handleUserClick.bind(this);
  }

  handleShowTooltip(active) {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2({
      category: 'workspace',
      action: 'presence',
      label: `hover_avatar_${active ? 'active' : 'inactive'}`,
      value: 1,
      entityId: this.props.entityId });


    this.setState({ isNameTooltipVisible: true });
  }

  handleUserClick(active) {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2({
      category: 'workspace',
      action: 'presence',
      label: `click_avatar_${active ? 'active' : 'inactive'}`,
      value: 1,
      entityId: this.props.entityId });

  }

  handleCloseTooltip() {
    this.setState({ isNameTooltipVisible: false });
  }

  getAvatarClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_4___default()('presence-indicator__user-avatar-wrapper', {
      'inactive': !this.props.active });

  }

  getTooltipTextClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_4___default()('presence-indicator__user-avatar-tooltip-status', {
      'active-status': this.props.active });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getAvatarClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            ref: ref => this.userTooltip = ref,
            onClick: () => {this.handleUserClick(this.props.active);},
            onMouseEnter: () => {this.handleShowTooltip(this.props.active);},
            onMouseLeave: this.handleCloseTooltip },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_1__["default"], {
            ref: 'avatar',
            size: 'medium',
            userId: this.props.userId })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_2__["Tooltip"], {
            className: 'presence-indicator__tooltip',
            show: this.state.isNameTooltipVisible,
            target: this.userTooltip,
            onClose: this.handleTooltipClose,
            closeOnClickOutside: true,
            immediate: true },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_2__["TooltipBody"], null,
            this.props.name,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: this.getTooltipTextClasses() },
              this.props.active ? ' (Active)' : ' (Inactive)')))));





  }};

/***/ }),

/***/ 4836:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PresenceDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1803);
/* harmony import */ var _js_components_base_Icons_RightSolidIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1804);
/* harmony import */ var _PresenceDropdownUser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4837);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


let

PresenceDropdown = class PresenceDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isActiveUsersOpen: true,
      isInactiveUsersOpen: true };


    this.handleActiveUserToggle = this.handleActiveUserToggle.bind(this);
    this.handleInactiveUserToggle = this.handleInactiveUserToggle.bind(this);
  }

  componentDidMount() {
    window.addEventListener('click', this.props.onClickOutside);
  }

  componentWillUnmount() {
    window.removeEventListener('click', this.props.onClickOutside);
  }

  handleActiveUserToggle(e) {
    e && e.stopPropagation();

    this.setState(prevState => {
      return _extends({},
      prevState, {
        isActiveUsersOpen: !prevState.isActiveUsersOpen });

    });
  }

  handleInactiveUserToggle(e) {
    e && e.stopPropagation();

    this.setState(prevState => {
      return _extends({},
      prevState, {
        isInactiveUsersOpen: !prevState.isInactiveUsersOpen });

    });
  }

  render() {
    const users = this.props.users;

    let activeUsers = [],
    inactiveUsers = [];

    _.forEach(users, userInfo => {
      if (userInfo.active) {
        activeUsers.push(userInfo);
      } else
      {
        inactiveUsers.push(userInfo);
      }
    });

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-header' }, 'Workspace members'),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-users' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-users--active' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'presence-indicator__dropdown-users--active-header',
                  onClick: this.handleActiveUserToggle },


                this.state.isActiveUsersOpen ?
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_1__["default"], {
                  className: 'presence-indicator-active-user-toggle' }) :

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_RightSolidIcon__WEBPACK_IMPORTED_MODULE_2__["default"], {
                  className: 'presence-indicator-active-user-toggle' }),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'presence-indicator__user-status-label' }, 'Active')),


              this.state.isActiveUsersOpen && (activeUsers.length ?
              _.map(activeUsers, user => {
                return (
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_PresenceDropdownUser__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    active: true,
                    key: user.id,
                    user: user }));


              }) :

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-empty-state' }, 'No active workspace members right now.'))),





            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-users--inactive' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  className: 'presence-indicator__dropdown-users--inactive-header',
                  onClick: this.handleInactiveUserToggle },


                this.state.isInactiveUsersOpen ?
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_1__["default"], {
                  className: 'presence-indicator-active-user-toggle' }) :

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_RightSolidIcon__WEBPACK_IMPORTED_MODULE_2__["default"], {
                  className: 'presence-indicator-active-user-toggle' }),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'presence-indicator__user-status-label' }, 'Inactive')),


              this.state.isInactiveUsersOpen && (inactiveUsers.length ?
              _.map(inactiveUsers, user => {
                return (
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_PresenceDropdownUser__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    key: user.id,
                    user: user }));


              }) :

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'presence-indicator__dropdown-empty-state' }, 'No inactive workspace members right now.')))))));









  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4837:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PresenceDropdownUser; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2070);
/* harmony import */ var _js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2078);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(748);



let

PresenceDropdownUser = class PresenceDropdownUser extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      showTooltip: false };


    this.nameRef = null;
    this.handleAvatarClick = this.handleAvatarClick.bind(this);
  }

  componentDidMount() {
    if (this.nameRef && this.nameRef.offsetWidth < this.nameRef.scrollWidth) {
      this.setState({ showTooltip: true });
    }
  }

  handleAvatarClick(userId) {
    Object(_js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__["openTeamUserProfile"])(userId);
  }

  render() {
    const { user, active } = this.props;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: `presence-indicator__${active ? 'active' : 'inactive'}-user`,
          key: user.id },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'presence-indicator__clickable-user-avatar',
            onClick: () => {this.handleAvatarClick(user.id);} },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_1__["default"], {
            size: 'medium',
            userId: user.id })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
            className: `presence-indicator__${active ? 'active' : 'inactive'}-user-name`,
            ref: ref => this.nameRef = ref,
            title: this.state.showTooltip ? user.name || user.username : '' },

          user.name || user.username)));



  }};

/***/ }),

/***/ 4838:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabShortcuts", function() { return getTabShortcuts; });
/**
 * Return an object with all tab level shortcuts
 *
 * @returns {Object}
 */
let getTabShortcuts = function () {
  return {
    switchToNextTab: pm.shortcuts.handle('switchToNextTab'),
    switchToPreviousTab: pm.shortcuts.handle('switchToPreviousTab'),
    switchToTab1: pm.shortcuts.handle('switchToTab1'),
    switchToTab2: pm.shortcuts.handle('switchToTab2'),
    switchToTab3: pm.shortcuts.handle('switchToTab3'),
    switchToTab4: pm.shortcuts.handle('switchToTab4'),
    switchToTab5: pm.shortcuts.handle('switchToTab5'),
    switchToTab6: pm.shortcuts.handle('switchToTab6'),
    switchToTab7: pm.shortcuts.handle('switchToTab7'),
    switchToTab8: pm.shortcuts.handle('switchToTab8'),
    switchToLastTab: pm.shortcuts.handle('switchToLastTab'),
    reopenLastClosedTab: pm.shortcuts.handle('reopenLastClosedTab') };

};



/***/ }),

/***/ 4839:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(749);
/* harmony import */ var _modules_services_SignInModalService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2111);



/**
                                                                                        * Returns the data required for the mock or monitor creation
                                                                                        *
                                                                                        * @param {Object} data
                                                                                        */
function getData({ collectionId = null, requests = null, opts }) {
  if (opts.activeStep === 1) {
    return {
      workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore').id,
      from: opts.from };

  }

  let environmentId = null,
  environmentStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('EnvironmentStore'),
  activeWorkspaceStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore'),
  environment = environmentStore.find(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveEnvironmentStore').id),
  environments = activeWorkspaceStore.environments,
  sortedEnvironments = _.sortBy(environments, e => _.toLower(e.name)),

  collection = collectionId && Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('CollectionStore').find(collectionId),
  collections = activeWorkspaceStore.editableCollections;

  if (environment) {
    environmentId = environment.id;
  }

  environments = _.concat({
    id: null,
    name: 'No Environment' },
  sortedEnvironments);

  // Launch the 2nd step of create new X modal since
  // the data is already present and creation step should be shown
  let data = {
    activeStep: 2,
    activeSource: 'workspace',
    ownCollections: collections,
    ownEnvironments: environments,
    workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore').id,
    from: opts.from };


  if (collectionId && collection) {
    data.selectedOptions = {
      environmentId,
      collectionId,
      ownerId: collection.owner,
      name: collection.name };

  } else
  {
    data.selectedOptions = {
      environmentId,
      name: opts.name,
      requests };

  }

  return data;
}


/**
   * Triggers the modal event
   *
   * @param  {...any} args
   */
function _triggerEvent(...args) {
  pm.mediator.trigger(...args);
}

/**
   * Checks if the user is not logged in then shows sign in modal
   * otherwise triggers the modal
   */
function _launchModal(event, data, onSuccess, opts) {
  let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('CurrentUserStore');

  if (opts.from === 'create_new_modal') {
    opts.onBack = () => _triggerEvent('openCreateNewXModal');
  }

  if (!currentUser.isLoggedIn) {
    return Object(_modules_services_SignInModalService__WEBPACK_IMPORTED_MODULE_1__["showContextualSignInModal"])(event, () => {
      _triggerEvent(event, data, onSuccess);
    }, opts);
  }

  _triggerEvent(event, data, onSuccess);
}

/* harmony default export */ __webpack_exports__["default"] = ({
  /**
                  * Launches Create New X Modal
                  * to create a new Documentation, Mock or Monitor for
                  * a collection or requests in history
                  *
                  * @param {*} event
                  * @param {*} data
                  * @param {*} onSuccess
                  */
  create: function (event, data, onSuccess = null, opts = {}) {
    _launchModal(event, getData(data), onSuccess, opts);
  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4840:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterInfobarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1259);
/* harmony import */ var _components_base_Infobar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2551);
/* harmony import */ var _services_UIEventService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1755);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


let
RequesterInfobarContainer = class RequesterInfobarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { info: null };
    this.handleClose = this.handleClose.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
    this.handleActionClick = this.handleActionClick.bind(this);
    this.handleDismiss = this.handleDismiss.bind(this);
    _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].initializeBridge();
  }

  componentWillUnmount() {
    this.detachListeners();
  }

  componentDidMount() {
    this.attachListeners();
  }

  attachListeners() {
    _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].on('show', this.handleOpen);
    _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].on('dismiss', this.handleClose);
  }

  detachListeners() {
    _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].off('show', this.handleOpen);
    _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].off('dismiss', this.handleClose);
  }

  handleActionClick() {
    _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].handleActionClick();
    if (!(this.state.info && this.state.info.isDismissable)) {
      return;
    }
    this.handleClose();
  }

  handleClose() {
    this.setState({ info: null }, () => {
      _controllers_Infobar__WEBPACK_IMPORTED_MODULE_1__["default"].dismissActive();
      this.unsubscribeHandler && this.unsubscribeHandler();
    });
  }

  handleDismiss() {
    this.state.info.onDismiss && this.state.info.onDismiss();
    this.handleClose();
  }

  handleOpen(info) {
    this.unsubscribeHandler && this.unsubscribeHandler();
    this.setState({ info }, () => {
      info.onView && info.onView();
      this.unsubscribeHandler = info.dismissEvent && _services_UIEventService__WEBPACK_IMPORTED_MODULE_3__["default"].subscribe(info.dismissEvent, this.handleDismiss);
    });
  }

  render() {
    if (_.isEmpty(this.state.info)) {
      return false;
    }
    const props = _extends({}, this.state.info, { onDismiss: this.handleDismiss });

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Infobar__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({
        onActionClick: this.handleActionClick },
      props)));


  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4841:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return VariablesProvider; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _GenericVariablesProvider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2879);
/* harmony import */ var _controllers_VariableGetters__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
var _class;


let


VariablesProvider = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class VariablesProvider extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getVariables() {
    return [].concat(Object(_controllers_VariableGetters__WEBPACK_IMPORTED_MODULE_2__["getDynamicVariables"])(), Object(_controllers_VariableGetters__WEBPACK_IMPORTED_MODULE_2__["getEnvironment"])(), Object(_controllers_VariableGetters__WEBPACK_IMPORTED_MODULE_2__["getGlobals"])());
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_GenericVariablesProvider__WEBPACK_IMPORTED_MODULE_1__["GenericVariablesProvider"], {
          variables: this.getVariables() },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(this.props.children, this.props)));


  }}) || _class;

/***/ }),

/***/ 4842:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterContentContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(751);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _RequesterSidebarHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4843);
/* harmony import */ var _RequesterSidebarContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4847);
/* harmony import */ var _components_tabs_RequesterTabEmptyShell__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2885);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1789);
/* harmony import */ var _components_base_Panes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1878);
/* harmony import */ var _constants_Panes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1880);
/* harmony import */ var _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1612);
/* harmony import */ var _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(774);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4416);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _onboarding_src_features_Recommendations_components_RecommendationViewer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2107);
var _class;















const REQUESTER_SIDEBAR_OPEN = 'isRequesterSidebarOpen',
SIDEBAR_MIN_WIDTH = 265,
SIDEBAR_MAX_WIDTH = 500,
SIDEBAR_COLLAPSED_WIDTH = 32,
SIDEBAR_FALLBACK_WIDTH = 300,
BUILDER_MIN_WIDTH = 450,
BUILDER_FALLBACK_WIDTH = 1000,
PANE_SIZES_SAVE_DEBOUNCE = 300;



const RequesterBuilderContainer = react_loadable__WEBPACK_IMPORTED_MODULE_14___default()({
  loader: () => Promise.all(/* import() | RequesterBuilderContainer */[__webpack_require__.e(9), __webpack_require__.e(15)]).then(__webpack_require__.bind(null, 5819)),
  loading: () => {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-builder' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_tabs_RequesterTabEmptyShell__WEBPACK_IMPORTED_MODULE_8__["RequesterTabsEmptyShell"], null),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_tabs_RequesterTabEmptyShell__WEBPACK_IMPORTED_MODULE_8__["RequesterTabContentShell"], null)));


  } });


const WorkspaceBrowser = react_loadable__WEBPACK_IMPORTED_MODULE_14___default()({
  loader: () => Promise.all(/* import() | WorkspaceBrowser */[__webpack_require__.e(9), __webpack_require__.e(16)]).then(__webpack_require__.bind(null, 5839)),
  loading: () => null });let



RequesterContentContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class RequesterContentContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {};

    this.sidebarStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('RequesterSidebarStore');

    this.toggleSidebar = this.toggleSidebar.bind(this);
    this.savePanesWidthsDebounced = lodash__WEBPACK_IMPORTED_MODULE_1___default.a.debounce(this.savePanesWidths.bind(this), PANE_SIZES_SAVE_DEBOUNCE);
    this.handlePanesResize = this.handlePanesResize.bind(this);
    this.focus = this.focus.bind(this);
  }

  componentDidMount() {
    pm.mediator.on('toggleSidebar', this.toggleSidebar);

    // always keep sidebar in sync with user preference
    this.reactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_3__["reaction"])(() => this.sidebarStore.isOpen, () => {
      if (this.sidebarPaneRef && typeof this.sidebarPaneRef.handleCollapseToggle === 'function') {
        this.sidebarPaneRef.handleCollapseToggle('x', !this.sidebarStore.isOpen);
      }
    });
  }

  componentWillUnmount() {
    pm.mediator.off('toggleSidebar', this.toggleSidebar);

    this.reactionDisposer && this.reactionDisposer();
  }

  toggleSidebar() {
    _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_12__["default"].set(REQUESTER_SIDEBAR_OPEN, !this.sidebarStore.isOpen);
  }

  savePanesWidths(sidebarWidth, requesterTabWidth) {
    pm.settings.setSetting('requesterSidebarWidth', sidebarWidth);
    pm.settings.setSetting('requesterBuilderWidth', requesterTabWidth);
  }

  handlePanesResize(updates) {
    if (!Array.isArray(updates)) {
      return;
    }

    if (updates.length >= 2 &&
    typeof updates[0].width === 'number' &&
    typeof updates[1].width === 'number')
    {
      const isSidebarOpen = this.sidebarStore.isOpen;

      // if sidebar is collapsed, set the sidebar to collapsed state
      // and bail because we don't want to sidebarStore collapsed width in settings
      if (updates[0].width === SIDEBAR_COLLAPSED_WIDTH) {
        // if state is not already closed, set it to closed
        isSidebarOpen && _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_12__["default"].set(REQUESTER_SIDEBAR_OPEN, false);

        return pm.mediator.trigger('focusBuilder');
      }

      // set sidebar to open if not already set
      !isSidebarOpen && _modules_services_UserPreferenceService__WEBPACK_IMPORTED_MODULE_12__["default"].set(REQUESTER_SIDEBAR_OPEN, true);

      this.savePanesWidthsDebounced(updates[0].width, updates[1].width);
    }
  }

  getBuilderClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'requester-content': true,
      'requester-content-builder': true });

  }

  getLibraryClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'requester-content': true,
      'requester-content-library': true });

  }

  focus(view) {
    this.refs.contents && this.refs.contents.focus();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-contents', ref: 'contents', tabIndex: 1 },

        Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('WorkspaceLifecycleStore').isSwitching &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'loader-blocker' }),


        Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceSessionStore').viewMode === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_13__["WORKSPACE_BUILDER_VIEW"] &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_10__["PaneGroup"], { defaultLayout: _constants_Panes__WEBPACK_IMPORTED_MODULE_11__["PANE_LAYOUT_HORIZONTAL"], onPaneResize: this.handlePanesResize },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_10__["Pane"], {
              className: 'sidebar',
              width: {
                collapsedByDefault: !this.sidebarStore.isOpen,
                shouldResistResize: true,
                default: pm.settings.getSetting('requesterSidebarWidth') || SIDEBAR_FALLBACK_WIDTH,
                min: SIDEBAR_MIN_WIDTH,
                max: SIDEBAR_MAX_WIDTH },

              ref: ref => {this.sidebarPaneRef = ref;} },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_10__["PaneHeader"], {
              verticalComponent: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterSidebarHeader__WEBPACK_IMPORTED_MODULE_6__["default"], null),
              width: SIDEBAR_COLLAPSED_WIDTH }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_10__["PaneContent"], null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterSidebarContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
                isSidebarOpen: this.sidebarStore.isOpen,
                className: 'requester-left-sidebar-wrapper' }))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_10__["Pane"], {
              width: {
                default: pm.settings.getSetting('requesterBuilderWidth') || BUILDER_FALLBACK_WIDTH,
                min: BUILDER_MIN_WIDTH } },


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Panes__WEBPACK_IMPORTED_MODULE_10__["PaneContent"], { className: this.getBuilderClasses() },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__["default"], { identifier: 'builder' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(RequesterBuilderContainer, {
                  ref: this.focus,
                  activePane: this.state.activePane,
                  onOutsideClick: this.switchToSidebar }))))),








        Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceSessionStore').viewMode === _constants_RequesterTabConstants__WEBPACK_IMPORTED_MODULE_13__["WORKSPACE_BROWSER_VIEW"] &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getLibraryClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__["default"], { identifier: 'browse' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(WorkspaceBrowser, { ref: this.focus }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_onboarding_src_features_Recommendations_components_RecommendationViewer__WEBPACK_IMPORTED_MODULE_15__["default"], {
              target: 'workspace/mode/browse',
              className: 'workspace-browse__onboarding-recommendation-viewer' })))));






  }}) || _class;

/***/ }),

/***/ 4843:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterSidebarHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_base_Tooltips__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1769);
/* harmony import */ var _components_base_Icons_HistoryIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4844);
/* harmony import */ var _components_base_Icons_CollectionIcon2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4845);
/* harmony import */ var _components_base_Icons_APIIcon2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4846);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);








const SIDEBAR_TABS = [{
  key: 'history',
  label: 'History',
  icon: _components_base_Icons_HistoryIcon__WEBPACK_IMPORTED_MODULE_2__["default"] },
{
  key: 'collections',
  label: 'Collections',
  icon: _components_base_Icons_CollectionIcon2__WEBPACK_IMPORTED_MODULE_3__["default"] },
{
  key: 'api',
  label: 'API',
  icon: _components_base_Icons_APIIcon2__WEBPACK_IMPORTED_MODULE_4__["default"] }];let


RequesterSidebarHeader = class RequesterSidebarHeader extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);

    this.state = {};

    this.sidebarStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('RequesterSidebarStore');
    this.tooltipTargets = {};

    this.handleShowTooltip = this.handleShowTooltip.bind(this);
    this.handleHideTooltip = this.handleHideTooltip.bind(this);
    this.handleOpenTab = this.handleOpenTab.bind(this);
  }

  componentWillUnmount() {
    // ensure that we don't call setState when it is unmounted
    clearTimeout(this.titleTooltip);
  }

  handleShowTooltip(tooltipKey) {
    this.titleTooltip = setTimeout(() => {
      this.setState({ [tooltipKey]: true });
    }, 500);
  }

  handleHideTooltip(tooltipKey) {
    clearTimeout(this.titleTooltip);
    if (this.state[tooltipKey]) {
      this.setState({ [tooltipKey]: false });
    }
  }

  handleOpenTab(tabName) {
    this.sidebarStore.setActiveTab(tabName);
    pm.settings.setSetting('activeSidebarSection', tabName);
    this.props.onCollapseToggle();
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-sidebar-header' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-sidebar-header__tabs' },
          SIDEBAR_TABS.map((tab, index) => {
            const Icon = tab.icon;

            // if icon is not present,  we skip adding this item
            if (!Icon) {
              return null;
            }

            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, { key: index },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                    className: `tabs__${tab.key}`,
                    ref: ref => {this.tooltipTargets[tab.key] = ref;} },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Icon, {
                    onClick: this.handleOpenTab.bind(null, tab.key),
                    onMouseEnter: this.handleShowTooltip.bind(null, tab.key),
                    onMouseLeave: this.handleHideTooltip.bind(null, tab.key) })),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_1__["Tooltip"], {
                    show: this.state[tab.key],
                    target: this.tooltipTargets[tab.key],
                    placement: 'right',
                    immediate: true },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_1__["TooltipBody"], null,
                    tab.label))));




          }))));



  }};

/***/ }),

/***/ 4844:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TimeIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'history-outer', d: 'M9 2C5.68629 2 3 4.68629 3 8C3 8.09598 3.00225 8.19141 3.0067 8.28623L4.14648 7.14645L4.85359 7.85355L2.50004 10.2071L0.146484 7.85355L0.853591 7.14645L2.00628 8.29914C2.00211 8.19992 2 8.1002 2 8C2 4.13401 5.13401 1 9 1C12.866 1 16 4.13401 16 8C16 11.866 12.866 15 9 15C7.37595 15 5.87982 14.4463 4.69205 13.5178L5.30795 12.7299C6.32611 13.5259 7.60699 14 9 14C12.3137 14 15 11.3137 15 8C15 4.68629 12.3137 2 9 2Z' }),
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'history-inner', d: 'M9 4H8V8.7831L10.7428 10.4287L11.2572 9.57125L9 8.2169V4Z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#282828', fillRule: 'evenodd', xlinkHref: '#history-outer' }),
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#282828', fillRule: 'evenodd', xlinkHref: '#history-inner' }));



function TimeIcon(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 4845:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionIcon2; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'pm-icon-collection-2', d: 'M15 13.5C15 14.3284 14.3284 15 13.5 15H2.5C1.67157 15 1 14.3284 1 13.5V2.5C1 1.67157 1.67157 1 2.5 1H13.5C14.3284 1 15 1.67157 15 2.5V13.5ZM2 2.5C2 2.22386 2.22386 2 2.5 2H5.04623C5.19041 2 5.32758 2.06224 5.42252 2.17075L8.62371 5.82925C8.71866 5.93776 8.85582 6 9 6H13.5C13.7761 6 14 6.22386 14 6.5V13.5C14 13.7761 13.7761 14 13.5 14H2.5C2.22386 14 2 13.7761 2 13.5V2.5ZM14 5.08535V2.5C14 2.22386 13.7761 2 13.5 2H6.60188L9.22688 5H13.5C13.6753 5 13.8436 5.03008 14 5.08535Z' })),

  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#282828', fillRule: 'evenodd', xlinkHref: '#pm-icon-collection-2' }));



function CollectionIcon2(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 4846:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APIIcon2; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('g', { id: 'pm-icon-api-2' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { d: 'M8.00008 1L11.0312 2.75V6.25L8.00008 8L4.96899 6.25V2.75L8.00008 1ZM5.96899 3.32735L8.00008 2.1547L10.0312 3.32735V5.67265L8.00008 6.8453L5.96899 5.67265V3.32735Z' }),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { d: 'M7.03117 9.75L4.00008 8L0.968994 9.75V13.25L4.00008 15L7.03117 13.25V9.75ZM4.00008 9.1547L1.96899 10.3274V12.6726L4.00008 13.8453L6.03117 12.6726V10.3274L4.00008 9.1547Z' }),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { d: 'M15.0312 9.75L12.0001 8L8.96899 9.75V13.25L12.0001 15L15.0312 13.25V9.75ZM12.0001 9.1547L9.96899 10.3274V12.6726L12.0001 13.8453L14.0312 12.6726V10.3274L12.0001 9.1547Z' }))),


  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { fill: '#282828', fillRule: 'evenodd', xlinkHref: '#pm-icon-api-2' }));




function APIIcon2(props) {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 4847:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterSidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RequesterLeftSidebarContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4848);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4416);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_promisifyIdleCallback__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4893);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1789);
var _dec, _class;






const CollectionBrowserContainer = react_loadable__WEBPACK_IMPORTED_MODULE_3___default()({
  loader: () => Object(_utils_promisifyIdleCallback__WEBPACK_IMPORTED_MODULE_4__["promisifyIdleCallback"])().then(() => Promise.all(/* import() | CollectionBrowserContainer */[__webpack_require__.e(9), __webpack_require__.e(17)]).then(__webpack_require__.bind(null, 5868))),
  loading: () => null });let



RequesterSidebarContainer = (_dec = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default()({ eventCapturingPhase: false }), _dec(_class = class RequesterSidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {

  handleClickOutside(e) {
    // Don't close the browser if the outside click is triggered from modal
    if (e.target.closest('.sidebar-toggle-button')) {
      return;
    }
    if (e.target.offsetParent != null &&
    !e.target.closest('.ReactModalPortal') &&
    !e.target.closest('.tooltip') &&
    !e.target.closest('#dropdown-root') // Prevent closing of collection browser on click of disabled item in dropdown
    ) {
        pm.mediator.trigger('hideCollectionBrowser');
        this.props.onOutsideClick && this.props.onOutsideClick(e);
      }
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__["default"], { identifier: 'sidebar', isVisible: this.props.isSidebarOpen },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.props.className },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequesterLeftSidebarContainer__WEBPACK_IMPORTED_MODULE_2__["default"], null),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(CollectionBrowserContainer, null))));



  }}) || _class);

/***/ }),

/***/ 4848:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterLeftSidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1794);
/* harmony import */ var _components_base_Inputs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1882);
/* harmony import */ var _components_base_Tabs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1791);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _collections_CollectionSidebarContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4849);
/* harmony import */ var _history_HistorySidebarContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4875);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1789);
/* harmony import */ var _services_TabShortcutsService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4838);
/* harmony import */ var _api_dev_components_api_sidebar_APISidebarContainer_APISidebarContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4886);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1763);
var _class;










let


RequesterLeftSidebarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_11__["observer"])(_class = class RequesterLeftSidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('RequesterSidebarStore');

    this.state = {
      activeTab: pm.settings.getSetting('activeSidebarSection') || 'history' };


    this.focus = this.focus.bind(this);
    this.handleNextItem = this.handleNextItem.bind(this);
    this.focusSearchBox = this.focusSearchBox.bind(this);
    this.handleTabChange = this.handleTabChange.bind(this);
    this.handleFocusInCollectionsTab = this.handleFocusInCollectionsTab.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);
    this.handleSearchCancel = this.handleSearchCancel.bind(this);
  }

  UNSAFE_componentWillMount() {
    pm.mediator.on('focusSearchBox', this.focusSearchBox);
    pm.mediator.on('focusSidebar', this.focus);
    pm.mediator.on('focusCollectionInSideBar', this.handleFocusInCollectionsTab);
    pm.settings.on('setSetting:activeSidebarSection', this.handleTabChange);
  }

  componentWillUnmount() {
    pm.mediator.off('focusSearchBox', this.focusSearchBox);
    pm.mediator.off('focusSidebar', this.focus);
    pm.mediator.off('focusCollectionInSideBar', this.handleFocusInCollectionsTab);
    pm.settings.off('setSetting:activeSidebarSection', this.handleTabChange);
  }

  getKeymapHandlers() {
    return Object(_services_TabShortcutsService__WEBPACK_IMPORTED_MODULE_9__["getTabShortcuts"])();
  }

  focus() {
    if (this.state.activeTab === 'history') {
      _.invoke(this, 'refs.history.__wrappedComponent.focus');
    } else
    if (this.state.activeTab === 'collections') {
      _.invoke(this, 'refs.collections.focus');
    } else
    if (this.state.activeTab === 'api') {
      _.invoke(this, 'refs.api.__wrappedInstance.focus');
    }
  }

  handleNextItem() {
    if (this.state.activeTab === 'history') {
      _.invoke(this, 'refs.history.__wrappedComponent.focus');
      _.invoke(this, 'refs.history.__wrappedComponent.selectNext');
    } else
    if (this.state.activeTab === 'collections') {
      _.invoke(this, 'refs.collections.focus');
      _.invoke(this, 'refs.collections.focusNext');
    }
  }

  handleTabChange(tab, cb) {
    if (tab === this.state.activeTab) {
      _.isFunction(cb) && cb();
      return;
    }
    this.setState({ activeTab: _.includes(['history', 'collections', 'api'], tab) ? tab : 'history' }, () => {
      this.focus();
      _.isFunction(cb) && cb();
      pm.settings.setSetting('activeSidebarSection', tab);
    });
  }

  handleFocusInCollectionsTab(collectionId, collectionDetailsTab) {
    // delay in rendering the collection in list hence the timeout
    setTimeout(() => {
      this.handleTabChange('collections', () => {
        _.invoke(this, 'refs.collections.focusCollection', collectionId, collectionDetailsTab);
      });
    }, 500);
  }

  focusSearchBox() {
    _.invoke(this, 'refs.filter.focus');
  }


  handleSearchChange(query) {
    this.store.setSearchQuery(query);
  }

  handleSearchCancel() {
    this.store.setSearchQuery('');
  }

  getSidebarContainerClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'requester-left-sidebar': true });

  }

  getSidebarContentClasses(view) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'requester-left-sidebar__tab-content': true,
      'requester-left-sidebar__tab-content-history-container': this.state.activeTab === 'history',
      'requester-left-sidebar__tab-content-collections-container': this.state.activeTab === 'collections',
      'is-hidden': this.state.activeTab !== view });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_2__["default"], { keyMap: pm.shortcuts.getShortcuts(), handlers: this.getKeymapHandlers() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getSidebarContainerClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-left-sidebar__search-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'filter' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Inputs__WEBPACK_IMPORTED_MODULE_3__["Input"], {
                ref: 'filter',
                placeholder: 'Filter',
                inputStyle: 'search',
                onChange: this.handleSearchChange,
                onCancel: this.handleSearchCancel,
                query: this.store.searchQuery,
                onDownArrow: this.handleNextItem }))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-left-sidebar__tabs-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_4__["Tabs"], {
                type: 'primary',
                fluid: true,
                defaultActive: 'collections',
                activeRef: this.state.activeTab,
                onChange: this.handleTabChange },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'historyTab' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_4__["Tab"], { refKey: 'history', fluid: true },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'History'))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'collectionTab' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_4__["Tab"], { refKey: 'collections', fluid: true },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'Collections'))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'apiTab' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_4__["Tab"], { refKey: 'api', fluid: true },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'APIs'))))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-left-sidebar__tab-content-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getSidebarContentClasses('history') },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'history', isVisible: this.state.activeTab === 'history' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_history_HistorySidebarContainer__WEBPACK_IMPORTED_MODULE_7__["default"], { ref: 'history' }))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getSidebarContentClasses('collections') },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'collection', isVisible: this.state.activeTab === 'collections' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collections_CollectionSidebarContainer__WEBPACK_IMPORTED_MODULE_6__["default"], { ref: 'collections' }))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getSidebarContentClasses('api') },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: 'api', isVisible: this.state.activeTab === 'api' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_dev_components_api_sidebar_APISidebarContainer_APISidebarContainer__WEBPACK_IMPORTED_MODULE_10__["default"], { ref: 'api' })))))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4849:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _CollectionSidebarMenuContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4850);
/* harmony import */ var _CollectionSidebarListContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4852);
/* harmony import */ var _components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4873);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2078);
var _class;





let


CollectionSidebarContainer = pure_render_decorator__WEBPACK_IMPORTED_MODULE_1___default()(_class = class CollectionSidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CollectionSidebarUIStore');
    this.focus = this.focus.bind(this);
    this.focusCollection = this.focusCollection.bind(this);
    this.focusNext = this.focusNext.bind(this);
  }

  focus() {
    _.invoke(this, 'refs.list.focus');
  }

  focusCollection(collectionId, CollectionSidebarContainer) {
    _.invoke(this, 'refs.list.__wrappedInstance.focusCollection', collectionId, CollectionSidebarContainer);
  }

  focusNext() {
    let collection = _.head(this.store.collections);
    _.invoke(this, 'refs.list.handleSelect', collection.id);
  }

  render() {
    let ActiveWorkspaceStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore');
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar', onClick: this.focus },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionSidebarMenuContainer__WEBPACK_IMPORTED_MODULE_2__["default"], null),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionSidebarListContainer__WEBPACK_IMPORTED_MODULE_3__["default"], {
            ref: 'list' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_4__["default"], {
          archivedResources: ActiveWorkspaceStore,
          label: 'COLLECTIONS',
          showWarning: true,
          onClick: _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openArchivedCollections"] })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4850:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarMenuContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_collections_sidebar_CollectionSidebarMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4851);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1789);


let

CollectionSidebarMenuContainer = class CollectionSidebarMenuContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { currentSortType: pm.settings.getSetting('sidebarCollectionsSortType') || 'name' };

    this.handleNewCollectionClick = this.handleNewCollectionClick.bind(this);
    this.handleSortTypeChange = this.handleSortTypeChange.bind(this);
  }

  handleNewCollectionClick() {
    pm.mediator.trigger('showNewCollectionModal');
  }

  handleSortTypeChange(nextType) {
    this.setState({ currentSortType: nextType }, () => {
      pm.settings.setSetting('sidebarCollectionsSortType', nextType);
    });
    pm.mediator.trigger('sidebarSortChange', nextType);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: 'header' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_sidebar_CollectionSidebarMenu__WEBPACK_IMPORTED_MODULE_1__["default"], {
          currentSortType: this.state.currentSortType,
          onNewCollectionClick: this.handleNewCollectionClick,
          onSortTypeChange: this.handleSortTypeChange })));



  }};

/***/ }),

/***/ 4851:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1789);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2078);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__);
var _class;






let


CollectionSidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class CollectionSidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSortTypeChange = this.handleSortTypeChange.bind(this);
    this.handleNewCollectionClick = this.handleNewCollectionClick.bind(this);
  }

  handleNewCollectionClick(value) {
    this.props.onNewCollectionClick && this.props.onNewCollectionClick(value);
  }

  handleSortTypeChange(nextType) {
    this.props.onSortTypeChange && this.props.onSortTypeChange(nextType);
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    } else
    {
      return 'Create new Collection';
    }
  }

  getAddIconClass(isEnabled) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-sidebar-menu__actions-new-button': true,
      'collection-sidebar-menu__actions-new-collection': isEnabled });

  }

  render() {
    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore'),
    isLoggedIn = currentUser.isLoggedIn;

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('PermissionStore'),
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').id,
    canAddCollection = permissionStore.can('addCollection', 'workspace', workspaceId);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-menu' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-menu__actions' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'addCollection' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                className: 'collection-sidebar-menu__actions-new-collection-wrapper',
                onClick: this.handleNewCollectionClick,
                tooltip: this.getTooltipText(!canAddCollection),
                disabled: !canAddCollection,
                type: 'text' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-add-stroke', size: 'small', className: this.getAddIconClass(canAddCollection) }), 'New Collection')),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: 'collectionTrash' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                onClick: _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openCollectionsTrash"],
                tooltip: isLoggedIn ? 'Recover your deleted collections' : 'Only signed in users can recover deleted collections',
                disabled: !isLoggedIn,
                type: 'text',
                className: 'collection-sidebar-menu__actions-trash' }, 'Trash')))));







  }}) || _class;

/***/ }),

/***/ 4852:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarListContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var _components_collections_CollectionSidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4853);
/* harmony import */ var _components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1794);
/* harmony import */ var _modules_services_CollectionSidebarService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4854);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1545);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(615);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1789);
/* harmony import */ var _components_empty_states_CollectionSidebarEmptyShell__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4855);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2451);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4570);
/* harmony import */ var _components_collections_sidebar_CollectionSidebarListItemFolder__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4856);
/* harmony import */ var _components_collections_sidebar_CollectionSidebarListItemRequest__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4862);
/* harmony import */ var _components_collections_sidebar_CollectionSidebarListItemHead__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4865);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(751);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1269);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(742);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4861);
/* harmony import */ var _utils_CollectionActionsUtil__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4868);
/* harmony import */ var _CollectionSidebarListItemEmpty__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4872);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_23__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;





















const DEFAULT_HEIGHT = 30,
ITEM_HEAD_HEIGHT = 60,
EMPTY_ITEM_HEIGHT = 56,
OVERSCAN_COUNT = 5,
COLLECTION = 'collection',
FOLDER = 'folder',
REQUEST = 'request',
EMPTY = 'empty';











/**
                                                            * @to-do: Move this helper function to InlineInput component
                                                            *
                                                            * @param {Object} editStateFromInput - state of InlineInput
                                                            *
                                                            * @returns {String|undefined}
                                                            */
function getInputValueFromInputEditState(editStateFromInput) {
  if (!(editStateFromInput && editStateFromInput.inlineInput)) {
    return;
  }

  return editStateFromInput.inlineInput.value;
}let



CollectionSidebarListContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_23___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class CollectionSidebarListContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      collections: [],
      filter: 'all',
      filterQuery: '',
      sortType: pm.settings.getSetting('sidebarCollectionsSortType') || 'name' };


    this.focusNext = this.focusNext.bind(this);
    this.focusPrev = this.focusPrev.bind(this);
    this.focusCollection = this.focusCollection.bind(this);
    this.expandItem = this.expandItem.bind(this);
    this.collapseItem = this.collapseItem.bind(this);
    this.selectItem = this.selectItem.bind(this);
    this.cutItem = this.cutItem.bind(this);
    this.copyItem = this.copyItem.bind(this);
    this.pasteItem = this.pasteItem.bind(this);
    this.duplicateItem = this.duplicateItem.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.renameItem = this.renameItem.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleDuplicate = this.handleDuplicate.bind(this);
    this.handleSidebarSortChange = this.handleSidebarSortChange.bind(this);
    this.handlePreviewRequestDebounced = _.debounce(this.openPreviewRequest, 300, { leading: true });
    this.duplicateItemThrottled = _.throttle(this.duplicateItem, 300, { leading: true, trailing: false });
    this.focusCollection = this.focusCollection.bind(this);
    this.handleCollectionBrowserOpened = this.handleCollectionBrowserOpened.bind(this);
    this.handleCollectionBrowserClosed = this.handleCollectionBrowserClosed.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.toggleCollectionBrowser = this.toggleCollectionBrowser.bind(this);
    this.handleDragDrop = this.handleDragDrop.bind(this);
    this.handleRequestActions = this.handleRequestActions.bind(this);
    this.handleRequestActionsDebounced = _.debounce(this.handleRequestActions, 300, { leading: true });
    this.handleFolderActions = this.handleFolderActions.bind(this);
    this.handleRenameShortcut = this.handleRenameShortcut.bind(this);
    this.getListItem = this.getListItem.bind(this);
    this.getItemSize = this.getItemSize.bind(this);
    this.observeSizeChange = this.observeSizeChange.bind(this);
    this.unobserveSizeChange = this.unobserveSizeChange.bind(this);
    this.scrollToItemById = this.scrollToItemById.bind(this);

    // edit cache
    this.setEditCache = this.setEditCache.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.saveCachedValue = this.saveCachedValue.bind(this);
    this.handleQuitShortcut = this.handleQuitShortcut.bind(this);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore');

    // height set for empty list items, as their height may change due to sidebar resizing
    this.heightSetForEmptyItems = {};

    // To reset cached height when there are changes in list items, for example
    // if there is a drag/drop.
    this.heightReactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_17__["reaction"])(() => this.store.visibleCollections, () => {
      this.listRef && this.listRef.resetAfterIndex(0);
    });

    // To move to the specified list item on focus shift
    this.focusReactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_17__["reaction"])(() => this.store.activeItem, activeItem => {
      if (!activeItem) {
        return;
      }

      this.scrollToItemById(activeItem.id);
    });

    // resize observer for empty list items
    this.resizeObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        if (!(entry && entry.target && entry.target.dataset)) {
          return;
        }

        let index = entry.target.dataset.index;

        this.heightSetForEmptyItems[index] = entry.target.offsetHeight;
      }

      this.listRef.resetAfterIndex(0);
    });

    /**
         * cache for item currently in edit mode
         *
         * @type {Object}
         * @property {String} id - id of the list item in edit mode
         * @property {String} type - type of the list item (collection / folder / request)
         * @property {Object} listItem - cache of EnvironmentPreviewListItem state
         * @property {Object} inlineInput - cache of inlineInput state
         */
    this.editCache = null;
  }

  componentDidMount() {
    this.attachMediatorListeners();
  }

  componentWillUnmount() {
    this.detachMediatorListeners();
    this.heightReactionDisposer && this.heightReactionDisposer();
    this.focusReactionDisposer && this.focusReactionDisposer();

    // If any item is in edit mode and not in view,
    // this will update the value if the component unmounts
    this.saveCachedValue();
  }

  scrollToItemById(itemId) {
    if (!itemId) {
      return;
    }

    let foundIndex = _.findIndex(this.store.visibleCollections, visibleItem => visibleItem.id === itemId);

    // item not found
    if (foundIndex < 0) {
      return;
    }

    this.listRef && this.listRef.scrollToItem(foundIndex);
  }

  saveCachedValue() {
    if (!this.editCache) {
      return;
    }

    let IdToUpdate = this.editCache.id,
    valueToUpdate = getInputValueFromInputEditState(this.editCache.inlineInput);

    // value can be an empty string hence checking for `isNil` (null/undefined)
    if (!IdToUpdate || _.isNil(valueToUpdate)) {
      return;
    }

    this.handleDropdownActionSelect(
    this.editCache.type,
    IdToUpdate,
    _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME"],
    { name: valueToUpdate });


    // clear the editCache after updating the value in DB
    this.setEditCache(null);
  }

  handleClickOutside(e) {
    const targetClassName = e && e.target && e.target.className,
    isFromInput = targetClassName === 'input input-box inline-input';

    if (!isFromInput && this.editCache) {
      this.saveCachedValue();

      // stop the propagation to children elements, as this click is supposed to save the item
      // currently in edit mode. Also `saveCachedValue` will trigger a re-render.
      e && e.stopPropagation();
    }
  }

  setEditCache(value) {
    this.editCache = value;
  }

  handleQuitShortcut() {
    this.setEditCache(null);
    this.renameItem(false);
  }

  observeSizeChange(node) {
    this.resizeObserver && this.resizeObserver.observe(node);
  }

  unobserveSizeChange(node, index) {
    this.resizeObserver && this.resizeObserver.unobserve(node);
    delete this.heightSetForEmptyItems[index];
  }

  getKeyMapHandlers() {
    return {
      nextItem: pm.shortcuts.handle('nextItem', this.focusNext),
      prevItem: pm.shortcuts.handle('prevItem', this.focusPrev),
      expandItem: pm.shortcuts.handle('expandItem', this.expandItem),
      collapseItem: pm.shortcuts.handle('collapseItem', this.collapseItem),
      select: pm.shortcuts.handle('select', this.selectItem),
      cut: pm.shortcuts.handle('cut', this.cutItem),
      copy: pm.shortcuts.handle('copy', this.copyItem),
      paste: pm.shortcuts.handle('paste', this.pasteItem),
      duplicate: pm.shortcuts.handle('duplicate', this.duplicateItemThrottled),
      delete: pm.shortcuts.handle('delete', this.deleteItem),
      rename: pm.shortcuts.handle('rename', this.handleRenameShortcut),
      search: pm.shortcuts.handle('search'),
      quit: pm.shortcuts.handle('quit', this.handleQuitShortcut) // discard changes
    };
  }

  handleRenameShortcut() {
    if (!this.store.activeItem) {
      return;
    }

    if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('edit', this.store.activeItem.type, this.store.activeItem.id)) {
      pm.toasts.error(`You do not have the permissions required to rename this ${this.store.activeItem.type}.`);
      return;
    }

    let isEditing = _.get(this.store, 'renamingItem.id') === _.get(this.store, 'activeItem.id');

    this.renameItem(!isEditing, this.store.activeItem);
  }

  focus() {
    let list = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.refs.list);
    list && list.focus();
  }

  openPreviewRequest(id) {
    let reqResource = Object(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_9__["requestResourceId"])({ id });
    _services_EditorService__WEBPACK_IMPORTED_MODULE_8__["default"].open(reqResource);
    pm.mediator.trigger('hideCollectionBrowser');
  }

  focusCollection(collectionId, collectionDetailsTab) {
    _.invoke(this, `refs[${collectionId}].focusCollection`, collectionId, collectionDetailsTab);
  }

  focusNext(e) {
    e && e.preventDefault();
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').focusNextItem();
    let activeItem = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem;
    if (!activeItem || activeItem.type !== 'request') {
      this.handlePreviewRequestDebounced.cancel && this.handlePreviewRequestDebounced.cancel();
      return;
    }
    this.handlePreviewRequestDebounced(activeItem.id);
  }

  focusPrev(e) {
    e && e.preventDefault();

    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').focusPreviousItem();
    let activeItem = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem;
    if (!activeItem || activeItem.type !== 'request') {
      this.handlePreviewRequestDebounced.cancel && this.handlePreviewRequestDebounced.cancel();
      return;
    }
    this.handlePreviewRequestDebounced(activeItem.id);
  }

  expandItem(e) {
    e && e.preventDefault();

    let CollectionSidebarUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore'),
    activeItem = CollectionSidebarUIStore.activeItem;

    if (!activeItem) {
      return;
    }

    CollectionSidebarUIStore.openItem({ id: activeItem.id, type: activeItem.type });
  }

  collapseItem(e) {
    e && e.preventDefault();

    let CollectionSidebarUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore'),
    activeItem = CollectionSidebarUIStore.activeItem,
    activeItemStore;

    if (!activeItem) {
      return;
    }

    // if item is open, close the item
    if (CollectionSidebarUIStore.isOpen(activeItem.id)) {
      return CollectionSidebarUIStore.closeItem({ id: activeItem.id, type: activeItem.type });
    }

    // if item is already closed, focus the parent
    activeItemStore = CollectionSidebarUIStore.findItem(activeItem);

    if (!activeItemStore) {
      return;
    }

    if (activeItemStore.parent && CollectionSidebarUIStore.isOpen(activeItemStore.parent.id)) {
      return CollectionSidebarUIStore.closeItem({ id: activeItemStore.parent.id, type: activeItemStore.parent.type });
    }

    if (activeItemStore.parent) {
      CollectionSidebarUIStore.focusItem(_.pick(activeItemStore.parent, ['id', 'type']));
    }
  }

  getActiveCollectionId() {
    return Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeCollection;
  }

  handleSelect(collectionId, cb) {
    this.store.focusItem({
      id: collectionId,
      type: 'collection' });


    this.store.isOpen(collectionId) ? this.store.openItem(collectionId) : this.store.toggleItem(collectionId);
    cb && cb();
  }

  handleDuplicate(id, type) {
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').focusItem({ id, type });
    if (type !== 'request') {
      return;
    }
    this.openPreviewRequest(id);
  }

  handleSidebarSortChange(type) {
    this.setState({ sortType: type });
  }

  getItemSize(index) {
    let currentItem = _.get(this.store, ['visibleCollections', index]);

    if (!currentItem) {
      return 0;
    }

    if (currentItem.type === COLLECTION) {
      return ITEM_HEAD_HEIGHT;
    }

    if (currentItem.type === EMPTY) {
      return this.heightSetForEmptyItems[index] || EMPTY_ITEM_HEIGHT;
    }

    return DEFAULT_HEIGHT;
  }

  getXPathForItem(item) {
    if (!item) {
      return;
    }

    if (item.type === COLLECTION) {
      return item.id;
    }

    return `${this.getXPathForItem(item.parent)}/${item.type}/${item.itemIndex}`;
  }

  getListItem(data) {
    let item = _.get(this.store, ['visibleCollections', data.index]),
    prevItem = data.index && _.get(this.store, ['visibleCollections', data.index - 1]), // if index is not zero
    nextItem = data.index + 1 <= this.store.visibleCollections.length && _.get(this.store, ['visibleCollections', data.index + 1]),
    isLastItemInCollection = nextItem && !nextItem.depth, // collection does not have a depth
    renamingItemID = _.get(this.store, 'renamingItem.id');

    if (!item) {
      return null;
    }

    let isEditing = item.id && item.id === renamingItemID;

    switch (item.type) {
      case EMPTY:
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className:
              classnames__WEBPACK_IMPORTED_MODULE_2___default()(
              'collection-virtualized-list-item__empty',
              {
                'is-last-item': isLastItemInCollection || !nextItem }),


              style: data.style },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionSidebarListItemEmpty__WEBPACK_IMPORTED_MODULE_22__["default"], {
              parent: prevItem,
              parentType: prevItem && prevItem.type,
              canAddRequest: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('addRequest', prevItem.type, prevItem.id),
              depth: item.depth,
              index: data.index,
              observeSizeChange: this.observeSizeChange,
              unobserveSizeChange: this.unobserveSizeChange,
              onAddRequest: this.handleCreateRequest })));



      case COLLECTION:
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-virtualized-list-item__head', style: data.style },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: item.id, key: item.id },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_sidebar_CollectionSidebarListItemHead__WEBPACK_IMPORTED_MODULE_16__["default"], {
                key: item.id,
                onItemToggle: this.handleSelect,
                collection: item,
                id: item.id,
                onToggleFavorite: this.handleCollectionFavoriteToggle.bind(this, item),
                isFocused: item.id === _.get(this.store, 'activeItem.id'),
                isOpen: this.store.isOpen(item.id),
                onAddRequest: this.handleCreateRequest,
                onCollectionBrowserToggle: this.toggleCollectionBrowser.bind(this, item.id),
                onDragDrop: this.handleDragDrop,
                onDropdownActionSelect: this.handleDropdownActionSelect,
                onRenameToggle: this.renameItem,
                isExpanded: this.store.expandedItem === item.id,
                isEditing: isEditing,
                setEditCache: this.setEditCache,
                editCache: isEditing && this.editCache }))));




      case FOLDER:
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className:
              classnames__WEBPACK_IMPORTED_MODULE_2___default()(
              'collection-virtualized-list-item__folder',
              {
                'is-last-item': isLastItemInCollection || !nextItem }),


              style: data.style },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: this.getXPathForItem(item), key: this.getXPathForItem(item) },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_sidebar_CollectionSidebarListItemFolder__WEBPACK_IMPORTED_MODULE_14__["default"], _extends({},
              _.pick(item, [
              'id',
              'method',
              'name']), {

                collectionId: item.collection,
                isRenaming: item.id === renamingItemID,
                key: item.id,
                id: item.id,
                onItemToggle: this.handleSelect,
                isFocused: item.id === _.get(this.store, 'activeItem.id'),
                folder: item,
                isOpen: this.store.isOpen(item.id),
                depth: item.depth,
                folderId: item.id,
                isFirstChild: prevItem && prevItem.depth < item.depth,
                onAddRequest: this.handleCreateRequest,
                onDragDrop: this.handleDragDrop,
                onDropdownActionSelect: this.handleDropdownActionSelect,
                onRenameToggle: this.renameItem,
                isEditing: isEditing,
                setEditCache: this.setEditCache,
                editCache: isEditing && this.editCache })))));




      case REQUEST:
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className:
              classnames__WEBPACK_IMPORTED_MODULE_2___default()(
              'collection-virtualized-list-item__request',
              {
                'is-last-item': isLastItemInCollection || !nextItem }),


              style: data.style },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: this.getXPathForItem(item), key: this.getXPathForItem(item) },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_sidebar_CollectionSidebarListItemRequest__WEBPACK_IMPORTED_MODULE_15__["default"], _extends({},
              _.pick(item, [
              'id',
              'method',
              'name']), {

                collectionId: item.collection,
                id: item.id,
                folderId: item.folder,
                key: item.id,
                depth: item.depth,
                isRenaming: item.id === renamingItemID,
                isFocused: item.id === _.get(this.store, 'activeItem.id'),
                isFirstChild: prevItem && prevItem.depth < item.depth,
                onDragDrop: this.handleDragDrop,
                onDropdownActionSelect: this.handleDropdownActionSelect,
                onRenameToggle: this.renameItem,
                isEditing: isEditing,
                setEditCache: this.setEditCache,
                editCache: isEditing && this.editCache })))));




      default:
        return null;}

  }

  attachMediatorListeners() {
    pm.mediator.on('collectionBrowserOpened', this.handleCollectionBrowserOpened);
    pm.mediator.on('collectionBrowserClosed', this.handleCollectionBrowserClosed);
  }

  detachMediatorListeners() {
    pm.mediator.off('collectionBrowserOpened', this.handleCollectionBrowserOpened);
    pm.mediator.off('collectionBrowserClosed', this.handleCollectionBrowserClosed);
  }

  focusCollection(collectionId, collectionDetailsTab = 'Documentation') {
    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').focusItem({
      id: collectionId,
      type: 'collection' });

    pm.mediator.trigger('showCollectionBrowser', collectionId, collectionDetailsTab);
    return true;
  }

  getActiveItemId() {
    return _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore'), ['activeItem', 'id']);
  }

  selectItem(e) {
    if (this.store.renamingItem) {
      this.saveCachedValue();
      return;
    }

    let activeItem = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem;
    if (this.state.isEditing || _.isEmpty(activeItem)) {
      return;
    }

    e && e.preventDefault();

    let isRequest = activeItem.type === 'request';
    isRequest && this.handleRequestActions(activeItem.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_SELECT"], { returnKey: true });
  }

  cutItem() {
    let itemToCut = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem;

    switch (itemToCut.type) {
      case 'request':
        if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('delete', 'request', itemToCut.id)) {
          return pm.toasts.error('You do not have permissions required to perform the action.');
        }
      case 'folder':
        if (!Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('delete', 'folder', itemToCut.id)) {
          return pm.toasts.error('You do not have permissions required to perform the action.');
        }
        break;
      default: // collection cut is not supported
        return;}


    pm.clipboard.cutItem(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem, itemToCut.id);
  }

  copyItem() {
    pm.clipboard.copyItem(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem, this.getActiveCollectionId());
  }

  pasteItem() {
    let clipboard = pm.clipboard.getClipboard();

    if (_.isEmpty(clipboard)) {
      return false;
    }

    let destination = {
      collection: this.getActiveCollectionId(),
      id: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem.id,
      type: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem.type };


    switch (clipboard.type) {

      case 'folder':
        if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('addFolder', 'collection', destination.id)) {
          return pm.clipboard.pasteItem(destination);
        } else
        {
          return pm.toasts.error('You do not have permissions required to perform the action.');
        }

      case 'request':
        if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('addRequest', 'collection', destination.id)) {
          return pm.clipboard.pasteItem(destination);
        } else
        {
          return pm.toasts.error('You do not have permissions required to perform the action.');
        }}


    Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').focusItem({
      id: destination.id,
      type: destination.type });

  }

  duplicateItem() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore'),
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('ActiveWorkspaceStore').id,
    canDuplicateCollection = permissionStore.can('addCollection', 'workspace', workspaceId),
    activeCollection = this.store.findItem({
      id: this.getActiveCollectionId(),
      type: COLLECTION });


    let {
      subscribed,
      write } =
    activeCollection,
    canEdit = !subscribed || subscribed && write;

    let activeItem = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem;

    if (!canEdit && activeItem.type !== 'collection') {
      return pm.toasts.error('You do not have permissions required to edit this collection.');
    }

    if (activeItem.type === 'collection') {
      // We're working with a collection
      if (canDuplicateCollection) {
        this.handleCollectionActions(this.getActiveCollectionId(), _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DUPLICATE"]);
      } else
      {
        return pm.toasts.error('You do not have permissions required to duplicate this collection.');
      }
    } else
    {
      // We're working with something inside the collection
      if (activeItem.type === 'folder') {
        if (permissionStore.can('duplicate', 'folder', activeItem.id)) {
          return this.handleFolderActions(activeItem.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DUPLICATE"]);
        } else
        {
          return pm.toasts.error('You do not have permissions required to duplicate this folder.');
        }
      }

      if (activeItem.type === 'request') {
        if (permissionStore.can('duplicate', 'request', activeItem.id)) {
          return this.handleRequestActions(activeItem.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DUPLICATE"]);
        } else
        {
          return pm.toasts.error('You do not have permissions required to duplicate this request.');
        }
      }
    }
    this.renameItem(false);
  }

  deleteItem(e) {
    let activeItem = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').activeItem;

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore');

    if (this.state.isEditing || _.isEmpty(activeItem)) {
      return;
    }

    e && e.preventDefault();

    if (activeItem.type === 'request') {
      if (permissionStore.can('delete', 'request', activeItem.id)) {
        return this.handleRequestActions(activeItem.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DELETE"]);
      }
      return pm.toasts.error('You do not have permissions required to delete this request.');
    }

    if (activeItem.type === 'folder') {
      if (permissionStore.can('delete', 'folder', activeItem.id)) {
        return this.handleFolderActions(activeItem.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DELETE"]);
      }
      return pm.toasts.error('You do not have permissions required to delete this folder.');
    }

    if (permissionStore.can('delete', 'collection', this.getActiveCollectionId())) {
      return this.handleCollectionActions(activeItem.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DELETE"]);
    }
    return pm.toasts.error('You do not have permissions required to delete this collection.');
  }

  renameItem(isEditing, source) {
    if (isEditing === false) {
      this.store.setRenamingItem(null);
      this.setEditCache(null);
    } else
    {
      this.store.setRenamingItem(source);
    }
  }

  /**
     * computes and returns the nextState.openItems
     * @param  {Array}   item   flattenedNode
     * @param  {Boolean} isOpen [optional] boolean to force open/close.
     *                          toggles if not provided.
     * @return {Array}          nextState.openItems
     */


  toggleCollectionBrowser(collectionId) {
    if (this.store.expandedItem === collectionId) {
      pm.mediator.trigger('hideCollectionBrowser');
    } else
    {
      pm.mediator.trigger('showCollectionBrowser', collectionId);
    }
  }

  handleCollectionBrowserOpened(id) {
    this.store.setExpandedItem(id);
  }

  handleCollectionBrowserClosed() {
    this.store.expandedItem && this.store.setExpandedItem(null);
  }

  handleDropdownActionSelect(type, id, action, modifiers) {
    if (type === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TARGET_COLLECTION"]) {
      this.handleCollectionActions(id, action, modifiers);
    } else
    if (type === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TARGET_FOLDER"]) {
      this.handleFolderActions(id, action, modifiers);
    } else
    if (type === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TARGET_REQUEST"]) {
      this.handleRequestActions(id, action, modifiers);
    }
  }

  handleCollectionActions(id, action, modifiers) {
    Object(_utils_CollectionActionsUtil__WEBPACK_IMPORTED_MODULE_21__["default"])(id, action, modifiers, { origin: 'sidebar' }, () => {
      if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DELETE"]) {
        this.focusPrev();
      } else
      if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME"]) {
        this.renameItem(false);
      } else
      if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_REMOVE_FROM_WORKSPACE"]) {
        this.focusPrev();
      } else
      if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME_TOGGLE"]) {
        Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').setRenamingItem({ id: id, type: 'collection' });
        let activeItemID = this.getActiveItemId();

        if (activeItemID === id) {
          this.renameItem(true, { id: id, type: 'collection' });
        }
      }
    });
  }

  handleFolderActions(id, action, modifiers) {
    const canDuplicateFolder = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('duplicate', 'folder', id);

    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_EDIT"] || action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_VIEW_ONLY"]) {
      pm.mediator.trigger('showEditFolderModal', id, undefined, 'collection_sidebar');
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DUPLICATE"] && canDuplicateFolder) {
      let duplicateFolderEvent = {
        name: 'duplicate',
        namespace: 'folder',
        data: { folder: { id } } };

      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__["default"])(duplicateFolderEvent).
      then(response => {
        let duplicatedFolderEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_19__["findEvents"])(response.response, { name: 'created_deep_at', namespace: 'folder' }),
        duplicatedFolderId = _.get(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_19__["getEventData"])(_.head(duplicatedFolderEvent)), 'folder.id');
        duplicatedFolderId && this.handleDuplicate(duplicatedFolderId, 'folder');
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in duplicating folder', response.error);
          return;
        }
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while duplicating folder', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteFolderModal', id, () => {
        this.focusPrev();
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_ADD_REQUEST"]) {
      this.handleCreateRequest(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('FolderStore').find(id));
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_ADD_FOLDER"]) {
      pm.mediator.trigger('showAddFolderModal', this.getActiveCollectionId(), id);
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME"]) {
      let updateFolderEvent = {
        name: 'update',
        namespace: 'folder',
        data: { id, name: modifiers.name } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__["default"])(updateFolderEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in renaming folder', response.error);
          return;
        }
        pm.mediator.trigger('focusSidebar');
        this.renameItem(false);
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while renaming folder', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME_TOGGLE"]) {
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').setRenamingItem({ id: id, type: 'folder' });
      let activeItemID = this.getActiveItemId();
      if (activeItemID === id) {
        this.renameItem(true, { id: id, type: 'folder' });
      }
    }
  }

  handleRequestActions(id, action, modifiers = {}) {
    const canDuplicateRequest = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('duplicate', 'request', id);
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_EDIT"]) {
      pm.mediator.trigger('editCollectionRequest', id, 'collection_sidebar');
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DUPLICATE"] && canDuplicateRequest) {

      let duplicateRequestEvent = {
        name: 'duplicate',
        namespace: 'request',
        data: { request: { id } } };

      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__["default"])(duplicateRequestEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in duplicating request', response.error);
          return;
        }

        let duplicatedRequestEvent = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_19__["findEvents"])(response.response, { name: 'created', namespace: 'request' }),
        duplicatedRequestId = _.get(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_19__["getEventData"])(_.head(duplicatedRequestEvent)), 'id');
        duplicatedRequestId && this.handleDuplicate(duplicatedRequestId, 'request');
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while duplicating request', err);
      });

      // Bulk Analytics event added from controller
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteRequestModal', id, () => {
        this.focusPrev();
      });
    } else
    if (_.includes([_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_OPEN_IN_NEW_TAB"], _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_SELECT"]], action)) {
      let newTabKey = false,
      newTabAction = action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_OPEN_IN_NEW_TAB"],
      isOsxPlatform = _.includes(navigator.platform, 'Mac');

      if (modifiers) {
        newTabKey = modifiers.shiftKey && (isOsxPlatform ? modifiers.metaKey : modifiers.ctrlKey);
      }

      _modules_services_CollectionSidebarService__WEBPACK_IMPORTED_MODULE_7__["default"].openRequestInTab(id, {
        newTab: newTabKey || newTabAction });


      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').focusItem({
        id: id,
        type: 'request' });


      (modifiers.returnKey || newTabAction) && pm.mediator.trigger('focusBuilder');
      pm.mediator.trigger('hideCollectionBrowser');
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME"]) {
      let updateRequestEvent = {
        name: 'update',
        namespace: 'request',
        data: { id, name: modifiers.name } };


      Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__["default"])(updateRequestEvent).
      then(response => {
        if (!_.isEmpty(_.get(response, 'error'))) {
          pm.logger.error('Error in renaming request', response.error);
          return;
        }
        pm.mediator.trigger('focusSidebar');
        this.renameItem(false);
      }).
      catch(err => {
        pm.logger.error('Error in pipeline while renaming request', err);
      });
    } else
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_20__["ACTION_TYPE_RENAME_TOGGLE"]) {
      Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionSidebarUIStore').setRenamingItem({ id: id, type: 'request' });
      let activeItemID = this.getActiveItemId();
      if (activeItemID === id) {
        this.renameItem(true, { id: id, type: 'request' });
      }
    }
  }

  handleDragDrop(source, destination, position) {
    if (source.id === destination.id) {
      return;
    }

    let moveItemEvent = {};
    if (destination.type === 'request' && source.type === 'request') {
      if (position === 'on') {
        position = 'before';
      }
      moveItemEvent = {
        name: 'move',
        namespace: 'request',
        data: {
          model: 'request',
          request: { id: source.id },
          [position]: {
            model: destination.type,
            modelId: destination.id } } };



    } else

    if (destination.type === 'folder' && source.type === 'folder') {
      if (position === 'on') {
        position = 'target';
      }
      moveItemEvent = {
        name: 'move',
        namespace: source.type,
        data: {
          model: source.type,
          [source.type]: { id: source.id },
          [position]: {
            model: destination.type,
            modelId: destination.id } } };



    } else

    if (destination.type === 'folder' && source.type === 'request') {
      if (position === 'on') {
        position = 'target';
      }
      moveItemEvent = {
        name: 'move',
        namespace: source.type,
        data: {
          model: source.type,
          [source.type]: { id: source.id },
          target: {
            model: destination.type,
            modelId: destination.id } } };



    } else

    if (destination.type === 'collection' && _.includes(['request', 'folder'], source.type)) {
      moveItemEvent = {
        name: 'move',
        namespace: source.type,
        data: {
          model: source.type,
          [source.type]: { id: source.id },
          target: {
            model: destination.type,
            modelId: destination.id } } };



    }

    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__["default"])(moveItemEvent).
    then(response => {
      if (!_.isEmpty(_.get(response, 'error'))) {
        pm.toasts.error(`Something went wrong while moving this ${source.type}`);
        return;
      }
    }).
    catch(err => {
      pm.toasts.error(`Something went wrong while moving this ${source.type}`);
    });
  }

  handleCollectionFavoriteToggle(collection) {
    if (!collection) {
      return;
    }

    let collectionId = collection.id,
    isFavorite = collection.isFavorite,
    action = !isFavorite ? 'favorite' : 'unfavorite',
    favoriteCollectionEvent = {
      name: action,
      namespace: 'collection',
      data: { collection: { id: collectionId } },
      meta: { origin: 'collection_browser' } };


    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_18__["default"])(favoriteCollectionEvent).
    then(response => {
      if (!_.isEmpty(_.get(response, 'error'))) {
        pm.logger.error(`Error while ${action} action in collection`, response.error);
        return;
      }
    }).
    catch(err => {
      pm.logger.error(`Error in pipeline while ${action} action in collection`, err);
    });
  }

  handleCreateRequest(target) {
    let collection = null,
    folder = null;

    switch (target.type) {
      case 'collection':
        collection = target;
        break;
      case 'folder':
        folder = target;
        break;}


    let initialSelection = {
      target: {
        collection,
        folder } };



    pm.mediator.trigger('showAddToCollectionModal', {}, initialSelection);
  }

  render() {
    let collections = this.store.visibleCollections,
    isHydrating = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').isHydrating;

    if (_.isEmpty(collections)) {
      let query = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('RequesterSidebarStore').searchQuery;
      return isHydrating ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CollectionSidebarEmptyShell__WEBPACK_IMPORTED_MODULE_11__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_collections_CollectionSidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_5__["default"], { query: query });
    }

    const lister = data => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_3__["Observer"], null,
          this.getListItem.bind(this, data)));


    },
    sizer = ({ height, width }) => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_3__["Observer"], null,
          () =>
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_window__WEBPACK_IMPORTED_MODULE_12__["VariableSizeList"], {
              height: height,
              itemCount: collections.length,
              itemSize: this.getItemSize,
              width: width,
              ref: ref => this.listRef = ref,
              overscanCount: OVERSCAN_COUNT,
              className: 'collection-sidebar-list__list' },

            lister)));





    };

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_6__["default"], { handlers: this.getKeyMapHandlers() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'collection-sidebar-list',
            'data-filter': this.state.filter,
            ref: 'list'

            // using `onClickCapture` instead of `onClick` to prevent propagation in cases of some item
            // already being in edit mode, and using the click to just save the item
            , onClickCapture: this.handleClickOutside },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_13__["default"], null, sizer))));



  }}) || _class) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4853:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarListEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__);
var _class;



let


CollectionSidebarListEmptyItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class CollectionSidebarListEmptyItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleCreateCollection = this.handleCreateCollection.bind(this);
  }

  handleCreateCollection() {
    this.props.onClose && this.props.onClose();
    pm.mediator.trigger('showNewCollectionModal', id => {
      pm.mediator.trigger('focusCollectionInSideBar', id);
    });
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  getContents() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('PermissionStore'),
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').id,
    canAddCollection = permissionStore.can('addCollection', 'workspace', workspaceId);

    if (this.props.query) {
      return `No results found for "${this.props.query}"`;
    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__illustration-wrapper entity-empty__illustration-wrapper--collections' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collections-empty__illustration' })),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'You don\u2019t have any collections'),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' }, 'Collections let you group related requests, making them easier to access and run.'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'text',
              onClick: this.handleCreateCollection,
              disabled: !canAddCollection,
              tooltip: this.getTooltipText(!canAddCollection) },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
              name: 'icon-action-add-stroke',
              className: 'create-collection-icon pm-icon pm-icon-secondary' }), 'Create a collection'))));






  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-empty-item' },
        this.getContents()));


  }}) || _class;

/***/ }),

/***/ 4854:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1545);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(615);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_1__);



let CollectionSidebarService = {
  openRequestInTab: function (id, opts) {
    if (!id) {
      return Promise.reject(new Error('CollectionSidebarService~openRequestInTab: Request resource is a mandatory parameter'));
    }

    let requestResource = Object(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_1__["requestResourceId"])({ id });

    return _services_EditorService__WEBPACK_IMPORTED_MODULE_0__["default"].open(requestResource, { forceNew: opts && opts.newTab });
  } };


/* harmony default export */ __webpack_exports__["default"] = (CollectionSidebarService);

/***/ }),

/***/ 4855:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const NUMBER_OF_COLLECTION_ITEMS = 5;

const CollectionSidebarEmptyShell = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-empty-shell' },

      _.times(NUMBER_OF_COLLECTION_ITEMS, index => {
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { key: index, className: 'collection-sidebar-empty-shell--collection' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-empty-shell--collection__dropdown' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-empty-shell--collection__icon' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-empty-shell--collection__info' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                className: 'collection-sidebar-empty-shell--collection__info--name',
                style: { 'width': `${Math.floor(Math.random() * 74) + 50}px` } }),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                className: 'collection-sidebar-empty-shell--collection__info--count',
                style: { 'width': `${Math.floor(Math.random() * 27) + 30}px` } }))));




      })));



};

/* harmony default export */ __webpack_exports__["default"] = (CollectionSidebarEmptyShell);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4856:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarListItemFolder; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2136);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1763);
/* harmony import */ var _base_ContextMenu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4857);
/* harmony import */ var _base_InlineInput__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1881);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _FolderActionsDropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4860);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4861);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _dec, _dec2, _dec3, _class;














const FOLDER_ITEM_HEIGHT = 30,
permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore');

const folderSource = {
  canDrag(props) {
    if (props && props.isRenaming) {
      return false;
    }
    return Boolean(permissionStore.can('delete', 'folder', props.folder.id));
  },

  beginDrag(props) {
    return {
      id: props.id,
      type: 'folder',
      folderId: props.folderId,
      collectionId: props.collectionId };

  },

  endDrag(props, monitor) {
    const dragItem = monitor.getItem(),
    { dropItem, position } = monitor.getDropResult() || {};

    if (_.isUndefined(dropItem)) {
      return;
    }

    props.onDragDrop(dragItem, dropItem, position);
  } };


const folderTarget = {
  hover(props, monitor, component) {
    const dragId = monitor.getItem().id,
    dropId = props.id,
    folderItemComponent = component.getDecoratedComponentInstance(),
    dragItem = monitor.getItem();
    let isEditable = false;

    if (dragItem.type === 'request') {
      isEditable = permissionStore.can('addRequest', 'folder', props.id);
    } else
    if (dragItem.type === 'folder') {
      isEditable = permissionStore.can('addFolder', 'folder', props.id);
    }
    if (dragId === dropId || !isEditable) {
      return {};
    }

    let sourceOffset = monitor.getClientOffset(),
    targetOffset = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(component).getBoundingClientRect(),
    threshold = FOLDER_ITEM_HEIGHT * 0.25,
    bottomThreshold = targetOffset.top + FOLDER_ITEM_HEIGHT - threshold,
    topThreshold = targetOffset.top + threshold;

    if (monitor.getItem().type !== 'request' && sourceOffset.y > bottomThreshold) {
      folderItemComponent.scheduleHoverUpdate('bottom');
    } else
    if (monitor.getItem().type !== 'request' && sourceOffset.y < topThreshold) {
      folderItemComponent.scheduleHoverUpdate('top');
    } else
    if (sourceOffset.y < bottomThreshold && sourceOffset.y > topThreshold) {
      folderItemComponent.scheduleHoverUpdate('on');
    }
  },

  drop(props, monitor, component) {
    const dragId = monitor.getItem().id,
    dropId = props.id,
    dragItem = monitor.getItem();
    let isEditable = false;

    if (dragItem.type === 'request') {
      isEditable = permissionStore.can('addRequest', 'folder', props.id);
    } else
    if (dragItem.type === 'folder') {
      isEditable = permissionStore.can('addFolder', 'folder', props.id);
    }
    if (dragId === dropId || !isEditable) {
      return {};
    }

    let sourceOffset = monitor.getClientOffset();
    let targetOffset = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(component).getBoundingClientRect();

    let threshold = targetOffset.height * 0.25;

    let bottomThreshold = targetOffset.bottom - threshold;
    let topThreshold = targetOffset.top + threshold;

    let position;
    if (sourceOffset.y > bottomThreshold) {
      position = 'after';
    } else
    if (sourceOffset.y < topThreshold) {
      position = 'before';
    } else
    {
      position = 'on';
    }

    return {
      dropItem: {
        id: props.id,
        type: 'folder',
        collectionId: props.collectionId,
        folderId: props.folderId },

      position };

  } };let

























































































CollectionSidebarListItemFolder = (_dec = Object(_base_ContextMenu__WEBPACK_IMPORTED_MODULE_5__["default"])([{ label: 'Rename', shortcut: 'rename', isVisible(props) {return permissionStore.can('edit', 'folder', props.id);}, onClick(props, component) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_RENAME_TOGGLE"]);} }, { label: 'Edit', isVisible(props) {return permissionStore.can('edit', 'folder', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_EDIT"]);} }, { label: 'View Details', isVisible(props) {return !permissionStore.can('edit', 'folder', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_VIEW_ONLY"]);} }, { label: 'Add Request', isVisible(props) {return permissionStore.can('addRequest', 'folder', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_ADD_REQUEST"]);} }, { label: 'Add Folder', isVisible(props) {return permissionStore.can('addFolder', 'folder', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_ADD_FOLDER"]);} }, { label: 'Duplicate', shortcut: 'duplicate', isVisible(props) {return permissionStore.can('duplicate', 'folder', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_DUPLICATE"]);} }, { label: 'Delete', shortcut: 'delete', isVisible(props) {return permissionStore.can('delete', 'folder', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_DELETE"]);} }], monitor => {return { isContextMenuOpen: monitor.isOpen };}), _dec2 = Object(react_dnd__WEBPACK_IMPORTED_MODULE_3__["DropTarget"])(['collection-sidebar-request-item', 'collection-sidebar-folder-item'], folderTarget, (connect, monitor) => {return { connectDropTarget: connect.dropTarget(), isDragOver: monitor.isOver({ shallow: true }) };}), _dec3 = Object(react_dnd__WEBPACK_IMPORTED_MODULE_3__["DragSource"])('collection-sidebar-folder-item', folderSource, (connect, monitor) => {return { connectDragSource: connect.dragSource(), connectDragPreview: connect.dragPreview(), isDragging: monitor.isDragging() };}), _dec(_class = _dec2(_class = _dec3(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class CollectionSidebarListItemFolder extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      dropdownOpen: false,
      dropHoverTop: false,
      dropHoverBottom: false,
      dropHover: false,
      isHovered: false };


    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleItemToggle = this.handleItemToggle.bind(this);
    this.handleDropDownActionSelect = this.handleDropDownActionSelect.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
    this.setDropHoverTop = this.setDropHoverTop.bind(this);
    this.setDropHoverBottom = this.setDropHoverBottom.bind(this);
    this.setDropHover = this.setDropHover.bind(this);
    this.handleMouseHover = this.handleMouseHover.bind(this);
    this.handleMouseHoverDebounced = _.debounce(this.handleMouseHover, 300, {
      leading: false,
      trailing: true });

  }

  componentDidMount() {

    // If the list item was in edit state, restore its state
    if (this.props.editCache && this.refs.inlineInput) {
      this.setState(this.props.editCache.listItem, () => {
        this.refs.inlineInput.setEditState(this.props.editCache.inlineInput);
      });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    this.props.isEditing !== nextProps.isEditing && this.toggleEditName();
  }

  UNSAFE_componentWillUpdate(nextProps) {
    if (!this.props.isFocused && nextProps.isFocused) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  componentWillUnmount() {
    cancelAnimationFrame(this.requestedFrame);
    this.handleMouseHoverDebounced.cancel();

    // If the list item is in its edit state, cache the internal state
    if (this.props.isEditing && this.refs.inlineInput) {
      this.props.setEditCache({
        inlineInput: this.refs.inlineInput.getEditState(),
        id: this.props.id,
        type: 'folder',
        listItem: this.state });

    }
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'collection-sidebar-list-item__entity': true,
      'collection-sidebar-list-item__folder': true,
      'is-drop-hovered-top': this.state.dropHoverTop && this.props.isDragOver,
      'is-drop-hovered-bottom': this.state.dropHoverBottom && this.props.isDragOver });

  }

  getHeadClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'collection-sidebar-list-item__folder__head': true,
      'is-open': this.props.isOpen,
      'is-hovered': this.state.dropdownOpen,
      'is-focused': this.props.isFocused,
      'is-dragged': this.props.isDragging,
      'is-right-above': this.state.dropHover && this.props.isDragOver });

  }

  scheduleHoverUpdate(type) {
    let func = this.setDropHover;
    if (type === 'bottom') {
      func = this.setDropHoverBottom;
    } else
    if (type === 'top') {
      func = this.setDropHoverTop;
    }
    if (!this.requestedFrame) {
      this.requestedFrame = requestAnimationFrame(() => {
        try {
          func && func();
        }
        catch (e) {
        } finally
        {
          this.requestedFrame = null;
        }
      });
    }
  }

  setDropHoverTop() {
    !this.state.dropHoverTop &&
    this.setState({
      dropHoverBottom: false,
      dropHoverTop: true,
      dropHover: false });

  }

  setDropHoverBottom() {
    !this.state.dropHoverBottom &&
    this.setState({
      dropHoverBottom: true,
      dropHoverTop: false,
      dropHover: false });

  }

  setDropHover() {
    !this.state.dropHover &&
    this.setState({
      dropHoverBottom: false,
      dropHoverTop: false,
      dropHover: true });

  }

  toggleEditName() {
    if (permissionStore.can('edit', 'folder', this.props.id)) {
      if (this.props.isEditing) {
        this.refs.inlineInput && this.refs.inlineInput.stopEditing();
      } else {
        this.refs.inlineInput && this.refs.inlineInput.startEditing();
      }
      this.props.onRenameToggle(!this.props.isEditing, { id: this.props.id, type: 'folder' });
    } else
    {
      pm.toasts.error('You do not have the permissions required to rename this folder.');
    }
  }

  handleToggleEditName(isEditing) {
    if (!isEditing) {
      this.refs.inlineInput && this.refs.inlineInput.stopEditing();
      this.props.onRenameToggle(false);
      this.props.setEditCache(null);
      pm.mediator.trigger('focusSidebar');
      return;
    }

    const inlineInput = this.refs.inlineInput;
    if (inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    }
  }

  handleItemToggle() {
    if (this.props.isContextMenuOpen()) {
      return;
    }

    this.props.onItemToggle && this.props.onItemToggle({
      id: this.props.id,
      type: 'folder' });

  }

  handleDropDownActionSelect(target, id, action) {
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_RENAME_TOGGLE"]) {
      this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], this.props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_RENAME_TOGGLE"]);
    }
    this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(target, id, action);
  }

  setEditingToTrue() {
    pm.mediator.trigger('focusSidebar');
    this.refs.inlineInput && this.refs.inlineInput.startEditing();
  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleSubmit(value) {
    this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TARGET_FOLDER"], this.props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_RENAME"], { name: value });
  }

  getFolderIconClasses() {
    let isOpen = this.props.isOpen;
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'pm-icon': true,
      'pm-icon-normal': true,
      'collection-sidebar-list-item__folder__head__icon': true,
      'icon_folder': true });

  }

  handleMouseHover(isHovered) {
    this.setState({ isHovered });
  }

  render() {

    let headClasses = this.getHeadClasses();

    const {
      connectDragSource,
      connectDropTarget,
      connectDragPreview,
      name } =
    this.props;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: this.getClasses(),
          onMouseEnter: this.handleMouseHoverDebounced.bind(this, true),
          onMouseLeave: this.handleMouseHoverDebounced.bind(this, false),
          style: { marginLeft: `${this.props.depth * 10}px` } }, ' ',

        connectDropTarget(connectDragPreview(connectDragSource(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            title: name,
            className: headClasses,
            onClick: this.handleItemToggle },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__folder__head__icon-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'nesting-level' }),
            this.props.isOpen ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-direction-down', className: 'pm-icon pm-icon-normal' }) :
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-direction-right', className: 'icon-direction-right', className: 'pm-icon pm-icon-normal' }),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-entity-folder-stroke', className: this.getFolderIconClasses() })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'head' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__folder__head__meta' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InlineInput__WEBPACK_IMPORTED_MODULE_6__["default"], {
                className: 'collection-sidebar-list-item__entity__name collection-sidebar-list-item__folder__head__name',
                placeholder: 'Folder Name',
                ref: 'inlineInput',
                value: name,
                onSubmit: this.handleSubmit,
                onToggleEdit: this.handleToggleEditName }))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__folder__head__actions' },

            (this.state.isHovered || this.state.dropdownOpen || this.props.isOpen) &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'folderOption' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FolderActionsDropdown__WEBPACK_IMPORTED_MODULE_8__["default"], _extends({},
              _.pick(this.props, ['id', 'subscribed']), {
                onSelect: this.handleDropDownActionSelect,
                onToggle: this.handleDropdownToggle }))))))))));









  }}) || _class) || _class) || _class) || _class);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4857:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_cloneWithRef__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4858);
/* harmony import */ var _utils_ContextMenuShortcutLabelHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4859);
/* harmony import */ var _electron_ElectronService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1223);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};





const remote = __webpack_require__(62).remote;let

ContextMenuMonitor = class ContextMenuMonitor {
  constructor() {
    this.isContextMenuOpen = false;
    this.isOpen = this.isOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  open() {
    this.isContextMenuOpen = true;
    this.attachEventListeners();
  }

  isOpen() {
    return this.isContextMenuOpen;
  }

  attachEventListeners() {
    window.addEventListener('mousedown', this.handleClose);
    window.addEventListener('blur', this.handleClose);
  }

  removeEventListeners() {
    window.removeEventListener('blur', this.handleClose);
    window.removeEventListener('mousedown', this.handleClose);
  }

  handleClose() {
    this.isContextMenuOpen = false;
    this.removeEventListeners();
  }};


const ContextMenu = (menuTemplate, options) => {
  return WrappedComponent => {
    return class ContextMenuComponent extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
      constructor(props) {
        super(props);
        this.handleContextMenu = this.handleContextMenu.bind(this);
        this.monitor = new ContextMenuMonitor();
        this.options = _.isFunction(options) && options(this.monitor) || {};
        this.handleConnectContextMenuSource = this.handleConnectContextMenuSource.bind(this);
      }

      handleContextMenu(e) {
        // Allow input-related context menu
        if (_.get(e, 'target.nodeName') === 'INPUT') {
          return;
        }

        e.preventDefault();
        e.stopPropagation();
        this.monitor.open();

        let filteredMenuTemplate = _.chain(menuTemplate).
        filter(template => {
          return !template.isVisible || template.isVisible(this.props);
        }).
        map(template => {
          template.click = () => {
            template.onClick(this.props, this.decoratedComponentInstance);
          };
          if (template.shortcut) {
            template.accelerator = Object(_utils_ContextMenuShortcutLabelHelper__WEBPACK_IMPORTED_MODULE_3__["default"])(template.shortcut);
          }
          return template;
        }).
        value();

        remote.Menu.buildFromTemplate(filteredMenuTemplate).
        popup(Object(_electron_ElectronService__WEBPACK_IMPORTED_MODULE_4__["getCurrentWindow"])());
      }

      handleConnectContextMenuSource(component) {
        return Object(_utils_cloneWithRef__WEBPACK_IMPORTED_MODULE_2__["default"])(component, node => {
          this.decoratedComponentInstanceNode = node;
        });
      }

      render() {
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(WrappedComponent, _extends({
            connectContextMenuSource: this.handleConnectContextMenuSource,
            ref: component => {
              if (!this.decoratedComponentInstance) {
                this.decoratedComponentInstance = component;
              }
            } },
          this.props,
          this.options)));


      }

      componentDidMount() {
        if (this.decoratedComponentInstanceNode) {
          this.decoratedComponentInstanceNode.addEventListener('contextmenu', this.handleContextMenu);
        } else
        {
          this.decoratedComponentInstanceNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.decoratedComponentInstance);
          if (this.decoratedComponentInstanceNode) {
            this.decoratedComponentInstanceNode.addEventListener('contextmenu', this.handleContextMenu);
          }
        }
      }

      componentWillUnmount() {
        if (this.decoratedComponentInstanceNode) {
          this.decoratedComponentInstanceNode.removeEventListener('contextmenu', this.handleContextMenu);
          this.decoratedComponentInstanceNode = null;
        }
      }};

  };
};

/* harmony default export */ __webpack_exports__["default"] = (ContextMenu);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4858:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
// From react-dnd


function cloneWithRef(element, newRef) {
  var previousRef = element.ref;
  if (!previousRef) {
    // When there is no ref on the element, use the new ref directly
    return Object(react__WEBPACK_IMPORTED_MODULE_0__["cloneElement"])(element, { ref: newRef });
  }

  return Object(react__WEBPACK_IMPORTED_MODULE_0__["cloneElement"])(element, {
    ref: function ref(node) {
      _.isFunction(newRef) && newRef(node);
      _.isFunction(previousRef) && previousRef(node);
    } });

}

/* harmony default export */ __webpack_exports__["default"] = (cloneWithRef);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4859:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_, process) {/* harmony import */ var _controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4285);
/**
 * Used in ContextMenu to fetch shortcut labels for menu items
 * @private
 */



const shortcuts = Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_0__["getShortcuts"])(),
isDarwin = window ? _.includes(navigator.platform, 'Mac') : process.platform === 'darwin',
getDeleteLabel = () => {
  return isDarwin ? 'Backspace' : 'delete';
};


const getContextMenuShortcutLabel = shortcutKey => {
  const shortcutLabel = _.get(shortcuts, `${shortcutKey}.shortcut`);
  return _.nth(shortcutLabel, 0) === 'del' ? getDeleteLabel() :
  _.isString(shortcutLabel) && shortcutLabel.replace('mod', 'CmdOrCtrl');
};

/* harmony default export */ __webpack_exports__["default"] = (getContextMenuShortcutLabel);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61), __webpack_require__(31)))

/***/ }),

/***/ 4860:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FolderActionsDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1793);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4285);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4861);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1763);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2467);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__);
var _class;









let


FolderActionsDropdown = Object(mobx_react__WEBPACK_IMPORTED_MODULE_7__["observer"])(_class = class FolderActionsDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleShortcutSelect = this.handleShortcutSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
  }

  getKeymapHandlers() {
    return {
      rename: pm.shortcuts.handle('rename', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_RENAME_TOGGLE"])),
      duplicate: pm.shortcuts.handle('duplicate', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DUPLICATE"])),
      delete: pm.shortcuts.handle('delete', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"])) };

  }

  handleShortcutSelect(action, e) {
    pm.mediator.trigger('focusSidebar');
    this.handleSelect(action);
  }

  handleSelect(action) {
    this.props.onSelect && this.props.onSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TARGET_FOLDER"], this.props.id, action);
  }

  handleToggle(value) {
    this.props.onToggle && this.props.onToggle(value);
  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  render() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
    canEditFolder = permissionStore.can('edit', 'folder', this.props.id),
    canAddRequestToFolder = permissionStore.can('addRequest', 'folder', this.props.id),
    canAddFolderToFolder = permissionStore.can('addFolder', 'folder', this.props.id),
    canDuplicateFolder = permissionStore.can('duplicate', 'folder', this.props.id),
    canDeleteFolder = permissionStore.can('delete', 'folder', this.props.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-folder-dropdown-actions-wrapper' },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["Dropdown"], {
            ref: 'menu',
            keyMapHandlers: this.getKeymapHandlers(),
            onSelect: this.handleSelect,
            onToggle: this.handleToggle,
            className: 'collection-sidebar-folder-actions-dropdown' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["DropdownButton"], { dropdownStyle: 'nocaret', type: 'custom' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-options-stroke', className: 'collection-sidebar-folder-dropdown-actions-button pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["DropdownMenu"], { 'align-right': true },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                disabledText: this.getDisabledText(!canEditFolder),
                disabled: !canEditFolder,
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_RENAME_TOGGLE"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-rename-stroke', className: 'dropdown-menu-item-icon menu-icon--rename pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Rename'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_3__["getShortcutByName"])('rename'))),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], { refKey: canEditFolder ? _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_EDIT"] : _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_VIEW_ONLY"] },

              canEditFolder ?
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-edit-stroke', className: 'dropdown-menu-item-icon menu-icon--edit pm-icon pm-icon-normal' }) :
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-view-stroke', className: 'dropdown-menu-item-icon menu-icon--view pm-icon pm-icon-normal' }),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, canEditFolder ? 'Edit' : 'View Details')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                disabledText: this.getDisabledText(!canAddRequestToFolder),
                disabled: !canAddRequestToFolder,
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_ADD_REQUEST"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-entity-request-stroke', className: 'dropdown-menu-item-icon menu-icon--new-request pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Add Request')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                disabledText: this.getDisabledText(!canAddFolderToFolder),
                disabled: !canAddFolderToFolder,
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_ADD_FOLDER"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-newFolder-stroke', className: 'dropdown-menu-item-icon menu-icon--new-folder pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Add Folder')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                disabledText: this.getDisabledText(!canDuplicateFolder),
                disabled: !canDuplicateFolder,
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DUPLICATE"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-copy-stroke', className: 'dropdown-menu-item-icon menu-icon--duplicate pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Duplicate'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_3__["getShortcutByName"])('duplicate'))),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                disabledText: this.getDisabledText(!canDeleteFolder),
                disabled: !canDeleteFolder,
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-delete-stroke', className: 'dropdown-menu-item-icon menu-icon--delete pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Delete'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_3__["getShortcutByName"])('delete')))))));






  }}) || _class;

/***/ }),

/***/ 4861:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DUPLICATE", function() { return ACTION_TYPE_DUPLICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_VIEW_ONLY", function() { return ACTION_TYPE_VIEW_ONLY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_EDIT", function() { return ACTION_TYPE_EDIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_FORK", function() { return ACTION_TYPE_FORK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_MERGE", function() { return ACTION_TYPE_MERGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_PULL_REQUEST", function() { return ACTION_TYPE_PULL_REQUEST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_RUN", function() { return ACTION_TYPE_RUN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SHARE", function() { return ACTION_TYPE_SHARE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DOWNLOAD", function() { return ACTION_TYPE_DOWNLOAD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE", function() { return ACTION_TYPE_DELETE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_ADD_REQUEST", function() { return ACTION_TYPE_ADD_REQUEST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_ADD_FOLDER", function() { return ACTION_TYPE_ADD_FOLDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_ADD_MONITOR", function() { return ACTION_TYPE_ADD_MONITOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_ADD_MOCK", function() { return ACTION_TYPE_ADD_MOCK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_PUBLISH_DOCS", function() { return ACTION_TYPE_PUBLISH_DOCS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_OPEN_IN_BUILDER", function() { return ACTION_TYPE_OPEN_IN_BUILDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SELECT", function() { return ACTION_TYPE_SELECT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_RENAME", function() { return ACTION_TYPE_RENAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_RENAME_TOGGLE", function() { return ACTION_TYPE_RENAME_TOGGLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_OPEN_IN_NEW_TAB", function() { return ACTION_TYPE_OPEN_IN_NEW_TAB; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DESCRIPTION_UPDATE", function() { return ACTION_TYPE_DESCRIPTION_UPDATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_PREVIEW", function() { return ACTION_TYPE_PREVIEW; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TARGET_COLLECTION", function() { return ACTION_TARGET_COLLECTION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TARGET_FOLDER", function() { return ACTION_TARGET_FOLDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TARGET_REQUEST", function() { return ACTION_TARGET_REQUEST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_ADD_TO_WORKSPACE", function() { return ACTION_ADD_TO_WORKSPACE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_REMOVE_FROM_WORKSPACE", function() { return ACTION_REMOVE_FROM_WORKSPACE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_MANAGE_ROLES", function() { return ACTION_MANAGE_ROLES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_REQUEST_ACCESS", function() { return ACTION_REQUEST_ACCESS; });
const ACTION_TYPE_DUPLICATE = 'duplicate',
ACTION_TYPE_VIEW_ONLY = 'view-only',
ACTION_TYPE_EDIT = 'edit',
ACTION_TYPE_FORK = 'fork',
ACTION_TYPE_MERGE = 'merge',
ACTION_TYPE_PULL_REQUEST = 'pull-request',
ACTION_TYPE_RUN = 'run',
ACTION_TYPE_SHARE = 'share',
ACTION_TYPE_DOWNLOAD = 'download',
ACTION_TYPE_DELETE = 'delete',
ACTION_TYPE_ADD_REQUEST = 'add-request',
ACTION_TYPE_ADD_FOLDER = 'add-folder',
ACTION_TYPE_ADD_MONITOR = 'add-monitor',
ACTION_TYPE_ADD_MOCK = 'add-mock',
ACTION_TYPE_PUBLISH_DOCS = 'publish-docs',
ACTION_TYPE_OPEN_IN_BUILDER = 'open_in_builder',
ACTION_TYPE_SELECT = 'select',
ACTION_TYPE_RENAME = 'rename',
ACTION_TYPE_RENAME_TOGGLE = 'rename_toggle',
ACTION_TYPE_OPEN_IN_NEW_TAB = 'open_in_new_tab',
ACTION_TYPE_DESCRIPTION_UPDATE = 'description_update',
ACTION_TYPE_PREVIEW = 'preview',
ACTION_TARGET_COLLECTION = 'collection',
ACTION_TARGET_FOLDER = 'folder',
ACTION_TARGET_REQUEST = 'request',
ACTION_ADD_TO_WORKSPACE = 'add-to-workspace',
ACTION_REMOVE_FROM_WORKSPACE = 'remove-from-workspace',
ACTION_MANAGE_ROLES = 'manage-roles',
ACTION_REQUEST_ACCESS = 'request-access';

/***/ }),

/***/ 4862:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarListItemRequest; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2136);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _base_ContextMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4857);
/* harmony import */ var _base_InlineInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1881);
/* harmony import */ var _request_RequestIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4863);
/* harmony import */ var _RequestActionsDropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4864);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4861);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1763);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _dec, _dec2, _dec3, _class;














const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore');
const getMiddleY = component => {
  const elementRect = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(component).getBoundingClientRect();
  return elementRect.top + elementRect.height / 2;
};

const itemSource = {
  canDrag(props) {
    if (props && props.isRenaming) {
      return false;
    }

    return Boolean(permissionStore.can('delete', 'request', props.id));
  },

  beginDrag(props) {
    return {
      id: props.id,
      type: 'request',
      folderId: props.folderId,
      collectionId: props.collectionId };

  },

  endDrag(props, monitor) {
    const dragItem = monitor.getItem(),
    { dropItem, position } = monitor.getDropResult() || {};

    if (_.isUndefined(dropItem)) {
      return;
    }

    props.onDragDrop(dragItem, dropItem, position);
  } };


const itemTarget = {
  hover(props, monitor, component) {
    const dragId = monitor.getItem().id,
    dropId = props.id,
    dragItem = monitor.getItem();
    let isEditable = false;

    if (dragItem.type === 'request') {
      isEditable = _.get(props, 'folderId') ? permissionStore.can('addRequest', 'folder', props.folderId) : permissionStore.can('addRequest', 'collection', props.collectionId);
    }
    if (dragId === dropId || !isEditable) {
      return {};
    }
    if (!props.isFirstChild) {
      component.getDecoratedComponentInstance().scheduleHoverUpdate('bottom');
      return;
    }

    // Will only be used for first request in its parent
    if (monitor.getClientOffset().y > getMiddleY(component)) {
      component.getDecoratedComponentInstance().scheduleHoverUpdate('bottom');
    } else
    {
      component.getDecoratedComponentInstance().scheduleHoverUpdate('top');
    }

  },

  drop(props, monitor, component) {
    const dragId = monitor.getItem().id,
    dropId = props.id,
    dragItem = monitor.getItem();
    let isEditable = false;

    if (dragItem.type === 'request') {
      isEditable = _.get(props, 'folderId') ? permissionStore.can('addRequest', 'folder', props.folderId) : permissionStore.can('addRequest', 'collection', props.collectionId);
    }
    if (dragId === dropId || !isEditable) {
      return {};
    }
    let position = 'after';
    if (props.isFirstChild) {
      position = monitor.getClientOffset().y > getMiddleY(component) ? 'after' : 'before';
    }

    return {
      dropItem: {
        id: props.id,
        type: 'request',
        folderId: props.folderId,
        collectionId: props.collectionId },

      position };

  } };let

































































CollectionSidebarListItemRequest = (_dec = Object(_base_ContextMenu__WEBPACK_IMPORTED_MODULE_4__["default"])([{ label: 'Open in New Tab', onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_OPEN_IN_NEW_TAB"]);} }, { label: 'Rename', shortcut: 'rename', isVisible(props) {return permissionStore.can('edit', 'request', props.id);}, onClick(props, component) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME_TOGGLE"]);} }, { label: 'Edit', isVisible(props) {return permissionStore.can('edit', 'request', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_EDIT"]);} }, { label: 'Duplicate', shortcut: 'duplicate', isVisible(props) {return permissionStore.can('duplicate', 'request', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DUPLICATE"]);} }, { label: 'Delete', shortcut: 'delete', isVisible(props) {return permissionStore.can('delete', 'request', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_DELETE"]);} }], monitor => {return { isContextMenuOpen: monitor.isOpen };}), _dec2 = Object(react_dnd__WEBPACK_IMPORTED_MODULE_3__["DropTarget"])('collection-sidebar-request-item', itemTarget, (connect, monitor) => {return { connectDropTarget: connect.dropTarget(), isDragOver: monitor.isOver({ shallow: true }) };}), _dec3 = Object(react_dnd__WEBPACK_IMPORTED_MODULE_3__["DragSource"])('collection-sidebar-request-item', itemSource, (connect, monitor) => {return { connectDragSource: connect.dragSource(), connectDragPreview: connect.dragPreview(), isDragging: monitor.isDragging() };}), _dec(_class = _dec2(_class = _dec3(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_10__["observer"])(_class = class CollectionSidebarListItemRequest extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      dropdownOpen: false,
      dropHoverTop: false,
      dropHoverBottom: false,
      isHovered: false };

    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleRequestSelect = this.handleRequestSelect.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
    this.setDropHoverTop = this.setDropHoverTop.bind(this);
    this.setDropHoverBottom = this.setDropHoverBottom.bind(this);
    this.handleMouseHover = this.handleMouseHover.bind(this);
    this.handleMouseHoverDebounced = _.debounce(this.handleMouseHover, 300, {
      leading: false,
      trailing: true });

  }

  componentDidMount() {

    // If the list item was in edit state, restore its state
    if (this.props.editCache && this.refs.inlineInput) {
      this.setState(this.props.editCache.listItem, () => {
        this.refs.inlineInput.setEditState(this.props.editCache.inlineInput);
      });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    this.props.isEditing !== nextProps.isEditing && this.toggleEditName();

    if (!this.props.isFocused && nextProps.isFocused) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  UNSAFE_componentWillUpdate(nextProps) {
    if (!this.props.isFocused && nextProps.isFocused) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  componentWillUnmount() {
    cancelAnimationFrame(this.requestedFrame);
    this.handleMouseHoverDebounced.cancel();

    // If the list item is in its edit state, cache the internal state
    if (this.props.isEditing && this.refs.inlineInput) {
      this.props.setEditCache({
        inlineInput: this.refs.inlineInput.getEditState(),
        id: this.props.id,
        type: 'request',
        listItem: this.state });

    }
  }

  scheduleHoverUpdate(type) {
    let func = this.setDropHoverTop;
    if (type === 'bottom') {
      func = this.setDropHoverBottom;
    }
    if (!this.requestedFrame) {
      this.requestedFrame = requestAnimationFrame(() => {
        try {
          func && func();
        }
        catch (e) {
        } finally
        {
          this.requestedFrame = null;
        }
      });
    }
  }

  setDropHoverTop() {
    !this.state.dropHoverTop &&
    this.setState({
      dropHoverBottom: false,
      dropHoverTop: true });

  }

  setDropHoverBottom() {
    !this.state.dropHoverBottom &&
    this.setState({
      dropHoverBottom: true,
      dropHoverTop: false });

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action, modifiers) {
    if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME_TOGGLE"]) {
      this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], this.props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME_TOGGLE"]);
      return;
    }
    this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], this.props.id, action, modifiers);
  }


  setEditingToTrue() {
    pm.mediator.trigger('focusSidebar');
    this.refs.inlineInput && this.refs.inlineInput.startEditing();
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'collection-sidebar-list-item__entity': true,
      'collection-sidebar-list-item__request': true,
      'is-hovered': this.state.dropdownOpen,
      'is-selected': this.props.selected,
      'is-focused': this.props.isFocused,
      'is-dragged': this.props.isDragging,
      'is-drop-hovered-top': this.state.dropHoverTop && this.props.isDragOver,
      'is-drop-hovered-bottom': this.state.dropHoverBottom && this.props.isDragOver,
      'is-active': this.props.selected });

  }

  handleSubmit(value) {
    this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TARGET_REQUEST"], this.props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_RENAME"], { name: value });
  }

  toggleEditName() {
    if (permissionStore.can('edit', 'request', this.props.id)) {
      if (this.props.isEditing) {
        this.refs.inlineInput && this.refs.inlineInput.stopEditing();
      } else {
        this.refs.inlineInput && this.refs.inlineInput.startEditing();
      }
      this.props.onRenameToggle(!this.props.isEditing, { id: this.props.id, type: 'request' });
    } else
    {
      pm.toasts.error('You do not have the permissions required to rename this request.');
    }
  }

  handleToggleEditName(isEditing) {
    if (!isEditing) {
      this.refs.inlineInput && this.refs.inlineInput.stopEditing();
      this.props.onRenameToggle(false);
      this.props.setEditCache(null);
      pm.mediator.trigger('focusSidebar');
      return;
    }

    const inlineInput = this.refs.inlineInput;
    if (inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    }
  }

  handleRequestSelect(e) {
    if (this.props.isContextMenuOpen()) {
      return;
    }

    e.stopPropagation();
    let CollectionSidebarUIStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CollectionSidebarUIStore');


    // if already selected, do nothing, to allow double-click.
    let isOsxPlatform = _.includes(navigator.platform, 'Mac');
    let selected = CollectionSidebarUIStore.isFocused(this.props.id);
    if (selected && !e.shiftKey && (isOsxPlatform ? !e.metaKey : !e.ctrlKey)) {
      return;
    }

    let modifiers = {
      ctrlKey: e.ctrlKey,
      metaKey: e.metaKey,
      shiftKey: e.shiftKey };

    this.handleDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_SELECT"], modifiers);

    CollectionSidebarUIStore.focusItem({
      id: this.props.id,
      type: 'request' });

  }

  handleMouseHover(isHovered) {
    this.setState({ isHovered });
  }

  render() {

    let { method = 'GET' } = this.props;

    const {
      connectDragSource,
      connectDropTarget,
      connectDragPreview,
      name } =
    this.props;

    return connectDropTarget(connectDragPreview(connectDragSource(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
        className: this.getClasses(),
        title: name,
        onClick: this.handleRequestSelect,
        onMouseEnter: this.handleMouseHoverDebounced.bind(this, true),
        onMouseLeave: this.handleMouseHoverDebounced.bind(this, false),
        style: { marginLeft: `${this.props.depth * 10}px` } },

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_request_RequestIcon__WEBPACK_IMPORTED_MODULE_6__["default"], { method: method }),
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'head' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__request__meta' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_InlineInput__WEBPACK_IMPORTED_MODULE_5__["default"], {
            className: 'collection-sidebar-list-item__entity__name collection-sidebar-list-item__request__name',
            placeholder: 'Request Name',
            ref: 'inlineInput',
            value: name,
            onSubmit: this.handleSubmit,
            onToggleEdit: this.handleToggleEditName }))),



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__request__actions' },

        (this.state.isHovered || this.state.dropdownOpen) &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: 'requestOption' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RequestActionsDropdown__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({},
          _.pick(this.props, ['id']), {
            onSelect: this.handleDropdownActionSelect,
            onToggle: this.handleDropdownToggle }))))))));






  }}) || _class) || _class) || _class) || _class);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4863:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequestIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _utils_RequestMethodHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4765);
var _class;


let


RequestIcon = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class RequestIcon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getMethodClasses(method) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-sidebar-list-item__request__label': true,
      'request-method--GET': method && _.includes(method.toUpperCase(), 'GET'),
      'request-method--PUT': method && _.includes(method.toUpperCase(), 'PUT'),
      'request-method--POST': method && _.includes(method.toUpperCase(), 'POST'),
      'request-method--DELETE': method && _.includes(method.toUpperCase(), 'DELETE') });

  }

  render() {
    let method = this.props.method || '';

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('collection-sidebar-list-item__request__label-wrapper', this.props.className) },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(this.getMethodClasses(method), this.props.methodClassname) }, _utils_RequestMethodHelper__WEBPACK_IMPORTED_MODULE_3__["default"].getMethodAbbreviation(method))));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4864:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequestActionsDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4285);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4861);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1763);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2467);
var _class;









let


RequestActionsDropdown = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class = class RequestActionsDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleShortcutSelect = this.handleShortcutSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
  }

  getKeymapHandlers() {
    return {
      rename: pm.shortcuts.handle('rename', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_RENAME_TOGGLE"])),
      duplicate: pm.shortcuts.handle('duplicate', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DUPLICATE"])),
      delete: pm.shortcuts.handle('delete', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DELETE"])) };

  }

  handleShortcutSelect(action, e) {
    pm.mediator.trigger('focusSidebar');
    this.handleSelect(action);
  }

  handleSelect(action) {
    this.props.onSelect && this.props.onSelect(action);
  }

  handleToggle(isOpen) {
    this.props.onToggle && this.props.onToggle(isOpen);
  }

  getDropDownActionClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'collection-sidebar-request-actions-dropdown': true,
      'collection-sidebar-request-actions-dropdown--single-menu': !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore').can('edit', 'request', this.props.id) });

  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }

  render() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('PermissionStore'),
    requestId = this.props.id,
    canEditRequest = permissionStore.can('edit', 'request', requestId),
    canDuplicateRequest = permissionStore.can('duplicate', 'request', requestId),
    canDeleteRequest = permissionStore.can('delete', 'request', requestId);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-request-dropdown-actions-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            ref: 'menu',
            keyMapHandlers: this.getKeymapHandlers(),
            onSelect: this.handleSelect,
            onToggle: this.handleToggle,
            className: this.getDropDownActionClasses() },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], { dropdownStyle: 'nocaret', type: 'custom' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-action-options-stroke', className: 'collection-sidebar-request-dropdown-actions-button pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], { 'align-right': true },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_OPEN_IN_NEW_TAB"] },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-action-newWindow-stroke', className: 'dropdown-menu-item-icon menu-icon--newtab pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Open in New Tab')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_RENAME_TOGGLE"],
                disabled: !canEditRequest,
                disabledText: this.getDisabledText(!canEditRequest) },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-action-rename-stroke', className: 'dropdown-menu-item-icon menu-icon--rename pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Rename'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__["getShortcutByName"])('rename'))),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_EDIT"],
                disabled: !canEditRequest,
                disabledText: this.getDisabledText(!canEditRequest) },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-action-edit-stroke', className: 'dropdown-menu-item-icon menu-icon--edit pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Edit')),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DUPLICATE"],
                disabled: !canDuplicateRequest,
                disabledText: this.getDisabledText(!canDuplicateRequest) },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-action-copy-stroke', className: 'dropdown-menu-item-icon menu-icon--duplicate pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Duplicate'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__["getShortcutByName"])('duplicate'))),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
                refKey: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DELETE"],
                disabled: !canDeleteRequest,
                disabledText: this.getDisabledText(!canDeleteRequest) },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: 'icon-action-delete-stroke', className: 'dropdown-menu-item-icon menu-icon--delete pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Delete'),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__["getShortcutByName"])('delete')))))));





  }}) || _class;

/***/ }),

/***/ 4865:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarListItemHead; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2136);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
/* harmony import */ var _utils_pureRenderDecorator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4866);
/* harmony import */ var _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2059);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1768);
/* harmony import */ var _components_base_InlineInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1881);
/* harmony import */ var _CollectionMetaIcons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4749);
/* harmony import */ var _CollectionForkLabel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3961);
/* harmony import */ var _CollectionActionsDropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4867);
/* harmony import */ var _base_ContextMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4857);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4861);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(749);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1789);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _dec, _dec2, _class;


















const collectionTarget = {
  canDrop(props) {
    return Boolean(!props.subscribed || props.write);
  },

  drop(props, monitor) {
    const dragId = monitor.getItem().id,
    dropId = props.collection.id,
    dragItem = monitor.getItem(),
    permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('PermissionStore');

    let isEditable = false;

    switch (dragItem.type) {
      case 'folder':
        if (permissionStore.can('addFolder', 'collection', props.collection.id)) {
          isEditable = true;
        }
      case 'request':
        if (permissionStore.can('addRequest', 'collection', props.collection.id)) {
          isEditable = true;
        }}


    if (dragId === dropId || !isEditable) {
      return {};
    }

    return {
      dropItem: {
        id: dropId,
        type: 'collection' } };


  } };


const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('PermissionStore'),
workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('ActiveWorkspaceStore').id;let
















































































































































































CollectionSidebarListItemHead = (_dec = Object(_base_ContextMenu__WEBPACK_IMPORTED_MODULE_11__["default"])([{ label: 'Share Collection', isVisible(props) {return permissionStore.can('share', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_SHARE"]);} }, { label: 'Manage Roles', isVisible() {let currentUserStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('CurrentUserStore');return Boolean(currentUserStore.team);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_MANAGE_ROLES"]);} }, { label: 'Rename', shortcut: 'rename', isVisible(props) {return permissionStore.can('edit', 'collection', props.id);}, onClick(props, component) {component.decoratedComponentInstance.toggleEditName();} }, { label: 'Edit', isVisible(props) {return permissionStore.can('edit', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_EDIT"]);} }, { label: 'View Details', isVisible(props) {return !permissionStore.can('edit', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_VIEW_ONLY"]);} }, { label: 'Create a fork', isVisible() {return true;}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_FORK"]);} }, { label: 'Merge changes', isVisible(props) {let isForked = _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('CollectionStore').find(props.id), 'isForked', false);return isForked;}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_MERGE"]);} }, { label: 'Create Pull Request', isVisible(props) {return _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('CollectionStore').find(props.id), 'isForked', false);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_PULL_REQUEST"]);} }, { label: 'Add Request', isVisible(props) {return permissionStore.can('addRequest', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_ADD_REQUEST"]);} }, { label: 'Add Folder', isVisible(props) {return permissionStore.can('addFolder', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_ADD_FOLDER"]);} }, { label: 'Duplicate', shortcut: 'duplicate', isVisible(props) {return permissionStore.can('addCollection', 'workspace', workspaceId);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DUPLICATE"]);} }, { label: 'Export', onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DOWNLOAD"]);} }, { label: 'Monitor Collection', isVisible(props) {return permissionStore.can('addMonitor', 'collection', props.id) && permissionStore.can('addMonitor', 'workspace', workspaceId);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_ADD_MONITOR"]);} }, { label: 'Mock Collection', isVisible(props) {return permissionStore.can('addMock', 'collection', props.id) && permissionStore.can('addMock', 'workspace', workspaceId);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_ADD_MOCK"]);} }, { label: 'Publish Docs', isVisible(props) {return permissionStore.can('publish', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_PUBLISH_DOCS"]);} }, { label: 'Remove from workspace', isVisible(props) {const isOnline = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('SyncStatusStore').isSocketConnected;return permissionStore.can('removeCollection', 'workspace', workspaceId) && isOnline;}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_REMOVE_FROM_WORKSPACE"]);} }, { label: 'Delete', shortcut: 'delete', isVisible(props) {return permissionStore.can('delete', 'collection', props.id);}, onClick(props) {props.onDropdownActionSelect && props.onDropdownActionSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"], props.id, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]);} }], monitor => {return { isContextMenuOpen: monitor.isOpen };}), _dec2 = Object(react_dnd__WEBPACK_IMPORTED_MODULE_1__["DropTarget"])(['collection-sidebar-request-item', 'collection-sidebar-folder-item'], collectionTarget, (connect, monitor) => {return { connectDropTarget: connect.dropTarget(), isDragOver: monitor.isOver({ shallow: true }), canDrop: monitor.canDrop() };}), _dec(_class = _dec2(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class CollectionSidebarListItemHead extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      dropdownOpen: false,
      showFavorite: true };


    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleCollectionBrowserToggle = this.handleCollectionBrowserToggle.bind(this);
    this.toggleEditName = this.toggleEditName.bind(this);
    this.handleCollectionClick = this.handleCollectionClick.bind(this);
    this.handleToggleFavorite = this.handleToggleFavorite.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
  }

  componentDidMount() {

    // If the list item was in edit state, restore its state
    if (this.props.editCache && this.refs.inlineInput) {
      this.setState(this.props.editCache.listItem, () => {
        this.refs.inlineInput.setEditState(this.props.editCache.inlineInput);
      });
    }
  }

  componentWillUnmount() {

    // If the list item is in its edit state, cache the internal state
    if (this.props.isEditing && this.refs.inlineInput) {
      this.props.setEditCache({
        inlineInput: this.refs.inlineInput.getEditState(),
        id: this.props.id,
        type: 'collection',
        listItem: this.state });

    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    this.props.isEditing !== nextProps.isEditing && this.toggleEditName();
  }

  UNSAFE_componentWillUpdate(nextProps) {
    if (!this.props.isFocused && nextProps.isFocused) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"])(this);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  handleCollectionClick() {
    if (this.props.isContextMenuOpen()) {
      return;
    }

    let collection = this.props.collection;
    this.props.onItemToggle && this.props.onItemToggle({ id: collection.id, type: 'collection' });
  }

  handleDropdownActionSelect(target, id, action) {
    this.props.onDropdownActionSelect && this.props.onDropdownActionSelect(target, id, action);
  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleToggleFavorite(e) {
    e.stopPropagation();
    this.props.onToggleFavorite && this.props.onToggleFavorite(this.props.collection.id);
  }

  handleSubmit(value) {
    this.props.onDropdownActionSelect &&
    this.props.onDropdownActionSelect(
    _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TARGET_COLLECTION"],
    this.props.collection.id,
    _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_RENAME"],
    { name: value });

  }

  toggleEditName() {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('PermissionStore').can('edit', 'collection', this.props.id)) {
      if (this.props.isEditing) {
        this.refs.inlineInput && this.refs.inlineInput.stopEditing();
      } else
      {
        this.refs.inlineInput && this.refs.inlineInput.startEditing();
      }

      this.props.onRenameToggle(!this.props.isEditing, { id: this.props.id, type: 'collection' });
    } else
    {
      pm.toasts.error('You do not have the permissions required to rename this collection.');
    }
  }

  handleToggleEditName(isEditing) {
    if (!isEditing) {
      this.props.onRenameToggle(false);
      this.props.setEditCache(null);
      pm.mediator.trigger('focusSidebar');
    }

    const inlineInput = this.refs.inlineInput;
    if (isEditing && inlineInput) {
      inlineInput.focus();
      inlineInput.selectAll();
    }

    this.setState({ showFavorite: !isEditing });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_12___default()({
      'collection-sidebar-list-item__head': true,
      'is-hovered': this.state.dropdownOpen,
      'is-focused': this.props.isFocused,
      'is-drop-hovered': this.props.canDrop && this.props.isDragOver,
      'is-favorited': this.props.collection.isFavorite,
      'is-open': this.props.isOpen });

  }

  handleCollectionBrowserToggle(e) {
    e.stopPropagation();
    this.props.onCollectionBrowserToggle && this.props.onCollectionBrowserToggle();
  }

  getActionsClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_12___default()({
      'collection-sidebar-list-item__head__actions': true,
      'is-selected': this.props.isExpanded });

  }

  getToggleBrowserClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_12___default()({
      'collection-sidebar-list-item__head__action': true,
      'collection-sidebar-list-item__head__action__browser': true,
      'is-open': this.props.isExpanded });

  }

  getExpandButtonClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_12___default()({
      'pm-icon': true,
      'pm-icon-normal': true,
      'collection-sidebar-list-item__collection-browser_action-open-icon': this.props.isExpanded,
      'collection-sidebar-list-item__collection-browser_action-close-icon': !this.props.isExpanded });

  }

  render() {
    const { connectDropTarget } = this.props;

    let collectionItem = this.props.collection,
    requestCount = collectionItem.requestCount,
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('CurrentUserStore'),
    isLoggedIn = currentUser.isLoggedIn,
    isOpen = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('CollectionSidebarUIStore').isOpen(collectionItem.id),
    teamSyncEnabled = currentUser.teamSyncEnabled;

    return connectDropTarget(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
        className: this.getClasses(),
        onClick: this.handleCollectionClick },

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__head__icon-wrapper' },
        isOpen ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { name: 'icon-direction-down', className: 'pm-icon pm-icon-normal' }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { name: 'icon-direction-right', className: 'pm-icon pm-icon-normal' }),
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { name: 'icon-entity-collection-stroke', className: 'icon-collection pm-icon pm-icon-normal', size: 'large' })),

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_16__["default"], { identifier: 'head' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__head__meta' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'collection-sidebar-list-item__head__name__wrapper',
              title: collectionItem.name },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_7__["default"], {
              className: 'collection-sidebar-list-item__head__name',
              placeholder: 'Collection Name',
              ref: 'inlineInput',
              value: collectionItem.name,
              onSubmit: this.handleSubmit,
              onToggleEdit: this.handleToggleEditName }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionMetaIcons__WEBPACK_IMPORTED_MODULE_8__["default"], { collection: collectionItem }),
            this.state.showFavorite &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
                active: collectionItem.isFavorite,
                className: 'collection-sidebar-list-item__head__favorite-button',
                onClick: this.handleToggleFavorite },


              collectionItem.isFavorite ?
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], {
                name: 'icon-action-favorite-fill',
                className: 'collection-sidebar-list-item__head__favorite-button-icon pm-icon pm-icon-secondary',
                size: 'small' }) :

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], {
                name: 'icon-action-favorite-stroke',
                className: 'pm-icon pm-icon-normal collection-sidebar-list-item__head__favorite-button-icon',
                size: 'small' }))),





          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__head__meta-info' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__head__requests' },
              requestCount, ' ', _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_5__["default"].pluralize({
                count: requestCount,
                singular: 'request',
                plural: 'requests' })),


            collectionItem.isForked &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_9__["default"], {
              className: 'collection-sidebar-list-item__head__fork-label',
              forkInfo: _.get(collectionItem, 'forkInfo') })))),





      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getActionsClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_16__["default"], { identifier: 'collectionBrowser' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: this.getToggleBrowserClasses(),
              onClick: this.handleCollectionBrowserToggle },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { name: 'icon-action-openRight-stroke', size: 'large', className: this.getExpandButtonClasses() }))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-list-item__head__action' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_16__["default"], { identifier: 'options' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionActionsDropdown__WEBPACK_IMPORTED_MODULE_10__["default"], _extends({},
            _.pick(collectionItem, ['id', 'shared', 'isForked']), {
              isPRO: currentUser.isLoggedIn && currentUser.teamSyncEnabled,
              isSignedIn: isLoggedIn,
              isTeamMember: teamSyncEnabled,
              onSelect: this.handleDropdownActionSelect,
              onToggle: this.handleDropdownToggle })))))));






  }}) || _class) || _class) || _class);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4866:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _shallowCompare__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1767);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



// Similar to pure-render-decorator but excludes functions when comparing


function shouldComponentUpdate(nextProps, nextState, options = {}) {
  return Object(_shallowCompare__WEBPACK_IMPORTED_MODULE_0__["default"])(this, nextProps, nextState, options);
}

/**
   * Makes the given component "pure".
   *
   * @private
   * @param options
   * @example @pureRender({ignoreFunctions: true})
   */
const pureRenderDecorator = args => {
  if (!_.isFunction(args) && _.isObject(args)) {
    const options = args;
    return DecoratedComponent => {
      DecoratedComponent.prototype.shouldComponentUpdate = function (nextProps, nextState) {
        return shouldComponentUpdate.apply(this, [nextProps, nextState, options]);
      };
      return DecoratedComponent;
    };
  } else
  if (_.isFunction(args)) {
    const component = args;
    component.prototype.shouldComponentUpdate = shouldComponentUpdate;
  }
};

/* harmony default export */ __webpack_exports__["default"] = (pureRenderDecorator);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4867:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionActionsDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4285);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4861);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1789);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1763);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2467);
var _class;










let


CollectionActionsDropdown = Object(mobx_react__WEBPACK_IMPORTED_MODULE_9__["observer"])(_class = class CollectionActionsDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleShortcutSelect = this.handleShortcutSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
  }

  getKeymapHandlers() {
    return {
      rename: pm.shortcuts.handle('rename', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_RENAME_TOGGLE"])),
      duplicate: pm.shortcuts.handle('duplicate', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DUPLICATE"])),
      delete: pm.shortcuts.handle('delete', this.handleShortcutSelect.bind(this, _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE"])) };

  }

  handleShortcutSelect(action) {
    pm.mediator.trigger('focusSidebar');
    this.handleSelect(action);
  }

  handleSelect(action) {
    this.props.onSelect && this.props.onSelect(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TARGET_COLLECTION"], this.props.id, action);
  }

  handleToggle(value) {
    this.props.onToggle && this.props.onToggle(value);
  }

  getActions() {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('PermissionStore'),
    currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore'),
    collectionId = this.props.id,
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').id,
    collection = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CollectionStore').find(collectionId),
    canEditCollection = permissionStore.can('edit', 'collection', collectionId),
    isShared = _.get(collection, 'isShared', false),
    isForked = _.get(collection, 'isForked', false),
    isOnline = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('SyncStatusStore').isSocketConnected;

    return [
    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SHARE"],
      label: 'Share Collection',
      isEnabled: permissionStore.can('share', 'collection', collectionId),
      xpathLabel: 'share',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-share-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SHARE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_MANAGE_ROLES"],
      label: 'Manage Roles',
      isEnabled: !!currentUser.team, // Enable it if the user belongs to a team
      xpathLabel: 'manageRoles',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-state-locked-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_MANAGE_ROLES"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_RENAME_TOGGLE"],
      label: 'Rename',
      shortcut: 'rename',
      isEnabled: permissionStore.can('edit', 'collection', collectionId),
      xpathLabel: 'rename',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-rename-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_RENAME_TOGGLE"]) }) },

    {
      type: canEditCollection ? _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_EDIT"] : _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_VIEW_ONLY"],
      label: canEditCollection ? 'Edit' : 'View Details',
      shortcut: 'edit',
      isEnabled: true,
      xpathLabel: 'edit',
      icon: canEditCollection ?
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-edit-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_EDIT"]) }) :
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-view-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_VIEW_ONLY"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_FORK"],
      label: 'Create a fork',
      isEnabled: true,
      xpathLabel: 'fork',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-fork-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_FORK"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_PULL_REQUEST"],
      label: 'Create Pull Request',
      isEnabled: isForked,
      xpathLabel: 'pull-request',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-pull-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_PULL_REQUEST"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_MERGE"],
      label: 'Merge changes',
      isEnabled: isForked,
      xpathLabel: 'merge',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-merge-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_MERGE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_REQUEST"],
      label: 'Add Request',
      isEnabled: permissionStore.can('addRequest', 'collection', collectionId),
      xpathLabel: 'addRequest',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-entity-request-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_REQUEST"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_FOLDER"],
      label: 'Add Folder',
      isEnabled: permissionStore.can('addFolder', 'collection', collectionId),
      xpathLabel: 'addFolder',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-newFolder-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_FOLDER"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DUPLICATE"],
      label: 'Duplicate',
      shortcut: 'duplicate',
      isEnabled: permissionStore.can('addCollection', 'workspace', workspaceId),
      xpathLabel: 'duplicate',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-copy-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DUPLICATE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DOWNLOAD"],
      label: 'Export',
      isEnabled: true,
      xpathLabel: 'export',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-download-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DOWNLOAD"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_MONITOR"],
      label: 'Monitor Collection',
      isEnabled: permissionStore.can('addMonitor', 'collection', collectionId) && permissionStore.can('addMonitor', 'workspace', workspaceId),
      xpathLabel: 'monitor',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-descriptive-observe-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_MONITOR"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_MOCK"],
      label: 'Mock Collection',
      isEnabled: permissionStore.can('addMock', 'collection', collectionId) && permissionStore.can('addMock', 'workspace', workspaceId),
      xpathLabel: 'mock',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-entity-mock-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_ADD_MOCK"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_PUBLISH_DOCS"],
      label: 'Publish Docs',
      isEnabled: permissionStore.can('publish', 'collection', collectionId),
      xpathLabel: 'publish',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-publish-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_PUBLISH_DOCS"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_REMOVE_FROM_WORKSPACE"],
      label: 'Remove from workspace',
      isEnabled: permissionStore.can('removeCollection', 'workspace', workspaceId) && isOnline,
      xpathLabel: 'remove',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-close-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_REMOVE_FROM_WORKSPACE"]) }) },

    {
      type: _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      shortcut: 'delete',
      isEnabled: permissionStore.can('delete', 'collection', collectionId),
      xpathLabel: 'delete',
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-delete-stroke', className: this.getMenuItemIconClasses(_constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE"]) }) }];


  }

  getMenuItemClasses(isPRO) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'dropdown-menu-item--pro-disabled': isPRO });
  }

  getMenuItemIconClasses(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'dropdown-menu-item-icon': true }, { 'pm-icon': true }, { 'pm-icon-normal': true }, 'menu-icon--' + label);
  }

  getDisabledText(isDisabled, actionType) {
    if (isDisabled) {
      let defaultMessage = 'You do not have permissions to perform this action.',
      manageRolesMessage = 'You need to be signed-in to a team to perform this action',
      collection = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CollectionStore').find(this.props.id),
      permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('PermissionStore'),
      workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').id;

      switch (actionType) {
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_MANAGE_ROLES"]:
          return manageRolesMessage;
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_MERGE"]:
          return 'This collection is not a fork';
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_PULL_REQUEST"]:
          return 'This collection is not a fork';
        case _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_REMOVE_FROM_WORKSPACE"]:
          if (permissionStore.can('removeCollection', 'workspace', workspaceId)) {
            return 'Get online to perform this action';
          } else
          {
            return defaultMessage;
          }
        default:
          return defaultMessage;}

    }
  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map(action => {
      const modifierLabel = action.modifier && action.modifier(this.props.isPRO);

      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
            className: this.getMenuItemClasses(modifierLabel),
            key: action.type,
            refKey: action.type,
            disabled: !action.isEnabled,
            disabledText: this.getDisabledText(!action.isEnabled, action.type) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: action.xpathLabel },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'collection-action-item' },
              action.icon,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, action.label),

              action.shortcut &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-shortcut' }, Object(_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_4__["getShortcutByName"])(action.shortcut)),


              modifierLabel &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-modifier' }, modifierLabel)))));





    }).value();
  }

  render() {
    let menuItems = this.getMenuItems();

    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'collection-sidebar-dropdown-actions-wrapper' },
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
          keyMapHandlers: this.getKeymapHandlers(),
          ref: 'menu',
          onSelect: this.handleSelect,
          onToggle: this.handleToggle,
          className: 'collection-sidebar-actions-dropdown' },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], {
            dropdownStyle: 'nocaret',
            type: 'custom' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], { tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { name: 'icon-action-options-stroke', className: 'collection-sidebar-collection-dropdown-actions-button pm-icon pm-icon-normal' }))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
            'align-right': true },

          menuItems)));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4868:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4861);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1269);
/* harmony import */ var _models_services_DocumenterService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4869);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2078);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(748);
/* harmony import */ var _modules_services_APIService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1220);
/* harmony import */ var _modules_services_CollectionPermissionService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1216);
/* harmony import */ var _containers_new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4839);
/* harmony import */ var _modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3929);
/* harmony import */ var _modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3930);
/* harmony import */ var _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4870);













/* harmony default export */ __webpack_exports__["default"] = ((id, action, modifiers, options = {}, callback) => {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }

  let store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('EnvironmentStore');

  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_RUN"]) {
    let environmentId = null,
    environment = store.find(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('ActiveEnvironmentStore').id);
    if (environment) {
      environmentId = environment.id;
    }
    pm.mediator.trigger('newRunnerWindow', id, null, environmentId);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_ADD_REQUEST"]) {
    pm.mediator.trigger('showAddToCollectionModal',
    {},
    {
      target: {
        type: 'collection',
        collection: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id) } });



  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_ADD_FOLDER"]) {
    pm.mediator.trigger('showAddFolderModal', id);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_ADD_MONITOR"]) {
    _containers_new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_8__["default"].create('openCreateNewMonitorModal',
    {
      collectionId: id,
      opts: { from: options.origin } },

    null,
    { from: options.origin });

  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_ADD_MOCK"]) {
    _mocks_containers_MockModalService__WEBPACK_IMPORTED_MODULE_11__["default"].create(
    {
      collectionId: id,
      opts: { from: options.origin } },

    null);

  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_EDIT"] || action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_VIEW_ONLY"]) {
    pm.mediator.trigger('showEditModal', id);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_FORK"]) {
    let collectionId = (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id) || {}).uid;

    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
      category: 'collection',
      action: 'initiate_fork',
      label: _.get(options, 'origin') === 'browse' ? 'workspace_browse_view' : 'sidebar' });


    // `options` object is used when along with forking a collection it needs to be updated, then
    // `options` object has details about models (request, folder) that are to be updated.
    pm.mediator.trigger('showForkCollectionModal', collectionId, options);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_MERGE"]) {
    const forkInfo = (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id) || {}).forkInfo || {};

    // Record analytics event for initiating merge action
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
      category: 'collection',
      action: 'initiate_merge',
      label: _.get(options, 'origin') === 'browse' ? 'workspace_browse_view' : 'sidebar' });


    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["viewCollectionDiff"])(`${forkInfo.id}`, `${forkInfo.baseCollectionId}`);
  } else
  if (action == _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_PULL_REQUEST"]) {
    const forkInfo = (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id) || {}).forkInfo || {};

    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["pullRequestCreate"])(`${forkInfo.id}`, `${forkInfo.baseCollectionId}`, `${Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('ActiveBrowseWorkspaceStore').id}`);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_DOWNLOAD"]) {
    pm.mediator.trigger('showExportCollectionModal', id);
    options.origin === 'browse' && _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('collection', 'export', 'browse_view');
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_DELETE"]) {
    // @todo: fix subscriber count and published status
    // var subscribers = pm.team_directory.getSubscribers(id),
    // published = pm.collections.getPublishStatus(this.props.collection.owner + '#' + id);
    var subscribers = [],
    subscriberCount = !_.isEmpty(subscribers) ? subscribers.length : 0,
    published = true,
    triggerOptions = {
      subscriberCount,
      published,
      origin: options.origin };


    pm.mediator.trigger('showCollectionDeleteModal', id, triggerOptions, callback);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_DUPLICATE"]) {
    let duplicateCollectionEvent,
    activeWorkspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('ActiveWorkspaceStore').id;

    duplicateCollectionEvent = {
      name: 'duplicate',
      namespace: 'collection',
      data: { collection: { id } } };


    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(duplicateCollectionEvent).
    then(response => {
      if (!_.isEmpty(_.get(response, 'error'))) {
        pm.logger.error('Error in duplicating collection', response.error);
        return;
      }

      options.origin === 'browse' && _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('collection', 'duplicate', 'browse_view');

      // @todo response needs the new Id
      // _.invoke(this, 'props.onDuplicate', newId);
    }).
    catch(err => {
      pm.logger.error('Error in pipeline while duplicating collection', err);
    });
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_SHARE"]) {
    let uid = _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id), 'uid');
    Object(_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_9__["shareCollection"])(uid, { origin: options.origin });
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('collection', 'modal', 'dropdown');
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_RENAME"]) {
    let updateCollectionEvent = {
      name: 'update',
      namespace: 'collection',
      data: { id, name: modifiers.name } };


    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_1__["default"])(updateCollectionEvent).
    then(response => {
      if (!_.isEmpty(_.get(response, 'error'))) {
        pm.logger.error('Error in renaming collection', response.error);
        return;
      }
      pm.mediator.trigger('focusSidebar');
      _.isFunction(callback) && callback();
    }).
    catch(err => {
      pm.logger.error('Error in pipeline while renaming collection', err);
    });
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_PUBLISH_DOCS"]) {
    if (options.origin === 'browse') {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('collection', 'publish', 'browse_view');
    } else {
      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEvent('documenter', 'initiate_publish', options.origin);
    }

    let currentUser = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CurrentUserStore');

    if (!currentUser.isLoggedIn) {
      pm.mediator.trigger('publishDocsSignedoutModal', true);
      _.isFunction(callback) && callback();
      return;
    }

    let collection = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id);
    _models_services_DocumenterService__WEBPACK_IMPORTED_MODULE_2__["default"].getDocumentationPublishURL(collection, (err, publishUrl) => {
      Object(_modules_services_APIService__WEBPACK_IMPORTED_MODULE_6__["openAuthenticatedRoute"])(publishUrl);

      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
        category: 'documentation',
        action: 'initiate_publish',
        label: 'collection_actions',
        entityType: 'collection',
        entityId: `${Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CurrentUserStore').id}-${id}` });

    });
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_ADD_TO_WORKSPACE"]) {
    let uid = _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id), 'uid');
    Object(_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_9__["shareCollection"])(uid, { origin: options.origin });
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_REMOVE_FROM_WORKSPACE"]) {
    let type = 'collection',
    { origin } = options;

    pm.mediator.trigger('showRemoveFromWorkspaceModal', id, { type, origin }, callback);
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_MANAGE_ROLES"]) {
    let uid = _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id), 'uid');
    Object(_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_10__["manageRolesOnCollection"])(uid, { origin: options.origin });
  } else
  if (action === _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_TYPE_RENAME_TOGGLE"]) {
    if (Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore').can('edit', 'collection', id)) {
      _.isFunction(callback) && callback();
    }
  } else
  if (action == _constants_CollectionActionsConstants__WEBPACK_IMPORTED_MODULE_0__["ACTION_REQUEST_ACCESS"]) {
    let uid = _.get(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CollectionStore').find(id), 'uid');

    Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["openRequestAccess"])('collection', uid, 'grant_role');
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4869:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205);
/* harmony import */ var backbone__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(backbone__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modules_services_APIService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1220);
/* harmony import */ var _models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2078);
/* harmony import */ var _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(781);
/* harmony import */ var _modules_controllers_PublishedCollectionController__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1542);
/* harmony import */ var _modules_controllers_UserController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1217);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);








/**
                                                    *
                                                    * @param {*} collectionId
                                                    * @param {*} cb
                                                    */
function getDocumentationURL(collectionId, cb) {
  _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_3__["default"].
  getCollection({ id: collectionId }).
  then((collection = {}) => {
    cb && cb(null, Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__["getEntityDetailsURL"])('collections', `${collection.owner}-${collectionId}`, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceSessionStore').workspace));
  }).
  catch(e => {
    pm.logger.error('Error in generating documenter URL', e);
    cb && cb(e);
  });
}

/**
   *
   * @param {*} collection
   * @param {*} source
   * @param {*} cb
   */
function getCollectionPublicURL(collection, source, cb) {

  _modules_controllers_UserController__WEBPACK_IMPORTED_MODULE_5__["default"].
  get().
  then(user => {
    let userId = user.id,
    publishedId = collection.publishedId,
    versionTag = collection.versionTag;

    _.isFunction(cb) && cb(null, window.postman_scribe_url + '/view/' + userId + '/' + publishedId + (
    source ? '?source=' + source : '') + (versionTag ? '?version=' + versionTag : ''));
  }).
  catch(e => {
    pm.logger.error('Error in handling collection public url', e);
    _.isFunction(cb) && cb(e);
  });
}

/**
   *
   * @param {*} collection
   * @param {*} cb
   */
function getDocumentationPublishURL(collection = {}, cb) {
  cb && cb(null, Object(_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__["getCollectionPublishURL"])(`${collection.owner}-${collection.id}`, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceSessionStore').workspace));
}

/**
   *
   * @param {*} user
   */
function populatePublishedCollections(user) {
  Object(_modules_services_APIService__WEBPACK_IMPORTED_MODULE_1__["GetPublishedCollectionsForTeam"])(user, (err, publishedCollections) => {
    if (err) {
      pm.logger.error('Error in fetching published collections', err);
      return;
    }
    var myPublishedCollections = _.filter(publishedCollections, function (collection) {
      return collection.owner === user.id;
    });

    _.each(myPublishedCollections, collection => {
      _modules_controllers_PublishedCollectionController__WEBPACK_IMPORTED_MODULE_4__["default"].get({ collectionId: collection.collectionId }).then(function (existingCollection) {
        !existingCollection && _modules_controllers_PublishedCollectionController__WEBPACK_IMPORTED_MODULE_4__["default"].create(collection);
      });
    });

  }, function (error) {
    pm.logger.error('Error fetching published collections', error);
  });
}

/**
   *
   * @param {*} environmentId
   * @param {*} callback
   */
function getPublishedCollectionsByEnvId(environmentId, callback) {
  _modules_controllers_PublishedCollectionController__WEBPACK_IMPORTED_MODULE_4__["default"].getAll().then(publishedCollections => {
    let collections = _.reduce(publishedCollections, (collections, pc) => {
      if (pc.environmentTemplateId === environmentId) {
        const collection = pm.collections.get(pc.collectionId);
        if (collection) {
          collections.push(collection);
        }
      }
      return collections;
    }, []);

    callback(collections);
  });
}

/* harmony default export */ __webpack_exports__["default"] = ({ getDocumentationURL, getCollectionPublicURL, getDocumentationPublishURL, populatePublishedCollections, getPublishedCollectionsByEnvId });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4870:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(749);
/* harmony import */ var _js_modules_services_SignInModalService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2111);
/* harmony import */ var _constants_intents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4871);




/**
                                                      * Triggers the modal event
                                                      *
                                                      * @param  {...any} args
                                                      */
function _triggerEvent(...args) {
  pm.mediator.trigger(...args);
}

/**
   * Checks if the user is not logged in then shows sign in modal
   * otherwise triggers the modal
   */
function _launchModal(data, onSuccess, intent = _constants_intents__WEBPACK_IMPORTED_MODULE_2__["CREATE"]) {
  let currentUser = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('CurrentUserStore');

  if (!currentUser.isLoggedIn) {
    return Object(_js_modules_services_SignInModalService__WEBPACK_IMPORTED_MODULE_1__["showContextualSignInModal"])('mock', () => {
      _triggerEvent('openMockModal', data, onSuccess, intent);
    });
  }

  _triggerEvent('openMockModal', data, onSuccess, intent);
}

/* harmony default export */ __webpack_exports__["default"] = ({
  /**
                  * Launches Mock Modal
                  *
                  * @param {*} data
                  * @param {*} onSuccess
                  */
  create: function (data, onSuccess = null) {
    _launchModal(data, onSuccess);
  },
  edit: function (data, onSuccess = null) {
    _launchModal(data, onSuccess, _constants_intents__WEBPACK_IMPORTED_MODULE_2__["EDIT"]);
  } });

/***/ }),

/***/ 4871:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EDIT", function() { return EDIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CREATE", function() { return CREATE; });
const EDIT = 'edit',
CREATE = 'create';

/***/ }),

/***/ 4872:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarListItemEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);


let

CollectionSidebarListItemEmpty = class CollectionSidebarListItemEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.selfNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    // Starts observing element
    this.props.observeSizeChange && this.props.observeSizeChange(this.selfNode);
  }

  componentWillUnmount() {
    this.props.unobserveSizeChange && this.props.unobserveSizeChange(this.selfNode, this.props.index);
  }

  render() {
    const parentType = this.props.parentType;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: 'collection-sidebar-list-item__body--empty',
          style: { marginLeft: `${10 * this.props.depth}px` },
          'data-index': this.props.index }, 'This ',

        parentType, ' is empty.\xA0',

        this.props.canAddRequest &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'text',
              className: 'learn-more-link',
              onClick: () => this.props.onAddRequest(this.props.parent) }, 'Add requests'), 'to this ',



          parentType, ' and create ', parentType === 'folder' && 'sub', 'folders to organize them')));




  }};

/***/ }),

/***/ 4873:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ArchivedResource; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _base_Icons_ArchiveIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4874);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1875);
/* harmony import */ var _messaging_Alert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2689);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);
var _class;







const COLLECTIONS = 'COLLECTIONS',
HISTORIES = 'HISTORIES';let


ArchivedResource = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class ArchivedResource extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getArchivedCount() {
    switch (this.props.label) {
      case COLLECTIONS:
        return this.props.archivedResources.archivedCollectionsCount;
      case HISTORIES:
        return this.props.archivedResources.archivedHistoryCount;}

  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'archived-resource-item': true,
      'is-actionable': !!this.props.onClick });

  }

  render() {

    let archivedCount = this.getArchivedCount();
    if (!archivedCount) {
      return '';
    }

    let warningMessage = `Some ${this.props.label.toLowerCase()} were archived because you’ve reached the shared requests limits. [Learn more](${_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_4__["ARCHIVED_RESOURCES_DOCS"]})`;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'archived-resource-item-container' },

        this.props.showWarning &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_messaging_Alert__WEBPACK_IMPORTED_MODULE_5__["default"], {
          message: warningMessage,
          type: 'warn' }),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClasses(), onClick: this.props.onClick },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'archived-resource-item-icon-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_ArchiveIcon__WEBPACK_IMPORTED_MODULE_3__["default"], { size: 'xs' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'archived-resource-item-text' }, 'ARCHIVED ', this.props.label, ' (', archivedCount, ')'))));



  }}) || _class;

ArchivedResource.propTypes = { archivedResources: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.object.isRequired };

/***/ }),

/***/ 4874:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ArchiveIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1647);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', { width: '16px', height: '16px', viewBox: '0 0 16 16' },
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('defs', null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', { id: 'archive', d: 'M15,3 L15,14.8461538 C15,15.4834055 14.5522847,16 14,16 L2,16 C1.44771525,16 1,15.4834055 1,14.8461538 L1,3 C0.44771525,3 6.76353751e-17,2.66421356 0,2.25 L0,0.75 C-6.76353751e-17,0.335786438 0.44771525,7.6089797e-17 1,0 L15,0 C15.5522847,-7.6089797e-17 16,0.335786438 16,0.75 L16,2.25 C16,2.66421356 15.5522847,3 15,3 Z M2,8 L2,9 L14,9 L14,8 L2,8 Z M6,4 L6,6 L10,6 L10,4 L6,4 Z M6,11 L6,13 L10,13 L10,11 L6,11 Z' })),

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('g', { id: 'icon/archive-filled', stroke: 'none', strokeWidth: '1', fill: 'none', fillRule: 'evenodd' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('mask', { id: 'mask-2', fill: 'white' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { xlinkHref: '#archive' })),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('use', { id: 'Combined-Shape', fill: '#979797', xlinkHref: '#archive' })));




function ArchiveIcon(props) {
    return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
        props, {
            icon: icon })));


}

/***/ }),

/***/ 4875:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(742);
/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1269);
/* harmony import */ var _components_history_HistorySidebar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4876);
/* harmony import */ var _modules_services_HistoryService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1557);
/* harmony import */ var _new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4839);
/* harmony import */ var _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4879);
var _class;











let



HistorySidebarContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class HistorySidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('HistorySidebarStore');

    this.focus = this.focus.bind(this);
    this.handleLoadRequestDebounced = _.debounce(this.handleLoadRequest, 100, { leading: true }).bind(this);
    this.handleActiveRequestChange = this.handleActiveRequestChange.bind(this);
    this.handleAddToCollection = this.handleAddToCollection.bind(this);
    this.handleDeleteMultiple = this.handleDeleteMultiple.bind(this);
    this.handleItemSelect = this.handleItemSelect.bind(this);
    this.handleLoadMore = this.handleLoadMore.bind(this);
    this.handleSelectHistoryAction = this.handleSelectHistoryAction.bind(this);
  }

  componentWillUnmount() {
    pm.mediator.off('activeRequestChanged', this.handleActiveRequestChange);
  }

  UNSAFE_componentWillMount() {
    pm.mediator.on('activeRequestChanged', this.handleActiveRequestChange);
  }

  focus() {
    _.invoke(this, 'refs.history.focus');
  }

  selectNext() {
    _.invoke(this, 'refs.history.selectNext');
  }

  handleActiveRequestChange(requestId) {
    if (!this.store.itemExists(requestId)) {
      this.store.resetSelection();
      return;
    }

    this.store.resetSelection([requestId]);
  }

  handleClickOutside(e) {
    if (!_.isEmpty(this.store.getSelectedItems())) {
      let modalElm = document.getElementsByClassName('ReactModal__Content')[0];
      if (modalElm && modalElm.contains(e.target)) {
        return;
      }
      this.store.resetSelection();
    }
  }

  handleLoadRequest(id, newTab = false) {
    if (!id) {
      return;
    }

    _modules_services_HistoryService__WEBPACK_IMPORTED_MODULE_7__["default"].openHistoryInTab(id, {
      newTab: newTab,
      preview: true });

  }

  handleItemSelect(id, modifiers = {}) {
    let isOsxPlatform = _.includes(navigator.platform, 'Mac');

    if (modifiers.shiftKey && (isOsxPlatform ? modifiers.metaKey : modifiers.ctrlKey)) {
      this.handleLoadRequestDebounced(id, true); // open request in a new tab
      pm.mediator.trigger('focusSidebar');
    } else
    if (modifiers.ctrlKey || modifiers.metaKey) {// select multiple requests
      if (this.store.isItemSelected(id)) {
        this.store.unselectItem(id);
      } else
      {
        this.store.selectItem(id);
      }
    } else
    {
      this.handleLoadRequestDebounced(id, false); // open request in current tab
      this.store.resetSelection([id]);
    }
  }

  handleAddToCollection(options = {}) {
    const { requests } = options;
    let selectedItems = _.isEmpty(requests) ? this.store.getSelectedItems() : requests;
    if (_.isEmpty(selectedItems)) {
      return;
    }

    _modules_services_HistoryService__WEBPACK_IMPORTED_MODULE_7__["default"].
    convertHistoryToRequests(selectedItems).
    then(requests => {
      if (_.size(requests) === 1) {
        requests[0] && pm.mediator.trigger('showAddToCollectionModal', requests[0], { from: options.from });
      } else
      {
        pm.mediator.trigger('addRequestsToCollection', requests, options);
      }
    });
  }

  handleToggleHistoryResponseSaving() {
    let workspaceSettings = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').settings,
    enableHistoryResponseSaving = workspaceSettings && workspaceSettings.enableHistoryResponseSaving,

    // compute the new value after toggle
    newSettings = { enableHistoryResponseSaving: !enableHistoryResponseSaving };

    return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('updateSettings', 'workspace', { id: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').id, settings: newSettings })).
    catch(e => {
      let errorMessage = e.isFriendly ? e.message : 'Could not update workspace settings';

      pm.toasts.error(errorMessage, { dedupeId: 'ws-settings-error' });
    });
  }

  resetHistorySelection(nextSelection) {
    if (nextSelection && nextSelection.id) {
      this.store.resetSelection([nextSelection.id]);
    } else {
      this.store.resetSelection();
    }
  }

  handleDeleteMultiple(ref, nextSelection) {
    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('PermissionStore'),
    workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').id;

    return Promise.resolve().
    then(() => {

      if (ref === 'all') {
        return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('deleteAllInWorkspace', 'history', Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').id));
      } else
      if (ref === 'selected') {
        if (permissionStore.can('delete', 'history')) {
          return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('deleteMultiple', 'history', { ids: this.store.getSelectedItems() }, null, null));
        } else
        {
          pm.toasts.error('You do not have permissions to delete history.');
        }
      }
    }).

    then(() => {
      this.resetHistorySelection(nextSelection);
    }).

    catch(() => {
      this.resetHistorySelection(nextSelection);
    });

  }

  handleLoadMore() {
    this.store.loadMore();
  }

  handleAddRequestToService(options, event) {
    const {
      requests,
      defaultCollectionName = '',
      from = '' } =
    options;

    let selectedItems = _.isEmpty(requests) ? this.store.getSelectedItems() : requests;
    if (_.isEmpty(selectedItems)) {
      return;
    }

    _modules_services_HistoryService__WEBPACK_IMPORTED_MODULE_7__["default"].
    convertHistoryToRequests(selectedItems).
    then(requests => {

      if (!_.isEmpty(requests)) {
        let opts = {
          name: defaultCollectionName,
          from };


        _new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_8__["default"].create(event, { requests, opts }, null, { from: 'history_sidebar' });
      }
    });
  }

  handleSelectHistoryAction(action, options) {
    switch (action) {
      case _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_SAVE"]:
        this.handleAddToCollection(options);
        break;

      case _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_MONITOR"]:
        this.handleAddRequestToService(options, 'openCreateNewMonitorModal');
        break;

      case _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DOCUMENT"]:
        this.handleAddRequestToService(options, 'openCreateNewDocumentationModal');
        break;

      case _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_MOCK"]:
        this.handleAddRequestToService(options, 'openCreateNewMockModal');
        break;

      case _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DELETE"]:
        Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('deleteMultiple', 'history', { ids: options.requests }, null, null));
        break;

      default:return;}

  }

  render() {
    let workspaceSettings = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').settings,
    enableHistoryResponseSaving = workspaceSettings && workspaceSettings.enableHistoryResponseSaving;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_history_HistorySidebar__WEBPACK_IMPORTED_MODULE_6__["default"], {
        store: this.store,
        enableHistoryResponseSaving: enableHistoryResponseSaving,
        onSelectHistoryAction: this.handleSelectHistoryAction,
        onDeleteMultiple: this.handleDeleteMultiple,
        onSelect: this.handleItemSelect,
        onLoadMore: this.handleLoadMore,
        onSaveCurrentRequest: this.handleAddToCollection,
        onToggleHistoryResponseSaving: this.handleToggleHistoryResponseSaving,
        ref: 'history' }));


  }}) || _class) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4876:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebar; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _HistorySidebarMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4877);
/* harmony import */ var _HistorySidebarList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4881);
/* harmony import */ var _archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4873);
/* harmony import */ var _base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1794);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4879);
var _class;







let


HistorySidebar = pure_render_decorator__WEBPACK_IMPORTED_MODULE_2___default()(_class = class HistorySidebar extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('HistorySidebarStore');
    this.historyStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('HistoryStore');

    this.focus = this.focus.bind(this);
    this.groupItems = this.groupItems.bind(this);
    this.selectNext = this.selectNext.bind(this);
    this.selectPrev = this.selectPrev.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.selectItem = this.selectItem.bind(this);
    this.multiselectNextItem = this.multiselectNextItem.bind(this);
    this.multiselectPrevItem = this.multiselectPrevItem.bind(this);
  }

  getKeyMapHandlers() {
    return {
      groupItems: pm.shortcuts.handle('groupItems', this.groupItems),
      nextItem: pm.shortcuts.handle('nextItem', this.selectNext),
      prevItem: pm.shortcuts.handle('prevItem', this.selectPrev),
      delete: pm.shortcuts.handle('delete', this.deleteItem),
      multiselectNextItem: pm.shortcuts.handle('multiselectNextItem', this.multiselectNextItem),
      multiselectPrevItem: pm.shortcuts.handle('multiselectPrevtItem', this.multiselectPrevItem),
      select: pm.shortcuts.handle('select', this.selectItem),
      search: pm.shortcuts.handle('search'),
      saveCurrentRequest: e => {
        e && e.stopPropagation();
        this.props.onSaveCurrentRequest();
      } };

  }

  focus() {
    let $history = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.refs.history);
    $history && $history.focus();
  }

  selectNext(e) {
    e && e.preventDefault();
    let nextItemId = this.store.getNextItem();
    nextItemId && _.invoke(this, 'props.onSelect', nextItemId);
  }

  selectPrev(e) {
    e && e.preventDefault();
    let prevItemId = this.store.getPrevItem();
    prevItemId && _.invoke(this, 'props.onSelect', prevItemId);
  }

  deleteItem(e) {
    e && e.preventDefault();
    let prevItemId = this.store.getPrevItem();
    console.warn('prevItemId fix');
    _.invoke(this, 'props.onDeleteMultiple', 'selected', prevItemId);
  }

  selectItem(e) {
    e && e.preventDefault();
    _.invoke(this, 'refs.list.selectItem');
  }

  multiselectNextItem(e) {
    e && e.preventDefault();
    let nextItemId = this.store.getNextItem();
    nextItemId && _.invoke(this, 'props.onSelect', nextItemId, { metaKey: true });
  }

  multiselectPrevItem(e) {
    e && e.preventDefault();
    let prevItemId = this.store.getPrevItem();
    prevItemId && _.invoke(this, 'props.onSelect', prevItemId, { metaKey: true });
  }

  groupItems() {
    this.props.onSelectHistoryAction && this.props.onSelectHistoryAction(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_SAVE"], {
      requests: this.store.getSelectedItems(),
      from: 'history_multiple' });

  }

  render() {
    let ActiveWorkspaceStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore');
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_6__["default"], {
          handlers: this.getKeyMapHandlers(),
          keyMap: pm.shortcuts.getShortcuts() },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: 'history-sidebar',
            ref: 'history' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarMenu__WEBPACK_IMPORTED_MODULE_3__["default"], {
              historySidebar: this.store,
              historyStore: this.historyStore,
              enableHistoryResponseSaving: this.props.enableHistoryResponseSaving,
              onDeleteMultiple: this.props.onDeleteMultiple,
              onSelectHistoryAction: this.props.onSelectHistoryAction,
              onToggleHistoryResponseSaving: this.props.onToggleHistoryResponseSaving }),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarList__WEBPACK_IMPORTED_MODULE_4__["default"], {
              ref: 'list',
              onDeleteMultiple: this.props.onDeleteMultiple,
              onLoadMore: this.props.onLoadMore,
              onSelect: this.props.onSelect,
              onSelectHistoryAction: this.props.onSelectHistoryAction })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_archivedResource_ArchivedResource__WEBPACK_IMPORTED_MODULE_5__["default"], { archivedResources: ActiveWorkspaceStore, label: 'HISTORIES' }))));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4877:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4878);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1763);
/* harmony import */ var _base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2511);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4879);
/* harmony import */ var _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4880);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__);
var _class;








let


HistorySidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class HistorySidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { dropdownOpen: false };

    this.handleDeleteClick = this.handleDeleteClick.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleAddToCollectionClick = this.handleAddToCollectionClick.bind(this);
    this.handleDeleteSelected = this.handleDeleteSelected.bind(this);
  }

  handleAddToCollectionClick(e) {
    e.stopPropagation();
    this.props.onSelectHistoryAction(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_SAVE"], {
      requests: this.props.historySidebar.getSelectedItems(),
      from: 'history_multiple' });

  }

  handleDeleteClick() {
    pm.mediator.trigger('showDeleteHistoryModal', async () => {
      try {this.props.onDeleteMultiple && (await this.props.onDeleteMultiple('all'));}
      catch (e) {pm.logger.error('Could not delete history', e);pm.toasts.error('Could not delete history');}
    }, {
      identifier: 'all' });

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    if (action === _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteHistoryModal', () => {
        this.props.onDeleteMultiple('selected');
      }, {
        identifier: 'selected' });

      return;
    }
    this.props.onSelectHistoryAction(action, {
      requests: this.props.historySidebar.getSelectedItems(),
      from: 'history_multiple' });

  }

  handleDeleteSelected() {
    this.handleDropdownActionSelect(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DELETE"]);
  }

  render() {
    let selectionSize = this.props.historySidebar.selectedItems.size,
    historySize = _.size(this.props.historyStore.values);

    const isLoggedIn = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').isLoggedIn,
    isOffline = !Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('SyncStatusStore').isSocketConnected,
    isDisabled = isOffline && isLoggedIn;

    if (selectionSize > 1) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu__left' },
            `${selectionSize} requests selected`),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu__right' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu__actions-delete-history-wrapper' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: 'history-sidebar-list-item__button__add',
                  type: 'icon',
                  onClick: this.handleAddToCollectionClick,
                  tooltip: _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SAVE_REQUESTS_TOOLTIP"] },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-add-stroke', size: 'large', className: 'history-sidebar-list-item__actions__add pm-icon pm-icon-normal' })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: 'history-sidebar-list-item__button__delete',
                  type: 'icon',
                  onClick: this.handleDeleteSelected,
                  tooltip: _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE_REQUESTS_TOOLTIP"] },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-delete-stroke', size: 'large', className: 'history-sidebar-list-item__actions__delete pm-icon pm-icon-normal' })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                count: selectionSize,
                onSelect: this.handleDropdownActionSelect,
                onToggle: this.handleDropdownToggle })))));





    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu__left' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu--save-response-toggle' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_4__["default"], {
              isActive: this.props.enableHistoryResponseSaving,
              onClick: this.props.onToggleHistoryResponseSaving,
              activeLabel: '',
              inactiveLabel: '' })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu--save-response-label' }, 'Save Responses')),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu__right' },

          historySize > 0 &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-menu__actions-delete-history-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                type: 'text',
                onClick: this.handleDeleteClick,
                tooltip: isDisabled ? 'You need to be online to clear history.' : null,
                disabled: isDisabled ? true : null,
                className: 'history-sidebar-menu--clear-all-label' }, 'Clear all')))));








  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4878:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryItemActionsDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2059);
/* harmony import */ var _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4879);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1763);
/* harmony import */ var _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2467);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__);
var _class;









let


HistoryItemActionsDropdown = Object(mobx_react__WEBPACK_IMPORTED_MODULE_7__["observer"])(_class = class HistoryItemActionsDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleShortcutSelect = this.handleShortcutSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
  }

  getKeymapHandlers() {
    return { delete: pm.shortcuts.handle('delete', this.handleShortcutSelect.bind(this, _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"])) };
  }

  handleShortcutSelect(action) {
    pm.mediator.trigger('focusSidebar');
    this.handleSelect(action);
  }

  handleSelect(action) {
    this.props.onSelect && this.props.onSelect(action);
    this.handleToggle(false);
  }

  handleToggle(isOpen) {
    this.props.onToggle && this.props.onToggle(isOpen);
  }

  getDropDownActionWrapperClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'collection-sidebar-request-dropdown-actions-wrapper': true });
  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }
  }


  render() {
    let pluralizeRequest = _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_4__["default"].pluralize({
      count: this.props.count,
      singular: 'Request',
      plural: 'Requests' });


    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
    canDeleteHistory = permissionStore.can('delete', 'history');

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getDropDownActionWrapperClasses() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            keyMapHandlers: this.getKeymapHandlers(),
            ref: 'menu',
            onSelect: this.handleSelect,
            onToggle: this.handleToggle,
            className: 'collection-sidebar-request-actions-dropdown' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], {
              dropdownStyle: 'nocaret',
              type: 'custom' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                className: 'history-sidebar-list-item__button__options',
                tooltip: _constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_8__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], {
                name: 'icon-action-options-stroke',
                size: 'small',
                className: 'history-sidebar-list-item__actions__options pm-icon pm-icon-normal' }))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
              'align-right': true },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_SAVE"] },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { size: 'large', name: 'icon-action-add-stroke', className: 'dropdown-menu-item-icon menu-icon--add pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, `Save ${pluralizeRequest}`)),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MONITOR"] },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-descriptive-observe-stroke', size: 'large', className: 'dropdown-menu-item-icon menu-icon--add-monitor pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, `Monitor ${pluralizeRequest}`)),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DOCUMENT"] },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-publish-stroke', size: 'large', className: 'dropdown-menu-item-icon menu-icon--publish-docs pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, `Document ${pluralizeRequest}`)),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], { refKey: _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MOCK"] },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-entity-mock-stroke', size: 'large', className: 'dropdown-menu-item-icon menu-icon--add-mock pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, `Mock ${pluralizeRequest}`)),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
                refKey: _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"],
                disabled: !canDeleteHistory,
                disabledText: this.getDisabledText(!canDeleteHistory) },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_9__["Icon"], { name: 'icon-action-delete-stroke', size: 'large', className: 'dropdown-menu-item-icon menu-icon--delete pm-icon pm-icon-normal' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' }, 'Delete'))))));





  }}) || _class;

/***/ }),

/***/ 4879:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SAVE", function() { return ACTION_TYPE_SAVE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_MONITOR", function() { return ACTION_TYPE_MONITOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DOCUMENT", function() { return ACTION_TYPE_DOCUMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_MOCK", function() { return ACTION_TYPE_MOCK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE", function() { return ACTION_TYPE_DELETE; });
const ACTION_TYPE_SAVE = 'save',
ACTION_TYPE_MONITOR = 'monitor',
ACTION_TYPE_DOCUMENT = 'document',
ACTION_TYPE_MOCK = 'mock',
ACTION_TYPE_DELETE = 'delete';

/***/ }),

/***/ 4880:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE_REQUEST_TOOLTIP", function() { return ACTION_TYPE_DELETE_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE_REQUESTS_TOOLTIP", function() { return ACTION_TYPE_DELETE_REQUESTS_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SAVE_REQUEST_TOOLTIP", function() { return ACTION_TYPE_SAVE_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SAVE_REQUESTS_TOOLTIP", function() { return ACTION_TYPE_SAVE_REQUESTS_TOOLTIP; });
const ACTION_TYPE_DELETE_REQUEST_TOOLTIP = 'Delete request',
ACTION_TYPE_DELETE_REQUESTS_TOOLTIP = 'Delete requests',
ACTION_TYPE_SAVE_REQUEST_TOOLTIP = 'Add request to Collection',
ACTION_TYPE_SAVE_REQUESTS_TOOLTIP = 'Add requests to Collection';

/***/ }),

/***/ 4881:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _HistorySidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4882);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var _empty_states_HistorySidebarEmptyShell__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4883);
/* harmony import */ var _HistoryListItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4884);
/* harmony import */ var _HistoryListMetaItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4885);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2451);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4570);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;










const MIN_ROW_HEIGHT = 30,
OVERSCAN_COUNT = 10;let


HistorySidebarList = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class HistorySidebarList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('HistorySidebarStore');

    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollDebounced = _.debounce(this.handleScroll, 300);
    this.handleToggleGroup = this.handleToggleGroup.bind(this);
    this.getListItem = this.getListItem.bind(this);
    this.getItemSize = this.getItemSize.bind(this);
    this.handleClearCachedHeight = this.handleClearCachedHeight.bind(this);
    this.observeSizeChange = this.observeSizeChange.bind(this);
    this.unobserveSizeChange = this.unobserveSizeChange.bind(this);

    this.heightSet = {};

    this.resizeObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        if (!(entry && entry.target && entry.target.dataset)) {
          return;
        }

        let index = entry.target.dataset.index;

        this.heightSet[index] = entry.target.offsetHeight;
      }

      this.handleClearCachedHeight(0);
    });
  }

  handleScroll() {
    let node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    if (node.scrollTop + node.offsetHeight === node.scrollHeight) {
      this.props.onLoadMore && this.props.onLoadMore();
    }
  }

  observeSizeChange(node) {
    this.resizeObserver && this.resizeObserver.observe(node);
  }

  unobserveSizeChange(node, index) {
    this.resizeObserver && this.resizeObserver.unobserve(node);
    delete this.heightSet[index];
  }

  handleClearCachedHeight(index) {
    this.listRef.resetAfterIndex(index);
  }

  handleToggleGroup(name) {
    if (this.store.isItemCollapsed(name)) {
      return this.store.expandItem(name);
    }

    this.store.collapseItem(name);
  }

  getItemSize(index) {
    let currentItem = _.get(this.store, ['historyItems', index]);

    if (currentItem.type === 'meta') {
      return MIN_ROW_HEIGHT;
    }

    return this.heightSet[index] || MIN_ROW_HEIGHT;
  }

  getListItem(data) {
    let historyItem = _.get(this.store, ['historyItems', data.index]);

    if (!historyItem) {
      return null;
    }

    if (historyItem.type === 'meta') {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-list__meta', style: data.style },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryListMetaItem__WEBPACK_IMPORTED_MODULE_7__["default"], {
            name: historyItem.name,
            key: historyItem.name,
            onSelect: this.props.onSelect,
            onSelectHistoryAction: this.props.onSelectHistoryAction,
            items: historyItem.items })));



    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-list__item', style: data.style },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryListItem__WEBPACK_IMPORTED_MODULE_6__["default"], _extends({},
        historyItem, {
          hideActions: _.size(this.store.getSelectedItems()) > 1,
          key: historyItem.id,
          selected: this.store.isItemSelected(historyItem.id),
          onSelect: this.props.onSelect,
          onSelectHistoryAction: this.props.onSelectHistoryAction,
          observeSizeChange: this.observeSizeChange,
          unobserveSizeChange: this.unobserveSizeChange,
          viewLargeBody: this.props.viewLargeBody,
          index: data.index }))));



  }

  render() {
    const isHydrating = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('HistoryStore').isHydrating,
    lister = data => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_2__["Observer"], null,
          this.getListItem.bind(this, data)));


    },
    sizer = ({ height, width }) => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_2__["Observer"], null,
          () =>
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_window__WEBPACK_IMPORTED_MODULE_8__["VariableSizeList"], {
              height: height,
              itemCount: this.store.historyItems.length,
              itemSize: this.getItemSize,
              width: width,
              ref: ref => this.listRef = ref,
              overscanCount: OVERSCAN_COUNT },

            lister)));





    };

    if (_.isEmpty(this.store.historyItems)) {
      let query = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('RequesterSidebarStore').searchQuery;
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list' },

          isHydrating ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_empty_states_HistorySidebarEmptyShell__WEBPACK_IMPORTED_MODULE_5__["default"], null) :
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_3__["default"], { query: query })));



    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: 'history-sidebar-list',
          ref: 'history',
          onScroll: this.handleScrollDebounced },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_9__["default"], null, sizer)));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4882:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarListEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2559);
var _class;




let


HistorySidebarListEmptyItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class HistorySidebarListEmptyItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleShowMeHow = this.handleShowMeHow.bind(this);
  }

  handleShowMeHow() {
    Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_4__["runTaggedLesson"])('debugging', {
      signInModalOptions: {
        type: 'history',
        origin: 'history_sidebar_show_me_how' } });


  }

  getContents() {
    if (this.props.query) {
      return `No results found for "${this.props.query}"`;
    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' }, 'You haven\'t sent any requests'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' }, 'Any request you send in this workspace will appear here.'),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__learn' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: 'secondary',
              onClick: this.handleShowMeHow },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
              name: 'icon-descriptive-step-stroke',
              className: 'entity-empty__learn__mouse-click-icon pm-icon pm-icon-secondary' }), 'Show me how'))));






  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-empty-item' },
        this.getContents()));


  }}) || _class;

/***/ }),

/***/ 4883:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const NUMBER_OF_HISTORY_ITEMS_PER_SECTION = 5,
NUMBER_OF_SECTIONS = 2;

const HistorySidebarEmptyShell = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-empty-shell' },

      _.times(NUMBER_OF_SECTIONS, sectionIndex => {
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { key: sectionIndex, className: 'history-sidebar-empty-shell--section' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-empty-shell--section--title' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-empty-shell--section--title__dropdown' }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-empty-shell--section--title__name' })),


            _.times(NUMBER_OF_HISTORY_ITEMS_PER_SECTION, index => {
              return (
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                    key: index,
                    className: 'history-sidebar-empty-shell--section--item' },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-empty-shell--section--item__icon' }),
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                    className: 'history-sidebar-empty-shell--section--item__url',
                    style: { 'width': `${Math.floor(Math.random() * 74) + 50}px` } })));



            })));



      })));



};

/* harmony default export */ __webpack_exports__["default"] = (HistorySidebarEmptyShell);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4884:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4878);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _components_request_RequestIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4863);
/* harmony import */ var _base_Avatar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2070);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1769);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(749);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1537);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4879);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1763);
/* harmony import */ var _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4880);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__);
var _class;













let


HistoryListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_11__["observer"])(_class = class HistoryListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      dropdownOpen: false,
      isTooltipVisible: false,
      tooltipTarget: null,
      isHovered: false };


    this.handleSelect = this.handleSelect.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleAddRequestToCollectionClick = this.handleAddRequestToCollectionClick.bind(this);
    this.handleRemoveRequest = this.handleRemoveRequest.bind(this);
    this.showTooltip = this.showTooltip.bind(this);
    this.hideTooltip = this.hideTooltip.bind(this);
    this.handleMouseEnter = this.handleMouseEnter.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
  }


  componentDidMount() {
    this.refs.avatar && this.setState({ tooltipTarget: Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.refs.avatar) });

    this.selfNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    // Starts observing element
    this.props.observeSizeChange && this.props.observeSizeChange(this.selfNode);
  }

  componentWillUnmount() {
    this.props.unobserveSizeChange && this.props.unobserveSizeChange(this.selfNode, this.props.index);
  }

  UNSAFE_componentWillUpdate(nextProps) {
    if (!this.props.selected && nextProps.selected) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  handleMouseEnter() {
    this.setState({ isHovered: true });
  }

  handleMouseLeave() {
    !this.state.isTooltipVisible && !this.state.dropdownOpen && this.setState({ isHovered: false });
  }

  showTooltip() {
    this.setState({ isTooltipVisible: true });
  }

  hideTooltip() {
    this.setState({ isTooltipVisible: false });
  }

  handleSelect(e) {
    e.stopPropagation();
    let modifiers = {
      ctrlKey: e.ctrlKey,
      metaKey: e.metaKey,
      shiftKey: e.shiftKey };

    this.props.onSelect && this.props.onSelect(this.props.id, modifiers);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'history-sidebar-list-item': true,
      'is-hovered': this.state.dropdownOpen,
      'is-selected': this.props.selected });

  }

  getLabelClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'history-sidebar-list-item__label': true,
      'request-method--GET': this.props.method && _.includes(this.props.method.toUpperCase(), 'GET'),
      'request-method--PUT': this.props.method && _.includes(this.props.method.toUpperCase(), 'PUT'),
      'request-method--POST': this.props.method && _.includes(this.props.method.toUpperCase(), 'POST'),
      'request-method--DELETE': this.props.method && _.includes(this.props.method.toUpperCase(), 'DELETE') });

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    this.props.onSelectHistoryAction(action, {
      requests: [this.props.id],
      from: 'history_single' });

  }

  handleAddRequestToCollectionClick(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_SAVE"], { from: 'history_single' });
  }

  handleRemoveRequest(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_DELETE"]);
  }

  getTooltipText(isDisabled) {
    if (isDisabled) {
      return 'You do not have permissions to perform this action.';
    }

    return _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_DELETE_REQUEST_TOOLTIP"];
  }

  render() {
    let updatedByMember = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('CurrentUserStore').teamMembers.get(this.props.lastUpdatedBy),
    updatedByMemberName = updatedByMember && (updatedByMember.name || updatedByMember.username);

    const permissionStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('PermissionStore'),
    canDeleteHistory = permissionStore.can('delete', 'history', this.props.id);

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: this.getClasses(),
          onClick: this.handleSelect,
          onMouseEnter: this.handleMouseEnter,
          onMouseLeave: this.handleMouseLeave,
          'data-index': this.props.index },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item-updatedBy',
            onMouseEnter: this.showTooltip,
            onMouseLeave: this.hideTooltip },


          this.state.isHovered && (
          !this.props.lastUpdatedBy || this.props.lastUpdatedBy === '0') ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { name: 'icon-descriptive-user-stroke', className: 'pm-icon pm-icon-normal' }) :
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Avatar__WEBPACK_IMPORTED_MODULE_6__["default"], {
            ref: 'avatar',
            size: 'small',
            userId: this.props.lastUpdatedBy })),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item__label-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_request_RequestIcon__WEBPACK_IMPORTED_MODULE_5__["default"], { method: this.props.method ? this.props.method : 'GET' })),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item__meta' },
          this.props.url),


        !this.props.hideActions && this.state.isHovered &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item__actions' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
              className: 'history-sidebar-list-item__button__add',
              type: 'icon',
              onClick: this.handleAddRequestToCollectionClick,
              tooltip: _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["ACTION_TYPE_SAVE_REQUEST_TOOLTIP"] },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], { size: 'small', name: 'icon-action-add-stroke', className: 'history-sidebar-list-item__actions__add pm-icon pm-icon-normal' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
              className: 'history-sidebar-list-item__button__delete',
              type: 'icon',
              onClick: this.handleRemoveRequest,
              disabled: !canDeleteHistory,
              tooltip: this.getTooltipText(!canDeleteHistory) },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_13__["Icon"], {
              name: 'icon-action-delete-stroke',
              size: 'small',
              className: 'history-sidebar-list-item__actions__delete pm-icon pm-icon-normal' })),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_3__["default"], {
            count: 1,
            onSelect: this.handleDropdownActionSelect,
            onToggle: this.handleDropdownToggle,
            id: this.props.id })),




        this.state.tooltipTarget &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__["Tooltip"], {
            immediate: true,
            show: this.state.isTooltipVisible,
            target: this.state.tooltipTarget,
            placement: 'right' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__["TooltipBody"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                updatedByMemberName),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                moment__WEBPACK_IMPORTED_MODULE_9___default()(this.props.createdAt).format('DD MMM YYYY, h:mm A')))))));







  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4885:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryListMetaItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4878);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(749);
/* harmony import */ var _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4879);
/* harmony import */ var _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4880);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__);








let

HistoryListMetaItem = class HistoryListMetaItem extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);
    this.state = {
      dropdownOpen: false,
      isHovered: false };


    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('HistorySidebarStore');

    this.handleToggleGroup = this.handleToggleGroup.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleAddRequestToCollectionClick = this.handleAddRequestToCollectionClick.bind(this);
    this.handleRemoveRequest = this.handleRemoveRequest.bind(this);
    this.handleMouseEnter = this.handleMouseEnter.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
  }

  handleMouseEnter() {
    this.setState({ isHovered: true });
  }

  handleMouseLeave() {
    !this.state.dropdownOpen && this.setState({ isHovered: false });
  }

  getCollapseButtonClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'caret': true,
      'pm-icon': true,
      'pm-icon-normal': true,
      'is-closed': this.store.isItemCollapsed(this.props.name) });

  }

  getMetaClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'history-sidebar-list-item-group__meta': true,
      'is-hovered': this.state.dropdownOpen });

  }

  handleToggleGroup() {
    let name = this.props.name;

    if (this.store.isItemCollapsed(name)) {
      return this.store.expandItem(name);
    }

    this.store.collapseItem(name);
  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    let modalOptions = {
      requests: this.props.items,
      defaultCollectionName: this.props.name,
      from: 'history_date_group' };

    if (action === _constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteHistoryModal', () => {
        this.props.onSelectHistoryAction(action, modalOptions);
      }, {
        identifier: 'selected' });

      return;
    }
    this.props.onSelectHistoryAction(action, modalOptions);
  }

  handleAddRequestToCollectionClick(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_SAVE"]);
  }

  handleRemoveRequest(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_constants_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"]);
  }

  render() {
    let hideActions = _.size(this.store.getSelectedItems()) > 1;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: 'history-sidebar-list-item-group',
          onMouseEnter: this.handleMouseEnter,
          onMouseLeave: this.handleMouseLeave },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: this.getMetaClasses(),
            onClick: this.handleToggleGroup },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item-group__name' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-direction-down', className: this.getCollapseButtonClasses() }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, this.props.name)),


          !hideActions && this.state.isHovered &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'history-sidebar-list-item-group__actions' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                className: 'history-sidebar-list-item__button__add',
                type: 'icon',
                onClick: this.handleAddRequestToCollectionClick,
                tooltip: _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_SAVE_REQUESTS_TOOLTIP"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], {
                size: 'small',
                name: 'icon-action-add-stroke',
                className: 'history-sidebar-list-item__actions__add pm-icon pm-icon-normal' })),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                className: 'history-sidebar-list-item__button__delete',
                type: 'icon',
                onClick: this.handleRemoveRequest,
                tooltip: _constants_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_DELETE_REQUESTS_TOOLTIP"] },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_7__["Icon"], { name: 'icon-action-delete-stroke', size: 'small', className: 'history-sidebar-list-item__actions__delete pm-icon pm-icon-normal' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
              count: _.size(this.props.items),
              onSelect: this.handleDropdownActionSelect,
              onToggle: this.handleDropdownToggle })))));






  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4886:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1794);
/* harmony import */ var _APISidebarMenu_APISidebarMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4887);
/* harmony import */ var _APISidebarList_APISidebarList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4888);
/* harmony import */ var _common_DeleteModal_DeleteModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3939);
/* harmony import */ var _api_editor_common_RemoveFromWorkspaceModal_RemoveFromWorkspaceModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3940);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(749);
var _class;









let


APISidebarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      openDeleteModal: false,
      openRemoveFromWSModal: false,
      apiToDelete: {},
      apiToRemove: {} };


    this.apiListStore;
    this.apiSidebarStore;

    this.focus = this.focus.bind(this);
    this.focusNext = this.focusNext.bind(this);
    this.focusPrev = this.focusPrev.bind(this);
    this.selectItem = this.selectItem.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.removeItem = this.removeItem.bind(this);
    this.renameItem = this.renameItem.bind(this);
    this.handleDeleteShortcut = this.handleDeleteShortcut.bind(this);
    this.toggleDeleteModal = this.toggleDeleteModal.bind(this);
    this.toggleRemoveFromWSModal = this.toggleRemoveFromWSModal.bind(this);
  }

  focus() {
    let sidebar = Object(react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"])(this.refs.sidebar);
    sidebar && sidebar.focus();
  }

  getKeyMapHandlers() {
    return {
      nextItem: pm.shortcuts.handle('nextItem', this.focusNext),
      prevItem: pm.shortcuts.handle('prevItem', this.focusPrev),
      select: pm.shortcuts.handle('select', this.selectItem),
      delete: pm.shortcuts.handle('delete', this.handleDeleteShortcut),
      rename: pm.shortcuts.handle('rename', this.renameItem) };

  }

  focusNext(e) {
    e && e.preventDefault();
    this.apiSidebarStore.focusNext();
  }

  focusPrev(e) {
    e && e.preventDefault();
    this.apiSidebarStore.focusPrev();
  }

  selectItem() {
    this.apiSidebarStore.openEditor(this.apiSidebarStore.activeItem);
  }

  renameItem() {
    let apiId = this.apiSidebarStore.activeItem;
    apiId && this.refs.list.refs[apiId].handleEditName();
  }

  deleteItem() {
    _.invoke(this.refs, 'list.handleDelete', this.state.apiToDelete);
  }

  removeItem() {
    _.invoke(this.refs, 'list.handleRemoveFromWS', this.state.apiToRemove);
  }

  handleDeleteShortcut() {
    let id = this.apiSidebarStore.activeItem,
    name = id && _.find(this.apiSidebarStore.sortedAPIs, api => api.id === id).name;

    id && name && this.toggleDeleteModal(id, name);
  }

  toggleDeleteModal(apiId, apiName) {
    this.setState({
      openDeleteModal: !this.state.openDeleteModal,
      apiToDelete: {
        id: apiId,
        name: apiName } },

    () => {
      this.state.openDeleteModal && _.invoke(this, 'deleteKeymapRef.focus');
    });
  }

  toggleRemoveFromWSModal(apiId, apiName) {
    this.setState({
      openRemoveFromWSModal: !this.state.openRemoveFromWSModal,
      apiToRemove: {
        id: apiId,
        name: apiName } },

    () => {
      this.state.openRemoveFromWSModal && _.invoke(this, 'removeFromWSKeymapRef.focus');
    });
  }

  render() {
    this.apiSidebarStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('APISidebarStore');
    this.apiListStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('APIListStore');

    let searchQuery = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('RequesterSidebarStore').searchQuery;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_3__["default"], { handlers: this.getKeyMapHandlers() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar', ref: 'sidebar' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarMenu_APISidebarMenu__WEBPACK_IMPORTED_MODULE_4__["default"], {
            ref: 'menu',
            apiListStore: this.apiListStore }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarList_APISidebarList__WEBPACK_IMPORTED_MODULE_5__["default"], {
            ref: 'list',
            apiListStore: this.apiListStore,
            apiSidebarStore: this.apiSidebarStore,
            searchQuery: searchQuery,

            toggleDeleteModal: this.toggleDeleteModal,
            toggleRemoveFromWSModal: this.toggleRemoveFromWSModal }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_DeleteModal_DeleteModal__WEBPACK_IMPORTED_MODULE_6__["default"], {
            keymapRef: ref => this.deleteKeymapRef = ref,

            headerTitle: 'Delete API?',
            content: 'This will delete the API from all workspaces – no one on your team will be able to access it.\nThis won\'t affect the mock servers, documentation, environments, and test suites linked to this API.',
            btnContent: 'Delete API',
            isOpen: this.state.openDeleteModal,
            isLoading: this.apiListStore.isDeleting,

            onSubmit: this.deleteItem,
            onRequestClose: this.toggleDeleteModal }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_editor_common_RemoveFromWorkspaceModal_RemoveFromWorkspaceModal__WEBPACK_IMPORTED_MODULE_7__["default"], {
            keymapRef: ref => this.removeFromWSKeymapRef = ref,

            headerTitle: 'Remove API?',
            content: 'Are you sure you want to remove this API from this workspace?\nThe mock servers, documentation, environments, test suites and monitors linked to this API won\'t be affected.',
            btnContent: 'Remove API',
            isOpen: this.state.openRemoveFromWSModal,
            isLoading: this.apiListStore.isRemovingFromWorkspace,

            onSubmit: this.removeItem,
            onRequestClose: this.toggleRemoveFromWSModal }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4887:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1768);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1808);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(748);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1789);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__);
var _class;









let


APISidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      refreshDisabled: false,
      isCreateAPIModalOpen: false };


    this.refresh = this.refresh.bind(this);
    this.getAddIconText = this.getAddIconText.bind(this);
    this.getRefreshIconClass = this.getRefreshIconClass.bind(this);
    this.getRefreshIconText = this.getRefreshIconText.bind(this);
    this.openCreateAPIModal = this.openCreateAPIModal.bind(this);
  }

  openCreateAPIModal() {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'api',
      action: 'start_create_flow',
      label: 'sidebar',
      value: 1 });


    pm.mediator.trigger('showCreateAPIModal');
  }

  refresh() {
    this.props.apiListStore.reload();
    this.setState({ refreshDisabled: true });
    this.enableRefreshTimeout = setTimeout(() => {
      this.setState({ refreshDisabled: false });
    }, 2000);
  }

  getRefreshIconClass(isEnabled) {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'pm-icon': true,
      'pm-icon-normal': true,
      'api-sidebar-menu__actions-refresh-api': isEnabled,
      'api-sidebar-menu__actions-refresh-loading': this.props.apiListStore.isHydrating });

  }

  getAddIconText(isLoggedOut, isOffline) {
    if (isLoggedOut) {
      return 'Sign in to create an API';
    }

    if (isOffline) {
      return 'Get online to create an API';
    }

    return 'Create new API';
  }

  getRefreshIconText() {
    if (this.state.refreshDisabled) {
      return 'Please wait...';
    }

    return 'Refresh';
  }

  componentWillUnmount() {
    clearTimeout(this.enableRefreshTimeout);
  }

  render() {
    let isLoggedIn = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore').isLoggedIn,
    isOnline = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('SyncStatusStore').isSocketConnected,
    canAddAPI = isLoggedIn && isOnline && !this.props.apiListStore.isCreating,
    canRefresh = canAddAPI && !this.state.refreshDisabled && !this.props.apiListStore.isHydrating;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-menu' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-menu__left' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_7__["default"], { identifier: 'newAPIButton' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
                className: 'api-sidebar-menu__actions-new-api-wrapper',
                onClick: this.openCreateAPIModal,
                tooltip: this.getAddIconText(!isLoggedIn, !isOnline),
                disabled: !canAddAPI,
                type: 'text' },


              this.props.apiListStore.isCreating ?
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_5__["default"], { className: 'api-sidebar-menu__actions-new-api-loader' }) :
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { size: 'small', name: 'icon-action-add-stroke', className: 'api-sidebar-menu__actions-new-api pm-icon pm-icon-normal' }), 'New API'))),





        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-menu__right' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
              className: 'api-sidebar-menu__actions-refresh-wrapper',
              onClick: this.refresh,
              tooltip: this.getRefreshIconText(),
              disabled: !canRefresh },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_8__["Icon"], { name: 'icon-action-refresh-stroke', className: this.getRefreshIconClass(canRefresh) })))));




  }}) || _class;

/***/ }),

/***/ 4888:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3929);
/* harmony import */ var _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3930);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1789);
/* harmony import */ var _APISidebarListItem_APISidebarListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4889);
/* harmony import */ var _APISidebarEmptyShell_APISidebarEmptyShell__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4891);
/* harmony import */ var _APISidebarListEmptyItem_APISidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4892);
var _class;








let


APISidebarList = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleRename = this.handleRename.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleRemoveFromWS = this.handleRemoveFromWS.bind(this);
  }

  handleSelect(apiId) {
    if (!apiId) {
      return;
    }

    // set focus and open in editor
    this.props.apiSidebarStore.openEditor(apiId);
  }

  handleDelete(api) {
    if (!api) {
      return;
    }

    let { apiSidebarStore } = this.props;

    this.props.apiListStore.delete(api.id, api.name).
    then(() => {

      // Switch focus if selected item got deleted
      if (api.id === apiSidebarStore.activeItem) {
        apiSidebarStore.focusPrev({ openEditor: false });
      }

      this.props.toggleDeleteModal();
    });
  }

  handleRemoveFromWS(api) {
    if (!api) {
      return;
    }

    let { apiSidebarStore } = this.props;

    this.props.apiListStore.removeFromWorkspace(api.id, api.name).
    then(() => {

      // Switch focus if selected item got removed
      if (api.id === apiSidebarStore.activeItem) {
        apiSidebarStore.focusPrev({ openEditor: false });
      }

      this.props.toggleRemoveFromWSModal();
    });
  }

  handleRename(apiId, oldName, newName) {
    this.props.apiListStore.rename(apiId, newName).
    catch(() => _.invoke(this.refs, `${apiId}.inlineInput.setState`, { value: oldName }));
  }

  renderEmptyList() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-list is-empty' },

        this.props.apiListStore.isHydrating ?
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarEmptyShell_APISidebarEmptyShell__WEBPACK_IMPORTED_MODULE_6__["default"], null) :
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarListEmptyItem_APISidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_7__["default"], {
          query: this.props.searchQuery,
          apiListStore: this.props.apiListStore })));




  }

  render() {
    let apiSidebarStore = this.props.apiSidebarStore,
    sortedApis = apiSidebarStore.sortedAPIs;

    if (_.isEmpty(sortedApis)) {
      return this.renderEmptyList();
    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-list' },

        _.map(sortedApis, apiItem => {
          return (
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: apiItem.id, key: apiItem.id },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarListItem_APISidebarListItem__WEBPACK_IMPORTED_MODULE_5__["default"], {
                ref: apiItem.id,
                key: apiItem.id,
                id: apiItem.id,

                name: apiItem.name,
                editable: apiItem.isEditable,
                shared: Boolean(apiItem.team),
                selected: apiSidebarStore.activeItem === apiItem.id,

                onSelect: this.handleSelect,
                onRename: this.handleRename,
                onDelete: this.props.toggleDeleteModal,
                onShare: _js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_2__["shareAPI"],
                onManageRole: _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_3__["manageRolesOnAPI"],
                onRemoveFromWorkspace: this.props.toggleRemoveFromWSModal })));



        })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4889:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _APIItemActionsDropdown_APIItemActionsDropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4890);
/* harmony import */ var _js_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1881);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3938);
/* harmony import */ var _js_services_UIEventService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1755);
/* harmony import */ var _js_services_EditorService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1545);
/* harmony import */ var _js_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1756);
var _class;











let


APISidebarListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      dropdownOpen: false };


    this.handleEditName = this.handleEditName.bind(this);
    this.handleToggleEditName = this.handleToggleEditName.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleRenameSubmit = this.handleRenameSubmit.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.openAPIInNewTab = this.openAPIInNewTab.bind(this);
  }

  componentDidMount() {
    this.unsubscribeHandler = _js_services_UIEventService__WEBPACK_IMPORTED_MODULE_8__["default"].subscribe(_js_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_10__["SAMPLE_API_IMPORT"], api => {

      // id of the imported sample API in lessons
      const apiId = _.get(api, 'data.id');

      this.openAPIInNewTab(apiId);
    });
  }

  componentWillUnmount() {
    this.unsubscribeHandler && this.unsubscribeHandler();
  }

  openAPIInNewTab(apiId) {
    _js_services_EditorService__WEBPACK_IMPORTED_MODULE_9__["default"].open(`customview://api?id=${apiId}`, {
      preview: false },
    {
      isNew: true });

  }

  componentDidUpdate(prevProps) {
    if (!prevProps.selected && this.props.selected) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_3__["findDOMNode"])(this.refs.listItem);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  handleDropdownActionSelect(action) {
    switch (action) {

      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SHARE"]:
        this.props.onShare(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_MANAGE_ROLES"]:
        this.props.onManageRole(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE"]:
        this.props.onDelete(this.props.id, this.props.name);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"]:
        this.props.onRemoveFromWorkspace(this.props.id, this.props.name);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_RENAME"]:
        this.handleEditName();
        return;}

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleEditName() {
    _.invoke(this.refs.inlineInput, 'toggleEdit');
  }

  handleToggleEditName(isEditing) {
    if (!isEditing) {
      pm.mediator.trigger('focusSidebar');
    }

    if (isEditing && this.refs.inlineInput) {
      this.refs.inlineInput.focus();
      this.refs.inlineInput.selectAll();
    }
  }

  handleRenameSubmit(newName) {
    this.props.onRename(this.props.id, this.props.name, newName);
  }

  getApiItemClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'api-sidebar-list-item': true,
      'is-focused': this.props.selected,
      'is-hovered': this.state.dropdownOpen });

  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
          className: this.getApiItemClasses(),
          onClick: () => this.props.onSelect(this.props.id, this.props.name),
          ref: 'listItem' },

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-list-item__icon' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], { size: 'large', name: 'icon-entity-api-stroke', className: 'pm-icon pm-icon-normal' })),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-list-item__meta' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_InlineInput__WEBPACK_IMPORTED_MODULE_5__["default"], {
            className: 'api-sidebar-list-item__meta-name',
            ref: 'inlineInput',
            placeholder: 'API Name',
            value: this.props.name,
            onSubmit: this.handleRenameSubmit,
            onToggleEdit: this.handleToggleEditName }),


          this.props.shared &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
            name: 'icon-descriptive-team-stroke',
            className: 'api-sidebar-list-item__meta-icon pm-icon pm-icon-normal',
            size: 'small',
            title: 'Shared with team' }),



          !this.props.editable &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
            name: 'icon-state-locked-stroke',
            className: 'api-sidebar-list-item__meta-icon pm-icon pm-icon-normal',
            size: 'small',
            title: 'Read only' })),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-list-item__actions' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APIItemActionsDropdown_APIItemActionsDropdown__WEBPACK_IMPORTED_MODULE_4__["default"], {
            onSelect: this.handleDropdownActionSelect,
            onToggle: this.handleDropdownToggle }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4890:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APIItemActionsDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1793);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3938);
/* harmony import */ var _js_constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2467);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
var _class;









let


APIItemActionsDropdown = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APIItemActionsDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
  }

  handleSelect(action) {
    this.props.onSelect && this.props.onSelect(action);
  }

  handleToggle(isOpen) {
    this.props.onToggle && this.props.onToggle(isOpen);
  }

  getDisabledText(isDisabled) {
    if (isDisabled) {
      return 'Get online to perform this action';
    }

    return '';
  }

  getActions() {
    let isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected;

    return [
    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_SHARE"],
      label: 'Share API',
      isDisabled: isOffline,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-action-share-stroke', className: `dropdown-menu-item-icon menu-icon--${_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_SHARE"]} pm-icon pm-icon-normal` }) },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MANAGE_ROLES"],
      label: 'Manage Roles',
      isDisabled: isOffline,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-state-locked-stroke', className: `dropdown-menu-item-icon menu-icon--${_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_MANAGE_ROLES"]} pm-icon pm-icon-normal` }) },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_RENAME"],
      label: 'Rename',
      isDisabled: isOffline,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-action-rename-stroke', className: `dropdown-menu-item-icon menu-icon--${_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_RENAME"]} pm-icon pm-icon-normal` }) },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"],
      label: 'Remove from workspace',
      isDisabled: isOffline,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-action-close-stroke', className: `dropdown-menu-item-icon menu-icon--${_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"]} pm-icon pm-icon-normal` }) },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"],
      label: 'Delete',
      isDisabled: isOffline,
      icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-action-delete-stroke', className: `dropdown-menu-item-icon menu-icon--${_constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_DELETE"]} pm-icon pm-icon-normal` }) }];


  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map(action => {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["MenuItem"], {
            key: action.type,
            refKey: action.type,
            disabled: action.isDisabled,
            disabledText: this.getDisabledText(action.isDisabled) },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'api-action-item' },
            action.icon,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'dropdown-menu-item-label' },
              action.label))));




    }).value();
  }

  render() {
    let menuItems = this.getMenuItems();

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-dropdown-actions-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            ref: 'menu',
            onSelect: this.handleSelect,
            onToggle: this.handleToggle,
            className: 'api-sidebar-actions-dropdown' },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownButton"], {
              dropdownStyle: 'nocaret',
              type: 'custom' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], { tooltip: _js_constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_6__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] }, ' ',
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: 'icon-action-options-stroke', className: 'api-sidebar-item-dropdown-action-button pm-icon pm-icon-normal' }))),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_2__["DropdownMenu"], {
              'align-right': true },

            menuItems))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4891:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const NUMBER_OF_API_ITEMS = 10;

const APISidebarEmptyShell = () => {
  return (
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-empty-shell' },

      _.times(NUMBER_OF_API_ITEMS, index => {
        return (
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              key: index,
              className: 'api-sidebar-empty-shell--section--item' },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-empty-shell--section--item__icon' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
              className: 'api-sidebar-empty-shell--section--item__url',
              style: { 'width': `${Math.floor(Math.random() * 74) + 50}px` } })));



      })));



};

/* harmony default export */ __webpack_exports__["default"] = (APISidebarEmptyShell);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4892:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarListEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(749);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1808);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(748);
/* harmony import */ var _js_modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2690);
/* harmony import */ var _onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2559);
var _class;








let


APISidebarListEmptyItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarListEmptyItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isCreateAPIModalOpen: false };


    this.handleOffline = this.handleOffline.bind(this);
    this.handleLoggedOut = this.handleLoggedOut.bind(this);
    this.getComponent = this.getComponent.bind(this);
    this.openCreateAPIModal = this.openCreateAPIModal.bind(this);
    this.handleStartLesson = this.handleStartLesson.bind(this);
  }

  openCreateAPIModal() {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
      category: 'api',
      action: 'start_create_flow',
      label: 'sidebar',
      value: 1 });


    pm.mediator.trigger('showCreateAPIModal');
  }

  handleOffline() {
    this.props.apiListStore.reload();
  }

  handleLoggedOut() {
    _js_modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_6__["default"].login();
  }

  /**
     * start Sample API lessons
     * from the empty state of API builder
     */
  handleStartLesson() {
    Object(_onboarding_public_Skills__WEBPACK_IMPORTED_MODULE_7__["runTaggedLesson"])('design-and-develop-APIs', {
      signInModalOptions: {
        type: 'sample-API',
        origin: 'api_sidebar_show_me_how' } });


  }

  getComponent(title, description, buttonText, handler) {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__title' },
          title),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__subtitle' },
          description),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'entity-empty__create-new' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: 'secondary',
              onClick: handler,
              disabled: this.props.apiListStore.isCreating },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, this.props.apiListStore.isCreating ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], null) : buttonText)))));




  }

  getContent() {
    let isLoggedOut = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore').isLoggedIn,
    isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').isSocketConnected,
    title = '',
    description = '',
    buttonText = '';

    if (isLoggedOut) {
      title = 'Sign in to create APIs';
      description = 'APIs define related collections and environments under a consistent schema.';
      buttonText = 'Sign in to create APIs';

      return this.getComponent(title, description, buttonText, this.handleLoggedOut);
    }

    if (this.props.query && !_.isEmpty(this.props.apiListStore.values)) {
      return `No results found for "${this.props.query}"`;
    }

    if (isOffline) {
      title = 'No internet connection';
      description = 'You need to be online to view your APIs. Check your internet connection and try again.';
      buttonText = 'Try Again';

      return this.getComponent(title, description, buttonText, this.handleOffline);
    }

    title = 'No APIs yet';
    description = 'APIs define related collections and environments under a consistent schema.';
    buttonText = 'Create an API';
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
        this.getComponent(title, description, buttonText, this.openCreateAPIModal),
        this.renderSampleAPISection()));


  }

  renderSampleAPISection() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-empty__down' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-empty__down-section' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-container' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-section' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-img' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-img__content' })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-txt' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-txt__header' }, 'New to APIs in Postman?'),


                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-txt__summary' }, 'Take a tour and see all that you can do within the API Builder.'))),




            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'lesson-start' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
                  className: 'lesson-start__btn',
                  type: 'text',
                  onClick: this.handleStartLesson }, 'Start'))))));








  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'api-sidebar-list-empty-item' },
        this.getContent()));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4893:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "promisifyIdleCallback", function() { return promisifyIdleCallback; });
/**
 *
 */
function promisifyIdleCallback(time) {
  return new Promise((resolve, reject) => {
    requestIdleCallback(() => {resolve();});
  });
}

/***/ }),

/***/ 4894:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterBottomPaneContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_find_replace__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4895);
/* harmony import */ var _runtime_components_console_Console__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4555);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(749);
/* harmony import */ var _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1540);
var _class;






let


RequesterBottomPaneContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class RequesterBottomPaneContainer extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('RequesterBottomPaneUIStore');
  }

  getTabClassName(tab, activeTab) {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      [`bottom-pane-tab-content--${tab}`]: tab,
      'is-hidden': activeTab !== tab });

  }

  handleOpenTab(tab) {
    this.store.openTab(tab);
  }

  handleCloseTab() {
    this.store.setIsOpen(false);
  }

  render() {
    const activeTab = this.store.activeTab;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'bottom-pane-container' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'bottom-pane-tab-content' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getTabClassName(_constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_6__["REQUESTER_BOTTOM_PANE_CONSOLE"], activeTab) },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_console_Console__WEBPACK_IMPORTED_MODULE_4__["default"], null)),


          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getTabClassName(_constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_6__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"], activeTab) },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_find_replace__WEBPACK_IMPORTED_MODULE_3__["default"], {
              isOpen: this.store.isOpen && activeTab === _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_6__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"],
              onOpen: this.handleOpenTab.bind(this, _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_6__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"]),
              onClose: this.handleCloseTab.bind(this) }))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'bottom-pane-status-bar' })));













  }}) || _class;

/***/ }),

/***/ 4895:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplace; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _FindReplaceOptionSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4896);
/* harmony import */ var _FindReplaceResultsSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4899);
/* harmony import */ var _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(781);
/* harmony import */ var _base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1794);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(749);
/* harmony import */ var _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1244);
/* harmony import */ var _runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1246);
/* harmony import */ var _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(763);
/* harmony import */ var _utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(764);
/* harmony import */ var _ReplaceService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4905);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;












var WebpackWorker = __webpack_require__(4906);let


FindReplace = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class FindReplace extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      searchedQuery: '',
      searchedResult: [],
      isLoading: false,
      selectedCount: 0,
      findReplaceOptions: {
        isRegex: false,
        ignoreCase: true,
        findQuery: '',
        searchTarget: 'all',
        subSearchTarget: {
          collections: false,
          environments: false,
          globals: false,
          tabs: false },

        selectedTarget: {
          collections: {
            show: false,
            items: [] },

          environments: {
            show: false,
            items: [] } },


        replaceString: '',
        isSelectedAll: false } };


    this.handleFind = this.handleFind.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleReplace = this.handleReplace.bind(this);
    this.handleOptionsChange = this.handleOptionsChange.bind(this);
    this.handleFindSelectedText = this.handleFindSelectedText.bind(this);
    pm.mediator.on('findSelectedText', this.handleFindSelectedText);
  }

  handleFindSelectedText(text) {
    this.setState({
      findReplaceOptions: _extends({},
      this.state.findReplaceOptions, {
        findQuery: text }) },

    () => {
      this.handleFind();
      this.props.onOpen();
    });
  }

  getKeyMapHandlers() {
    return { quit: pm.shortcuts.handle('quit', this.handleClose) };
  }

  handleClose() {
    pm.mediator.trigger('focusBuilder');
    this.props.onClose();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.isOpen && nextProps.isOpen !== this.props.isOpen) {
      this.refs.findReplaceOptionSection.focus();
    }
  }

  async getTargetCollections(findOptions) {
    let criteria = {};
    if (findOptions.searchTarget === 'some') {
      criteria = { id: _.get(findOptions.selectedTarget, 'collections.items') };
    } else
    {
      criteria = { id: _.map(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').collections, 'id') };
    }

    let collectionList = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_3__["default"].getCollections(criteria),
    collections = await Promise.all(_.map(collectionList, async col => {
      let collection = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_3__["default"].getCollection({ id: col.id }, { populate: true }),
      sessionVariable = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_9__["default"].get({
        id: Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__["getSessionId"])('collection', col.id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id) });


      if (sessionVariable && sessionVariable.values) {
        collection.variables = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__["zipVariables"])(collection.variables, sessionVariable.values);
      }
      return collection;
    }));

    return collections;
  }

  async getTargetEnvironments(findOptions) {
    let criteria = {};
    if (findOptions.searchTarget === 'some') {
      criteria = { id: _.get(findOptions.selectedTarget, 'environments.items') };
    } else {
      criteria = { id: _.map(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').environments, 'id') };
    }

    let environmentList = await _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_7__["default"].getAll(criteria),
    environments = await Promise.all(_.map(environmentList, async env => {
      let environment = await _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_7__["default"].get({ id: env.id }),
      sessionVariable = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_9__["default"].get({
        id: Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__["getSessionId"])('environment', env.id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id) });


      if (sessionVariable && sessionVariable.values) {
        environment.values = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__["zipVariables"])(environment.values, sessionVariable.values);
      }
      return environment;
    }));

    return environments;
  }

  async getTargetGlobals(findOptions) {
    if (findOptions.searchTarget === 'some' && !findOptions.subSearchTarget.globals) {
      return [];
    }
    let workspaceGlobals = await _runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_8__["default"].get({ workspace: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveGlobalsStore').workspace }),
    sessionVariable = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_9__["default"].get({
      id: Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__["getSessionId"])('globals', workspaceGlobals.id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id) });


    if (sessionVariable && sessionVariable.values) {
      workspaceGlobals.values = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_10__["zipVariables"])(workspaceGlobals.values, sessionVariable.values);
    }
    return workspaceGlobals;
  }

  async getTargetTabs(findOptions) {
    const allowedTabs = ['request', 'response'];
    if (findOptions.searchTarget === 'some' && !findOptions.subSearchTarget.tabs) {
      return [];
    }
    let tabs = _.chain(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceSessionStore').visibleEditors).
    map(id => {
      let editorModel = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('EditorStore').find(id).model;
      return {
        id,
        type: editorModel.info.model,
        data: editorModel.resourceToSave && editorModel.resourceToSave(),
        name: editorModel.name };

    }).
    filter(tab => {
      return _.includes(allowedTabs, tab.type);
    }).
    value();

    return tabs;
  }

  async handleFind() {
    var myWorker = new WebpackWorker(),
    findReplaceOptions = this.state.findReplaceOptions;

    if (!findReplaceOptions.findQuery) {
      this.setState({
        searchedQuery: '',
        searchedResult: [],
        isLoading: false,
        selectedCount: 0 });

      return;
    }
    myWorker.onerror = error => {
      this.setState({ isLoading: false });
      pm.logger.error('worker error', {
        filename: error.filename,
        message: error.message,
        lineno: error.lineno,
        colno: error.colno,
        isTrusted: error.isTrusted });

      myWorker.terminate();
    };

    let [
    collections,
    environments,
    globals,
    tabs] =
    await Promise.all([
    this.getTargetCollections(findReplaceOptions),
    this.getTargetEnvironments(findReplaceOptions),
    this.getTargetGlobals(findReplaceOptions),
    this.getTargetTabs(findReplaceOptions)]);


    myWorker.postMessage(JSON.stringify({
      type: 'find',
      userId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore').id,
      findOptions: _.pick(findReplaceOptions, ['findQuery', 'isRegex', 'ignoreCase']),
      searchTargets: {
        collections,
        environments,
        globals,
        tabs } }));



    myWorker.onmessage = e => {
      this.setState({
        searchedResult: _.get(e.data, 'result'),
        searchedQuery: _.get(e.data, 'findQuery'),
        isLoading: false,
        selectedCount: 0,
        findReplaceOptions: _extends({},
        this.state.findReplaceOptions, {
          isSelectedAll: false }) });


      myWorker.terminate();
    };

    this.setState({ isLoading: true });
  }

  handleChange(searchedResult) {
    let selectedCount = 0;
    _.forOwn(searchedResult, (targets, key) => {
      _.forEach(targets, target => {
        _.forEach(target.entities, entity => {
          _.forEach(entity.fields, field => {
            selectedCount += _.size(_.filter(field.instances, 'isSelected'));
          });
        });
      });
    });
    this.setState({
      searchedResult,
      selectedCount });

  }

  handleReplace(replaceString) {
    this.setState({ isLoading: true });
    _ReplaceService__WEBPACK_IMPORTED_MODULE_11__["default"].replace(this.state.searchedResult, replaceString).then(actions => {
      return Promise.all(actions).then(() => {
        this.handleFind();
      });
    }).catch(e => {
      this.handleFind();
      pm.logger.error(e);
    });
  }

  handleOptionsChange(option, cb) {
    this.setState({
      findReplaceOptions: _extends({},
      this.state.findReplaceOptions,
      option) },

    cb);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_4__["default"], { keyMap: pm.shortcuts.getShortcuts(), handlers: this.getKeyMapHandlers() },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceOptionSection__WEBPACK_IMPORTED_MODULE_1__["default"], {
            ref: 'findReplaceOptionSection',
            onFind: this.handleFind,
            workspaceId: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id,
            userCollections: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').collections,
            userEnvironments: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').environments,
            searchedResult: this.state.searchedResult,
            onClose: this.handleClose,
            onReplace: this.handleReplace,
            onSelectAll: this.handleChange,
            selectedCount: this.state.selectedCount,
            options: this.state.findReplaceOptions,
            onOptionsChange: this.handleOptionsChange }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceResultsSection__WEBPACK_IMPORTED_MODULE_2__["default"], {
            isLoading: this.state.isLoading,
            searchedResult: this.state.searchedResult,
            searchedQuery: this.state.searchedQuery,
            onChange: this.handleChange }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4896:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplaceOptionSection; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1882);
/* harmony import */ var _base_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2120);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1768);
/* harmony import */ var _base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1803);
/* harmony import */ var react_radio_group__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2687);
/* harmony import */ var react_radio_group__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_radio_group__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _FindReplaceSearchTargetSelector__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4897);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(748);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1763);
/* harmony import */ var _constants_FindReplaceConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4898);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;










let


FindReplaceOptionSection = Object(mobx_react__WEBPACK_IMPORTED_MODULE_10__["observer"])(_class = class FindReplaceOptionSection extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { uniqueName: Math.random().toString(36).substring(7) };
    this.handleRegexChange = this.handleRegexChange.bind(this);
    this.handleCaseChange = this.handleCaseChange.bind(this);
    this.handleFindQueryChange = this.handleFindQueryChange.bind(this);
    this.handleFind = this.handleFind.bind(this);
    this.handleReplace = this.handleReplace.bind(this);
    this.handleTargetSelect = this.handleTargetSelect.bind(this);
    this.handleTargetEntitySelectorClose = this.handleTargetEntitySelectorClose.bind(this);
    this.handleEntitySelect = this.handleEntitySelect.bind(this);
    this.handleSelectAllChange = this.handleSelectAllChange.bind(this);
    this.handleGlobalsToggle = this.handleTargetToggle.bind(this, 'globals');
    this.handleTabsToggle = this.handleTargetToggle.bind(this, 'tabs');
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.userCollections !== nextProps.userCollections || this.props.userEnvironments !== nextProps.userEnvironments) {
      let collectionIds = _.map(nextProps.userCollections, 'id'),
      environmentIds = _.map(nextProps.userEnvironments, 'id');
      this.props.onOptionsChange({
        selectedTarget: {
          environments: _extends({},
          this.props.options.selectedTarget.environments, {
            items: _.intersection(environmentIds, this.props.options.selectedTarget.environments.items) }),

          collections: _extends({},
          this.props.options.selectedTarget.collections, {
            items: _.intersection(collectionIds, this.props.options.selectedTarget.collections.items) }) } });



    }
  }

  handleRegexChange(value) {
    this.props.onOptionsChange({ isRegex: value });
  }

  handleCaseChange(value) {
    this.props.onOptionsChange({ ignoreCase: value });
  }

  handleFindQueryChange(value) {
    this.props.onOptionsChange({ findQuery: value });
  }

  handleFind() {
    if (this.isFindDisabled()) {
      return;
    }

    this.props.onFind();
    this.handleFindAnalytics();
  }

  handleReplace() {
    if (this.isReplaceDisabled()) {
      return;
    }
    this.props.onReplace(this.props.options.replaceString);
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEvent('bottombar', 'replace');
  }

  handleFindAnalytics() {
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEvent('bottombar', 'find', `${this.props.options.searchTarget === 'all' ? 'everything' : 'selective'}`);

    if (this.props.options.searchTarget === 'some') {
      for (var key in this.props.options.selectedTarget) {
        if (this.props.options.subSearchTarget[key]) {
          _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEvent('bottombar', 'find_choose_entities', key, _.size(this.props.options.selectedTarget[key].items));
        }
      }

      if (this.props.options.subSearchTarget.globals) {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEvent('bottombar', 'find_choose_entities', 'globals');
      }

      if (this.props.options.subSearchTarget.tabs) {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEvent('bottombar', 'find_choose_entities', 'tabs');
      }
    }
  }

  focus() {
    setTimeout(() => {
      this.refs.findInput.focus();
    }, 0);
  }

  handleTargetSelect(value, e) {
    setTimeout(() => {
      this.props.onOptionsChange({ searchTarget: value });
    }, 0);
  }

  handleTargetEntitySelectorOpen(entity) {
    if (this.props.options.searchTarget === 'all') {
      return;
    }
    this.props.onOptionsChange({
      'selectedTarget': _extends({},
      this.props.options.selectedTarget, {
        [entity]: _extends({},
        this.props.options.selectedTarget[entity], {
          show: true }) }) });



  }

  handleTargetEntitySelectorClose(entity) {
    this.props.onOptionsChange({
      'selectedTarget': _extends({},
      this.props.options.selectedTarget, {
        [entity]: _extends({},
        this.props.options.selectedTarget[entity], {
          show: false }) }) });



  }

  handleEntitySelect(entity, selectedItems) {
    let collectionState = _.clone(this.props.options.selectedTarget[entity]);
    collectionState.items = selectedItems;
    this.props.onOptionsChange({
      'selectedTarget': _extends({},
      this.props.options.selectedTarget, {
        [entity]: collectionState }),

      'subSearchTarget': _extends({},
      this.props.options.subSearchTarget, {
        [entity]: !_.isEmpty(selectedItems) }) });


  }

  getSelectedTargetCount(type) {
    return _.size(_.get(this.props.options.selectedTarget, `[${type}].items`));
  }

  getEntitiesClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({
      'find-target-option-entities': true,
      'is-disabled': this.props.options.searchTarget === 'all' });

  }

  getReplaceBoxClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_6___default()({
      'replace-box-wrapper': true,
      'is-disabled': _.isEmpty(this.props.searchedResult) });

  }

  isFindDisabled() {
    if (!this.props.options.findQuery) {
      return true;
    }
    if (this.props.options.searchTarget === 'some') {
      if (this.props.options.subSearchTarget.globals || this.props.options.subSearchTarget.tabs) {
        return false;
      }
      return _.every(_.values(this.props.options.selectedTarget), o => {
        return _.isEmpty(o.items);
      });
    }
    return false;
  }

  isReplaceDisabled() {
    if (!this.props.selectedCount || !this.props.options.replaceString) {
      return true;
    }
    return false;
  }

  handleSelectAllChange() {
    this.props.onOptionsChange({ isSelectedAll: !this.props.options.isSelectedAll }, () => {
      this.props.onSelectAll(_.transform(this.props.searchedResult, (result, targets, key) => {
        result[key] = _.map(targets, target => {
          return _extends({},
          target, {
            entities: _.map(target.entities, entity => {
              let canReplace = true;

              // set RBAC permissions for find and replace in 'select all'
              if (!_.includes(_constants_FindReplaceConstants__WEBPACK_IMPORTED_MODULE_11__["OPENTABS"], entity.type)) {
                canReplace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore').can('edit', entity.type, entity.id);
              }
              return _extends({},
              entity, {
                isSelected: canReplace && this.props.options.isSelectedAll,
                fields: _.map(entity.fields, field => {
                  return _extends({},
                  field, {
                    isSelected: canReplace && this.props.options.isSelectedAll,
                    instances: _.map(field.instances, f => {
                      return _extends({},
                      f, {
                        isSelected: canReplace && this.props.options.isSelectedAll });

                    }) });

                }) });

            }) });

        });
      }, {}));
    });
  }

  handleTargetToggle(entity) {
    if (this.props.options.searchTarget === 'all') {
      return;
    }
    this.props.onOptionsChange({
      subSearchTarget: _extends({},
      this.props.options.subSearchTarget, {
        [entity]: !this.props.options.subSearchTarget[entity] }) });


  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-options-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-box-container' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'section-label' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { type: 'heading-h5', value: 'FIND' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-box-wrapper' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-input-wrapper' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                  ref: 'findInput',
                  type: 'text',
                  inputStyle: 'box',
                  onChange: this.handleFindQueryChange,
                  value: this.props.options.findQuery,
                  placeholder: 'Enter text to find...',
                  onSubmit: this.handleFind,
                  onEscape: this.props.onClose }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-input-extra-options' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-input-extra-option-item' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                      checked: this.props.options.isRegex,
                      onChange: this.handleRegexChange }),

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Regex', type: 'body-medium' })),

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-input-extra-option-item' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                      checked: this.props.options.ignoreCase,
                      onChange: this.handleCaseChange }),

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Ignore Case', type: 'body-medium' })))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                  type: 'primary',
                  size: 'small',
                  onClick: this.handleFind,
                  disabled: this.isFindDisabled() },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Find', type: 'button-medium' })))),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-target-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'section-label' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { type: 'heading-h5', value: 'WHERE' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_radio_group__WEBPACK_IMPORTED_MODULE_5__["RadioGroup"], {
                name: this.props.options.uniqueName,
                selectedValue: this.props.options.searchTarget,
                onChange: this.handleTargetSelect,
                className: 'find-target-options-wrapper' },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('label', { className: 'find-target-option-item' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_radio_group__WEBPACK_IMPORTED_MODULE_5__["Radio"], { value: 'all', className: 'radio-button' }),
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { type: 'body-medium', value: 'Everything' })))),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('label', { className: 'find-target-option-item' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_radio_group__WEBPACK_IMPORTED_MODULE_5__["Radio"], { value: 'some', className: 'radio-button' }),
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { type: 'body-medium', value: 'Choose entities to find in' }))))),




            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getEntitiesClasses() },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-target-option-entity collection-entity' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                  checked: this.getSelectedTargetCount('collections') !== 0,
                  disabled: this.props.options.searchTarget === 'all',
                  onChange: this.handleTargetEntitySelectorOpen.bind(this, 'collections') }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                    className: 'entity-wrapper',
                    onClick: this.handleTargetEntitySelectorOpen.bind(this, 'collections') },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, `Collections (${this.getSelectedTargetCount('collections')})`),
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 'xs', className: 'expand-entity' })),


                _.get(this.props.options.selectedTarget, 'collections.show') &&
                this.props.options.searchTarget === 'some' &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceSearchTargetSelector__WEBPACK_IMPORTED_MODULE_7__["default"], {
                  label: 'Collections',
                  selectedItems: this.props.options.selectedTarget.collections.items,
                  items: this.props.userCollections,
                  onClose: this.handleTargetEntitySelectorClose.bind(this, 'collections'),
                  onSelect: this.handleEntitySelect.bind(this, 'collections'),
                  onCancel: this.props.onClose })),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-target-option-entity environment-entity' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                  checked: this.getSelectedTargetCount('environments') !== 0,
                  disabled: this.props.options.searchTarget === 'all',
                  onChange: this.handleTargetEntitySelectorOpen.bind(this, 'environments') }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                    className: 'entity-wrapper',
                    onClick: this.handleTargetEntitySelectorOpen.bind(this, 'environments') },

                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, `Environments (${this.getSelectedTargetCount('environments')})`),
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { size: 'xs', className: 'expand-entity' })),


                _.get(this.props.options.selectedTarget, 'environments.show') &&
                this.props.options.searchTarget === 'some' &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceSearchTargetSelector__WEBPACK_IMPORTED_MODULE_7__["default"], {
                  label: 'Environments',
                  selectedItems: this.props.options.selectedTarget.environments.items,
                  items: this.props.userEnvironments,
                  onClose: this.handleTargetEntitySelectorClose.bind(this, 'environments'),
                  onSelect: this.handleEntitySelect.bind(this, 'environments') })),



              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-target-option-entity' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                  checked: this.props.options.subSearchTarget.globals,
                  disabled: this.props.options.searchTarget === 'all',
                  onChange: this.handleGlobalsToggle }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { onClick: this.handleGlobalsToggle },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Globals', type: 'body-medium' }))),


              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-target-option-entity' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                  checked: this.props.options.subSearchTarget.tabs,
                  disabled: this.props.options.searchTarget === 'all',
                  onChange: this.handleTabsToggle }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { onClick: this.handleTabsToggle },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Open tabs', type: 'body-medium' })))))),





        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getReplaceBoxClasses() },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'section-label' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { type: 'heading-h5', value: 'REPLACE WITH' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'replace-input-wrapper' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'replace-input-option-wrapper' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                type: 'text',
                inputStyle: 'box',
                value: this.props.options.replaceString,
                placeholder: 'Enter text to replace with...',
                onChange: value => {
                  this.props.onOptionsChange({ replaceString: value });
                },
                onSubmit: this.handleReplace }),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'replace-input-extra-options' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                  checked: this.props.options.isSelectedAll,
                  onChange: this.handleSelectAllChange }),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Select all', type: 'body-medium' }))),


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                type: 'primary',
                size: 'small',
                onClick: this.handleReplace,
                disabled: this.isReplaceDisabled() },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: `Replace in ${this.props.selectedCount} selected`, type: 'button-medium' }))))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4897:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplaceSearchTargetSelector; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1882);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _base_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2120);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1883);
/* harmony import */ var _collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3961);
var _class;





let


FindReplaceSearchTargetSelector = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default()(_class = class FindReplaceSearchTargetSelector extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      searchQuery: '' };

    this.handleSelectAllItems = this.handleSelectAllItems.bind(this);
    this.handleQueryChange = this.handleQueryChange.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
  }

  handleSelectAllItems() {

    let selectedItems = _.size(this.props.selectedItems) === _.size(this.props.items) ?
    [] : _.map(this.getFilteredItems(), 'id');
    this.props.onSelect(selectedItems);
  }

  handleClickOutside() {
    this.props.onClose();
  }

  handleSelectItem(id) {
    let selectedItems = [];
    if (_.includes(this.props.selectedItems, id)) {
      selectedItems = _.filter(this.props.selectedItems, itemId => {return itemId !== id;});
    } else
    {
      selectedItems = _.concat(this.props.selectedItems, id);
    }
    this.props.onSelect(selectedItems);
  }

  handleQueryChange(value) {
    this.setState({ searchQuery: value });
  }

  getFilteredItems() {
    return _.filter(this.props.items, item => {
      return _.includes(_.toLower(item.name), _.toLower(this.state.searchQuery));
    });
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-target-selector-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-target-selector-header' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-target-selector-label' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: this.props.label, type: 'label-primary-medium' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__["default"], { onClick: this.props.onClose })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Input"], {
            type: 'text',
            inputStyle: 'search',
            value: this.state.searchQuery,
            placeholder: `Search for ${_.toLower(this.props.label)}`,
            onChange: this.handleQueryChange,
            onCancel: this.props.onCancel }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-target-selector-meta' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'search-target-selector-meta--count' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `All ${_.toLower(this.props.label)} (${_.size(this.props.items)})`, type: 'label-primary-medium' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'search-target-selector-meta--count-selected' },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `${_.size(this.props.selectedItems)} selected`, type: 'label-primary-medium' })),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], { type: 'text', className: 'search-target-selector-meta--action', onClick: this.handleSelectAllItems },
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `${_.size(this.props.selectedItems) === _.size(this.props.items) ? 'Unselect' : 'Select'} all`, type: 'button-medium' }))))),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-target-selector--list' },

          _.map(this.getFilteredItems(), item => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                  key: item.id,
                  className: 'search-target-selector--list-item',
                  onClick: this.handleSelectItem.bind(this, item.id) },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], { checked: _.includes(this.props.selectedItems, item.id) }),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { title: item.name },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: item.name, type: 'body-medium' })),

                item.type === 'collection' && item.forkInfo &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  className: 'search-target-selector--list-item-fork',
                  forkInfo: item.forkInfo })));




          }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4898:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OPENTABS", function() { return OPENTABS; });
const OPENTABS = ['tabRequest', 'tabResponse'];

/***/ }),

/***/ 4899:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplaceResultsSection; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _base_Tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1791);
/* harmony import */ var _base_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2120);
/* harmony import */ var _FindReplaceTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4900);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1799);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1808);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(748);
/* harmony import */ var _constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2110);
/* harmony import */ var _utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4904);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1545);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(615);
/* harmony import */ var _utils_EditorUtils__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_11__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;












const TABS = {
  COLLECTIONS: 'Collections',
  ENVIRONMENTS: 'Environments',
  GLOBALS: 'Globals',
  EDITORS: 'Tabs' };


/**
                      *
                      * @param {Object} data - FindReplaceHelper
                      */
function deNormalizeFilter(data) {
  return _.map(data, (value, key) => {
    return {
      key,
      displayName: value.filterDisplayName };

  });
}

const collectionFields = [{
  type: 'collection',
  displayName: 'Collections',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].collection) },
{
  type: 'folder',
  displayName: 'Folders',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].folder) },
{
  type: 'request',
  displayName: 'Requests',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].request) },
{
  type: 'response',
  displayName: 'Examples',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].response) }];


const environmentFields = [{
  type: 'environment',
  displayName: 'Environments',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].environment) }];


const globalFields = [{
  type: 'globals',
  displayName: 'Globals',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].globals) }];


const tabFields = [{
  type: 'tabRequest',
  displayName: 'Requests',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].tabRequest) },
{
  type: 'tabResponse',
  displayName: 'Examples',
  fields: deNormalizeFilter(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_9__["default"].tabResponse) }];let



FindReplaceResultsSection = pure_render_decorator__WEBPACK_IMPORTED_MODULE_5___default()(_class = class FindReplaceResultsSection extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { activeTab: TABS.EDITORS };
    this.handleTabSelect = this.handleTabSelect.bind(this);
  }

  handleTabSelect(value) {
    this.setState({ activeTab: value });
  }

  getResultCount(arr) {
    if (_.isEmpty(arr)) {
      return 0;
    }
    return _.reduce(arr, (sum, obj) => {
      return sum + obj.occurrences;
    }, 0);
  }

  handleChange(target, items) {
    this.props.onChange(_extends({},
    this.props.searchedResult, {
      [target]: items }));

  }

  render() {
    if (this.props.isLoading) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-results-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_6__["default"], null)));


    }
    if (_.isEmpty(this.props.searchedResult)) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-results-wrapper' },

          this.props.isLoading ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_6__["default"], null) :
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-empty-results-wrapper empty-results' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'find-replace-empty-results-image' }),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-empty-results-text' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: 'Enter the search query in the left to search across collections, environments and globals. When you find something, you\'ll see the search results here.', type: 'body-medium' })))));





    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-results-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-results--tabs' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_2__["Tabs"], {
              type: 'primary',
              defaultActive: TABS.EDITORS,
              activeRef: this.state.activeTab,
              onChange: this.handleTabSelect },

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_2__["Tab"], { refKey: TABS.EDITORS, className: 'find-replace-results--editors' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `Open tabs (${this.getResultCount(this.props.searchedResult.tabs)})`, type: 'body-medium' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_2__["Tab"], { refKey: TABS.COLLECTIONS, className: 'find-replace-results--collections' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `Collections (${this.getResultCount(this.props.searchedResult.collections)})`, type: 'body-medium' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_2__["Tab"], { refKey: TABS.ENVIRONMENTS, className: 'find-replace-results--environments' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `Environments (${this.getResultCount(this.props.searchedResult.environments)})`, type: 'body-medium' })),

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tabs__WEBPACK_IMPORTED_MODULE_2__["Tab"], { refKey: TABS.GLOBALS, className: 'find-replace-results--globals' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `Globals (${this.getResultCount(this.props.searchedResult.globals)})`, type: 'body-medium' })))),




        this.state.activeTab === TABS.EDITORS &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceTab__WEBPACK_IMPORTED_MODULE_4__["default"], {
          type: 'tabs',
          searchedItems: this.props.searchedResult.tabs,
          searchedQuery: this.props.searchedQuery,
          fields: tabFields,
          onChange: this.handleChange.bind(this, 'tabs') }),



        this.state.activeTab === TABS.COLLECTIONS &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceTab__WEBPACK_IMPORTED_MODULE_4__["default"], {
          type: 'collection',
          searchedItems: this.props.searchedResult.collections,
          searchedQuery: this.props.searchedQuery,
          fields: collectionFields,
          onChange: this.handleChange.bind(this, 'collections'),
          renderOpenEntityComponent: entity => {
            let resourceId;
            switch (entity.type) {
              case 'request':
                resourceId = Object(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_11__["requestResourceId"])({ id: entity.id });
                break;
              case 'response':
                resourceId = Object(_utils_EditorUtils__WEBPACK_IMPORTED_MODULE_11__["responseResourceId"])({ id: entity.id });
                break;}

            if (!resourceId) {
              return null;
            }
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  type: 'text',
                  className: 'open-entity entity--request',
                  onClick: () => {
                    if (!(entity && entity.id)) {
                      return;
                    }

                    return _services_EditorService__WEBPACK_IMPORTED_MODULE_10__["default"].open(resourceId, { preview: false }).
                    then(() => {
                      _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('bottombar', 'find_open', 'collections');
                    });
                  } },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: 'Open in builder', type: 'button-small' })));


          } }),



        this.state.activeTab === TABS.ENVIRONMENTS &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceTab__WEBPACK_IMPORTED_MODULE_4__["default"], {
          type: 'environment',
          searchedItems: this.props.searchedResult.environments,
          searchedQuery: this.props.searchedQuery,
          fields: environmentFields,
          onChange: this.handleChange.bind(this, 'environments'),
          renderOpenEntityComponent: entity => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  type: 'text',
                  className: 'open-entity',
                  onClick: () => {
                    pm.mediator.trigger('showManageEnvironmentModal', entity.id);
                    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('bottombar', 'find_open', 'environments');
                  } }, 'Open'));




          } }),



        this.state.activeTab === TABS.GLOBALS &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceTab__WEBPACK_IMPORTED_MODULE_4__["default"], {
          type: 'globals',
          searchedItems: this.props.searchedResult.globals,
          searchedQuery: this.props.searchedQuery,
          fields: globalFields,
          onChange: this.handleChange.bind(this, 'globals'),
          renderOpenEntityComponent: entity => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  type: 'text',
                  className: 'open-entity',
                  onClick: () => {
                    pm.mediator.trigger('showManageEnvironmentModal', _constants_ManageEnvironmentViews__WEBPACK_IMPORTED_MODULE_8__["MANAGE_ENVIRONMENT_VIEW_GLOBALS"]);
                    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('bottombar', 'find_open', 'globals');
                  } }, 'Open'));




          } })));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4900:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplaceCollectionsTab; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _FoundTarget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4901);
/* harmony import */ var _FindReplaceFieldSelector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4902);
/* harmony import */ var _FindReplaceNotFound__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4903);



let

FindReplaceCollectionsTab = class FindReplaceCollectionsTab extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    let defaultFields = this.getDefaultIncudedFields();
    this.state = {
      includedFields: defaultFields,
      fieldCount: _.size(defaultFields) };


    this.handleIncludeFields = this.handleIncludeFields.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  getDefaultIncudedFields() {
    let fields = [];
    _.forEach(this.props.fields, itemField => {
      _.forEach(itemField.fields, f => {
        fields.push(`${itemField.type}-${f.key}`);
      });
    });

    return fields;
  }

  handleIncludeFields(type, property) {
    let str = `${type}-${property}`;
    let includedFields = this.state.includedFields;
    if (_.includes(this.state.includedFields, str)) {
      includedFields = _.filter(this.state.includedFields, field => {return field !== str;});
    } else
    {
      includedFields = _.concat(includedFields, str);
    }
    this.setState({ includedFields });
  }

  renderFoundTargets() {
    return _.reduce(this.props.searchedItems, (acc, item, index) => {
      let filteredEntities = _.filter(item.entities, entity => {
        return !_.isEmpty(
        _.filter(entity.fields, field => {
          return _.includes(this.state.includedFields, `${entity.type}-${field.property}`);
        }));

      });

      if (!_.isEmpty(filteredEntities)) {
        acc.push(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FoundTarget__WEBPACK_IMPORTED_MODULE_1__["default"], {
          key: item.id,
          id: index,
          baseType: this.props.type,
          target: item,
          renderOpenEntityComponent: this.props.renderOpenEntityComponent,
          onChange: this.handleChange,
          includedFields: this.state.includedFields }));


      }

      return acc;
    }, []);
  }

  handleChange(position, object) {
    this.props.onChange(
    _.map(this.props.searchedItems, (item, index) => {
      if (position !== index) {
        return item;
      }
      return object;
    }));

  }

  render() {
    let foundTargets = this.renderFoundTargets();
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-tab-content' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceFieldSelector__WEBPACK_IMPORTED_MODULE_2__["default"], {
          onIncludeFields: this.handleIncludeFields,
          fields: this.props.fields,
          includedFields: this.state.includedFields,
          fieldCount: this.state.fieldCount }),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace--found-results' },

          _.isEmpty(foundTargets) ?
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FindReplaceNotFound__WEBPACK_IMPORTED_MODULE_3__["default"], { searchedQuery: this.props.searchedQuery }) :
          foundTargets)));




  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4901:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FoundTarget; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1769);
/* harmony import */ var _base_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2120);
/* harmony import */ var _base_Icons_CollectionIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1646);
/* harmony import */ var _base_Icons_EnvironmentIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1655);
/* harmony import */ var _base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1803);
/* harmony import */ var _base_Icons_RightSolidIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1804);
/* harmony import */ var _base_Icons_FolderIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2470);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(749);
/* harmony import */ var _collections_CollectionMetaIcons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4749);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1882);
/* harmony import */ var _utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2059);
/* harmony import */ var _constants_FindReplaceConstants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4898);
/* harmony import */ var _collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3961);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};













let

FoundInstance = class FoundInstance extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);
    this.state = { showTooltip: false };
    this.handleShowTooltipToggle = this.handleShowTooltipToggle.bind(this);
    this.handleHideTooltipToggle = this.handleHideTooltipToggle.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleShowTooltipToggle() {
    if (!this.props.instance.tooltipContent) {
      return;
    }

    !this.state.showTooltip && this.setState({ showTooltip: true });
  }

  handleHideTooltipToggle() {
    if (!this.props.instance.tooltipContent) {
      return;
    }

    this.state.showTooltip && this.setState({ showTooltip: false });
  }

  handleChange() {
    this.props.onChange(this.props.id);
  }

  render() {
    let {
      metaString,
      index,
      matchedString,
      tooltipContent,
      isSelected } =
    this.props.instance;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-instance-row' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_11__["Checkbox"], {
          checked: isSelected,
          onChange: this.handleChange,
          disabled: this.props.disabled }),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
            className: this.props.className, ref: 'searchInstance',
            onMouseEnter: this.handleShowTooltipToggle,
            onMouseLeave: this.handleHideTooltipToggle },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: metaString.substring(0, index), type: 'body-medium' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'instance-highlight-text' },
            matchedString),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: metaString.substring(index + matchedString.length, metaString.length), type: 'body-medium' }),

          tooltipContent &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'instance-tooltip', ref: 'instanceTooltip' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_2__["Tooltip"], {
                show: this.state.showTooltip,
                target: this.refs.instanceTooltip,
                placement: 'bottom-left',
                immediate: true },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_2__["TooltipBody"], null,
                tooltipContent))))));







  }};let


FoundFields = class FoundFields extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.handleInstanceChange = this.handleInstanceChange.bind(this);
  }

  handleChange() {
    this.props.onChange(this.props.id, _extends({},
    this.props.field, {
      isSelected: !this.props.field.isSelected,
      instances: _.map(this.props.field.instances, instance => {
        return _extends({},
        instance, {
          isSelected: !this.props.field.isSelected });

      }) }));

  }

  handleInstanceChange(instanceId) {
    this.props.onChange(this.props.id, _extends({},
    this.props.field, {
      isSelected: this.props.field.isSelected && !this.props.field.isSelected,
      instances: _.map(this.props.field.instances, (instance, index) => {
        if (index !== instanceId) {
          return instance;
        }
        return _extends({},
        instance, {
          isSelected: !instance.isSelected });

      }) }));

  }

  render() {
    let { field } = this.props;
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity__field' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity__field-label-row' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_11__["Checkbox"], {
            checked: this.props.field.isSelected,
            onChange: this.handleChange,
            disabled: this.props.disabled }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity__field-label' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: field.label, type: 'body-medium' }))),


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity--instances' },

          _.map(field.instances, (instance, index) => {
            return (
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FoundInstance, {
                key: index,
                id: index,
                className: 'found-in-target-entity--instance',
                instance: instance,
                onChange: this.handleInstanceChange,
                disabled: this.props.disabled }));


          }))));




  }};let


FoundEntity = class FoundEntity extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.handleFieldChange = this.handleFieldChange.bind(this);
  }

  getLabelForEntity(entity) {
    if (!entity) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null);
    }
    const labels = {
      'GET': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'identifier--GET', value: entity }),
      'POST': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'identifier--POST', value: entity }),
      'DELETE': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'identifier--DELETE', value: entity }),
      'PUT': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'identifier--PUT', value: entity }),
      'FOLDER': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_FolderIcon__WEBPACK_IMPORTED_MODULE_8__["default"], { className: 'identifier--FOLDER' }),
      'EXAMPLE': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'identifier--PUT', value: 'EXAMPLE' }) };


    return labels[entity] || react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--default' }, entity);
  }

  handleChange() {
    this.props.onChange(this.props.id, _extends({},
    this.props.entity, {
      isSelected: !this.props.entity.isSelected,
      fields: _.map(this.props.entity.fields, field => {
        return _extends({},
        field, {
          isSelected: !this.props.entity.isSelected,
          instances: _.map(field.instances, instance => {
            return _extends({},
            instance, {
              isSelected: !this.props.entity.isSelected });

          }) });

      }) }));

  }

  handleFieldChange(fieldId, changedField) {
    this.props.onChange(this.props.id, _extends({},
    this.props.entity, {
      isSelected: this.props.entity.isSelected && !this.props.entity.isSelected,
      fields: _.map(this.props.entity.fields, (field, index) => {
        if (index !== fieldId) {
          return field;
        }
        return changedField;
      }) }));

  }

  renderFoundFields() {
    return _.reduce(this.props.entity.fields, (acc, field, index) => {
      if (_.includes(this.props.includedFields, `${this.props.entity.type}-${field.property}`)) {
        acc.push(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FoundFields, {
          key: index,
          id: index,
          field: field,
          onChange: this.handleFieldChange,
          disabled: this.props.disabled }));


      }
      return acc;
    }, []);
  }

  render() {
    let { entity } = this.props;

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity__path-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_11__["Checkbox"], {
            checked: this.props.entity.isSelected,
            onChange: this.handleChange,
            disabled: this.props.disabled }),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'found-in-target-entity__path' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'entity-breadcrumb' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'path-prefix', value: entity.path }),
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'entity-name-wrapper' },
                entity.path ? '  >  ' : '',
                this.getLabelForEntity(entity.label),
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { className: 'entity-name', value: entity.name }))))),





        _.invoke(this.props, 'renderOpenEntityComponent', entity),


        this.renderFoundFields()));



  }};let


FoundTarget = class FoundTarget extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);
    this.state = { show: true };
    this.toggleShow = this.toggleShow.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  getClassNames() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'found-in-target': true,
      'empty-name': !_.get(this.props.target, 'targetName') });

  }

  toggleShow() {
    this.setState({ show: !this.state.show });
  }

  getBaseIcon(type) {
    const labels = {
      'collection': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CollectionIcon__WEBPACK_IMPORTED_MODULE_4__["default"], { className: 'target-collection' }),
      'environment': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_EnvironmentIcon__WEBPACK_IMPORTED_MODULE_5__["default"], { className: 'target-environment' }),
      'GET': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--GET' }, type),
      'POST': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--POST' }, type),
      'DELETE': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--DELETE' }, type),
      'PUT': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--PUT' }, type),
      'FOLDER': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_FolderIcon__WEBPACK_IMPORTED_MODULE_8__["default"], { className: 'identifier--FOLDER' }),
      'EXAMPLE': react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--PUT' }, 'EXAMPLE') };


    return labels[type] || react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'identifier--default' }, type);
  }

  handleChange(entityId, changedEntity) {
    this.props.onChange(this.props.id, _extends({},
    this.props.target, {
      entities: _.map(this.props.target.entities, (entity, index) => {
        if (entityId !== index) {
          return entity;
        }
        return changedEntity;
      }) }));

  }

  renderFoundEntities() {
    let canReplace = true;

    return _.reduce(this.props.target.entities, (acc, entity, index) => {
      let filteredFields = _.filter(entity.fields, field => {
        return _.includes(this.props.includedFields, `${entity.type}-${field.property}`);
      });

      // set permissions for find and replace in collection,environment and globals
      if (!_.includes(_constants_FindReplaceConstants__WEBPACK_IMPORTED_MODULE_13__["OPENTABS"], entity.type)) {
        canReplace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore').can('edit', entity.type, entity.id);
      }

      if (!_.isEmpty(filteredFields)) {
        acc.push(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FoundEntity, {
          key: index,
          id: index,
          baseType: this.props.baseType,
          entity: entity,
          renderOpenEntityComponent: this.props.renderOpenEntityComponent,
          onChange: this.handleChange,
          includedFields: this.props.includedFields,
          disabled: !canReplace }));


      }

      return acc;
    }, []);
  }

  render() {
    let { target } = this.props;
    let collection = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CollectionStore').find(target.id);
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getClassNames() },

        target.targetName &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'found-in-target--header', onClick: this.toggleShow },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'found-in-target--name-wrapper' },
            this.state.show ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_6__["default"], { className: 'arrow' }) : react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_RightSolidIcon__WEBPACK_IMPORTED_MODULE_7__["default"], { className: 'arrow' }),
            this.getBaseIcon(target.type),
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'found-in-target--name', title: target.targetName },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: target.targetName, type: 'label-primary-medium' })),


            this.props.baseType === 'collection' && collection &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collections_CollectionMetaIcons__WEBPACK_IMPORTED_MODULE_10__["default"], { collection: collection }),

            this.props.baseType === 'collection' && collection &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collections_CollectionForkLabel__WEBPACK_IMPORTED_MODULE_14__["default"], {
              className: 'found-in-target__fork',
              forkInfo: collection.forkInfo })),



          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'found-in-target--count' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value:
              ` (${target.occurrences} ${_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_12__["default"].pluralize({
                count: target.occurrences,
                singular: 'result',
                plural: 'results' })
              })`,

              type: 'body-medium' }))),





        this.state.show && this.renderFoundEntities()));



  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4902:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplaceFieldSelector; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Inputs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1882);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1768);
/* harmony import */ var _base_Text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2120);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1770);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1803);
var _class;




let


FindReplaceFieldSelector = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default()(_class = class FindReplaceFieldSelector extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { show: false };
    this.handleToggleSelector = this.handleToggleSelector.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
  }

  handleToggleSelector() {
    this.setState({ show: !this.state.show });
  }

  handleFieldSelect(type, property) {
    this.props.onIncludeFields(type, property);
  }

  handleClickOutside() {
    this.state.show && this.setState({ show: false });
  }

  getFieldLabelText() {
    return _.size(this.props.includedFields) == this.props.fieldCount ? 'ALL' : _.size(this.props.includedFields);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace--field-selector' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: 'text',
            className: 'find-replace--field-selector-button',
            onClick: this.handleToggleSelector },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: `FILTER (${this.getFieldLabelText()} FIELDS)`, type: 'button-medium' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_DownSolidIcon__WEBPACK_IMPORTED_MODULE_5__["default"], { className: 'find-replace--field-selector-expand' })),


        this.state.show &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-field-selector-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-field-selector--head' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: 'INCLUDE FIELDS', type: 'heading-h6' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-field-selector--list' },

            _.map(this.props.fields, (fieldType, index) => {
              return (
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { key: index, className: 'search-field-selector--section' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'search-field-selector--section-label' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: fieldType.displayName, type: 'label-primary-medium' })),


                  _.map(fieldType.fields, (field, index) => {
                    return (
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { key: index, className: 'search-field-selector--section-item' },
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Inputs__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], { checked: _.includes(this.props.includedFields, `${fieldType.type}-${field.key}`), onChange: this.handleFieldSelect.bind(this, fieldType.type, field.key) }),
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_3__["default"], { value: field.displayName, type: 'body-medium' })));


                  })));



            })))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4903:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return FindReplaceNotFound; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var _base_Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2120);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);



let

FindReplaceNotFound = class FindReplaceNotFound extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-results-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-empty-results-wrapper' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'find-replace-empty-results-image' }),
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'find-replace-empty-results-header' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: `Nothing found for "${this.props.searchedQuery}"`, type: 'heading-h4' })),

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Text__WEBPACK_IMPORTED_MODULE_2__["default"], { value: 'Try another search, or modify the entities to find in.', type: 'body-medium' })))));




  }};

/***/ }),

/***/ 4904:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _utils_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(784);
/* harmony import */ var _constants_AuthConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1729);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const limit = 25;

/**
                   * Instances of the searched string in a given entity property
                   *
                   * @typedef {Object} foundInstance
                   * @property {number} actualIndex - Start index of the found result in actual string
                   * @property {number} index - Start index of the found result in meta string
                   * @property {string} matchedString - String which matched the given Regex
                   * @property {string} metaString - A section of the string that contains the found result
                   */


/**
                       * Entity properties in which we found the searched string
                       *
                       * @typedef {Object} foundFields
                       * @property {string} label Label to be displayed in results
                       * @property {string} property Property or path to reach the property
                       * @property {foundInstance[]} instances Array of found instances
                       */

/**
                           *
                           * @param {Object} options
                           * @param {string} options.text - string in which you want to find
                           * @param {regex} options.regex
                           * @param {string} [options.meta] - optional properties
                           *
                           * @returns {foundInstance[]}
                           */
function find({ text, regex, meta = {} }) {
  let arr,
  result = [];
  text = text || '';
  while ((arr = regex.exec(text)) !== null) {
    let delta = Math.floor(arr.index / limit),
    matchedString = arr[0];

    result.push(_.extend({
      actualIndex: arr.index,
      matchedString: matchedString,
      index: arr.index - limit * delta,
      metaString: text.substring(limit * delta, arr.index + matchedString.length > limit * (delta + 1) ? arr.index + matchedString.length : limit * (delta + 1)) },
    meta));
  }

  return result;
}

/**
   * @param {Object} option
   * @param {String} option.data Property value in which you want to find
   * @param {regex} option.regex
   * @param {string} option.label Label to be displayed in results
   * @param {string} option.[propertyPath] Property or path to reach that property
   *
   * @returns {foundFields[]}
   */
function findInString({ data, regex, label, propertyPath = '' }) {
  let splitedProperty = propertyPath.split('.'),
  property = splitedProperty.shift(),
  result = find({ text: data, regex, meta: { pathToProperty: splitedProperty.join('.') } });

  if (_.isEmpty(result)) {
    return [];
  }
  return [{
    property,
    label,
    instances: result }];

}

/**
   * @param {Object} option
   * @param {Object[]} option.data Property value in which you want to find
   * @param {regex} option.regex
   * @param {string} option.label Label to be displayed in results
   * @param {string} option.propertyPath Property or path to reach that property
   *
   * @returns {foundFields[]}
   */
function findInArrObj({ data, regex, label, propertyPath }) {
  let keys = [],
  values = [],
  description = [],
  sessionValues = [];
  _.forEach(data, (obj, index) => {
    let searchedKeys = find({
      text: _.toString(obj.key),
      regex,
      meta: { pathToProperty: `${index}.key` } }),

    searchedValues = find({
      text: _.toString(obj.value),
      regex,
      meta: {
        tooltipContent: obj.key && `Key: ${obj.key}`,
        pathToProperty: `${index}.value` } }),


    searchedDescription = find({
      text: _.toString(obj.description),
      regex,
      meta: {
        tooltipContent: obj.key && `Key: ${obj.key}`,
        pathToProperty: `${index}.description` } }),


    searchedSessionValues = find({
      text: _.toString(obj.sessionValue),
      regex,
      meta: {
        tooltipContent: obj.key && `Key: ${obj.key}`,
        pathToProperty: `${index}.sessionValue` } });



    if (!_.isEmpty(searchedKeys)) {
      keys = _.concat(keys, searchedKeys);
    }
    if (!_.isEmpty(searchedValues)) {
      values = _.concat(values, searchedValues);
    }
    if (!_.isEmpty(searchedDescription)) {
      description = _.concat(description, searchedDescription);
    }
    if (!_.isEmpty(searchedSessionValues)) {
      sessionValues = _.concat(sessionValues, searchedSessionValues);
    }
  });

  let result = [];
  if (!_.isEmpty(keys)) {
    result.push({
      property: propertyPath,
      label: `${label} name`,
      instances: keys });

  }
  if (!_.isEmpty(values)) {
    result.push({
      property: propertyPath,
      label: `${label} value`,
      instances: values });

  }
  if (!_.isEmpty(description)) {
    result.push({
      property: propertyPath,
      label: `${label} description`,
      instances: description });

  }
  if (!_.isEmpty(sessionValues)) {
    result.push({
      property: propertyPath,
      label: `${label} current value`,
      instances: sessionValues });

  }

  return result;
}

/**
   * @param {Object} option
   * @param {Object[]|String} option.data Property value in which you want to find
   * @param {regex} option.regex
   * @param {string} option.label Label to be displayed in results
   * @param {string} option.propertyPath Property or path to reach that property
   *
   * @returns {foundFields[]}
   */
function findInBody({ data, regex, label, propertyPath }) {
  if (_.isEmpty(data)) {
    return [];
  }
  if (typeof data === 'string') {
    return findInString({ data, regex, label: 'Request Body', propertyPath });
  } else
  {
    return findInArrObj({ data, regex, label: 'Request Body', propertyPath });
  }
}

/**
   * @param {Object} option
   * @param {Object} option.data Property value in which you want to find
   * @param {regex} option.regex
   * @param {string} option.label Label to be displayed in results
   * @param {string} option.propertyPath Property or path to reach that property
   *
   * @returns {foundFields[]}
   */
function findInAuth({ data, regex, label, propertyPath }) {
  let results = [];
  if (_.isEmpty(data)) {
    return results;
  }
  let type = _.get(data, 'type'),
  authArray = _.get(data, [type], []),
  ignoreProperties = [
  'id',
  'showPassword',
  'disableRetryRequest',
  'signatureMethod',
  'timestamp',
  'addParamsToHeader',
  'addEmptyParamsToSign',
  'disableRetryRequest'],

  authLabel = _constants_AuthConstants__WEBPACK_IMPORTED_MODULE_1__["AUTH_TYPE_LABEL_MAP"][type];

  _.forEach(authArray, (obj, index) => {
    if (_.includes(ignoreProperties, _.get(obj, 'key'))) {
      return;
    }
    let authResult = findInString({ data: obj.value, regex, label: `${label} > ${authLabel} > ${obj.key}`, propertyPath: `${propertyPath}.${type}.${index}.value` });
    results = _.concat(results, authResult);
  });
  return results;
}

// Replacer Helpers

/**
 *
 * @param {Object} option
 * @param {string} option.source Base string in which you want to replace
 * @param {number} option.index index at which you want to replace
 * @param {string} option.oldString String to be replace
 * @param {string} option.newString String to replace with
 */
function replaceAt({ source, index, oldString, newString }) {
  return source.substr(0, index) + source.substr(index, source.length).replace(oldString, newString);
}

/**
   *
   * @param {Object} option
   * @param {Object} option.data Object in which these properties needs to be replaced
   * @param {Object} option.replacementString String to replace with
   * @param {FoundInstance[]} option.instances
   * @param {String} option.propertyPath Path to reach that Property
   */
function replaceInProperty({ data, replacementString, instances, propertyPath }) {
  let diff = 0;
  _.forEach(instances, instance => {
    let newString = replaceAt({ source: _.get(data, propertyPath), index: instance.actualIndex + diff, oldString: instance.matchedString, newString: replacementString });
    diff += replacementString.length - instance.matchedString.length;
    _.set(data, propertyPath, newString);
  });
}

/**
   *
   * @param {Object} option
   * @param {Object} option.data Object in which these properties needs to be replaced
   * @param {Object} option.replacementString String to replace with
   * @param {FoundInstance[]} option.instances
   * @param {String} option.propertyPath Path to reach that Property
   */
function replaceInScripts({ data, replacementString, instances, propertyPath }) {
  let type = _.last(propertyPath.split('_')),
  script = _.get(_.find(data.events, ['listen', type]), 'script', {}),
  scriptString = { exec: _.get(script, 'exec', []).join('\n') };
  replaceInProperty({ data: scriptString, replacementString, instances, propertyPath: 'exec' });
  _.set(script, 'exec', scriptString.exec.split('\n'));
}

/**
   *
   * @param {Object} option
   * @param {Object} option.data Object in which these properties needs to be replaced
   * @param {Object} option.replacementString String to replace with
   * @param {FoundInstance[]} option.instances
   * @param {String} option.propertyPath Path to reach that Property
   */
function replaceInBody({ data, replacementString, instances, propertyPath }) {
  if (typeof _.get(data, propertyPath) === 'string') {
    replaceInProperty({ data, replacementString, instances, propertyPath });
  } else
  {
    replaceInObject({ data, replacementString, instances, propertyPath });
  }
}

/**
   *
   * @param {Object} option
   * @param {Object} option.data Object in which these properties needs to be replaced
   * @param {Object} option.replacementString String to replace with
   * @param {FoundInstance[]} option.instances
   * @param {String} option.propertyPath Path to reach that Property
   */
function replaceInObject({ data, replacementString, instances, propertyPath }) {
  let groupedProperty = _.groupBy(instances, 'pathToProperty');
  _.forOwn(groupedProperty, (groupedValues, key) => {
    replaceInProperty({ data, replacementString, instances: groupedValues, propertyPath: `${propertyPath}.${key}` });
  });
}

const collection = {
  name: {
    accessor: item => item.name,
    label: 'Collection name',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Name' },

  description: {
    accessor: item => item.description,
    label: 'Collection description',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Description' },

  events_prerequest: {
    accessor: item => _.get(_.find(item.events, ['listen', 'prerequest']), ['script', 'exec'], []).join('\n'),
    label: 'Collection Pre-request script',
    findHelper: findInString,
    replaceHelper: replaceInScripts,
    filterDisplayName: 'Pre-request script' },

  events_test: {
    accessor: item => _.get(_.find(item.events, ['listen', 'test']), ['script', 'exec'], []).join('\n'),
    label: 'Collection Tests',
    findHelper: findInString,
    replaceHelper: replaceInScripts,
    filterDisplayName: 'Tests' },

  auth: {
    accessor: item => item.auth,
    label: 'Authorization',
    findHelper: findInAuth,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Authorization' },

  variables: {
    accessor: item => item.variables,
    label: 'Variable',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Variable' } },


folder = {
  name: {
    accessor: item => item.name,
    label: 'Folder name',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Name' },

  description: {
    accessor: item => item.description,
    label: 'Folder description',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Description' },

  events_prerequest: {
    accessor: item => _.get(_.find(item.events, ['listen', 'prerequest']), ['script', 'exec'], []).join('\n'),
    label: 'Folder Pre-request script',
    findHelper: findInString,
    replaceHelper: replaceInScripts,
    filterDisplayName: 'Pre-request script' },

  events_test: {
    accessor: item => _.get(_.find(item.events, ['listen', 'test']), ['script', 'exec'], []).join('\n'),
    label: 'Folder Tests',
    findHelper: findInString,
    replaceHelper: replaceInScripts,
    filterDisplayName: 'Tests' },

  auth: {
    accessor: item => item.auth,
    label: 'Authorization',
    findHelper: findInAuth,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Authorization' } },


request = {
  name: {
    accessor: item => item.name,
    label: 'Request name',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Name' },

  description: {
    accessor: item => item.description,
    label: 'Request description',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Description' },

  url: {
    accessor: item => item.url,
    label: 'Request URL',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'URL' },

  queryParams: {
    accessor: item => _.map(item.queryParams, queryParam => {
      /*
                                                              * key and value of query param is already part of URL,
                                                              * It should only be replaced in URL as it is the source of truth
                                                              */
      if (queryParam.enabled) {
        return { description: queryParam.description };
      }
      return queryParam;
    }),
    label: 'Request Query Parameter',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Query parameters' },

  pathVariableData: {
    accessor: item => _.map(item.pathVariableData, pathVariable => {
      /*
                                                                     * key of path variable is already part of URL,
                                                                     * It should only be replaced in URL as it is the source of truth
                                                                     */
      return {
        description: pathVariable.description,
        value: pathVariable.value };

    }),
    label: 'Request Path Variable',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Path variables' },

  headerData: {
    accessor: item => item.headerData,
    label: 'Request Header',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Headers' },

  events_prerequest: {
    accessor: item => _.get(_.find(item.events, ['listen', 'prerequest']), ['script', 'exec'], []).join('\n'),
    label: 'Request Pre-request script',
    findHelper: findInString,
    replaceHelper: replaceInScripts,
    filterDisplayName: 'Pre-request script' },

  events_test: {
    accessor: item => _.get(_.find(item.events, ['listen', 'test']), ['script', 'exec'], []).join('\n'),
    label: 'Request Tests',
    findHelper: findInString,
    replaceHelper: replaceInScripts,
    filterDisplayName: 'Tests' },

  auth: {
    accessor: item => item.auth,
    label: 'Authorization',
    findHelper: findInAuth,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Authorization' },

  data: {
    accessor: item => item.data,
    label: 'Request body',
    findHelper: findInBody,
    replaceHelper: replaceInBody,
    filterDisplayName: 'Request body' } },


response = {
  name: {
    accessor: item => item.name,
    label: 'Example name',
    replaceHelper: replaceInProperty,
    findHelper: findInString,
    filterDisplayName: 'Name' },

  requestObject_url: {
    accessor: item => item.requestObject && item.requestObject.url,
    label: 'Example request URL',
    findHelper: findInString,
    replaceHelper: options => replaceInProperty(_extends({}, options, { propertyPath: options.propertyPath.split('_').join('.') })),
    filterDisplayName: 'URL' },

  requestObject_queryParams: {
    accessor: item => item.requestObject && _.map(item.requestObject.queryParams, queryParam => {
      /*
                                                                                                  * key and value of query param is already part of URL,
                                                                                                  * It should only be replaced in URL as it is the source of truth
                                                                                                  */
      if (queryParam.enabled) {
        return { description: queryParam.description };
      }
      return queryParam;
    }),
    label: 'Example query parameter',
    findHelper: findInArrObj,
    replaceHelper: options => replaceInObject(_extends({}, options, { propertyPath: options.propertyPath.split('_').join('.') })),
    filterDisplayName: 'Query parameters' },

  requestObject_pathVariableData: {
    accessor: item => item.requestObject && _.map(item.requestObject.pathVariableData, pathVariable => {
      /*
                                                                                                         * key of path variable is already part of URL,
                                                                                                         * It should only be replaced in URL as it is the source of truth
                                                                                                         */
      return {
        description: pathVariable.description,
        value: pathVariable.value };

    }),
    label: 'Example path variable',
    findHelper: findInArrObj,
    replaceHelper: options => replaceInObject(_extends({}, options, { propertyPath: options.propertyPath.split('_').join('.') })),
    filterDisplayName: 'Path variables' },

  requestObject_headerData: {
    accessor: item => item.requestObject && item.requestObject.headerData,
    label: 'Example request headers',
    findHelper: findInArrObj,
    replaceHelper: options => replaceInObject(_extends({}, options, { propertyPath: options.propertyPath.split('_').join('.') })),
    filterDisplayName: 'Request headers' },

  requestObject_data: {
    accessor: item => item.requestObject && item.requestObject.data,
    label: 'Example request body',
    findHelper: findInBody,
    replaceHelper: options => replaceInBody(_extends({}, options, { propertyPath: options.propertyPath.split('_').join('.') })),
    filterDisplayName: 'Request body' },

  text: {
    accessor: item => item.text,
    label: 'Example response',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Response body' },

  headers: {
    accessor: item => item.headers,
    label: 'Example response headers',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Headers' } },


environment = {
  name: {
    accessor: item => item.name,
    label: 'Environment name',
    findHelper: findInString,
    replaceHelper: replaceInProperty,
    filterDisplayName: 'Name' },

  values: {
    accessor: item => item.values,
    label: 'Environment variable',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Variables' } },


globals = {
  values: {
    accessor: item => item.values,
    label: 'Global variable',
    findHelper: findInArrObj,
    replaceHelper: replaceInObject,
    filterDisplayName: 'Variables' } };



/* harmony default export */ __webpack_exports__["default"] = ({
  collection,
  folder,
  request,
  response,
  environment,
  globals,
  tabRequest: request,
  tabResponse: response });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4905:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1269);
/* harmony import */ var _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(781);
/* harmony import */ var _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1244);
/* harmony import */ var _runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1246);
/* harmony import */ var _utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4904);
/* harmony import */ var _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(763);
/* harmony import */ var _utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(764);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(749);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(742);










const accessorMap = {
  folder: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getFolder,
  request: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getRequest,
  response: _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getResponse,
  collection: async ({ id }) => {
    let collection = await _modules_controllers_CollectionController__WEBPACK_IMPORTED_MODULE_1__["default"].getCollection({ id }),
    sessionVariable = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__["default"].get({
      id: Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])('collection', id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id) });

    if (sessionVariable && sessionVariable.values) {
      collection.variables = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["zipVariables"])(collection.variables, sessionVariable.values);
    }

    return collection;
  },
  environment: async ({ id }) => {
    let environment = await _runtime_controllers_EnvironmentController__WEBPACK_IMPORTED_MODULE_2__["default"].get({ id }),
    sessionVariable = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__["default"].get({
      id: Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])('environment', id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id) });


    if (sessionVariable && sessionVariable.values) {
      environment.values = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["zipVariables"])(environment.values, sessionVariable.values);
    }
    return environment;
  },
  globals: async ({ id }) => {
    let globals = await _runtime_controllers_GlobalsController__WEBPACK_IMPORTED_MODULE_3__["default"].get({ id }),
    sessionVariable = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__["default"].get({
      id: Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])('globals', id, Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id) });


    if (sessionVariable && sessionVariable.values) {
      globals.values = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["zipVariables"])(globals.values, sessionVariable.values);
    }
    return globals;
  },
  tabRequest: async ({ id }) => {
    if (!_.includes(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceSessionStore').visibleEditors, id)) {
      return;
    }
    let editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('EditorStore').find(id);
    return editor && editor.model.resourceToSave();
  },
  tabResponse: async ({ id }) => {
    if (!_.includes(Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceSessionStore').visibleEditors, id)) {
      return;
    }
    let editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('EditorStore').find(id);
    return editor && editor.model.resourceToSave();
  } };


/**
        *
        */
async function replaceCollectionHelper(id, data) {
  let workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id,
  dispatchActions = [],
  sessionId = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])('collection', id, workspaceId),
  session = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__["default"].get({ id: sessionId });

  if (session) {
    let { variables, sessionVariables } = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["unzipVariables"])(data.variables);

    data.variables = variables;
    dispatchActions.push(
    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(
    Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('update', 'variablesession', {
      id: sessionId,
      model: 'collection',
      modelId: id,
      workspace: workspaceId,
      values: sessionVariables })));



  }

  dispatchActions.push(
  Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(
  Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('update', 'collection', data)));



  return dispatchActions;
}


async function replaceEnvironmentHelper(id, data) {
  let workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id,
  dispatchActions = [],
  sessionId = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])('environment', id, workspaceId),
  session = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__["default"].get({ id: sessionId });

  if (session) {
    let { variables, sessionVariables } = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["unzipVariables"])(data.values);

    data.values = variables;
    dispatchActions.push(
    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(
    Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('update', 'variablesession', {
      id: sessionId,
      model: 'environment',
      modelId: id,
      workspace: workspaceId,
      values: sessionVariables })));



  }

  dispatchActions.push(
  Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(
  Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('update', 'environment', data)));



  return dispatchActions;
}


async function replaceGlobalsHelper(id, data) {
  let workspaceId = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id,
  dispatchActions = [],
  sessionId = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["getSessionId"])('globals', id, workspaceId),
  session = await _modules_controllers_VariableSessionController__WEBPACK_IMPORTED_MODULE_5__["default"].get({ id: sessionId });

  if (session) {
    let { variables, sessionVariables } = Object(_utils_VariableSessionHelper__WEBPACK_IMPORTED_MODULE_6__["unzipVariables"])(data.values);

    data.values = variables;
    dispatchActions.push(
    Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(
    Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('update', 'variablesession', {
      id: sessionId,
      model: 'globals',
      modelId: id,
      workspace: workspaceId,
      values: sessionVariables })));



  }

  dispatchActions.push(
  Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(
  Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_8__["createEvent"])('update', 'globals', data)));



  return dispatchActions;
}

async function replaceActionHelper({ id, type, data }) {
  let updateEvent;

  switch (type) {

    case 'folder':

    case 'request':

    case 'response':

      updateEvent = {
        name: 'update',
        namespace: type,
        data };


      return Object(_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_0__["default"])(updateEvent);

    case 'collection':
      return await replaceCollectionHelper(id, data);

    case 'environment':
      return await replaceEnvironmentHelper(id, data);

    case 'globals':
      return await replaceGlobalsHelper(id, data);

    case 'tabRequest':
    case 'tabResponse':
      let editor = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('EditorStore').find(id);
      editor.model.setFromDeserialized(data);
      return Promise.resolve();}

}

/**
   * This is the normalized version of replace target.
   * This helps in performing replace operation efficiently
   *
   * @typedef {Object} normalizedTarget
   * @property {string} type Type of entity e.g collection, request etc
   * @property {string} id Id of the entity
   * @property {Object} changes This object will have properties, defined under
   * different entity types, in FindReplaceHelper, and these properties will represent
   * an array of found instances with that property in this entity. Refer tests to see object
   * structure.
   *
   */


/**
       * Searched results on which we need to perform replace
       *
       * @param {Object} replaceTarget
       * @param {FoundTarget[]} replaceTarget.collections
       * @param {FoundTarget[]} replaceTarget.environments
       * @param {FoundTarget[]} replaceTarget.globals
       *
       * @returns {normalizedTarget[]}
       */
function normalizeTarget(replaceTarget) {
  let result = [];
  _.forOwn(replaceTarget, targets => {
    _.forEach(targets, target => {
      _.forEach(target.entities, entity => {
        let changes = {};
        _.forEach(entity.fields, field => {
          let instancesToReplace = _.filter(field.instances, 'isSelected');
          if (!_.isEmpty(instancesToReplace)) {
            if (_.isArray(changes[field.property])) {
              changes[field.property] = _.concat(changes[field.property], instancesToReplace);
            } else
            {
              changes[field.property] = instancesToReplace;
            }
          }
        });

        if (!_.isEmpty(changes)) {
          result.push({
            type: entity.type,
            id: entity.id,
            changes });

        }
      });
    });
  });
  return result;
}

/* harmony default export */ __webpack_exports__["default"] = ({
  /**
                  *
                  * @param {Object} replaceTarget
                  * @param {FoundTarget[]} replaceTarget.collections
                  * @param {FoundTarget[]} replaceTarget.environments
                  * @param {FoundTarget[]} replaceTarget.globals
                  * @param {string} replacementString String to replace with
                  *
                  * @returns {promise}
                  */
  async replace(replaceTarget, replacementString) {
    let normalizedTargets = normalizeTarget(replaceTarget),
    actions = [];
    if (_.isEmpty(normalizedTargets)) {
      return;
    }
    await Promise.all(_.map(normalizedTargets, async (normalizedTarget, index) => {
      if (!accessorMap.hasOwnProperty(normalizedTarget.type)) {
        return;
      }
      let data = await accessorMap[normalizedTarget.type]({ id: normalizedTarget.id });
      if (!data) {
        return;
      }
      _.forOwn(normalizedTarget.changes, (instances, key) => {
        let obj = _.get(_utils_FindReplaceHelper__WEBPACK_IMPORTED_MODULE_4__["default"], [normalizedTarget.type, key]);
        if (!obj || !_.isFunction(obj.replaceHelper)) {
          return;
        }
        obj.replaceHelper({ data, replacementString, instances, propertyPath: key });
      });
      let promises = await replaceActionHelper({
        id: normalizedTarget.id,
        type: normalizedTarget.type,
        data });

      actions = actions.concat(promises);
    }));
    return actions;
  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4906:
/***/ (function(module, exports, __webpack_require__) {

module.exports = function() {
  return new Worker(__webpack_require__.p + "findReplaceWorker.js");
};

/***/ }),

/***/ 4907:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RequesterBottomPaneHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(751);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1763);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4416);
/* harmony import */ var react_loadable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loadable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_promisifyIdleCallback__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4893);
/* harmony import */ var _components_base_Tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1791);
/* harmony import */ var _components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1883);
/* harmony import */ var _runtime_components_console_ConsoleActions_ConsoleActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4782);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(749);
/* harmony import */ var _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1540);
/* harmony import */ var _runtime_components_console_ConsoleHeader_ConsoleFilter_ConsoleFilter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4568);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(748);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1885);
/* harmony import */ var _postman_design_system__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_postman_design_system__WEBPACK_IMPORTED_MODULE_12__);
var _class;














const StatusBarContainer = react_loadable__WEBPACK_IMPORTED_MODULE_3___default()({
  loader: () => Object(_utils_promisifyIdleCallback__WEBPACK_IMPORTED_MODULE_4__["promisifyIdleCallback"])().
  then(() =>
  Promise.all(/* import() | StatusBarContainer */[__webpack_require__.e(9), __webpack_require__.e(18)]).then(__webpack_require__.bind(null, 5894))),

  loading: () => null });let



RequesterBottomPaneHeader = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class RequesterBottomPaneHeader extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  constructor(props) {
    super(props);

    this.store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('RequesterBottomPaneUIStore');
    this.consoleStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('ConsoleStore');
    this.renderUncollapsedActions = this.renderUncollapsedActions.bind(this);

    // variables to track change in properties.
    this.collapsedState = props.isCollapsed;
    this.activeTab = this.store.activeTab;
  }

  componentDidMount() {
    // collapse the Pane when `isOpen` in UI Store is set to false
    this.openStateReactDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_1__["reaction"])(() => {
      return this.store && this.store.isOpen;
    }, isOpen => {
      typeof this.props.onCollapseToggle === 'function' &&
      this.props.onCollapseToggle(!isOpen);
    });
  }

  componentDidUpdate() {
    if (!this.store) {
      return;
    }

    // check if there was a change in open state or active tab state.
    if (this.collapsedState !== this.props.isCollapsed || this.activeTab !== this.store.activeTab) {
      this.collapsedState = this.props.isCollapsed;
      this.activeTab = this.store.activeTab;

      // this event is triggered when the bottom pane is opened and active tab is Console
      if (!this.collapsedState && this.activeTab === _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PANE_CONSOLE"]) {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEventV2({
          category: 'console',
          action: 'open_pane',
          label: 'tab' });

      }
    }

    // whenever pane is collapsed, set the value in UI store to `false`.
    //
    // @note this handles the case when Pane was collapsed because of user
    // action and has no effect when the store was collapsed because of
    // updating the UI store.
    this.store.setIsOpen(!this.props.isCollapsed);
  }

  componentWillUnmount() {
    this.openStateReactDisposer && this.openStateReactDisposer();
  }

  handleSelect(tabName) {
    this.store && this.store.openTab(tabName);
  }

  handleTabClose() {
    return this.store && this.store.setIsOpen(false);
  }

  renderUncollapsedActions() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
        this.store.activeTab === _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PANE_CONSOLE"] &&
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_console_ConsoleActions_ConsoleActions__WEBPACK_IMPORTED_MODULE_7__["default"], { showOptions: true }),

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_6__["default"], {
          className: 'actions__close-icon',
          style: 'header',
          onClick: this.handleTabClose.bind(this) })));



  }

  render() {
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'requester-bottom-pane-header' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'pane-header__section-left' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'pane-header__tabs' },
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_5__["Tabs"], {
                type: 'primary',
                className: 'pane-header-tabs',
                activeRef: !this.props.isCollapsed && this.store && this.store.activeTab,
                onChange: this.handleSelect.bind(this) },

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_5__["Tab"], {
                  key: _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"],
                  refKey: _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"],
                  className: 'pane-header-tabs--find-replace' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_12__["Icon"], { name: 'icon-action-search-stroke', className: 'pm-icon pm-icon-normal' }), ' Find and Replace'),

              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_Tabs__WEBPACK_IMPORTED_MODULE_5__["Tab"], {
                  key: _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PANE_CONSOLE"],
                  refKey: _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PANE_CONSOLE"],
                  className: 'pane-header-tabs--console' },

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_design_system__WEBPACK_IMPORTED_MODULE_12__["Icon"], { name: 'icon-descriptive-console-stroke', className: 'pm-icon pm-icon-normal' }), ' Console'))),




          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'pane-header__options' },
            this.store.isOpen && this.store.activeTab === _constants_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_9__["REQUESTER_BOTTOM_PANE_CONSOLE"] &&
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_components_console_ConsoleHeader_ConsoleFilter_ConsoleFilter__WEBPACK_IMPORTED_MODULE_10__["default"], null))),



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'pane-header__section-right' },
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'pane-header__actions' },
            this.store.isOpen && this.renderUncollapsedActions())),




        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(StatusBarContainer, null)));


  }}) || _class;

/***/ }),

/***/ 4908:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Popover; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1768);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1648);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1883);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1769);
/* harmony import */ var _base_Markdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1783);
/* harmony import */ var _services_UIEventService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1755);
/* harmony import */ var _constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1756);
/* harmony import */ var _base_PieProgress__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2503);
/* harmony import */ var scrollparent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4909);
/* harmony import */ var scrollparent__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(scrollparent__WEBPACK_IMPORTED_MODULE_9__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};










const TARGET_VISIBLE_CLASS = 'target-visible';

const defaultState = {
  show: false,
  isDismissable: true,
  placement: 'bottom',
  immediate: true,
  primaryAction: null,
  secondaryAction: null,
  title: '',
  message: '',
  meta: {},
  target: null,
  className: '',
  onDismiss: null,
  dismissEvent: null };let


Popover = class Popover extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor() {
    super();

    this.state = _extends({}, defaultState);

    this.handleOpen = this.handleOpen.bind(this);
    this.dismissPopover = this.dismissPopover.bind(this);

    this.handlePrimaryAction = this.handlePrimaryAction.bind(this);
    this.handleSecondaryAction = this.handleSecondaryAction.bind(this);
    this.handleTargetClick = this.handleTargetClick.bind(this);
  }

  UNSAFE_componentWillMount() {
    pm.mediator.on('showPopover', this.handleOpen);
  }

  componentWillUnmount() {
    pm.mediator.off('showPopover', this.handleOpen);
  }

  checkIfPropertyOutOfBoundHorizontally(property, targetCoordinates, parentCoordinates) {
    return targetCoordinates[property] <= parentCoordinates.left ||
    targetCoordinates[property] >= parentCoordinates.right;
  }

  checkIfPropertyOutOfBoundVertically(property, targetCoordinates, parentCoordinates) {
    return targetCoordinates[property] <= parentCoordinates.top ||
    targetCoordinates[property] >= parentCoordinates.bottom;
  }

  /**
     * Scroll an element into view only if placement side of an element is not visible
     * @param {Object} target
     * @param {String} placement
     */
  scrollTargetIfNeeded(target, placement = 'top') {
    let parent = scrollparent__WEBPACK_IMPORTED_MODULE_9___default()(target),
    targetCoordinates = target.getBoundingClientRect(),
    parentCoordinates = parent.getBoundingClientRect(),
    position = _.head(placement.split('-'));

    if ((position === 'left' || position === 'right') && (

    this.checkIfPropertyOutOfBoundHorizontally(position, targetCoordinates, parentCoordinates) ||
    this.checkIfPropertyOutOfBoundVertically('top', targetCoordinates, parentCoordinates) ||
    this.checkIfPropertyOutOfBoundVertically('bottom', targetCoordinates, parentCoordinates)))
    {

      target.scrollIntoViewIfNeeded();
    } else

    if ((position === 'top' || position === 'bottom') && (

    this.checkIfPropertyOutOfBoundVertically(position, targetCoordinates, parentCoordinates) ||
    this.checkIfPropertyOutOfBoundHorizontally('left', targetCoordinates, parentCoordinates) ||
    this.checkIfPropertyOutOfBoundHorizontally('right', targetCoordinates, parentCoordinates)))
    {

      target.scrollIntoViewIfNeeded();
    }
  }

  /**
     * Target object needs to be given as DOM node itself
     * eg. { target: DOMNode }
     *
     * @param {Object} target
     * @param {Object} renderOptions
     */
  handleOpen({ target }, renderOptions) {
    if (!target || _.isEmpty(renderOptions)) {
      return false;
    }

    // Hack to make reactstrap rerender
    if (this.state.show && renderOptions.show) {
      this.closePopover();
    }

    target.classList.add(TARGET_VISIBLE_CLASS);

    this.scrollTargetIfNeeded(target, renderOptions.placement);

    this.setState(_extends({
      show: true,
      target },
    renderOptions),
    _.get(renderOptions, 'onView', _.noop));
    pm.mediator.once(renderOptions.dismissEvent, this.dismissPopover);
  }

  handlePrimaryAction() {
    this.state.primaryAction && this.state.primaryAction.onClick();
    this.closePopover();
  }

  handleSecondaryAction() {
    this.state.secondaryAction && this.state.secondaryAction.onClick();
    this.closePopover();
  }

  dismissPopover() {
    this.state.onDismiss && this.state.onDismiss();
    this.closePopover();
  }

  closePopover() {
    // If a handler needs to be called on dismiss of the popover
    this.state.target && this.state.target.classList.remove(TARGET_VISIBLE_CLASS);
    this.state.dismissEvent && pm.mediator.off(this.state.dismissEvent, this.dismissPopover);
    this.setState(defaultState);
  }

  getActions() {
    const { primaryAction, secondaryAction } = this.state;

    if (primaryAction || secondaryAction) {
      return (
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-actions' },

          secondaryAction &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'popover-secondary-action',
              type: 'secondary',
              size: 'small',
              onMouseDown: this.handleSecondaryAction },

            secondaryAction.label),



          primaryAction &&
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: 'popover-primary-action',
              type: 'primary',
              size: 'small',
              onMouseDown: this.handlePrimaryAction },

            primaryAction.label)));




    }
  }

  getPopoverClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({ 'popover': true }, this.state.className);
  }

  handleTargetClick() {
    if (!this.state.allowTargetClick) {
      return;
    }
    _services_UIEventService__WEBPACK_IMPORTED_MODULE_6__["default"].publish(_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_7__["ONBOARDING_TARGET_CLICKED"]);
    this.closePopover();
  }

  render() {
    let showMeta = !_.isEmpty(this.state.meta),
    progress = Math.floor(this.state.meta.progress || 0);
    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-wrapper' },
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_4__["Tooltip"], {
            show: this.state.show,
            target: this.state.target,
            placement: this.state.placement,
            className: 'tooltip-popover',
            immediate: this.state.immediate,
            container: this.state.container,
            onTargetClick: this.handleTargetClick },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_4__["TooltipBody"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: this.getPopoverClasses(), ref: 'popover' },
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-content' },

                showMeta &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-step' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-step-title' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_PieProgress__WEBPACK_IMPORTED_MODULE_8__["default"], { size: 16, progress: progress }),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, this.state.meta.headerText)),


                  this.state.isDismissable &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
                      className: 'popover-dismiss',
                      onClick: this.dismissPopover }, 'End lesson')),






                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-header' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-header-title' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, this.state.title),

                    !showMeta && this.state.isDismissable &&
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_3__["default"], {
                      className: 'popover-dismiss',
                      size: 'xs',
                      onClick: this.dismissPopover }))),




                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-body' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-string' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'popover-markdown-label' },
                      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Markdown__WEBPACK_IMPORTED_MODULE_5__["default"], { source: this.state.message.charAt(0).toUpperCase() + this.state.message.slice(1) })))),



                this.getActions()))))));






  }};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4909:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (root, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else {}
}(this, function () {
  var regex = /(auto|scroll)/;

  var parents = function (node, ps) {
    if (node.parentNode === null) { return ps; }

    return parents(node.parentNode, ps.concat([node]));
  };

  var style = function (node, prop) {
    return getComputedStyle(node, null).getPropertyValue(prop);
  };

  var overflow = function (node) {
    return style(node, "overflow") + style(node, "overflow-y") + style(node, "overflow-x");
  };

  var scroll = function (node) {
   return regex.test(overflow(node));
  };

  var scrollParent = function (node) {
    if (!(node instanceof HTMLElement || node instanceof SVGElement)) {
      return ;
    }

    var ps = parents(node.parentNode, []);

    for (var i = 0; i < ps.length; i += 1) {
      if (scroll(ps[i])) {
        return ps[i];
      }
    }

    return document.scrollingElement || document.documentElement;
  };

  return scrollParent;
}));


/***/ }),

/***/ 4910:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeOnboarding", function() { return initializeOnboarding; });
/* harmony import */ var _src_features_InAppMessage_initializeInAppMessage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4911);
/* harmony import */ var _src_features_Launchpad_initializeLaunchpad__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4914);



/**
                                                                                  *
                                                                                  */
function initializeOnboarding() {
  Object(_src_features_InAppMessage_initializeInAppMessage__WEBPACK_IMPORTED_MODULE_0__["default"])();
  Object(_src_features_Launchpad_initializeLaunchpad__WEBPACK_IMPORTED_MODULE_1__["default"])();
}

/***/ }),

/***/ 4911:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _InAppMessageController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2600);
/* harmony import */ var _message_transformer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4912);
/* harmony import */ var _common_InAppEngagementService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4096);
/* harmony import */ var _NotificationPollingService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4913);
/* harmony import */ var _common_dependencies__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2109);







/**
                                                                                             * @param {*} cb
                                                                                             *
                                                                                             */
function initializeInAppMessaging() {
  /*
                                     * Consumer of in-app messages need to register its ownn handlers with in-app
                                     * message controller. The controller just calls your handlers whenever it want to
                                     * perform different tasks. This gives the consumer flexibility and keeps the controller
                                     * unopinionated about what you should do when certain message needs to be shown.
                                     */
  Object(_InAppMessageController__WEBPACK_IMPORTED_MODULE_0__["registerHandlers"])({

    messageHandlers: {
      toast: message => {
        let options = Object(_message_transformer__WEBPACK_IMPORTED_MODULE_1__["transformForToast"])(message);
        pm.toasts[options.level](options.text, options);
      },
      banner: message => {
        _common_dependencies__WEBPACK_IMPORTED_MODULE_4__["infobarController"].add(Object(_message_transformer__WEBPACK_IMPORTED_MODULE_1__["transformForBanner"])(message));
        _common_dependencies__WEBPACK_IMPORTED_MODULE_4__["infobarController"].show();
      },
      text: message => {
        Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_4__["getStore"])('TextMessageStore').addNotification(message);
      },

      popover: message => {
        Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_4__["PopoverController"])(Object(_message_transformer__WEBPACK_IMPORTED_MODULE_1__["transformForPopover"])(message), _.get(message, 'message.target'));
      },

      backgroundPush: message => {
        let { action } = Object(_message_transformer__WEBPACK_IMPORTED_MODULE_1__["transformForBackgroundPush"])(message);
        message.onView && message.onView();
        action && action();
      },

      modal: message => {
        pm.mediator.trigger('showInAppModal', Object(_message_transformer__WEBPACK_IMPORTED_MODULE_1__["transformForModal"])(message));
      } },



    actionHandlers: _common_InAppEngagementService__WEBPACK_IMPORTED_MODULE_2__["default"] });

  Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_4__["getStore"])('InAppMessageStore');
  _NotificationPollingService__WEBPACK_IMPORTED_MODULE_3__["default"].init();
}

/* harmony default export */ __webpack_exports__["default"] = (initializeInAppMessaging);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4912:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transformForToast", function() { return transformForToast; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transformForBanner", function() { return transformForBanner; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transformForPopover", function() { return transformForPopover; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transformForBackgroundPush", function() { return transformForBackgroundPush; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transformForModal", function() { return transformForModal; });
/**
 * @param {*} message - message sent received from InAppController
 */
function transformForToast(message) {
  return {
    level: _.get(message, 'tag.level'),
    title: _.get(message, 'message.title'),
    text: _.get(message, 'message.text'),
    primaryAction: _.get(message, 'message.buttons.primary'),
    secondaryAction: _.get(message, 'message.buttons.secondary'),
    isDismissable: !_.get(message, 'dismiss.disabled'),
    timeout: _.get(message, 'dismiss.auto'),
    onDismiss: _.get(message, 'dismiss.onDismiss'),
    dismissEvent: _.get(message, 'dismiss.event'),
    onView: _.get(message, 'onView') };

}

/**
   * @param {*} message - message sent received from InAppController
   */
function transformForBanner(message) {
  return {
    message: _.get(message, 'message.text'),
    priority: _.get(message, 'message.priority') || 100,
    type: _.get(message, 'tag.level'),
    primaryAction: _.get(message, 'message.buttons.primary'),
    secondaryAction: _.get(message, 'message.buttons.secondary'),
    isDismissable: !_.get(message, 'dismiss.disabled'),
    onDismiss: _.get(message, 'dismiss.onDismiss'),
    dismissEvent: _.get(message, 'dismiss.event'),
    onView: _.get(message, 'onView') };

}

/**
   * @param {*} message - message sent received from InAppController
   */
function transformForPopover(message) {
  return {
    show: true,
    immediate: true,
    title: _.get(message, 'message.title'),
    placement: _.get(message, 'message.position', 'bottom-left'),
    allowTargetClick: _.get(message, 'message.allowTargetClick'),
    message: _.get(message, 'message.text', ''),
    primaryAction: _.get(message, 'message.buttons.primary'),
    secondaryAction: _.get(message, 'message.buttons.secondary'),
    isDismissable: !_.get(message, 'dismiss.disabled'),
    meta: _.get(message, 'message.meta'),
    onDismiss: _.get(message, 'dismiss.onDismiss'),
    dismissEvent: _.get(message, 'dismiss.event'),
    onView: _.get(message, 'onView') };

}

/**
   * @param {*} message - message sent received from InAppController
   */
function transformForBackgroundPush(message) {
  return {
    action: _.get(message, 'message.buttons.primary.onClick') };

}

/**
   * @param {*} message - message sent received from InAppController
   */
function transformForModal(message) {
  return {
    title: _.get(message, 'message.title'),
    message: _.get(message, 'message.text'),
    meta: _.get(message, 'message.meta'),
    primaryAction: _.get(message, 'message.buttons.primary'),
    secondaryAction: _.get(message, 'message.buttons.secondary'),
    isDismissable: !_.get(message, 'dismiss.disabled'),
    onDismiss: _.get(message, 'dismiss.onDismiss'),
    dismissEvent: _.get(message, 'dismiss.event'),
    onView: _.get(message, 'onView') };

}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4913:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _common_dependencies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2109);


const DEFAULT_LIMIT = 10,
POLLING_HEADER_NAME = 'x-polling-interval',
acceptedNotificationTypes = ['toast', 'banner', 'backgroundPush', 'modal'];

let alreadyInitialized = false,
nextPolling = null,
nextPollInterval = null;

/**
                         * Fetches notifications for signed in users
                         *
                         * @private
                         */
async function _fetchSignedInNotifications() {
  let currentUser = await _common_dependencies__WEBPACK_IMPORTED_MODULE_0__["UserController"].get();

  pm.notificationPollingBaseUrl = currentUser.syncserver_url;

  // If the user is signed out and signs back in, we call fetchNotifications
  return _fetchNotifications();
}

/**
  * Attaches online listener
  */
function _attachOnlineListener() {
  pm.mediator.off('appOnline', _fetchSignedInNotifications);
  pm.mediator.on('appOnline', _fetchSignedInNotifications);
}

/**
  * Extracts notifications, filters unread
  * @param { Object } notifications
  */
function _dispatchUnreadNotifications(notifications) {

  _.chain(notifications).
  filter(notification => {
    return notification.data && notification.data.events && !_.some(notification.data.events, { key: 'viewed' });
  }).
  forEach(notification => {
    return _dispatchNotification(notification.data);
  }).
  value();
}

/**
  * Creates the notification event and dispatches user action
  * @param { Object } notification
  */
async function _dispatchNotification(notification) {

  let isUserSignedIn = await _isUserSignedIn(),
  meta = {};

  if (!isUserSignedIn) {
    meta = { source: 'SignedOutUser' };
  }

  // Adding source in meta to distinguish who's triggering the event so that the logic is not dependent on checking if the user is signed in or not.
  let notificationEvent = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_0__["createEvent"])('create', 'notification', notification, null, meta);

  return Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_0__["dispatchSyncAction"])(notificationEvent);
}

/**
  * Checks if the user is signed
  * @returns { Boolean } isUserSignedIn
  */
async function _isUserSignedIn() {
  let { id } = await _common_dependencies__WEBPACK_IMPORTED_MODULE_0__["UserController"].get();

  return id !== '0';
}

/**
  * Fetches the base URL from S3 bucket
  */
function _fetchBaseUrl() {
  return _common_dependencies__WEBPACK_IMPORTED_MODULE_0__["HttpService"].request(pm.notificationPollingConfigUrl).
  then(({ body }) => {
    if (body.config && body.config.notificationsUrl) {
      return body.config.notificationsUrl;
    }

    return pm.notificationPollingBaseUrl;
  }).
  catch(({ error }) => {
    return pm.notificationPollingBaseUrl;
  });
}

/**
  * Function to attach a bootstrap finish listener and trigger fetchNotifications for signed in users
  */
function _attachSyncFinishListener() {
  let syncStatusStore = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_0__["getStore"])('SyncStatusStore');

  syncStatusStore.onSyncAvailable().
  then(() => {
    _attachOnlineListener();

    return _fetchSignedInNotifications();
  });
}

/**
    * Fetches notification from sync URL and sets the next polling interval - clears the poll interval previously set.
    * Also computes headers and params based on user status (Signed in or not)
    */
async function _fetchNotifications() {
  const currentUser = await _common_dependencies__WEBPACK_IMPORTED_MODULE_0__["UserController"].get();

  let { notificationURL, headers } = _computeNotificationURLAndHeaders(currentUser);

  // If the user's status changes before the timeout is triggered, we unset the existing timer
  nextPolling && clearTimeout(nextPolling);

  _common_dependencies__WEBPACK_IMPORTED_MODULE_0__["HttpService"].request(notificationURL, {
    headers: headers }).
  then(({ body, headers }) => {
    let nextPoll = parseInt(headers.get(POLLING_HEADER_NAME));

    if (!_.isNaN(nextPoll)) {
      clearTimeout(nextPolling);

      nextPollInterval = nextPoll; // Caching the poll interval
      nextPolling = setTimeout(_fetchNotifications, nextPollInterval);
    }

    alreadyInitialized = true;
    return _dispatchUnreadNotifications(body);
  }).
  catch(({ error }) => {

    // Incase the API fetch fails, we set timeout to the previously cached interval
    clearTimeout(nextPolling);
    nextPolling = setTimeout(NotificationPollingService.init, nextPollInterval);
  });
}

/**
  * Sets access token in the header if the user is signed in or app id in the params if the user is signed out
  * @param { Object } currentUser
  * @returns { Object }
  */
function _computeNotificationURLAndHeaders(currentUser) {
  let notificationURL = `${pm.notificationPollingBaseUrl}/notification?limit=${DEFAULT_LIMIT}&events=viewed`,
  headers = {};

  if (currentUser.id === '0') {
    notificationURL += `&app_id=${pm.app.get('installationId')}`;
  } else
  {
    const token = _.get(currentUser, 'auth.access_token');

    // Add type filter with the notification type we want to show
    notificationURL += `&type=${acceptedNotificationTypes.join('&type=')}&groupByType=true`;

    headers = {
      'x-access-token': token };

  }

  return { notificationURL, headers };
}

const NotificationPollingService = {

  /**
                                     * Checks that the function was not already called. If not, attaches listeners and initializes variables
                                     */
  async init() {
    if (alreadyInitialized) {
      return;
    }

    const isUserSignedIn = await _isUserSignedIn();

    nextPolling = null;
    nextPollInterval = 7200000; // 2hrs. Fallback interval if the API call fails for the first time

    // This is called before so that we can initiate signed in user notification polling as soon as the user signs in
    _attachSyncFinishListener();

    if (!isUserSignedIn) {
      pm.notificationPollingBaseUrl = await _fetchBaseUrl();

      return _fetchNotifications();
    }
  } };


/* harmony default export */ __webpack_exports__["default"] = (NotificationPollingService);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4914:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return initializeLaunchpad; });
/* harmony import */ var _openLaunchpadService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4915);
/* harmony import */ var _common_dependencies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2109);



/**
                                                                            *
                                                                            */
function initializeLaunchpad() {
  _common_dependencies__WEBPACK_IMPORTED_MODULE_1__["UIEventService"].subscribe('openLaunchpad', () => {
    _common_dependencies__WEBPACK_IMPORTED_MODULE_1__["EditorService"].open('customview://launchpad', { preview: false });
  });
  _openLaunchpadService__WEBPACK_IMPORTED_MODULE_0__["default"].initialize();
}

/***/ }),

/***/ 4915:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(751);
/* harmony import */ var _common_dependencies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2109);



const actions = ['switchedWorkspace', 'joined', 'lockUserSession', 'authenticated'],
nameSpaces = ['workspace', 'user', 'authentication'];

let launchpadService = {

  // Flag used to verify whether user session expired or not.
  isSessionExpired: false,

  // open launchpad.
  async openLaunchpad(data) {
    let openEditors = _.difference(data.editorOrder, data.closedEditors),
    launchpadSettingByUser = pm.settings.getSetting('openLaunchpad'),
    openLaunchpad = true,
    count = 0;

    if (!launchpadSettingByUser) {
      return;
    }

    _.forEach(openEditors, editor => {
      let editorInfo = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('EditorStore').find(editor);

      if (_.get(editorInfo, 'model.info.model') !== 'request') {
        openLaunchpad = false;
        return false;
      }

      if (_.get(editorInfo, 'model.isDirty')) {
        openLaunchpad = false;
        return false;
      }

      if (_.get(editorInfo, 'model.baseResource') !== undefined) {
        openLaunchpad = false;
        return false;
      }

      count++;
    });

    if (openLaunchpad && count === openEditors.length) {
      _common_dependencies__WEBPACK_IMPORTED_MODULE_1__["EditorService"].open('customview://launchpad', { preview: false });
    }
  },

  async hydrateEditorStores() {
    // wait for ActiveWorkspaceSessionStore to be initialized.
    await new Promise(resolve => {
      if (Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').id) {
        return resolve();
      }

      let disposer = Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').id, () => {
        disposer && disposer();
        resolve();
      });
    });

    let session = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore'),
    openEditors = _.difference(session.editorOrder, session.closedEditors);

    if (_.isEmpty(openEditors)) {
      return session;
    }

    // wait for editor tabs in editor store to initialize.
    await Promise.all(_.map(openEditors, editor => {
      return new Promise(resolve => {
        if (!_.isEmpty(Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('EditorStore').find(editor))) {
          return resolve();
        }

        let disposer = Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('EditorStore').find(editor), () => {
          disposer && disposer();
          resolve();
        });
      });
    }));

    // wait for each editor tab lifecycle to be idle
    await Promise.all(_.map(openEditors, editor => {
      return new Promise(resolve => {
        let lifecycle = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('EditorStore').find(editor).lifecycle;

        if (lifecycle === 'idle') {
          return resolve();
        }

        let disposer = Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('EditorStore').find(editor).lifecycle, lifecycle => {
          if (lifecycle === 'idle') {
            disposer && disposer();
            resolve();
          }
        });
      });
    }));

    return session;
  },

  // handle all model-events
  handleEvents(event) {
    Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["processEvent"])(event, actions, async (processedEvent, cb) => {
      let eventNameSpace = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getEventNamespace"])(processedEvent),
      eventName = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getEventName"])(processedEvent),
      eventData = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getEventData"])(processedEvent);

      if (!_.includes(nameSpaces, eventNameSpace)) {
        return cb();
      }

      if (!_.includes(actions, eventName)) {
        return cb();
      }

      if (eventName === 'switchedWorkspace') {
        let switchedWorkspaceId = eventData.workspace,
        session;

        await launchpadService.hydrateActiveWorkspaceSessionStore(switchedWorkspaceId);

        session = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore');

        launchpadService.openLaunchpad(session);
      }

      if (eventName === 'joined') {
        let joinedWorkspaceId = _.get(eventData.workspace, 'id'),
        session;

        if (joinedWorkspaceId) {
          await launchpadService.hydrateActiveWorkspaceSessionStore(joinedWorkspaceId);
          session = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore');

          launchpadService.openLaunchpad(session);
        }
      }

      if (eventName === 'lockUserSession') {
        launchpadService.isSessionExpired = true;
      }

      if (eventName === 'authenticated') {
        if (launchpadService.isSessionExpired) {
          launchpadService.isSessionExpired = false;
          return;
        }

        let session = await launchpadService.hydrateEditorStores();

        launchpadService.openLaunchpad(session);
      }
    });
  },

  // verify the workspace is switched or joined.
  hydrateActiveWorkspaceSessionStore(workspaceId) {
    return new Promise(resolve => {
      if (Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').workspace === workspaceId) {
        return resolve();
      }

      let disposer = Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceSessionStore').workspace, workspace => {
        if (workspace === workspaceId) {
          disposer && disposer();
          resolve();
        }
      });
    });
  },

  async initialize() {

    let modelEventChannel = pm.eventBus.channel('model-events'),
    authHandlerEventChannel = pm.eventBus.channel('auth-handler-events');

    modelEventChannel.subscribe(this.handleEvents);
    authHandlerEventChannel.subscribe(this.handleEvents);

    let session = await this.hydrateEditorStores();

    // open launchpad on app boot.
    this.openLaunchpad(session);
  } };


/* harmony default export */ __webpack_exports__["default"] = (launchpadService);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ }),

/***/ 4916:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return InlineComment; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(749);
/* harmony import */ var _js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2078);
/* harmony import */ var _js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1769);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1768);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(784);
/* harmony import */ var _js_components_comments_CommentContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2068);
/* harmony import */ var _js_modules_services_InlineCommentTransformerService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1753);
/* harmony import */ var _js_components_base_Icons_FillCommentIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2076);
/* harmony import */ var _js_components_base_Icons_UpSolidIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1802);
/* harmony import */ var _js_components_base_Icons_RefreshIcon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2073);
/* harmony import */ var _js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2059);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};var _class;











let


InlineComment = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class InlineComment extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      updating: [],
      creating: false,
      hasError: false,
      deleting: [],
      isCommentInputClose: true };


    this.editor = null;

    this.cachedComments = [];

    this.inlineCommentUIStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('InlineCommentUIStore');
    this.annotationStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('AnnotationStore');

    this.onResolve = this.onResolve.bind(this);
    this.synchronizeComments = this.synchronizeComments.bind(this);
    this.handleResolveComment = this.handleResolveComment.bind(this);
    this.handleAddComment = this.handleAddComment.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.handleUpdate = this.handleUpdate.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.userClick = this.userClick.bind(this);
    this.handleCommentClose = this.handleCommentClose.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.handleRequestUpdate = this.handleRequestUpdate.bind(this);
    this.filterComments = this.filterComments.bind(this);
    this.getAnnotation = this.getAnnotation.bind(this);
    this.parseError = this.parseError.bind(this);
    this.setListRef = this.setListRef.bind(this);
    this.scrollToEnd = this.scrollToEnd.bind(this);
    this.setCommentWrapperRef = this.setCommentWrapperRef.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
  }

  componentDidUpdate(prevProps, prevState) {
    // scroll the list to end when the popover is opened
    if (this.inlineCommentUIStore.showCommentPopover) {
      requestIdleCallback(() => this.scrollToEnd());
    }
  }

  getAnnotation(schemaPath) {
    let annotation = _.filter(this.annotationStore.values, annotation => {
      return annotation.anchor === _.get(schemaPath, 'anchor') &&
      annotation.selection.index === _.get(schemaPath, 'selection.index') &&
      annotation.selection.identifier === _.get(schemaPath, 'selection.identifier') &&
      _.isEqual(annotation.selection.range, _.get(schemaPath, 'selection.range')) &&
      !(annotation.status.orphaned || annotation.status.resolved);
    });

    // Safe check that only one active annotation present
    if (annotation.length === 1) {
      return annotation[0];
    }

    return;
  }

  userClick(id) {
    Object(_js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["openTeamUserProfile"])(id);
  }

  filterComments(comments, annotation) {
    if (_.isEmpty(comments) || _.isEmpty(annotation)) {
      return [];
    }

    return _.filter(comments, comment => {
      return comment.annotationId === annotation.id;
    });
  }

  synchronizeComments(comments, invalidate = false) {
    const lastComment = comments[comments.length - 1];

    if (comments[0] === lastComment) {
      this.cachedComments = comments;
      return this.cachedComments;
    }

    if (!this.inlineCommentUIStore.showCommentPopover) {
      this.cachedComments = comments;
      return this.cachedComments;
    }

    if (invalidate) {
      this.cachedComments = comments;
      this.forceUpdate();
      return this.cachedComments;
    }

    if (_.isEmpty(this.cachedComments) ||
    lastComment && lastComment.createdBy === Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore').id) {
      this.cachedComments = comments;
    } else {
      this.cachedComments = this.cachedComments.filter(x => Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CommentStore').find(x.id));
    }

    return this.cachedComments;
  }

  handleAddComment() {
    this.setState({ isCommentInputClose: false });
  }

  handleCommentClose() {
    this.inlineCommentUIStore.target && this.inlineCommentUIStore.target.classList.remove('inline-comment-available__focused');
    this.inlineCommentUIStore.setCommentPopoverState(false);
    this.inlineCommentUIStore.setCommentState(false);
    this.inlineCommentUIStore.setTooltipPlacement(null);

    if (this.editor.isEntityUpdated) {
      _.isFunction(this.editor.updateEntity) && this.editor.updateEntity();
    }
  }

  handleClickOutside(e) {
    if (this.inlineCommentPopoverRef && !this.inlineCommentPopoverRef.contains(e.target)) {
      this.inlineCommentUIStore.target && this.inlineCommentUIStore.target.classList.remove('inline-comment-available__focused');
      this.inlineCommentUIStore.setCommentPopoverState(false);
      this.inlineCommentUIStore.setCommentState(false);
      this.inlineCommentUIStore.setTooltipPlacement(null);
    }

    if (this.editor.isEntityUpdated) {
      _.isFunction(this.editor.updateEntity) && this.editor.updateEntity();
    }
  }

  handleRequestUpdate() {
    this.inlineCommentUIStore.setCommentPopoverState(false);
    this.inlineCommentUIStore.setCommentState(false);

    _.isFunction(this.editor.updateEntity) && this.editor.updateEntity();
  }

  handleMouseEnter() {
    this.inlineCommentUIStore.hoverTimeoutHandler && clearTimeout(this.inlineCommentUIStore.hoverTimeoutHandler);

    this.inlineCommentUIStore.hoverTimeoutHandler = setTimeout(() => {
      this.inlineCommentUIStore.setCommentPopoverState(true);
    }, 100);
  }

  handleMouseLeave() {
    this.inlineCommentUIStore.hoverTimeoutHandler && clearTimeout(this.inlineCommentUIStore.hoverTimeoutHandler);
  }

  parseError(e) {
    if (!e.isFriendly) {
      return '';
    }

    return e.message;
  }

  scrollToEnd() {
    if (!this.listRef) {
      return;
    }

    if (this.state.hasError || this.state.updating.length > 0) {
      return;
    }
    const maxScrollTop = this.listRef.scrollHeight - this.listRef.clientHeight;
    this.listRef.scrollTop = maxScrollTop > 0 ? maxScrollTop : 0;
  }

  setListRef(node) {
    this.listRef = node;
  }

  setCommentWrapperRef(node) {
    this.inlineCommentPopoverRef = node;

    this.forceUpdate();
  }

  onResolve() {
    pm.mediator.trigger('showResolveCommentThreadModal', () => {
      return this.handleResolveComment();
    });
  }

  handleResolveComment() {
    return this.editor.actions.resolveAnnotation({
      id: _.get(this.annotation, 'id') }).
    then(() => {
      this.inlineCommentUIStore.setCommentPopoverState(false);
      this.inlineCommentUIStore.setCommentState(false);
    }).
    catch(e => {
      pm.toasts.error('An error occurred while resolve the thread.', { title: 'Unable to resolve thread' });
    });
  }

  handleCreate(data, tags) {
    let isOffline = !this.editor.getAdditionalData('isSocketConnected');

    if (isOffline) {
      pm.toasts.error('You need to be online to comment.');
      return;
    }

    if (!this.inlineCommentUIStore.path) {
      pm.logger.error('This element does not have valid xPath');
      return;
    }

    const value = {
      text: this.inlineCommentUIStore.value || _.get(this.inlineCommentUIStore, 'target.innerText', '').trim() },

    createData = {
      body: data,
      tags: tags,
      request: this.editor.requestId };


    if (this.annotation) {
      createData.annotationId = this.annotation.id;
    } else
    {
      createData.anchor = _.get(this.schemaPath, 'anchor');
      createData.selection = _.get(this.schemaPath, 'selection');
      createData.value = value;
    }

    this.setState({ creating: true });
    this.editor.actions.createComment(createData).then(() => {
      this.setState({
        creating: false,
        hasError: false });


      let scrollTimeout = setTimeout(() => {
        this.scrollToEnd();

        clearTimeout(scrollTimeout);
      }, 300);
    }).
    catch(e => {
      pm.toasts.error(this.parseError(e) || 'An error occurred while creating a comment.', { title: 'Unable to save comment' });
      this.setState({
        creating: false,
        hasError: true });

    });
  }

  handleUpdate({ id, body, tags }) {
    let isOffline = !this.editor.getAdditionalData('isSocketConnected');

    if (isOffline) {
      pm.toasts.error('You need to be online to update a comment.');

      return;
    }

    this.setState(prevState => ({ updating: _.union(prevState.updating, [id]) }));
    return this.editor.actions.
    updateComment({ id, body, tags }).
    then(() => {
      this.setState(prevState => ({
        updating: _.remove(prevState.updating, id),
        hasError: false }));

    }).
    catch(e => {
      pm.toasts.error(this.parseError(e) || 'An error occurred while updating the comment.', { title: 'Unable to save comment' });
      this.setState(prevState => ({
        updating: _.remove(prevState.updating, id),
        hasError: true }));

    });
  }

  handleDelete(id) {
    let isOffline = !this.editor.getAdditionalData('isSocketConnected');

    if (isOffline) {
      pm.toasts.error('You need to be online to delete a comment.');

      return;
    }

    this.setState(prevState => ({ deleting: _.union(prevState.deleting, [id]) }));
    return this.editor.actions.
    deleteComment({ id }).
    then(() => {
      this.setState(prevState => ({ deleting: _.remove(prevState.deleting, id) }));
    }).
    catch(e => {
      pm.toasts.error(this.parseError(e) || 'An error occurred while deleting the comment.');
      this.setState(prevState => ({ deleting: _.remove(prevState.deleting, id) }));
    });
  }

  handleRetry() {
    this.editor.actions.getComments({
      request: this.editor.requestId,
      editor: this.editor,
      force: true });

  }

  render() {
    const activeEditor = this.inlineCommentUIStore.activeEditor,
    editor = _.get(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('EditorStore').find(activeEditor), 'model'),
    isDirty = editor && editor.isDirty,
    range = this.inlineCommentUIStore.range,
    schemaPath = editor && !isDirty && this.inlineCommentUIStore.path &&
    _js_modules_services_InlineCommentTransformerService__WEBPACK_IMPORTED_MODULE_8__["default"].getSchemaPathInfoFromViewPath(this.inlineCommentUIStore.path, editor.requestId, 'request', range),
    annotation = this.getAnnotation(schemaPath),
    filteredComments = editor && !isDirty && annotation &&
    this.filterComments(editor.getAdditionalData('comments'), annotation) || [],
    comments = _.sortBy(filteredComments, 'createdAt'),
    cachedComments = !_.isEmpty(comments) ? this.synchronizeComments(comments) : comments,
    commentDiffLength = comments.length - cachedComments.length,
    loading = editor && editor.getAdditionalData('commentsLoading'),
    loadError = editor && editor.getAdditionalData('commentsLoadingError'),
    currentUser = editor && editor.getAdditionalData('currentUser') || {},
    teamUsersMap = editor && editor.getAdditionalData('teamUsersMap') || {},
    teamUsers = Object.values(teamUsersMap),
    isOffline = editor && !editor.getAdditionalData('isSocketConnected'),
    isDisabled = !currentUser.isLoggedIn || isOffline,
    isAdmin = _js_utils_util__WEBPACK_IMPORTED_MODULE_6__["default"].isUserAdmin(currentUser);

    let position = 'right-top';

    this.schemaPath = schemaPath;
    this.annotation = annotation;
    this.editor = editor;

    if (this.inlineCommentUIStore.target && this.inlineCommentPopoverRef) {
      let availableSpace = window.outerWidth - this.inlineCommentUIStore.target.getBoundingClientRect().right;

      if (availableSpace < this.inlineCommentPopoverRef.offsetWidth) {
        position = 'left-top';
      }
    }

    return (
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_4__["Tooltip"], {
            immediate: true,
            className: 'inline-comment comment',
            placement: this.inlineCommentUIStore.tooltipPlacement || position,
            target: this.inlineCommentUIStore.target,
            show: this.inlineCommentUIStore.showCommentPopover },

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_4__["TooltipBody"], null,
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                className: 'inline-comment-wrapper',
                ref: this.setCommentWrapperRef },


              this.inlineCommentUIStore.showCommentPopover &&
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', null,

                annotation &&
                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'inline-comment__header' },
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'inline-comment__header-comment' }, 'Comments ',
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', { className: 'comment-badge' }, cachedComments.length)),


                  commentDiffLength > 0 &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                      className: 'inline-comment__update-badge',
                      onClick: () => this.synchronizeComments(comments, true) },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_UpSolidIcon__WEBPACK_IMPORTED_MODULE_10__["default"], { style: 'primary' }),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null,
                      commentDiffLength, ' new ', _js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_12__["default"].pluralize({
                        count: commentDiffLength,
                        singular: 'comment',
                        plural: 'comments' }))),





                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'inline-comment__header-resolve' },
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
                        className: 'inline-comment-drawer__header-resolve',
                        type: 'text',
                        size: 'small',
                        onClick: this.onResolve }, 'Resolve'))),






                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_comments_CommentContainer__WEBPACK_IMPORTED_MODULE_7__["Comments"], _extends({},
                _.pick(this.state, ['updating', 'creating', 'deleting']), {
                  inlineComment: true,
                  data: cachedComments,
                  isAdmin: isAdmin,
                  isOffline: isOffline,
                  loading: loading,
                  loadError: loadError,
                  teamUsers: teamUsers,
                  teamUsersMap: teamUsersMap,
                  user: currentUser,
                  setListRef: this.setListRef,
                  inputDisabled: editor.isEntityUpdated,
                  commentRef: this.inlineCommentPopoverRef,
                  onClickOutside: this.handleClickOutside,
                  onClose: this.handleCommentClose,
                  onCommentCreate: this.handleCreate,
                  onCommentDelete: this.handleDelete,
                  onCommentUpdate: this.handleUpdate,
                  onUserClick: this.userClick,
                  hasError: this.state.hasError,
                  onRetry: this.handleRetry,
                  disableRetry: true })),

                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', { className: 'inline-comment__changes-badge-container' },

                  editor.isEntityUpdated &&
                  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
                      className: 'inline-comment__changes-badge',
                      onClick: this.handleRequestUpdate },

                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_RefreshIcon__WEBPACK_IMPORTED_MODULE_11__["default"], { style: 'primary' }),
                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', null, 'New changes made. View updated request.')))))))));











  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(61)))

/***/ })

}]);