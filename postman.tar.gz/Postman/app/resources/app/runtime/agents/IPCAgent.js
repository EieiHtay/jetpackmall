const { ipcMain } = require('electron');

/**
 * Agent interface to start listening and running
 */
function start (R, done) {
  ipcMain.on('runtime-ipc-command', (event, message) => {
    if (message.namespace === 'execution' && message.name === 'terminate') {
      R.stopRun(message.data.execution, (message) => {
        event.reply('runtime-ipc-event', message);
      });

      return;
    }

    if (message.name === 'execute') {
      R.startRun(message.data.info, message.data.collection, message.data.variables, message.data.options, (message) => {
        event.reply('runtime-ipc-event', message);
      });
      return;
    }

    if (message.namespace === 'execution' && message.name === 'pause') {
      R.pauseRun(message.data.execution, (message) => {
        event.reply('runtime-ipc-event', message);
      });
    }

    if (message.namespace === 'execution' && message.name === 'resume') {
      R.resumeRun(message.data.execution, (message) => {
        event.reply('runtime-ipc-event', message);
      });
    }

    if (message.namespace === 'attachListener' && message.name === 'cookies') {
      R.attachCookiesChangeListener(message.data.partitionId, () => {
        event.reply('runtime-ipc-listeners', { type: 'cookies', message: { event: 'changed' } });
      });
    }
  });

  ipcMain.handle('runtime-ipc-cb', async (e, event, fn, args) => {
    return new Promise((resolve) => {
      if (event === 'cookie') {
        return R.cookieHandler(fn, ...args, (err, result) => {
          resolve([err, result]);
        });
      }

      if (event === 'runtime' && fn === 'previewRequest') {
        return R.previewRequest(...args, (err, result) => {
          resolve([err, result]);
        });
      }

      if (event === 'files' && fn === 'create-temp') {
        return R.createTemporaryFile(...args, (err, tempFilePath) => {
          resolve([err, tempFilePath]);
        });
      }

      if (event === 'files' && fn === 'read') {
        return R.readFile(...args, (err, content) => {
          resolve([err, content]);
        });
      }

      if (event === 'files' && fn === 'access') {
        return R.accessFile(...args, (err) => {
          resolve([err]);
        });
      }

      if (event === 'files' && fn === 'saveResponse') {
        return R.saveStreamToFile(...args, (err, success) => {
          resolve([err, success]);
        });
      }

      return resolve([]);
    });
  });

  ipcMain.on('postman-runtime-ipc-sync', (event, fn, args) => {
    if (fn === 'isInWorkingDir') {
      return event.returnValue = R.isInWorkingDir(...args);
    }
  });

  pm.logger.info('RuntimeIPCAgent~started: Success');

  done && done();
}

module.exports = { start };
